<?php
include_once '../sys/inc/yadro.php';
$doc = new document(1);
$doc->title = __('Sizni taklif qilmoqda');

if (isset($_GET['gruppy']) && isset($_GET['admin'])) {

 if (mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_user` WHERE `admin` = '".$user->id."' AND `id_gruppa` = '".$_GET['gruppy']."' AND `admin` = '".$_GET['admin']."' AND `ak` = '3'"), 0)){
	 if(isset($_GET['och']) && isset($_GET['qoo'])){
$doc->err(__('Hakkerlik qilmang'));			 
	 }elseif(isset($_GET['qoo'])){
mysql_query("UPDATE `gruppa_user` SET `ak` = '1' WHERE `user` = '".$_GET['qoo']."' AND `admin` = '".$user->id."' AND `id_gruppa` = '".$_GET['gruppy']."' AND `admin` = '".$_GET['admin']."' AND `ak` = '3'");
$doc->msg(__('So`rov yo`llandi.'));
 }elseif(isset($_GET['och'])){
	 mysql_query("DELETE FROM `gruppa_user` WHERE `user` = '".$_GET['och']."' AND `admin` = '".$user->id."' AND `id_gruppa` = '".$_GET['gruppy']."' AND `admin` = '".$_GET['admin']."' AND `ak` = '3' ");	
$doc->err(__('Siz bu azoni gurpadan haydadingiz'));	 
 }
}else{
$doc->err(__('Siz Bu gurpada yo`qsiz yoki qo`shilgansiz.'));
}
}
$pages = new pages(mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_user` WHERE `admin` = '".$user->id."' AND `ak` = '3'"), 0));
$listing = new listing();
$q = mysql_query("SELECT * FROM `gruppa_user` WHERE `admin` = '".$user->id."' AND `ak` = '3' ORDER BY `time` DESC LIMIT ".$pages->limit);
while ($gruppa= mysql_fetch_assoc($q)) {
$gruppy = new user($gruppa['user']);
$voo = mysql_query("SELECT * FROM `gruppa` WHERE `id` = '".$gruppa['id_gruppa']."' LIMIT 1") ;
$grupp = mysql_fetch_object($voo);
$admine =  new user($gruppy->admin);
$kv = $listing->kv();
$kv->url = '/gruppa/?gruppy='.$grupp->id;
$kv->image = $gruppy ->getAva($doc->img_max_width());	
$kv->title = $gruppy->title;
$kv->mehmon = '<span style="font-size: 75%;"><a href="/gruppa/?gruppy='.$grupp->id.'">'.('Gurrupa nomi').' <b style="color: green;">( '.$grupp->nomi.' )</b></a></span>';
$kv->time = misc::when($gruppa['time']);
$kv->admine = ''.stsID($gruppy->id).'';
    $kv->action('delete', '?gruppy='.$gruppa['id_gruppa'].'&admin='.$grupp->admin.'&och='.$gruppy->id.'');
    $kv->action('nns', '');	
	$kv->action('create', '?gruppy='.$gruppa['id_gruppa'].'&admin='.$grupp->admin.'&qoo='.$gruppy->id.'');
	
 }
$listing->display(__('Ro`yhat bo`sh'));
$pages->this_page();
$pages->display('?');
$doc->grp(__('Gruppa ochish'), '/gruppa/?ocha');
$doc->grp(__('Mening gruppalarim'), '/gruppa/?mening='.$user->id.'');
$gurpaga_chaqiryapti = mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_user` WHERE `user` = '".$user->id."' AND `ak` = '2'"), 0);
if($gurpaga_chaqiryapti)$doc->dost(__('Sizni taklif qilmoqda %s', '<span class="strike_k">  '.$gurpaga_chaqiryapti.' </span>'), '/grup.html');
