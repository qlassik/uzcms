<?php
include_once '../sys/inc/yadro.php';
$doc = new document(1);
$doc->title = __('Sizni taklif qilmoqda');

if (isset($_GET['gruppy']) && isset($_GET['admin'])) {

 if (mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_user` WHERE `user` = '".$user->id."' AND `id_gruppa` = '".$_GET['gruppy']."' AND `admin` = '".$_GET['admin']."' AND `ak` = '2'"), 0)){
	 if(isset($_GET['och']) && isset($_GET['qoo'])){
$doc->err(__('Hakkerlik qilmang'));			 
	 }elseif(isset($_GET['qoo'])){
mysql_query("UPDATE `gruppa_user` SET `ak` = '1' WHERE `user` = '".$user->id."' AND `id_gruppa` = '".$_GET['gruppy']."' AND `admin` = '".$_GET['admin']."' AND `ak` = '2'");
$user->gruppa = $user->gruppa - 1;
$doc->msg(__('Qo`shildingiz.'));
 }elseif(isset($_GET['och'])){
	 mysql_query("DELETE FROM `gruppa_user` WHERE `user` = '".$user->id."' AND `id_gruppa` = '".$_GET['gruppy']."' AND `admin` = '".$_GET['admin']."' AND `ak` = '2' ");	
$user->gruppa = $user->gruppa - 1;
$doc->err(__('Gurpani sahifangizdan o`chirdingiz'));	 
 }
}else{
$doc->err(__('Siz Bu gurpada yo`qsiz yoki qo`shilgansiz.'));
}
}
$pages = new pages(mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_user` WHERE `user` = '".$user->id."' AND `ak` = '2'"), 0));
$listing = new listing();
$q = mysql_query("SELECT * FROM `gruppa_user` WHERE `user` = '".$user->id."' AND `ak` = '2' ORDER BY `time` DESC LIMIT ".$pages->limit);
while ($gruppa= mysql_fetch_assoc($q)) {
$gruppy = new user($gruppa['admin']);
$voo = mysql_query("SELECT * FROM `gruppa` WHERE `id` = '".$gruppa['id_gruppa']."' LIMIT 1") ;
$grupp = mysql_fetch_object($voo);
$admine =  new user($gruppy->admin);

$kv = $listing->kv();
$kv->url = '?gruppy='.$gruppa['id'];
if ($admine->rasim){
$kv->image = '/files/.gruppy/'.$admine->rasim;
}else{
$kv->image = $admine->getAva($doc->img_max_width());	
}
$kv->title = smiles(text::toOutput($grupp->nomi));
$kv->mehmon = '<a href="?gruppy='.$grupp->id.'&azolar" title="voo.uz"><span style="font-size: 75%;">'.('Do`stlar').' <b style="color: green;">( '.mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_user` WHERE `id_gruppa` = '".$gruppy->id."' AND `admin` = '".$grupp->admin."' AND `ak` = '1'"), 0).'</b> /  <b style="color: red;">'.mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_user` WHERE `id_gruppa` = '".$gruppy->id."' AND `admin` = '".$grupp->admin."' AND `ak` = '2'"), 0).')</b></span></a>';
$kv->time = misc::when($gruppa['time']);
if (md5(text::toOutput($gruppa['matn'])) == md5($gruppa['matn'])){
$kv->admine = smiles(text::toOutput($gruppa['matn']));	
}else{
$kv->admine = '<img style="" src="/img/music_disable.png" title="voo.uz" /> '.__('Multimediya qo`yilgan').'';
}
 
    $kv->action('delete', '?gruppy='.$gruppy->id.'&admin='.$grupp->admin.'&och='.$user->id.'');
    $kv->action('nns', '');	
	$kv->action('create', '?gruppy='.$gruppy->id.'&admin='.$grupp->admin.'&qoo='.$user->id.'');
	
 }
$listing->display(__('Ro`yhat bo`sh'));
$pages->this_page();
$pages->display('?');
$doc->grp(__('Gruppa ochish'), '/gruppa/?ocha');
$doc->grp(__('Mening gruppalarim'), '/gruppa/?mening='.$user->id.'');
$gurpamga_keldi = mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_user` WHERE `admin` = '".$user->id."' AND `ak` = '3'"), 0);
if($gurpamga_keldi)$doc->dost(__('Gurpaga do`slik keldi %s', '<span class="strike_k">  '.$gurpamga_keldi.' </span>'), '/grup_keldi.html');
