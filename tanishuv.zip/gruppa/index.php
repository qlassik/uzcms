<?php 
include_once '../sys/inc/yadro.php';
$doc = new document ();
$doc->title = __('GRUPPA');
if(isset($_GET['gruppy'])){
$doc->title = __('GRUPPA YARATISH');
$idvoo = (int) $_GET['gruppy'];
$voo = mysql_query("SELECT * FROM `gruppa` WHERE `id` = '$idvoo' LIMIT 1") ;
if(!mysql_num_rows($voo)){
header('Location: ?') ;
exit ;
}
$gruppy = mysql_fetch_object($voo) ;
if (isset($_GET ['qoo'])){
$shu = (empty($_GET ['qoo'])) ? $user : new user((int)$_GET ['qoo']);
}elseif (isset($_GET ['och'])){
$shu = (empty($_GET ['och'])) ? $user : new user((int)$_GET ['och']);
}else{
$shu = (empty($user->id)) ? $user : new user((int)$user->id);	
}
$admine =  new user($gruppy->admin);
If ($user->id == $admine->id);else{
$aktiv_b = mysql_query("SELECT * FROM `gruppa_user` WHERE `id_gruppa` = '$gruppy->id' AND `admin` = '$gruppy->admin' AND `user` = '$shu->id' AND `ak` = '1' LIMIT 1") ;

$ak_b = mysql_fetch_object($aktiv_b);
$noaktiv_b = mysql_query("SELECT * FROM `gruppa_user` WHERE `id_gruppa` = '$gruppy->id' AND `admin` = '$gruppy->admin' AND `user` = '$shu->id' AND `ak` = '2' LIMIT 1") ;
$noak_b = mysql_fetch_object($noaktiv_b);
$azoga_b = mysql_query("SELECT * FROM `gruppa_user` WHERE `id_gruppa` = '$gruppy->id' AND `admin` = '$gruppy->admin' AND `user` = '$shu->id' AND `ak` = '3' LIMIT 1") ;
$azo_b = mysql_fetch_object($azoga_b);
$aktiv =  new user(@$ak_b->user);
$aktivmas =  new user(@$noak_b->user);
$azo_bol =  new user(@$azo_b->user);
}
$gurpamga_kelganlar = mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_user` WHERE `id_gruppa` = '".$gruppy->id."' AND `ak` = '3'"), 0);
$gurpamga_kelib_kutyatkanlar = mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_user` WHERE `id_gruppa` = '".$gruppy->id."' AND `ak` = '2'"), 0);
$gurpamda_aktivlar = mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_user` WHERE `id_gruppa` = '".$gruppy->id."' AND `ak` = '1'"), 0);
$administrator = mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_admin` WHERE `id_gruppa` = '".$gruppy->id."'"), 0);
if($gruppy->fon){
	echo'<style>
#fonu{
    background: url("/files/.gruppy/'.$gruppy->fon.'") 100% 100% no-repeat;
    background-size: cover; 
}
</style>';
}else{
	echo'<style>
#fonu{
    background: url("/files/.gruppy/mask@2x.png");
}
</style>';
}

$doc->title = __('%s grupamizga xush kelibsiz', $gruppy->nomi);




















if (isset($_GET ['albom'])){

if (isset($_GET ['sozlashga'])){	

if(isset($_POST['papka']))
		{
		 mysql_query("UPDATE `gruppa_albom` SET  `papka` = '".$_POST['papka']."' WHERE `id`='".$_GET['sozlashga']."'");	
		header('Refresh: 1; url=?gruppy='.$gruppy->id.'&albom');
	
		exit;
		}

$qa = mysql_query("SELECT * FROM `gruppa_albom` WHERE `id`='".$_GET['sozlashga']."'  ORDER BY `id` DESC LIMIT 1");
while ($sma = mysql_fetch_assoc($qa)) {
$nomi = $sma['papka'];
} 


$listing = new listing();
$fv = new fv("?gruppy=".$gruppy->id."&albom=sozlashga&sozlashga=".$_GET['sozlashga']."&" . passgen());
$fv->input('papka', __('Bo`lim nomi'), $nomi);
$fv->button(__('O`zgartirish'), 'save', false);
$fv->display();
	
if ($user->id == $gruppy->admin){
$doc->dost(__('Rasim yuklash'), '?gruppy='.$gruppy->id.'&albom=yuk');		
$doc->grp(''.sm_icon(qlassik_ru('9')).' '.__('Azolar').'', '?gruppy='.$gruppy->id.'&azolar');		
$doc->grp(''.sm_icon(qlassik_ru('10')).' '.__('Foto biriktirish').'', '?gruppy='.$gruppy->id.'&surat');
$doc->grp(''.sm_icon(qlassik_ru('11')).' '.__('Ovoz biriktirish').'', '?gruppy='.$gruppy->id.'&ovoz');	
$doc->grp(''.sm_icon(qlassik_ru('12')).' '.__('Administrator qo`shish').'', '?gruppy='.$gruppy->id.'&admin');
$doc->grp(''.sm_icon(qlassik_ru('13')).' '.__('Sozlash').'', '?gruppy='.$gruppy->id.'&sozlash');
}else{
if($aktiv->id == $user->id){
if ($gruppy->zakrit == '1')$doc->grp(''.sm_icon(qlassik_ru('14')).' '.__('Do`stlar qo`shish').'', '?gruppy='.$gruppy->id.'&dostlar');		
$doc->grp(''.sm_icon(qlassik_ru('15')).' '.__('Gurpadan chiqish').'', '?gruppy='.$gruppy->id.'&chiqesh');
}else{
if(@$noak_b->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}elseif(@$azo_bol->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}else{
$doc->grp(''.sm_icon(qlassik_ru('17')).' '.__('Gurpaga qo`shilish').'', '?gruppy='.$gruppy->id.'&iltimos');
}
}	
}
$doc->grp(''.sm_icon(qlassik_ru('18')).' '.__('Qaytish').'', '?mening='.$gruppy->id.'');
$doc->grp(''.sm_icon(qlassik_ru('19')).' '.__('Gurpaga').'', '?gruppy='.$gruppy->id.'');

	
	exit;
}	
	
	
if (isset($_GET ['ochir_g_f'])){	
		$strker_path = FILES . '/.gruppy';
        $strker_dir = new files($strker_path);
if (!empty($_POST ['delete'])) {
        if (empty($_POST ['captcha']) || empty($_POST ['captcha_session']) || !captcha::check($_POST ['captcha'], $_POST ['captcha_session']))
            $doc->err(__('Raqam to`gri holatda kiritilmadi'));
        else {
		$result = mysql_query("SELECT * FROM `gruppa_albom` WHERE `id`='".$_GET['ochir_g_f']."' ");
        $myrow = mysql_fetch_array($result);  
        do   
       {  
       $nom = $myrow["rasim"];
       $strke = new files_file($strker_path, $nom);
       $strke->delete();
        
        mysql_query("DELETE FROM `gruppa_albom` WHERE `id`='".$_GET['ochir_g_f']."'  ");	
	
	}
	while ($myrow = mysql_fetch_array($result)); 
	}
	
	$doc->msg(__('O`chirildi'));
	header('Refresh: 1; url=?gruppy='.$gruppy->id.'&albom');
	exit;
    }  

	$fv = new fv("?gruppy=".$gruppy->id."&albom=ochir_g_f&ochir_g_f=".$_GET['ochir_g_f']."&" . passgen());
    $fv->captcha();
    $fv->button(__('Siz bu bo`limdi o`chirasizmi'), 'delete');
    $fv->display();


if ($user->id == $gruppy->admin){
$doc->dost(__('Rasim yuklash'), '?gruppy='.$gruppy->id.'&albom=yuk');		
$doc->grp(''.sm_icon(qlassik_ru('9')).' '.__('Azolar').'', '?gruppy='.$gruppy->id.'&azolar');		
$doc->grp(''.sm_icon(qlassik_ru('10')).' '.__('Foto biriktirish').'', '?gruppy='.$gruppy->id.'&surat');
$doc->grp(''.sm_icon(qlassik_ru('11')).' '.__('Ovoz biriktirish').'', '?gruppy='.$gruppy->id.'&ovoz');	
$doc->grp(''.sm_icon(qlassik_ru('12')).' '.__('Administrator qo`shish').'', '?gruppy='.$gruppy->id.'&admin');
$doc->grp(''.sm_icon(qlassik_ru('13')).' '.__('Sozlash').'', '?gruppy='.$gruppy->id.'&sozlash');
}else{
if($aktiv->id == $user->id){
if ($gruppy->zakrit == '1')$doc->grp(''.sm_icon(qlassik_ru('14')).' '.__('Do`stlar qo`shish').'', '?gruppy='.$gruppy->id.'&dostlar');		
$doc->grp(''.sm_icon(qlassik_ru('15')).' '.__('Gurpadan chiqish').'', '?gruppy='.$gruppy->id.'&chiqesh');
}else{
if(@$noak_b->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}elseif(@$azo_bol->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}else{
$doc->grp(''.sm_icon(qlassik_ru('17')).' '.__('Gurpaga qo`shilish').'', '?gruppy='.$gruppy->id.'&iltimos');
}
}	
}
$doc->grp(''.sm_icon(qlassik_ru('18')).' '.__('Qaytish').'', '?mening='.$gruppy->id.'');
$doc->grp(''.sm_icon(qlassik_ru('19')).' '.__('Gurpaga').'', '?gruppy='.$gruppy->id.'');

	
	exit;
}

 if($_GET['albom'] == 'yuk'){
$avatar_file_name = ''. TIME .'_albom.png';
$avatars_path = FILES . '/.gruppy'; 
$avatars_dir = new files($avatars_path);

 if (!isset($_SESSION['timess'] )){
	$_SESSION['timess'] = TIME - 2;
    }
   $sa = $_SESSION['timess'] ;
	if(TIME >= $sa && !empty($_FILES ['file'])) {
    if ($_FILES ['file'] ['error']) {
        $doc->err(__('Fayl yuklanmadi'));
    } elseif (!$_FILES ['file'] ['size']) {
        $doc->err(__('faylа yo`q'));
    } elseif(!preg_match("/\.(gif|png|jpg|GIF|PNG|JPG)$/", text::for_filename($_FILES ['file'] ['name']))){
        $doc->err(__('Rasim farmatda emas'));
    } elseif (!$img = @imagecreatefromjpeg($_FILES ['file'] ['tmp_name']) || !$img = @imagecreatefrompng($_FILES ['file'] ['tmp_name']) || !$img = @imagecreatefromgif($_FILES ['file'] ['tmp_name'])) {
        $doc->err(__('Rasim farmatda emas yoki @ simmollar yozilgan'));
    }else {
        if ($avatars_dir->is_file($avatar_file_name)) {
            $avatar = new files_file($avatars_path, $avatar_file_name);
            $avatar->delete(); 
        }

        if ($files_ok = $avatars_dir->filesAdd(array($_FILES ['file'] ['tmp_name'] => $avatar_file_name))) {
            $avatars_dir->group_show = 0;
            $files_ok [$_FILES ['file'] ['tmp_name']]->group_show = 0;
            $files_ok [$_FILES ['file'] ['tmp_name']]->id_user = $user->id;
            $files_ok [$_FILES ['file'] ['tmp_name']]->group_edit = max($user->group, 2);
     
        mysql_query("INSERT INTO `gruppa_albom` (`id_gruppa`, `admin`, `papka`, `rasim`, `time`) VALUES ('" . $gruppy->id. "', '" . $gruppy->admin . "','".$_POST['nomi']."', '".$avatar_file_name."', '"  . TIME .  "' )");
		$_SESSION['timess'] = TIME + 2;
	    unset($files_ok);
		 header('Refresh: 1; url=?gruppy='.$gruppy->id.'&albom');
       } else {
                $doc->err(__('Fayl yuklanmadi'));
        }
    }
}

$fv = new fv("?gruppy=".$gruppy->id."&albom=yuk&" . passgen());
$fv->text('nomi', __('Foto nomi').' (*.jpg  .gif .png)');
$fv->file('file', __('Foto').' (*.jpg  .gif .png)');
$fv->button(__('Yuklash'));
$fv->display();

 
	 
	 
	 
	 
	 
if ($user->id == $gruppy->admin){
$doc->dost(__('Rasim yuklash'), '?gruppy='.$gruppy->id.'&albom=yuk');		
$doc->grp(''.sm_icon(qlassik_ru('9')).' '.__('Azolar').'', '?gruppy='.$gruppy->id.'&azolar');		
$doc->grp(''.sm_icon(qlassik_ru('10')).' '.__('Foto biriktirish').'', '?gruppy='.$gruppy->id.'&surat');
$doc->grp(''.sm_icon(qlassik_ru('11')).' '.__('Ovoz biriktirish').'', '?gruppy='.$gruppy->id.'&ovoz');	
$doc->grp(''.sm_icon(qlassik_ru('12')).' '.__('Administrator qo`shish').'', '?gruppy='.$gruppy->id.'&admin');
$doc->grp(''.sm_icon(qlassik_ru('13')).' '.__('Sozlash').'', '?gruppy='.$gruppy->id.'&sozlash');
}else{
if($aktiv->id == $user->id){
if ($gruppy->zakrit == '1')$doc->grp(''.sm_icon(qlassik_ru('14')).' '.__('Do`stlar qo`shish').'', '?gruppy='.$gruppy->id.'&dostlar');		
$doc->grp(''.sm_icon(qlassik_ru('15')).' '.__('Gurpadan chiqish').'', '?gruppy='.$gruppy->id.'&chiqesh');
}else{
if(@$noak_b->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}elseif(@$azo_bol->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}else{
$doc->grp(''.sm_icon(qlassik_ru('17')).' '.__('Gurpaga qo`shilish').'', '?gruppy='.$gruppy->id.'&iltimos');
}
}	
}
$doc->grp(''.sm_icon(qlassik_ru('18')).' '.__('Qaytish').'', '?mening='.$gruppy->id.'');
$doc->grp(''.sm_icon(qlassik_ru('19')).' '.__('Gurpaga').'', '?gruppy='.$gruppy->id.'');

	
	exit;
}
	 
$pages = new pages(mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_albom` WHERE `id_gruppa` = '".$gruppy->id."' AND `admin` = '".$gruppy->admin."'"), 0));
$listing = new listing();
$q = mysql_query("SELECT * FROM `gruppa_albom` WHERE `id_gruppa` = '".$gruppy->id."' AND `admin` = '".$gruppy->admin."' ORDER BY `time` DESC LIMIT ".$pages->limit);
while ($p_user = mysql_fetch_assoc($q)) {
$fotos = $listing->fotos();
$fotos->image = '/files/.gruppy/'.$p_user['rasim'];
if ($user->id == $gruppy->admin){
$fotos->action('edit', '?gruppy='.$gruppy->id.'&albom=sozlashga&sozlashga='.$p_user['id'].'');
$fotos->action('nns', '');	
$fotos->action('delete', '?gruppy='.$gruppy->id.'&albom=ochir_g_f&ochir_g_f='.$p_user['id'].'');	
}
 }


$listing->display(__('Ro`yhat bo`sh'));
$pages->this_page();
$pages->display('?gruppy='.$gruppy->id.'&kitob');	
	










	
if ($user->id == $gruppy->admin){
$doc->dost(__('Rasim yuklash'), '?gruppy='.$gruppy->id.'&albom=yuk');		
$doc->grp(''.sm_icon(qlassik_ru('9')).' '.__('Azolar').'', '?gruppy='.$gruppy->id.'&azolar');		
$doc->grp(''.sm_icon(qlassik_ru('10')).' '.__('Foto biriktirish').'', '?gruppy='.$gruppy->id.'&surat');
$doc->grp(''.sm_icon(qlassik_ru('11')).' '.__('Ovoz biriktirish').'', '?gruppy='.$gruppy->id.'&ovoz');	
$doc->grp(''.sm_icon(qlassik_ru('12')).' '.__('Administrator qo`shish').'', '?gruppy='.$gruppy->id.'&admin');
$doc->grp(''.sm_icon(qlassik_ru('13')).' '.__('Sozlash').'', '?gruppy='.$gruppy->id.'&sozlash');
}else{
if($aktiv->id == $user->id){
if ($gruppy->zakrit == '1')$doc->grp(''.sm_icon(qlassik_ru('14')).' '.__('Do`stlar qo`shish').'', '?gruppy='.$gruppy->id.'&dostlar');		
$doc->grp(''.sm_icon(qlassik_ru('15')).' '.__('Gurpadan chiqish').'', '?gruppy='.$gruppy->id.'&chiqesh');
}else{
if(@$noak_b->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}elseif(@$azo_bol->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}else{
$doc->grp(''.sm_icon(qlassik_ru('17')).' '.__('Gurpaga qo`shilish').'', '?gruppy='.$gruppy->id.'&iltimos');
}
}	
}
$doc->grp(''.sm_icon(qlassik_ru('18')).' '.__('Qaytish').'', '?mening='.$gruppy->id.'');
$doc->grp(''.sm_icon(qlassik_ru('19')).' '.__('Gurpaga').'', '?gruppy='.$gruppy->id.'');

	
	exit;
}
























if (isset($_GET ['kitob'])){
$doc->title = __('%s grupa kitobi', $gruppy->nomi);
if ($_GET ['kitob'] == 'iddm'){	
	
$idee = (int) $_GET['iddm'];
$q = mysql_query("SELECT * FROM `gruppa_kitob` WHERE `id` = '".$idee."' AND `id_gruppa` = '".$gruppy->id."'");
if (!mysql_num_rows($q)) {
    header('Refresh: 1; url=./');
    $doc->err(__('Kitob ochmagan'));
    exit;
}
if (isset($_GET ['iddmb'])){
	
$saw = (int) $_GET['iddmb'];
$q = mysql_query("SELECT * FROM `gruppa_kitob_varaq` WHERE `id` = '".$saw."' AND `id_gruppa` = '".$gruppy->id."'");
if (!mysql_num_rows($q)) {
    header('Refresh: 1; url=./');
    $doc->err(__('Kitob ochmagan'));
    exit;
}


$listing = new listing();
$q = mysql_query("SELECT * FROM `gruppa_kitob_varaq` WHERE `id` = '".$saw."' AND `time_create` = '".$idee."' AND `id_gruppa` = '".$gruppy->id."' AND `admin` = '".$gruppy->admin."' ORDER BY `time` DESC LIMIT 1");
while ($p_user = mysql_fetch_assoc($q)) {
$kv = $listing->kv();
$kv->title = ' '.$p_user['nomi'].'  <span style="font-size: 85%; float:right; padding:5px; background:#f7f5f5;"> '.misc::when($p_user['time']).' </span><hr /> <center><div width="100%" style="font-size: 95%; float:center; padding:5px; background:#f7f5f5;">vv</div></center>';

 }
$listing->display(__('Ro`yhat bo`sh'));
	
	

	
	
	
	
	
	
	
	
	
	
	
	if ($user->id == $gruppy->admin){
$doc->dost(__('Sahifa yaratish'), '?gruppy='.$gruppy->id.'&kitob=iddm&iddm='.$idee.'&Sahifa=yaratisha');		

$doc->grp(''.sm_icon(qlassik_ru('9')).' '.__('Azolar').'', '?gruppy='.$gruppy->id.'&azolar');		
$doc->grp(''.sm_icon(qlassik_ru('10')).' '.__('Foto biriktirish').'', '?gruppy='.$gruppy->id.'&surat');
$doc->grp(''.sm_icon(qlassik_ru('11')).' '.__('Ovoz biriktirish').'', '?gruppy='.$gruppy->id.'&ovoz');	
$doc->grp(''.sm_icon(qlassik_ru('12')).' '.__('Administrator qo`shish').'', '?gruppy='.$gruppy->id.'&admin');
$doc->grp(''.sm_icon(qlassik_ru('13')).' '.__('Sozlash').'', '?gruppy='.$gruppy->id.'&sozlash');
}else{
if($aktiv->id == $user->id){
if ($gruppy->zakrit == '1')$doc->grp(''.sm_icon(qlassik_ru('14')).' '.__('Do`stlar qo`shish').'', '?gruppy='.$gruppy->id.'&dostlar');		
$doc->grp(''.sm_icon(qlassik_ru('15')).' '.__('Gurpadan chiqish').'', '?gruppy='.$gruppy->id.'&chiqesh');
}else{
if(@$noak_b->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}elseif(@$azo_bol->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}else{
$doc->grp(''.sm_icon(qlassik_ru('17')).' '.__('Gurpaga qo`shilish').'', '?gruppy='.$gruppy->id.'&iltimos');
}
}	
}
$doc->grp(''.sm_icon(qlassik_ru('18')).' '.__('Qaytish').'', '?mening='.$gruppy->id.'');
$doc->grp(''.sm_icon(qlassik_ru('19')).' '.__('Gurpaga').'', '?gruppy='.$gruppy->id.'');

	
	exit;
}	

if (isset($_GET ['Sahifa'])){
	
	
if ($user->id == $gruppy->admin && $_GET ['kitob'] == 'iddm' &&  $_GET ['iddm'] == ''.$_GET ['iddm'].''  && $_GET ['Sahifa'] == 'yaratisha'){	
if (isset($_POST['nomi'])) {
    $nomi = text::for_name($_POST['nomi']);
    $matn = text::input_text($_POST['matn']);
    if (!$nomi) {
        $doc->err(__('Kitob nomini kiritin'));
    } else {
        mysql_query("INSERT INTO `gruppa_kitob_varaq` (`id_gruppa`, `admin`, `time`, `nomi`, `matn`, `time_create`)
 VALUES ('" . $gruppy->id. "', '" . $gruppy->admin . "', '" . TIME . "', '" . my_esc($nomi) . "', '" . my_esc($matn) . "', '" . my_esc($idee) . "')");
  $doc->msg(__('Kitob yaratildi'));

        if (isset($_GET['return'])) {
           header('Refresh: 1; url=' . $_GET['return']);
        } else {
           header('Refresh: 1; url=?gruppy='.$gruppy->id.'&kitob=iddm&iddm='.$idee.'&' . SID);
        }

        exit;
    }
}
	
	
	
$form = new form("?gruppy=".$gruppy->id."&kitob=iddm&iddm=".$_GET ['iddm']."&Sahifa=".$_GET['Sahifa']."");
$form->text('nomi', __('Kitob nomi'));
$form->textarea('matn', __('Tafsif'));
$form->button(__('Kitob yaratish'));
$form->display();
	if ($user->id == $gruppy->admin){
$doc->dost(__('Kitob yaratish'), '?gruppy='.$gruppy->id.'&kitob=yaratish');		
$doc->grp(''.sm_icon(qlassik_ru('9')).' '.__('Azolar').'', '?gruppy='.$gruppy->id.'&azolar');		
$doc->grp(''.sm_icon(qlassik_ru('10')).' '.__('Foto biriktirish').'', '?gruppy='.$gruppy->id.'&surat');
$doc->grp(''.sm_icon(qlassik_ru('11')).' '.__('Ovoz biriktirish').'', '?gruppy='.$gruppy->id.'&ovoz');	
$doc->grp(''.sm_icon(qlassik_ru('12')).' '.__('Administrator qo`shish').'', '?gruppy='.$gruppy->id.'&admin');
$doc->grp(''.sm_icon(qlassik_ru('13')).' '.__('Sozlash').'', '?gruppy='.$gruppy->id.'&sozlash');
}else{
if($aktiv->id == $user->id){
if ($gruppy->zakrit == '1')$doc->grp(''.sm_icon(qlassik_ru('14')).' '.__('Do`stlar qo`shish').'', '?gruppy='.$gruppy->id.'&dostlar');		
$doc->grp(''.sm_icon(qlassik_ru('15')).' '.__('Gurpadan chiqish').'', '?gruppy='.$gruppy->id.'&chiqesh');
}else{
if(@$noak_b->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}elseif(@$azo_bol->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}else{
$doc->grp(''.sm_icon(qlassik_ru('17')).' '.__('Gurpaga qo`shilish').'', '?gruppy='.$gruppy->id.'&iltimos');
}
}	
}
$doc->grp(''.sm_icon(qlassik_ru('18')).' '.__('Qaytish').'', '?mening='.$gruppy->id.'');
$doc->grp(''.sm_icon(qlassik_ru('19')).' '.__('Gurpaga').'', '?gruppy='.$gruppy->id.'');
$doc->grp(''.sm_icon(qlassik_ru('19')).' '.__('kitobga').'', '?gruppy='.$gruppy->id.'&kitob');

	
	exit;	
}
	
	
if ($user->id == $gruppy->admin && $_GET ['kitob'] == 'iddm' &&  $_GET ['iddm'] == ''.$_GET ['iddm'].''  && $_GET ['Sahifa'] == 'sozlashgaa'){	
if (isset($_POST['nomi'])) {
    $nomi = text::for_name($_POST['nomi']);
    $matn = text::input_text($_POST['matn']);
    if (!$nomi) {
        $doc->err(__('Kitob nomini kiritin'));
    } else {
mysql_query("UPDATE `gruppa_kitob_varaq` SET `nomi` = '" . my_esc($nomi) . "', `matn` = '" . my_esc($matn) . "'  WHERE `id_gruppa` = '".$gruppy->id."'  AND `id` = '".$_GET['sozlashgaa']."' LIMIT 1");
        
  $doc->msg(__('O`zgartirildi'));

        if (isset($_GET['return'])) {
           header('Refresh: 1; url=' . $_GET['return']);
        } else {
           header('Refresh: 1; url=?gruppy='.$gruppy->id.'&kitob=iddm&iddm='.$_GET ['iddm'].'&' . SID);
        }

        exit;
    }
}
	
$q = mysql_query("SELECT * FROM `gruppa_kitob_varaq` WHERE `id` = '".$_GET['sozlashgaa']."'");

if (!mysql_num_rows($q)) {
    header('Refresh: 1; url=./');
    $doc->err(__('Kitob mavzu yoq'));
    exit;
}

$topic = mysql_fetch_assoc($q);

$form = new form("?gruppy=".$gruppy->id."&kitob=iddm&iddm=".$_GET ['iddm']."&Sahifa=sozlashgaa&sozlashgaa=".$_GET['sozlashgaa']."");
$form->text('nomi', __('Kitob nomi'), $topic['nomi']);
$form->textarea('matn', __('Tafsif'), $topic['matn']);
$form->button(__('Kitobni o`zgartirish'));
$form->display();
	if ($user->id == $gruppy->admin){
$doc->dost(__('Kitob yaratish'), '?gruppy='.$gruppy->id.'&kitob=yaratish');		
$doc->grp(''.sm_icon(qlassik_ru('9')).' '.__('Azolar').'', '?gruppy='.$gruppy->id.'&azolar');		
$doc->grp(''.sm_icon(qlassik_ru('10')).' '.__('Foto biriktirish').'', '?gruppy='.$gruppy->id.'&surat');
$doc->grp(''.sm_icon(qlassik_ru('11')).' '.__('Ovoz biriktirish').'', '?gruppy='.$gruppy->id.'&ovoz');	
$doc->grp(''.sm_icon(qlassik_ru('12')).' '.__('Administrator qo`shish').'', '?gruppy='.$gruppy->id.'&admin');
$doc->grp(''.sm_icon(qlassik_ru('13')).' '.__('Sozlash').'', '?gruppy='.$gruppy->id.'&sozlash');
}else{
if($aktiv->id == $user->id){
if ($gruppy->zakrit == '1')$doc->grp(''.sm_icon(qlassik_ru('14')).' '.__('Do`stlar qo`shish').'', '?gruppy='.$gruppy->id.'&dostlar');		
$doc->grp(''.sm_icon(qlassik_ru('15')).' '.__('Gurpadan chiqish').'', '?gruppy='.$gruppy->id.'&chiqesh');
}else{
if(@$noak_b->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}elseif(@$azo_bol->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}else{
$doc->grp(''.sm_icon(qlassik_ru('17')).' '.__('Gurpaga qo`shilish').'', '?gruppy='.$gruppy->id.'&iltimos');
}
}	
}
$doc->grp(''.sm_icon(qlassik_ru('18')).' '.__('Qaytish').'', '?mening='.$gruppy->id.'');
$doc->grp(''.sm_icon(qlassik_ru('19')).' '.__('Gurpaga').'', '?gruppy='.$gruppy->id.'');
$doc->grp(''.sm_icon(qlassik_ru('19')).' '.__('kitobga').'', '?gruppy='.$gruppy->id.'&kitob');

	
	exit;	
}
	
	
if ($user->id == $gruppy->admin && $_GET ['kitob'] == 'iddm' &&  $_GET ['iddm'] == ''.$_GET ['iddm'].''  && $_GET ['Sahifa'] == 'ochir_g_fa'){	
	
	
if (isset($_POST['delete'])) {
    if (empty($_POST['captcha']) || empty($_POST['captcha_session']) || !captcha::check($_POST['captcha'], $_POST['captcha_session'])) {
        $doc->err(__('Raqam to`gri holatda kiritilmadi'));
    } else {
       
mysql_query("DELETE FROM `gruppa_kitob_varaq` WHERE `admin` ='".$gruppy->admin."' AND `id` = '".$_GET['ochir_g_fa']."' LIMIT 1");
$doc->err(__('O`chirildi'));
header('Refresh: 1; url=?gruppy='.$gruppy->id.'&kitob=iddm&iddm='.$_GET ['iddm'].'');
        exit;
    }
}

$form = new form("?gruppy=".$gruppy->id."&kitob=iddm&iddm=".$_GET ['iddm']."&Sahifa=ochir_g_fa&ochir_g_fa=".$_GET['ochir_g_fa']."");
$form->captcha();
$form->button(__('O`chirish'), 'delete');
$form->display();
	if ($user->id == $gruppy->admin){
$doc->dost(__('Kitob yaratish'), '?gruppy='.$gruppy->id.'&kitob=yaratish');		
$doc->grp(''.sm_icon(qlassik_ru('9')).' '.__('Azolar').'', '?gruppy='.$gruppy->id.'&azolar');		
$doc->grp(''.sm_icon(qlassik_ru('10')).' '.__('Foto biriktirish').'', '?gruppy='.$gruppy->id.'&surat');
$doc->grp(''.sm_icon(qlassik_ru('11')).' '.__('Ovoz biriktirish').'', '?gruppy='.$gruppy->id.'&ovoz');	
$doc->grp(''.sm_icon(qlassik_ru('12')).' '.__('Administrator qo`shish').'', '?gruppy='.$gruppy->id.'&admin');
$doc->grp(''.sm_icon(qlassik_ru('13')).' '.__('Sozlash').'', '?gruppy='.$gruppy->id.'&sozlash');
}else{
if($aktiv->id == $user->id){
if ($gruppy->zakrit == '1')$doc->grp(''.sm_icon(qlassik_ru('14')).' '.__('Do`stlar qo`shish').'', '?gruppy='.$gruppy->id.'&dostlar');		
$doc->grp(''.sm_icon(qlassik_ru('15')).' '.__('Gurpadan chiqish').'', '?gruppy='.$gruppy->id.'&chiqesh');
}else{
if(@$noak_b->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}elseif(@$azo_bol->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}else{
$doc->grp(''.sm_icon(qlassik_ru('17')).' '.__('Gurpaga qo`shilish').'', '?gruppy='.$gruppy->id.'&iltimos');
}
}	
}
$doc->grp(''.sm_icon(qlassik_ru('18')).' '.__('Qaytish').'', '?mening='.$gruppy->id.'');
$doc->grp(''.sm_icon(qlassik_ru('19')).' '.__('Gurpaga').'', '?gruppy='.$gruppy->id.'');
$doc->grp(''.sm_icon(qlassik_ru('19')).' '.__('kitobga').'', '?gruppy='.$gruppy->id.'&kitob');

	
	exit;	
}
	
}



	
	
$pages = new pages(mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_kitob_varaq` WHERE `time_create` = '".$idee."' AND `id_gruppa` = '".$gruppy->id."' AND `admin` = '".$gruppy->admin."'"), 0));
$listing = new listing();
$q = mysql_query("SELECT * FROM `gruppa_kitob_varaq` WHERE `time_create` = '".$idee."' AND `id_gruppa` = '".$gruppy->id."' AND `admin` = '".$gruppy->admin."' ORDER BY `time` DESC LIMIT ".$pages->limit);
while ($p_user = mysql_fetch_assoc($q)) {
$kv = $listing->kv();
$kv->url = '?gruppy='.$gruppy->id.'&kitob&iddm='.$idee.'&iddmm='.$p_user['id'].'';
$kv->title = ''.sm_icon(qlassik_ru('24')).' '.$p_user['nomi'];
$kv->url = '?gruppy='.$gruppy->id.'&kitob=iddm&iddm='.$idee.'&iddmb='.$p_user['id'].'';
if ($user->id == $gruppy->admin){
$kv->action('edit', '?gruppy='.$gruppy->id.'&kitob=iddm&iddm='.$idee.'&Sahifa=sozlashgaa&sozlashgaa='.$p_user['id'].'');
$kv->action('nns', '');	
$kv->action('delete', '?gruppy='.$gruppy->id.'&kitob=iddm&iddm='.$idee.'&Sahifa=ochir_g_fa&ochir_g_fa='.$p_user['id'].'');
}
 }


$listing->display(__('Ro`yhat bo`sh'));
$pages->this_page();
$pages->display('?gruppy='.$gruppy->id.'&kitob=iddm&iddm='.$idee.'');	
	
	
	

	
	
	
	
	
	
	
	
	
	
	
	if ($user->id == $gruppy->admin){
$doc->dost(__('Sahifa yaratish'), '?gruppy='.$gruppy->id.'&kitob=iddm&iddm='.$idee.'&Sahifa=yaratisha');		

$doc->grp(''.sm_icon(qlassik_ru('9')).' '.__('Azolar').'', '?gruppy='.$gruppy->id.'&azolar');		
$doc->grp(''.sm_icon(qlassik_ru('10')).' '.__('Foto biriktirish').'', '?gruppy='.$gruppy->id.'&surat');
$doc->grp(''.sm_icon(qlassik_ru('11')).' '.__('Ovoz biriktirish').'', '?gruppy='.$gruppy->id.'&ovoz');	
$doc->grp(''.sm_icon(qlassik_ru('12')).' '.__('Administrator qo`shish').'', '?gruppy='.$gruppy->id.'&admin');
$doc->grp(''.sm_icon(qlassik_ru('13')).' '.__('Sozlash').'', '?gruppy='.$gruppy->id.'&sozlash');
}else{
if($aktiv->id == $user->id){
if ($gruppy->zakrit == '1')$doc->grp(''.sm_icon(qlassik_ru('14')).' '.__('Do`stlar qo`shish').'', '?gruppy='.$gruppy->id.'&dostlar');		
$doc->grp(''.sm_icon(qlassik_ru('15')).' '.__('Gurpadan chiqish').'', '?gruppy='.$gruppy->id.'&chiqesh');
}else{
if(@$noak_b->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}elseif(@$azo_bol->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}else{
$doc->grp(''.sm_icon(qlassik_ru('17')).' '.__('Gurpaga qo`shilish').'', '?gruppy='.$gruppy->id.'&iltimos');
}
}	
}
$doc->grp(''.sm_icon(qlassik_ru('18')).' '.__('Qaytish').'', '?mening='.$gruppy->id.'');
$doc->grp(''.sm_icon(qlassik_ru('19')).' '.__('Gurpaga').'', '?gruppy='.$gruppy->id.'');

	
	exit;	
}
	

if ($user->id == $gruppy->admin && $_GET ['kitob'] == 'yaratish'){	
if (isset($_POST['nomi'])) {
    $nomi = text::for_name($_POST['nomi']);
    if (!$nomi) {
        $doc->err(__('Kitob nomini kiritin'));
    } else {
        mysql_query("INSERT INTO `gruppa_kitob` (`id_gruppa`, `admin`, `time`, `nomi`)
 VALUES ('" . $gruppy->id. "', '" . $gruppy->admin . "', '" . TIME . "', '" . my_esc($nomi) . "')");
  $doc->msg(__('Kitob yaratildi'));

        if (isset($_GET['return'])) {
           header('Refresh: 1; url=' . $_GET['return']);
        } else {
           header('Refresh: 1; url=?gruppy='.$gruppy->id.'&kitob&' . SID);
        }

        exit;
    }
}
	
	
	
	
$form = new form("?gruppy=".$gruppy->id."&kitob=yaratish");
$form->text('nomi', __('Kitob nomi'));
$form->button(__('Kitob yaratish'));
$form->display();
	if ($user->id == $gruppy->admin){
$doc->dost(__('Kitob yaratish'), '?gruppy='.$gruppy->id.'&kitob=yaratish');		
$doc->grp(''.sm_icon(qlassik_ru('9')).' '.__('Azolar').'', '?gruppy='.$gruppy->id.'&azolar');		
$doc->grp(''.sm_icon(qlassik_ru('10')).' '.__('Foto biriktirish').'', '?gruppy='.$gruppy->id.'&surat');
$doc->grp(''.sm_icon(qlassik_ru('11')).' '.__('Ovoz biriktirish').'', '?gruppy='.$gruppy->id.'&ovoz');	
$doc->grp(''.sm_icon(qlassik_ru('12')).' '.__('Administrator qo`shish').'', '?gruppy='.$gruppy->id.'&admin');
$doc->grp(''.sm_icon(qlassik_ru('13')).' '.__('Sozlash').'', '?gruppy='.$gruppy->id.'&sozlash');
}else{
if($aktiv->id == $user->id){
if ($gruppy->zakrit == '1')$doc->grp(''.sm_icon(qlassik_ru('14')).' '.__('Do`stlar qo`shish').'', '?gruppy='.$gruppy->id.'&dostlar');		
$doc->grp(''.sm_icon(qlassik_ru('15')).' '.__('Gurpadan chiqish').'', '?gruppy='.$gruppy->id.'&chiqesh');
}else{
if(@$noak_b->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}elseif(@$azo_bol->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}else{
$doc->grp(''.sm_icon(qlassik_ru('17')).' '.__('Gurpaga qo`shilish').'', '?gruppy='.$gruppy->id.'&iltimos');
}
}	
}
$doc->grp(''.sm_icon(qlassik_ru('18')).' '.__('Qaytish').'', '?mening='.$gruppy->id.'');
$doc->grp(''.sm_icon(qlassik_ru('19')).' '.__('Gurpaga').'', '?gruppy='.$gruppy->id.'');
$doc->grp(''.sm_icon(qlassik_ru('19')).' '.__('kitobga').'', '?gruppy='.$gruppy->id.'&kitob');

	
	exit;	
}
	
	
if ($user->id == $gruppy->admin && $_GET ['kitob'] == 'sozlashga'){	
if (isset($_POST['nomi'])) {
    $nomi = text::for_name($_POST['nomi']);
    if (!$nomi) {
        $doc->err(__('Kitob nomini kiritin'));
    } else {
mysql_query("UPDATE `gruppa_kitob` SET `nomi` = '" . my_esc($nomi) . "'  WHERE `id_gruppa` = '".$gruppy->id."'  AND `id` = '".$_GET['sozlashga']."' LIMIT 1");
        
  $doc->msg(__('Kitob sozlandi'));

        if (isset($_GET['return'])) {
           header('Refresh: 1; url=' . $_GET['return']);
        } else {
           header('Refresh: 1; url=?gruppy='.$gruppy->id.'&kitob&' . SID);
        }

        exit;
    }
}
	
$q = mysql_query("SELECT * FROM `gruppa_kitob` WHERE `id` = '".$_GET['sozlashga']."'");

if (!mysql_num_rows($q)) {
    header('Refresh: 1; url=./');
    $doc->err(__('Kitob joylashmagan'));
    exit;
}

$topic = mysql_fetch_assoc($q);

	
$form = new form("?gruppy=".$gruppy->id."&kitob=sozlashga&sozlashga=".$_GET['sozlashga']."");	
$form->text('nomi', __('Kitob nomi'), $topic['nomi']);
$form->button(__('Kitobni o`zgartirish'));
$form->display();
	if ($user->id == $gruppy->admin){
$doc->dost(__('Kitob yaratish'), '?gruppy='.$gruppy->id.'&kitob=yaratish');		
$doc->grp(''.sm_icon(qlassik_ru('9')).' '.__('Azolar').'', '?gruppy='.$gruppy->id.'&azolar');		
$doc->grp(''.sm_icon(qlassik_ru('10')).' '.__('Foto biriktirish').'', '?gruppy='.$gruppy->id.'&surat');
$doc->grp(''.sm_icon(qlassik_ru('11')).' '.__('Ovoz biriktirish').'', '?gruppy='.$gruppy->id.'&ovoz');	
$doc->grp(''.sm_icon(qlassik_ru('12')).' '.__('Administrator qo`shish').'', '?gruppy='.$gruppy->id.'&admin');
$doc->grp(''.sm_icon(qlassik_ru('13')).' '.__('Sozlash').'', '?gruppy='.$gruppy->id.'&sozlash');
}else{
if($aktiv->id == $user->id){
if ($gruppy->zakrit == '1')$doc->grp(''.sm_icon(qlassik_ru('14')).' '.__('Do`stlar qo`shish').'', '?gruppy='.$gruppy->id.'&dostlar');		
$doc->grp(''.sm_icon(qlassik_ru('15')).' '.__('Gurpadan chiqish').'', '?gruppy='.$gruppy->id.'&chiqesh');
}else{
if(@$noak_b->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}elseif(@$azo_bol->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}else{
$doc->grp(''.sm_icon(qlassik_ru('17')).' '.__('Gurpaga qo`shilish').'', '?gruppy='.$gruppy->id.'&iltimos');
}
}	
}
$doc->grp(''.sm_icon(qlassik_ru('18')).' '.__('Qaytish').'', '?mening='.$gruppy->id.'');
$doc->grp(''.sm_icon(qlassik_ru('19')).' '.__('Gurpaga').'', '?gruppy='.$gruppy->id.'');
$doc->grp(''.sm_icon(qlassik_ru('19')).' '.__('kitobga').'', '?gruppy='.$gruppy->id.'&kitob');

	
	exit;	
}
	
	
if ($user->id == $gruppy->admin && $_GET ['kitob'] == 'ochir_g_f'){	
	
	
if (isset($_POST['delete'])) {
    if (empty($_POST['captcha']) || empty($_POST['captcha_session']) || !captcha::check($_POST['captcha'], $_POST['captcha_session'])) {
        $doc->err(__('Raqam to`gri holatda kiritilmadi'));
    } else {
        $q = mysql_query("SELECT `id` FROM `gruppa_kitob_varaq` WHERE `id_topic` = '$topic[id]'");
        while ($theme = mysql_fetch_assoc($q)) {
            $dir = new files(FILES . '/.kitob/' . $theme['id']);
            $dir->delete();
            unset($dir);
        }
mysql_query("DELETE FROM `gruppa_kitob` WHERE  `admin` ='".$gruppy->admin."' AND  `id` = '".$_GET['ochir_g_f']."' LIMIT 1");
$doc->msg(__('Kitob o`chirildi'));
        exit;
    }
}



$form = new form("?gruppy=".$gruppy->id."&kitob=ochir_g_f&ochir_g_f=".$_GET['ochir_g_f']."");
$form->captcha();
$form->button(__('O`chirish'), 'delete');
$form->display();
	if ($user->id == $gruppy->admin){
$doc->dost(__('Kitob yaratish'), '?gruppy='.$gruppy->id.'&kitob=yaratish');		
$doc->grp(''.sm_icon(qlassik_ru('9')).' '.__('Azolar').'', '?gruppy='.$gruppy->id.'&azolar');		
$doc->grp(''.sm_icon(qlassik_ru('10')).' '.__('Foto biriktirish').'', '?gruppy='.$gruppy->id.'&surat');
$doc->grp(''.sm_icon(qlassik_ru('11')).' '.__('Ovoz biriktirish').'', '?gruppy='.$gruppy->id.'&ovoz');	
$doc->grp(''.sm_icon(qlassik_ru('12')).' '.__('Administrator qo`shish').'', '?gruppy='.$gruppy->id.'&admin');
$doc->grp(''.sm_icon(qlassik_ru('13')).' '.__('Sozlash').'', '?gruppy='.$gruppy->id.'&sozlash');
}else{
if($aktiv->id == $user->id){
if ($gruppy->zakrit == '1')$doc->grp(''.sm_icon(qlassik_ru('14')).' '.__('Do`stlar qo`shish').'', '?gruppy='.$gruppy->id.'&dostlar');		
$doc->grp(''.sm_icon(qlassik_ru('15')).' '.__('Gurpadan chiqish').'', '?gruppy='.$gruppy->id.'&chiqesh');
}else{
if(@$noak_b->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}elseif(@$azo_bol->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}else{
$doc->grp(''.sm_icon(qlassik_ru('17')).' '.__('Gurpaga qo`shilish').'', '?gruppy='.$gruppy->id.'&iltimos');
}
}	
}
$doc->grp(''.sm_icon(qlassik_ru('18')).' '.__('Qaytish').'', '?mening='.$gruppy->id.'');
$doc->grp(''.sm_icon(qlassik_ru('19')).' '.__('Gurpaga').'', '?gruppy='.$gruppy->id.'');
$doc->grp(''.sm_icon(qlassik_ru('19')).' '.__('kitobga').'', '?gruppy='.$gruppy->id.'&kitob');

	
	exit;	
}
	
	
$pages = new pages(mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_kitob` WHERE `id_gruppa` = '".$gruppy->id."' AND `admin` = '".$gruppy->admin."'"), 0));
$listing = new listing();
$q = mysql_query("SELECT * FROM `gruppa_kitob` WHERE `id_gruppa` = '".$gruppy->id."' AND `admin` = '".$gruppy->admin."' ORDER BY `time` DESC LIMIT ".$pages->limit);
while ($p_user = mysql_fetch_assoc($q)) {
$kv = $listing->kv();
$kv->url = '?gruppy='.$gruppy->id.'&kitob&iddm='.$p_user['id'].'';
$kv->title = ''.sm_icon(qlassik_ru('24')).' '.$p_user['nomi'];
$kv->url = '?gruppy='.$gruppy->id.'&kitob=iddm&iddm='.$p_user['id'].'';
if ($user->id == $gruppy->admin){
$kv->action('edit', '?gruppy='.$gruppy->id.'&kitob=sozlashga&sozlashga='.$p_user['id'].'');
$kv->action('nns', '');	
$kv->action('delete', '?gruppy='.$gruppy->id.'&kitob=ochir_g_f&ochir_g_f='.$p_user['id'].'');	
}
 }


$listing->display(__('Ro`yhat bo`sh'));
$pages->this_page();
$pages->display('?gruppy='.$gruppy->id.'&kitob');	
	
	
	

	
	
	
	
	
	
	
	
	
	
	
	if ($user->id == $gruppy->admin){
$doc->dost(__('Kitob yaratish'), '?gruppy='.$gruppy->id.'&kitob=yaratish');		
$doc->grp(''.sm_icon(qlassik_ru('9')).' '.__('Azolar').'', '?gruppy='.$gruppy->id.'&azolar');		
$doc->grp(''.sm_icon(qlassik_ru('10')).' '.__('Foto biriktirish').'', '?gruppy='.$gruppy->id.'&surat');
$doc->grp(''.sm_icon(qlassik_ru('11')).' '.__('Ovoz biriktirish').'', '?gruppy='.$gruppy->id.'&ovoz');	
$doc->grp(''.sm_icon(qlassik_ru('12')).' '.__('Administrator qo`shish').'', '?gruppy='.$gruppy->id.'&admin');
$doc->grp(''.sm_icon(qlassik_ru('13')).' '.__('Sozlash').'', '?gruppy='.$gruppy->id.'&sozlash');
}else{
if($aktiv->id == $user->id){
if ($gruppy->zakrit == '1')$doc->grp(''.sm_icon(qlassik_ru('14')).' '.__('Do`stlar qo`shish').'', '?gruppy='.$gruppy->id.'&dostlar');		
$doc->grp(''.sm_icon(qlassik_ru('15')).' '.__('Gurpadan chiqish').'', '?gruppy='.$gruppy->id.'&chiqesh');
}else{
if(@$noak_b->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}elseif(@$azo_bol->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}else{
$doc->grp(''.sm_icon(qlassik_ru('17')).' '.__('Gurpaga qo`shilish').'', '?gruppy='.$gruppy->id.'&iltimos');
}
}	
}
$doc->grp(''.sm_icon(qlassik_ru('18')).' '.__('Qaytish').'', '?mening='.$gruppy->id.'');
$doc->grp(''.sm_icon(qlassik_ru('19')).' '.__('Gurpaga').'', '?gruppy='.$gruppy->id.'');

	
	exit;		
}





if (isset($_GET ['forum'])){
$doc->title = __('%s grupa forumi', $gruppy->nomi);
if ($_GET ['forum'] == 'idm'){	
	
$idee = (int) $_GET['idm'];
$q = mysql_query("SELECT * FROM `forum_topics` WHERE `id` = '".$idee."' AND `id_gruppa` = '".$gruppy->id."'");
if (!mysql_num_rows($q)) {
    header('Refresh: 1; url=./');
    $doc->err(__('Bo`lim ochmagan'));
    exit;
}
if (isset($_GET ['idmb'])){
	
$saw = (int) $_GET['idmb'];
$q = mysql_query("SELECT * FROM `forum_themes` WHERE `id` = '".$saw."' AND `id_gruppa` = '".$gruppy->id."'");
if (!mysql_num_rows($q)) {
    header('Refresh: 1; url=./');
    $doc->err(__('Bo`lim ochmagan'));
    exit;
}


$listing = new listing();
$q = mysql_query("SELECT * FROM `forum_themes` WHERE `id` = '".$saw."' AND `time_create` = '".$idee."' AND `id_gruppa` = '".$gruppy->id."' AND `admin` = '".$gruppy->admin."' ORDER BY `time` DESC LIMIT 1");
while ($p_user = mysql_fetch_assoc($q)) {
$kv = $listing->kv();
$kv->title = ' '.$p_user['name'].'  <span style="font-size: 85%; float:right; padding:5px; background:#f7f5f5;"> '.misc::when($p_user['time']).' </span><hr /> <center><div width="100%" style="font-size: 95%; float:center; padding:5px; background:#f7f5f5;">vv</div></center>';

 }
$listing->display(__('Ro`yhat bo`sh'));
	
	

	
	
	
	
	
	
	
	
	
	
	
	if ($user->id == $gruppy->admin){
$doc->dost(__('Lavha yaratish'), '?gruppy='.$gruppy->id.'&forum=idm&idm='.$idee.'&lavha=yaratisha');		

$doc->grp(''.sm_icon(qlassik_ru('9')).' '.__('Azolar').'', '?gruppy='.$gruppy->id.'&azolar');		
$doc->grp(''.sm_icon(qlassik_ru('10')).' '.__('Foto biriktirish').'', '?gruppy='.$gruppy->id.'&surat');
$doc->grp(''.sm_icon(qlassik_ru('11')).' '.__('Ovoz biriktirish').'', '?gruppy='.$gruppy->id.'&ovoz');	
$doc->grp(''.sm_icon(qlassik_ru('12')).' '.__('Administrator qo`shish').'', '?gruppy='.$gruppy->id.'&admin');
$doc->grp(''.sm_icon(qlassik_ru('13')).' '.__('Sozlash').'', '?gruppy='.$gruppy->id.'&sozlash');
}else{
if($aktiv->id == $user->id){
if ($gruppy->zakrit == '1')$doc->grp(''.sm_icon(qlassik_ru('14')).' '.__('Do`stlar qo`shish').'', '?gruppy='.$gruppy->id.'&dostlar');		
$doc->grp(''.sm_icon(qlassik_ru('15')).' '.__('Gurpadan chiqish').'', '?gruppy='.$gruppy->id.'&chiqesh');
}else{
if(@$noak_b->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}elseif(@$azo_bol->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}else{
$doc->grp(''.sm_icon(qlassik_ru('17')).' '.__('Gurpaga qo`shilish').'', '?gruppy='.$gruppy->id.'&iltimos');
}
}	
}
$doc->grp(''.sm_icon(qlassik_ru('18')).' '.__('Qaytish').'', '?mening='.$gruppy->id.'');
$doc->grp(''.sm_icon(qlassik_ru('19')).' '.__('Gurpaga').'', '?gruppy='.$gruppy->id.'');

	
	exit;
}	

if (isset($_GET ['lavha'])){
	
	
if ($user->id == $gruppy->admin && $_GET ['forum'] == 'idm' &&  $_GET ['idm'] == ''.$_GET ['idm'].''  && $_GET ['lavha'] == 'yaratisha'){	
if (isset($_POST['name'])) {
    $name = text::for_name($_POST['name']);
    $matn = text::input_text($_POST['matn']);
    if (!$name) {
        $doc->err(__('Bo`lim nomini kiritin'));
    } else {
        mysql_query("INSERT INTO `forum_themes` (`id_gruppa`, `admin`, `time`, `name`, `matn`, `time_create`, `group_show`, `group_write`, `group_edit`)
 VALUES ('" . $gruppy->id. "', '" . $gruppy->admin . "', '" . TIME . "', '" . my_esc($name) . "', '" . my_esc($matn) . "', '" . my_esc($idee) . "', '".$gruppy->group_show."', '".$gruppy->group_write . "', '" . $gruppy->group_edit . "')");
  $doc->msg(__('bo`lim yaratildi'));

        if (isset($_GET['return'])) {
           header('Refresh: 1; url=' . $_GET['return']);
        } else {
           header('Refresh: 1; url=?gruppy='.$gruppy->id.'&forum=idm&idm='.$idee.'&' . SID);
        }

        exit;
    }
}
	
	
	
$form = new form("?gruppy=".$gruppy->id."&forum=idm&idm=".$_GET ['idm']."&lavha=".$_GET['lavha']."");
$form->text('name', __('Bo`lim nomi'));
$form->textarea('matn', __('Tafsif'));
$form->button(__('Bo`lim yaratish'));
$form->display();
	if ($user->id == $gruppy->admin){
$doc->dost(__('Bo`lim yaratish'), '?gruppy='.$gruppy->id.'&forum=yaratish');		
$doc->grp(''.sm_icon(qlassik_ru('9')).' '.__('Azolar').'', '?gruppy='.$gruppy->id.'&azolar');		
$doc->grp(''.sm_icon(qlassik_ru('10')).' '.__('Foto biriktirish').'', '?gruppy='.$gruppy->id.'&surat');
$doc->grp(''.sm_icon(qlassik_ru('11')).' '.__('Ovoz biriktirish').'', '?gruppy='.$gruppy->id.'&ovoz');	
$doc->grp(''.sm_icon(qlassik_ru('12')).' '.__('Administrator qo`shish').'', '?gruppy='.$gruppy->id.'&admin');
$doc->grp(''.sm_icon(qlassik_ru('13')).' '.__('Sozlash').'', '?gruppy='.$gruppy->id.'&sozlash');
}else{
if($aktiv->id == $user->id){
if ($gruppy->zakrit == '1')$doc->grp(''.sm_icon(qlassik_ru('14')).' '.__('Do`stlar qo`shish').'', '?gruppy='.$gruppy->id.'&dostlar');		
$doc->grp(''.sm_icon(qlassik_ru('15')).' '.__('Gurpadan chiqish').'', '?gruppy='.$gruppy->id.'&chiqesh');
}else{
if(@$noak_b->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}elseif(@$azo_bol->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}else{
$doc->grp(''.sm_icon(qlassik_ru('17')).' '.__('Gurpaga qo`shilish').'', '?gruppy='.$gruppy->id.'&iltimos');
}
}	
}
$doc->grp(''.sm_icon(qlassik_ru('18')).' '.__('Qaytish').'', '?mening='.$gruppy->id.'');
$doc->grp(''.sm_icon(qlassik_ru('19')).' '.__('Gurpaga').'', '?gruppy='.$gruppy->id.'');
$doc->grp(''.sm_icon(qlassik_ru('19')).' '.__('Forumga').'', '?gruppy='.$gruppy->id.'&forum');

	
	exit;	
}
	
	
if ($user->id == $gruppy->admin && $_GET ['forum'] == 'idm' &&  $_GET ['idm'] == ''.$_GET ['idm'].''  && $_GET ['lavha'] == 'sozlashgaa'){	
if (isset($_POST['name'])) {
    $name = text::for_name($_POST['name']);
    $description = text::input_text($_POST['matn']);
    if (!$name) {
        $doc->err(__('Bo`lim nomini kiritin'));
    } else {
mysql_query("UPDATE `forum_themes` SET `name` = '" . my_esc($name) . "', `matn` = '" . my_esc($description) . "'  WHERE `id_gruppa` = '".$gruppy->id."'  AND `id` = '".$_GET['sozlashgaa']."' LIMIT 1");
        
  $doc->msg(__('O`zgartirildi'));

        if (isset($_GET['return'])) {
           header('Refresh: 1; url=' . $_GET['return']);
        } else {
           header('Refresh: 1; url=?gruppy='.$gruppy->id.'&forum=idm&idm='.$_GET ['idm'].'&' . SID);
        }

        exit;
    }
}
	
$q = mysql_query("SELECT * FROM `forum_themes` WHERE `id` = '".$_GET['sozlashgaa']."'");

if (!mysql_num_rows($q)) {
    header('Refresh: 1; url=./');
    $doc->err(__('Bo`lim mavzu yoq'));
    exit;
}

$topic = mysql_fetch_assoc($q);

$form = new form("?gruppy=".$gruppy->id."&forum=idm&idm=".$_GET ['idm']."&lavha=sozlashgaa&sozlashgaa=".$_GET['sozlashgaa']."");
$form->text('name', __('Bo`lim nomi'), $topic['name']);
$form->textarea('matn', __('Tafsif'), $topic['matn']);
$form->button(__('Bo`limni o`zgartirish'));
$form->display();
	if ($user->id == $gruppy->admin){
$doc->dost(__('Bo`lim yaratish'), '?gruppy='.$gruppy->id.'&forum=yaratish');		
$doc->grp(''.sm_icon(qlassik_ru('9')).' '.__('Azolar').'', '?gruppy='.$gruppy->id.'&azolar');		
$doc->grp(''.sm_icon(qlassik_ru('10')).' '.__('Foto biriktirish').'', '?gruppy='.$gruppy->id.'&surat');
$doc->grp(''.sm_icon(qlassik_ru('11')).' '.__('Ovoz biriktirish').'', '?gruppy='.$gruppy->id.'&ovoz');	
$doc->grp(''.sm_icon(qlassik_ru('12')).' '.__('Administrator qo`shish').'', '?gruppy='.$gruppy->id.'&admin');
$doc->grp(''.sm_icon(qlassik_ru('13')).' '.__('Sozlash').'', '?gruppy='.$gruppy->id.'&sozlash');
}else{
if($aktiv->id == $user->id){
if ($gruppy->zakrit == '1')$doc->grp(''.sm_icon(qlassik_ru('14')).' '.__('Do`stlar qo`shish').'', '?gruppy='.$gruppy->id.'&dostlar');		
$doc->grp(''.sm_icon(qlassik_ru('15')).' '.__('Gurpadan chiqish').'', '?gruppy='.$gruppy->id.'&chiqesh');
}else{
if(@$noak_b->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}elseif(@$azo_bol->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}else{
$doc->grp(''.sm_icon(qlassik_ru('17')).' '.__('Gurpaga qo`shilish').'', '?gruppy='.$gruppy->id.'&iltimos');
}
}	
}
$doc->grp(''.sm_icon(qlassik_ru('18')).' '.__('Qaytish').'', '?mening='.$gruppy->id.'');
$doc->grp(''.sm_icon(qlassik_ru('19')).' '.__('Gurpaga').'', '?gruppy='.$gruppy->id.'');
$doc->grp(''.sm_icon(qlassik_ru('19')).' '.__('Forumga').'', '?gruppy='.$gruppy->id.'&forum');

	
	exit;	
}
	
	
if ($user->id == $gruppy->admin && $_GET ['forum'] == 'idm' &&  $_GET ['idm'] == ''.$_GET ['idm'].''  && $_GET ['lavha'] == 'ochir_g_fa'){	
	
	
if (isset($_POST['delete'])) {
    if (empty($_POST['captcha']) || empty($_POST['captcha_session']) || !captcha::check($_POST['captcha'], $_POST['captcha_session'])) {
        $doc->err(__('Raqam to`gri holatda kiritilmadi'));
    } else {
       
mysql_query("DELETE FROM `forum_themes` WHERE `admin` ='".$gruppy->admin."' AND `id` = '".$_GET['ochir_g_fa']."' LIMIT 1");
$doc->err(__('O`chirildi'));
header('Refresh: 1; url=?gruppy='.$gruppy->id.'&forum=idm&idm='.$_GET ['idm'].'');
        exit;
    }
}

$form = new form("?gruppy=".$gruppy->id."&forum=idm&idm=".$_GET ['idm']."&lavha=ochir_g_fa&ochir_g_fa=".$_GET['ochir_g_fa']."");
$form->captcha();
$form->button(__('O`chirish'), 'delete');
$form->display();
	if ($user->id == $gruppy->admin){
$doc->dost(__('Bo`lim yaratish'), '?gruppy='.$gruppy->id.'&forum=yaratish');		
$doc->grp(''.sm_icon(qlassik_ru('9')).' '.__('Azolar').'', '?gruppy='.$gruppy->id.'&azolar');		
$doc->grp(''.sm_icon(qlassik_ru('10')).' '.__('Foto biriktirish').'', '?gruppy='.$gruppy->id.'&surat');
$doc->grp(''.sm_icon(qlassik_ru('11')).' '.__('Ovoz biriktirish').'', '?gruppy='.$gruppy->id.'&ovoz');	
$doc->grp(''.sm_icon(qlassik_ru('12')).' '.__('Administrator qo`shish').'', '?gruppy='.$gruppy->id.'&admin');
$doc->grp(''.sm_icon(qlassik_ru('13')).' '.__('Sozlash').'', '?gruppy='.$gruppy->id.'&sozlash');
}else{
if($aktiv->id == $user->id){
if ($gruppy->zakrit == '1')$doc->grp(''.sm_icon(qlassik_ru('14')).' '.__('Do`stlar qo`shish').'', '?gruppy='.$gruppy->id.'&dostlar');		
$doc->grp(''.sm_icon(qlassik_ru('15')).' '.__('Gurpadan chiqish').'', '?gruppy='.$gruppy->id.'&chiqesh');
}else{
if(@$noak_b->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}elseif(@$azo_bol->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}else{
$doc->grp(''.sm_icon(qlassik_ru('17')).' '.__('Gurpaga qo`shilish').'', '?gruppy='.$gruppy->id.'&iltimos');
}
}	
}
$doc->grp(''.sm_icon(qlassik_ru('18')).' '.__('Qaytish').'', '?mening='.$gruppy->id.'');
$doc->grp(''.sm_icon(qlassik_ru('19')).' '.__('Gurpaga').'', '?gruppy='.$gruppy->id.'');
$doc->grp(''.sm_icon(qlassik_ru('19')).' '.__('Forumga').'', '?gruppy='.$gruppy->id.'&forum');

	
	exit;	
}
	
}



	
	
$pages = new pages(mysql_result(mysql_query("SELECT COUNT(*) FROM `forum_themes` WHERE `time_create` = '".$idee."' AND `id_gruppa` = '".$gruppy->id."' AND `admin` = '".$gruppy->admin."'"), 0));
$listing = new listing();
$q = mysql_query("SELECT * FROM `forum_themes` WHERE `time_create` = '".$idee."' AND `id_gruppa` = '".$gruppy->id."' AND `admin` = '".$gruppy->admin."' ORDER BY `time` DESC LIMIT ".$pages->limit);
while ($p_user = mysql_fetch_assoc($q)) {
$kv = $listing->kv();
$kv->url = '?gruppy='.$gruppy->id.'&forum&idm='.$idee.'&idmm='.$p_user['id'].'';
$kv->title = ''.sm_icon(qlassik_ru('24')).' '.$p_user['name'];
$kv->url = '?gruppy='.$gruppy->id.'&forum=idm&idm='.$idee.'&idmb='.$p_user['id'].'';
if ($user->id == $gruppy->admin){
$kv->action('edit', '?gruppy='.$gruppy->id.'&forum=idm&idm='.$idee.'&lavha=sozlashgaa&sozlashgaa='.$p_user['id'].'');
$kv->action('nns', '');	
$kv->action('delete', '?gruppy='.$gruppy->id.'&forum=idm&idm='.$idee.'&lavha=ochir_g_fa&ochir_g_fa='.$p_user['id'].'');
}
 }


$listing->display(__('Ro`yhat bo`sh'));
$pages->this_page();
$pages->display('?gruppy='.$gruppy->id.'&forum=idm&idm='.$idee.'');	
	
	
	

	
	
	
	
	
	
	
	
	
	
	
	if ($user->id == $gruppy->admin){
$doc->dost(__('Lavha yaratish'), '?gruppy='.$gruppy->id.'&forum=idm&idm='.$idee.'&lavha=yaratisha');		

$doc->grp(''.sm_icon(qlassik_ru('9')).' '.__('Azolar').'', '?gruppy='.$gruppy->id.'&azolar');		
$doc->grp(''.sm_icon(qlassik_ru('10')).' '.__('Foto biriktirish').'', '?gruppy='.$gruppy->id.'&surat');
$doc->grp(''.sm_icon(qlassik_ru('11')).' '.__('Ovoz biriktirish').'', '?gruppy='.$gruppy->id.'&ovoz');	
$doc->grp(''.sm_icon(qlassik_ru('12')).' '.__('Administrator qo`shish').'', '?gruppy='.$gruppy->id.'&admin');
$doc->grp(''.sm_icon(qlassik_ru('13')).' '.__('Sozlash').'', '?gruppy='.$gruppy->id.'&sozlash');
}else{
if($aktiv->id == $user->id){
if ($gruppy->zakrit == '1')$doc->grp(''.sm_icon(qlassik_ru('14')).' '.__('Do`stlar qo`shish').'', '?gruppy='.$gruppy->id.'&dostlar');		
$doc->grp(''.sm_icon(qlassik_ru('15')).' '.__('Gurpadan chiqish').'', '?gruppy='.$gruppy->id.'&chiqesh');
}else{
if(@$noak_b->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}elseif(@$azo_bol->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}else{
$doc->grp(''.sm_icon(qlassik_ru('17')).' '.__('Gurpaga qo`shilish').'', '?gruppy='.$gruppy->id.'&iltimos');
}
}	
}
$doc->grp(''.sm_icon(qlassik_ru('18')).' '.__('Qaytish').'', '?mening='.$gruppy->id.'');
$doc->grp(''.sm_icon(qlassik_ru('19')).' '.__('Gurpaga').'', '?gruppy='.$gruppy->id.'');

	
	exit;	
}
	

if ($user->id == $gruppy->admin && $_GET ['forum'] == 'yaratish'){	
if (isset($_POST['name'])) {
    $name = text::for_name($_POST['name']);
    $description = text::input_text($_POST['description']);
    if (!$name) {
        $doc->err(__('Bo`lim nomini kiritin'));
    } else {
        mysql_query("INSERT INTO `forum_topics` (`id_gruppa`, `admin`, `time`, `name`, `description`, `group_show`, `group_write`, `group_edit`)
 VALUES ('" . $gruppy->id. "', '" . $gruppy->admin . "', '" . TIME . "', '" . my_esc($name) . "', '" . my_esc($description) . "', '".$gruppy->group_show."', '".$gruppy->group_write . "', '" . $gruppy->group_edit . "')");
  $doc->msg(__('bo`lim yaratildi'));

        if (isset($_GET['return'])) {
           header('Refresh: 1; url=' . $_GET['return']);
        } else {
           header('Refresh: 1; url=?gruppy='.$gruppy->id.'&forum&' . SID);
        }

        exit;
    }
}
	
	
	
	
$form = new form("?gruppy=".$gruppy->id."&forum=yaratish");
$form->text('name', __('Bo`lim nomi'));
$form->textarea('description', __('Tafsif'));
$form->button(__('Bo`lim yaratish'));
$form->display();
	if ($user->id == $gruppy->admin){
$doc->dost(__('Bo`lim yaratish'), '?gruppy='.$gruppy->id.'&forum=yaratish');		
$doc->grp(''.sm_icon(qlassik_ru('9')).' '.__('Azolar').'', '?gruppy='.$gruppy->id.'&azolar');		
$doc->grp(''.sm_icon(qlassik_ru('10')).' '.__('Foto biriktirish').'', '?gruppy='.$gruppy->id.'&surat');
$doc->grp(''.sm_icon(qlassik_ru('11')).' '.__('Ovoz biriktirish').'', '?gruppy='.$gruppy->id.'&ovoz');	
$doc->grp(''.sm_icon(qlassik_ru('12')).' '.__('Administrator qo`shish').'', '?gruppy='.$gruppy->id.'&admin');
$doc->grp(''.sm_icon(qlassik_ru('13')).' '.__('Sozlash').'', '?gruppy='.$gruppy->id.'&sozlash');
}else{
if($aktiv->id == $user->id){
if ($gruppy->zakrit == '1')$doc->grp(''.sm_icon(qlassik_ru('14')).' '.__('Do`stlar qo`shish').'', '?gruppy='.$gruppy->id.'&dostlar');		
$doc->grp(''.sm_icon(qlassik_ru('15')).' '.__('Gurpadan chiqish').'', '?gruppy='.$gruppy->id.'&chiqesh');
}else{
if(@$noak_b->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}elseif(@$azo_bol->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}else{
$doc->grp(''.sm_icon(qlassik_ru('17')).' '.__('Gurpaga qo`shilish').'', '?gruppy='.$gruppy->id.'&iltimos');
}
}	
}
$doc->grp(''.sm_icon(qlassik_ru('18')).' '.__('Qaytish').'', '?mening='.$gruppy->id.'');
$doc->grp(''.sm_icon(qlassik_ru('19')).' '.__('Gurpaga').'', '?gruppy='.$gruppy->id.'');
$doc->grp(''.sm_icon(qlassik_ru('19')).' '.__('Forumga').'', '?gruppy='.$gruppy->id.'&forum');

	
	exit;	
}
	
	
if ($user->id == $gruppy->admin && $_GET ['forum'] == 'sozlashga'){	
if (isset($_POST['name'])) {
    $name = text::for_name($_POST['name']);
    $description = text::input_text($_POST['description']);
    if (!$name) {
        $doc->err(__('Bo`lim nomini kiritin'));
    } else {
mysql_query("UPDATE `forum_topics` SET `name` = '" . my_esc($name) . "', `description` = '" . my_esc($description) . "'  WHERE `id_gruppa` = '".$gruppy->id."'  AND `id` = '".$_GET['sozlashga']."' LIMIT 1");
        
  $doc->msg(__('Bo`lim sozlandi'));

        if (isset($_GET['return'])) {
           header('Refresh: 1; url=' . $_GET['return']);
        } else {
           header('Refresh: 1; url=?gruppy='.$gruppy->id.'&forum&' . SID);
        }

        exit;
    }
}
	
$q = mysql_query("SELECT * FROM `forum_topics` WHERE `id` = '".$_GET['sozlashga']."'");

if (!mysql_num_rows($q)) {
    header('Refresh: 1; url=./');
    $doc->err(__('Bo`lim joylashmagan'));
    exit;
}

$topic = mysql_fetch_assoc($q);

	
$form = new form("?gruppy=".$gruppy->id."&forum=sozlashga&sozlashga=".$_GET['sozlashga']."");	
$form->text('name', __('Bo`lim nomi'), $topic['name']);
$form->textarea('description', __('Tafsif'), $topic['description']);
$form->button(__('Bo`limni o`zgartirish'));
$form->display();
	if ($user->id == $gruppy->admin){
$doc->dost(__('Bo`lim yaratish'), '?gruppy='.$gruppy->id.'&forum=yaratish');		
$doc->grp(''.sm_icon(qlassik_ru('9')).' '.__('Azolar').'', '?gruppy='.$gruppy->id.'&azolar');		
$doc->grp(''.sm_icon(qlassik_ru('10')).' '.__('Foto biriktirish').'', '?gruppy='.$gruppy->id.'&surat');
$doc->grp(''.sm_icon(qlassik_ru('11')).' '.__('Ovoz biriktirish').'', '?gruppy='.$gruppy->id.'&ovoz');	
$doc->grp(''.sm_icon(qlassik_ru('12')).' '.__('Administrator qo`shish').'', '?gruppy='.$gruppy->id.'&admin');
$doc->grp(''.sm_icon(qlassik_ru('13')).' '.__('Sozlash').'', '?gruppy='.$gruppy->id.'&sozlash');
}else{
if($aktiv->id == $user->id){
if ($gruppy->zakrit == '1')$doc->grp(''.sm_icon(qlassik_ru('14')).' '.__('Do`stlar qo`shish').'', '?gruppy='.$gruppy->id.'&dostlar');		
$doc->grp(''.sm_icon(qlassik_ru('15')).' '.__('Gurpadan chiqish').'', '?gruppy='.$gruppy->id.'&chiqesh');
}else{
if(@$noak_b->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}elseif(@$azo_bol->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}else{
$doc->grp(''.sm_icon(qlassik_ru('17')).' '.__('Gurpaga qo`shilish').'', '?gruppy='.$gruppy->id.'&iltimos');
}
}	
}
$doc->grp(''.sm_icon(qlassik_ru('18')).' '.__('Qaytish').'', '?mening='.$gruppy->id.'');
$doc->grp(''.sm_icon(qlassik_ru('19')).' '.__('Gurpaga').'', '?gruppy='.$gruppy->id.'');
$doc->grp(''.sm_icon(qlassik_ru('19')).' '.__('Forumga').'', '?gruppy='.$gruppy->id.'&forum');

	
	exit;	
}
	
	
if ($user->id == $gruppy->admin && $_GET ['forum'] == 'ochir_g_f'){	
	
	
if (isset($_POST['delete'])) {
    if (empty($_POST['captcha']) || empty($_POST['captcha_session']) || !captcha::check($_POST['captcha'], $_POST['captcha_session'])) {
        $doc->err(__('Raqam to`gri holatda kiritilmadi'));
    } else {
        $q = mysql_query("SELECT `id` FROM `forum_themes` WHERE `id_topic` = '$topic[id]'");
        while ($theme = mysql_fetch_assoc($q)) {
            $dir = new files(FILES . '/.forum/' . $theme['id']);
            $dir->delete();
            unset($dir);
        }
mysql_query("DELETE FROM `forum_topics` WHERE  `admin` ='".$gruppy->admin."' AND  `id` = '".$_GET['ochir_g_f']."' LIMIT 1");
$doc->msg(__('Bo`lim o`chirildi'));
        exit;
    }
}



$form = new form("?gruppy=".$gruppy->id."&forum=ochir_g_f&ochir_g_f=".$_GET['ochir_g_f']."");
$form->captcha();
$form->button(__('O`chirish'), 'delete');
$form->display();
	if ($user->id == $gruppy->admin){
$doc->dost(__('Bo`lim yaratish'), '?gruppy='.$gruppy->id.'&forum=yaratish');		
$doc->grp(''.sm_icon(qlassik_ru('9')).' '.__('Azolar').'', '?gruppy='.$gruppy->id.'&azolar');		
$doc->grp(''.sm_icon(qlassik_ru('10')).' '.__('Foto biriktirish').'', '?gruppy='.$gruppy->id.'&surat');
$doc->grp(''.sm_icon(qlassik_ru('11')).' '.__('Ovoz biriktirish').'', '?gruppy='.$gruppy->id.'&ovoz');	
$doc->grp(''.sm_icon(qlassik_ru('12')).' '.__('Administrator qo`shish').'', '?gruppy='.$gruppy->id.'&admin');
$doc->grp(''.sm_icon(qlassik_ru('13')).' '.__('Sozlash').'', '?gruppy='.$gruppy->id.'&sozlash');
}else{
if($aktiv->id == $user->id){
if ($gruppy->zakrit == '1')$doc->grp(''.sm_icon(qlassik_ru('14')).' '.__('Do`stlar qo`shish').'', '?gruppy='.$gruppy->id.'&dostlar');		
$doc->grp(''.sm_icon(qlassik_ru('15')).' '.__('Gurpadan chiqish').'', '?gruppy='.$gruppy->id.'&chiqesh');
}else{
if(@$noak_b->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}elseif(@$azo_bol->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}else{
$doc->grp(''.sm_icon(qlassik_ru('17')).' '.__('Gurpaga qo`shilish').'', '?gruppy='.$gruppy->id.'&iltimos');
}
}	
}
$doc->grp(''.sm_icon(qlassik_ru('18')).' '.__('Qaytish').'', '?mening='.$gruppy->id.'');
$doc->grp(''.sm_icon(qlassik_ru('19')).' '.__('Gurpaga').'', '?gruppy='.$gruppy->id.'');
$doc->grp(''.sm_icon(qlassik_ru('19')).' '.__('Forumga').'', '?gruppy='.$gruppy->id.'&forum');

	
	exit;	
}
	
	
$pages = new pages(mysql_result(mysql_query("SELECT COUNT(*) FROM `forum_topics` WHERE `id_gruppa` = '".$gruppy->id."' AND `admin` = '".$gruppy->admin."'"), 0));
$listing = new listing();
$q = mysql_query("SELECT * FROM `forum_topics` WHERE `id_gruppa` = '".$gruppy->id."' AND `admin` = '".$gruppy->admin."' ORDER BY `time` DESC LIMIT ".$pages->limit);
while ($p_user = mysql_fetch_assoc($q)) {
$kv = $listing->kv();
$kv->url = '?gruppy='.$gruppy->id.'&forum&idm='.$p_user['id'].'';
$kv->title = ''.sm_icon(qlassik_ru('24')).' '.$p_user['name'];
$kv->url = '?gruppy='.$gruppy->id.'&forum=idm&idm='.$p_user['id'].'';
if ($user->id == $gruppy->admin){
$kv->action('edit', '?gruppy='.$gruppy->id.'&forum=sozlashga&sozlashga='.$p_user['id'].'');
$kv->action('nns', '');	
$kv->action('delete', '?gruppy='.$gruppy->id.'&forum=ochir_g_f&ochir_g_f='.$p_user['id'].'');	
}
 }


$listing->display(__('Ro`yhat bo`sh'));
$pages->this_page();
$pages->display('?gruppy='.$gruppy->id.'&forum');	
	
	
	

	
	
	
	
	
	
	
	
	
	
	
	if ($user->id == $gruppy->admin){
$doc->dost(__('Bo`lim yaratish'), '?gruppy='.$gruppy->id.'&forum=yaratish');		
$doc->grp(''.sm_icon(qlassik_ru('9')).' '.__('Azolar').'', '?gruppy='.$gruppy->id.'&azolar');		
$doc->grp(''.sm_icon(qlassik_ru('10')).' '.__('Foto biriktirish').'', '?gruppy='.$gruppy->id.'&surat');
$doc->grp(''.sm_icon(qlassik_ru('11')).' '.__('Ovoz biriktirish').'', '?gruppy='.$gruppy->id.'&ovoz');	
$doc->grp(''.sm_icon(qlassik_ru('12')).' '.__('Administrator qo`shish').'', '?gruppy='.$gruppy->id.'&admin');
$doc->grp(''.sm_icon(qlassik_ru('13')).' '.__('Sozlash').'', '?gruppy='.$gruppy->id.'&sozlash');
}else{
if($aktiv->id == $user->id){
if ($gruppy->zakrit == '1')$doc->grp(''.sm_icon(qlassik_ru('14')).' '.__('Do`stlar qo`shish').'', '?gruppy='.$gruppy->id.'&dostlar');		
$doc->grp(''.sm_icon(qlassik_ru('15')).' '.__('Gurpadan chiqish').'', '?gruppy='.$gruppy->id.'&chiqesh');
}else{
if(@$noak_b->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}elseif(@$azo_bol->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}else{
$doc->grp(''.sm_icon(qlassik_ru('17')).' '.__('Gurpaga qo`shilish').'', '?gruppy='.$gruppy->id.'&iltimos');
}
}	
}
$doc->grp(''.sm_icon(qlassik_ru('18')).' '.__('Qaytish').'', '?mening='.$gruppy->id.'');
$doc->grp(''.sm_icon(qlassik_ru('19')).' '.__('Gurpaga').'', '?gruppy='.$gruppy->id.'');

	
	exit;		
}




if ($gruppy->zakrit == '1' && isset($_GET ['dostlar'])){
	
	
	
	
	
	if (isset($_GET['qoo']) && $gruppy->zakrit == '1' && isset($_GET['kantak'])  || isset($_GET['qoo']) && $gruppy->zakrit == '1' && isset($_GET['ide'])  ||  $gruppy->zakrit == '1' && isset($_GET['online'])){
		  $use = new user($_GET['qoo']);
		  if (mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_user` WHERE `user` = '".$use->id."' AND `id_gruppa` = '".$gruppy->id."' AND `admin` = '".$gruppy->admin."' AND `ak` = '2' "), 0)){
				$doc->err(__('Do`stingiz oldin qo`shilgan'));	
				header('Refresh: 1; url=?');	
			}else{
mysql_query("INSERT INTO `gruppa_user` (`id_gruppa`, `admin`, `user`, `time`, `ak`)
VALUES ('" . $gruppy->id. "', '" . $gruppy->admin . "', '" . $use->id . "', '" . TIME . "', '2' )");
$use->gruppa = $use->gruppa + 1;
//$_SESSION['timesd'] = TIME + 3;
       $doc->msg(__('Ofaring qo`shdingiz'));	

		}
		}
	
	
	
	
	
	
	
	
	
	
	if (isset($_GET ['kantak']) || isset($_GET ['kantakk'])){
		$doc->title = __('%s ga kontak orqali qo`shish', $gruppy->nomi);	
$sql_where = array("`mail`.`id_user` = '{$user->id}'");
if (isset($_GET ['xabar_keldi'])) {
    $sql_where[] = "`mail`.`is_read` = '0'";
}

$pages = new pages ();
$pages->posts = mysql_result(mysql_query("SELECT COUNT(DISTINCT(`mail`.`id_sender`)) FROM `mail` WHERE " . implode(' AND ', $sql_where)), 0); 
$pages->this_page(); 

$q = mysql_query("SELECT `users`.`id`,
        `mail`.`id_sender`,
        MAX(`mail`.`time`) AS `time`,
        MIN(`mail`.`is_read`) AS `is_read`,
        COUNT(`mail`.`id`) AS `count`
FROM `mail`
LEFT JOIN `users` ON `mail`.`id_sender` = `users`.`id`
WHERE " . implode(' AND ', $sql_where) . "
GROUP BY `mail`.`id_sender`
ORDER BY `time` DESC
LIMIT $pages->limit");

$listing = new listing();
while ($mail = mysql_fetch_assoc($q)) {
	$ank = new user((int)$mail['id_sender']);
    $kv = $listing->kv();
	if($ank->id){
     if ($user->id == $ank->id);else{
  $kv->image = $ank->getAva($doc->img_max_width());
    $kv->url = 'xabar?id=' . $ank->id;
    $kv->title = $ank->nick();
	$kv->admine = mailsoz($ank->id);
	$kv->time = mailtime($ank->id);
	  if (mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_user` WHERE `user` = '".$ank->id."' AND `id_gruppa` = '".$gruppy->id."' AND `admin` = '".$gruppy->admin."' AND `ak` = '1' "), 0)){
    $kv->action('delete', '?gruppy='.$gruppy->id.'&och='.$ank->id.'&kantakk');
	}else{
		if (mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_user` WHERE `user` = '".$ank->id."' AND `id_gruppa` = '".$gruppy->id."' AND `admin` = '".$gruppy->admin."' AND `ak` = '2' "), 0)){
	if ($user->id == $ank->id);else{
$kv->action('shx', '/xabar?id='.$ank->id.'');	
}}else{
	$kv->action('create', '?gruppy='.$gruppy->id.'&qoo='.$ank->id.'&dostlar&kantak');			
		}
	}
}
}
}  



$listing->display(__('Xabarlar yo`q'));

$pages->display('?');
	$doc->dost(__('Xamma gurpalar'), '?');
	$doc->dost(__('Mening gruppalarim'), '?mening='.$gruppy->admin.'');		
    
	
	if ($user->id == $gruppy->admin){
$doc->grp(''.sm_icon(qlassik_ru('9')).' '.__('Azolar').'', '?gruppy='.$gruppy->id.'&azolar');		
$doc->grp(''.sm_icon(qlassik_ru('10')).' '.__('Foto biriktirish').'', '?gruppy='.$gruppy->id.'&surat');
$doc->grp(''.sm_icon(qlassik_ru('11')).' '.__('Ovoz biriktirish').'', '?gruppy='.$gruppy->id.'&ovoz');	
$doc->grp(''.sm_icon(qlassik_ru('12')).' '.__('Administrator qo`shish').'', '?gruppy='.$gruppy->id.'&admin');
$doc->grp(''.sm_icon(qlassik_ru('13')).' '.__('Sozlash').'', '?gruppy='.$gruppy->id.'&sozlash');
}else{
if($aktiv->id == $user->id){
if ($gruppy->zakrit == '1')$doc->grp(''.sm_icon(qlassik_ru('14')).' '.__('Do`stlar qo`shish').'', '?gruppy='.$gruppy->id.'&dostlar');	
$doc->grp(''.sm_icon(qlassik_ru('15')).' '.__('Gurpadan chiqish').'', '?gruppy='.$gruppy->id.'&chiqesh');
}else{
if(@$noak_b->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}elseif(@$azo_bol->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}else{
$doc->grp(''.sm_icon(qlassik_ru('17')).' '.__('Gurpaga qo`shilish').'', '?gruppy='.$gruppy->id.'&iltimos');
}
}	
}
$doc->grp(''.sm_icon(qlassik_ru('18')).' '.__('Qaytish').'', '?mening='.$gruppy->id.'');
$doc->grp(''.sm_icon(qlassik_ru('19')).' '.__('Gurpaga').'', '?gruppy='.$gruppy->id.'');

	
	exit;	
	}	
	if (isset($_GET ['ide']) || isset($_GET ['idee'])){
			$doc->title = __('%s ga id raqam orqali qo`shish', $gruppy->nomi);

	switch (@$_GET['order']) {
    case 'sum':
        $order = 'sum';
        $sort = 'DESC';
        $where = "WHERE `sum` > '0'";
        $doc->title = __('Puldorlar');
        break;
    case 'group':
        $order = 'group';
        $sort = 'DESC';
        $where = "WHERE `group` >= '2'";
        $doc->title = __('Mansobdorlar');
        break;
    case 'login':
        $order = 'login';
        $sort = 'ASC';
        $where = '';
        break;
    case 'balls':
        $order = 'balls';
        $sort = 'DESC';
        $where = '';
        break;
    case 'rating':
        $order = 'rating';
        $sort = 'DESC';
        $where = '';
        break;
    default:
        $order = 'id';
        $sort = 'DESC';
        $where = '';
        break;
}

if (!empty($_GET['search']))
    $search = text::input_text($_GET['search']);
if (isset($search) && !$search)
    $doc->err(__('Malumot yo`q'));
elseif (isset($search) && $search) {
    $where = "WHERE `login` LIKE '%" . my_esc($search) . "%'";
    $doc->title = __('Izlash по запросу "%s"', $search);
}

$posts = array();
$pages = new pages;
$pages->posts = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` $where"), 0);

$ord = array();
$ord[] = array("?order=id&amp;page={$pages->this_page}" . (isset($search) ? '&amp;search=' . urlencode($search) : ''), __('ID fodalanuvchiniki'), $order == 'id');
$ord[] = array("?order=login&amp;page={$pages->this_page}" . (isset($search) ? '&amp;search=' . urlencode($search) : ''), __('Login'), $order == 'login');
$ord[] = array("?order=rating&amp;page={$pages->this_page}" . (isset($search) ? '&amp;search=' . urlencode($search) : ''), __('Reytin'), $order == 'rating');
$ord[] = array("?order=balls&amp;page={$pages->this_page}" . (isset($search) ? '&amp;search=' . urlencode($search) : ''), __('Ball'), $order == 'balls');
$ord[] = array("?order=group&amp;page={$pages->this_page}" . (isset($search) ? '&amp;search=' . urlencode($search) : ''), __('Mansobdorlar'), $order == 'group');
$ord[] = array("?order=sum&amp;page={$pages->this_page}" . (isset($search) ? '&amp;search=' . urlencode($search) : ''), __('Boylar'), $order == 'sum');
$or = new design();
$or->assign('order', $ord);
$or->display('fv.order.tpl');

$q = mysql_query("SELECT `id` FROM `users` $where ORDER BY `$order` " . $sort . " LIMIT " . $pages->limit);

$listing = new listing();
if ($order == 'sum') {
    $post = $listing->post();
    $post->url = '?info=donate';
    $post->title = __('Qaytish');
    $post->hightlight = true;
    $post->icon('donate');
}

while ($ank = mysql_fetch_assoc($q)) {
    $p_user = new user($ank['id']);
	if($p_user->id){
    $kv = $listing->kv();
   if ($user->id == $p_user->id);else{
   $kv->url = '/ID'.$p_user->id.'';
    $kv->image = $p_user->getAva($doc->img_max_width());
    $kv->title = $p_user->nick();
    $kv->time = misc::when($p_user->last_visit);
    $kv->admine = ''.stsID($p_user->id).'';
  if (mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_user` WHERE `user` = '".$p_user->id."' AND `id_gruppa` = '".$gruppy->id."' AND `admin` = '".$gruppy->admin."' AND `ak` = '1' "), 0)){
	if ($user->id == $p_user->id);else{
$kv->action('shx', '/xabar?id='.$p_user->id.'');	
}
}else{
	$kv->action('create', '?gruppy='.$gruppy->id.'&qoo='.$p_user->id.'&dostlar&ide');
	}
   
    switch ($order) {
        case 'id':
            $kv->content[] = '[b]' . __('ID fodalanuvchiniki') . ': ' . $p_user->id . '[/b]';
            break;
        case 'group':
            $kv->content[] = '[b]' . __($p_user->group_name) . '[/b]';
            break;
        case 'rating':
            $kv->content[] = '[b]' . __('Reytin') . ': ' . $p_user->rating . '[/b]';
            break;
        case 'balls':
            $kv->content[] = '[b]' . __('Ball') . ': ' . ((int)$p_user->balls) . '[/b]';
            break;
        case 'sum':
            $kv->content[] = '[b]' . __('Sum: %s sum.', $p_user->sum) . '[/b]';
            break;
    }

    $kv->content[] = '[small]' . __('Ro`yxatdan otilgan vaqti') . ': ' . date('d-m-Y', $p_user->reg_date) . '[/small]';
    $kv->content[] = '[small]' . __('Oxiri saytga kirgan vaqti') . ': ' . misc::when($p_user->last_visit) . '[/small]';
   }
}
	}
$fv = new fv('?', false);
$fv->hidden('order', $order);
$fv->text('search', __('Nickni yozin'), @$search, false);
$fv->button(__('Izlash'));
$fv->display();

$listing->display($order == 'sum' ? __('Azolar xolati') : __('Azolar yo`q'));

$pages->display("?order=$order&amp;" . (isset($search) ? 'search=' . urlencode($search) . '&amp;' : '')); 
$doc->dost(__('Xamma gurpalar'), '?');
	$doc->dost(__('Mening gruppalarim'), '?mening='.$gruppy->admin.'');		
    
	
	if ($user->id == $gruppy->admin){
$doc->grp(''.sm_icon(qlassik_ru('9')).' '.__('Azolar').'', '?gruppy='.$gruppy->id.'&azolar');		
$doc->grp(''.sm_icon(qlassik_ru('10')).' '.__('Foto biriktirish').'', '?gruppy='.$gruppy->id.'&surat');
$doc->grp(''.sm_icon(qlassik_ru('11')).' '.__('Ovoz biriktirish').'', '?gruppy='.$gruppy->id.'&ovoz');	
$doc->grp(''.sm_icon(qlassik_ru('12')).' '.__('Administrator qo`shish').'', '?gruppy='.$gruppy->id.'&admin');
$doc->grp(''.sm_icon(qlassik_ru('13')).' '.__('Sozlash').'', '?gruppy='.$gruppy->id.'&sozlash');
}else{
if($aktiv->id == $user->id){
if ($gruppy->zakrit == '1')$doc->grp(''.sm_icon(qlassik_ru('14')).' '.__('Do`stlar qo`shish').'', '?gruppy='.$gruppy->id.'&dostlar');		
$doc->grp(''.sm_icon(qlassik_ru('15')).' '.__('Gurpadan chiqish').'', '?gruppy='.$gruppy->id.'&chiqesh');
}else{
if(@$noak_b->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}elseif(@$azo_bol->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}else{
$doc->grp(''.sm_icon(qlassik_ru('17')).' '.__('Gurpaga qo`shilish').'', '?gruppy='.$gruppy->id.'&iltimos');
}
}	
}
$doc->grp(''.sm_icon(qlassik_ru('18')).' '.__('Qaytish').'', '?mening='.$gruppy->id.'');
$doc->grp(''.sm_icon(qlassik_ru('19')).' '.__('Gurpaga').'', '?gruppy='.$gruppy->id.'');
exit;		
	}	
	if (isset($_GET ['online'])  || isset($_GET ['onlinee']) ){
			$doc->title = __('%s ga onlayndagilarni qo`shish', $gruppy->nomi);
	$pages = new pages(mysql_result(mysql_query("SELECT COUNT(*) FROM `users_online`"), 0));
$listing = new listing();
$q = mysql_query("SELECT `users_online`.* , `browsers`.`name` AS `browser`
 FROM `users_online`
 LEFT JOIN `browsers`
 ON `users_online`.`id_browser` = `browsers`.`id`
 ORDER BY `users_online`.`time_login` DESC LIMIT " . $pages->limit);

while ($p_user = mysql_fetch_assoc($q)) {

$ank = new user($p_user['id_user']);
    $kv = $listing->kv();
	if($ank->id){
  if ($user->id == $ank->id);else{
	
  $kv->image = $ank->getAva($doc->img_max_width());
    $kv->url = 'xabar?id=' . $ank->id;
    $kv->title = $ank->nick();
	$kv->admine = stsID($ank->id);
	$kv->time = mailtime($ank->id);
if (mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_user` WHERE `user` = '".$ank->id."' AND `id_gruppa` = '".$gruppy->id."' AND `ak` = '2' "), 0))
    {
if ($user->id == $ank->id);else{
$kv->action('shx', '/xabar?id='.$ank->id.'');	
}
}else{
	$kv->action('create', '?gruppy='.$gruppy->id.'&qoo='.$ank->id.'&dostlar&online');
	}
    }
    }
	}


     $listing->display(__('Ro`yhat bo`sh'));
     $pages->this_page();
     $pages->display('?');



	$doc->dost(__('Xamma gurpalar'), '?');
	$doc->dost(__('Mening gruppalarim'), '?mening='.$gruppy->admin.'');		
    
	
	if ($user->id == $gruppy->admin){
$doc->grp(''.sm_icon(qlassik_ru('9')).' '.__('Azolar').'', '?gruppy='.$gruppy->id.'&azolar');		
$doc->grp(''.sm_icon(qlassik_ru('10')).' '.__('Foto biriktirish').'', '?gruppy='.$gruppy->id.'&surat');
$doc->grp(''.sm_icon(qlassik_ru('11')).' '.__('Ovoz biriktirish').'', '?gruppy='.$gruppy->id.'&ovoz');	
$doc->grp(''.sm_icon(qlassik_ru('12')).' '.__('Administrator qo`shish').'', '?gruppy='.$gruppy->id.'&admin');
$doc->grp(''.sm_icon(qlassik_ru('13')).' '.__('Sozlash').'', '?gruppy='.$gruppy->id.'&sozlash');
}else{
if($aktiv->id == $user->id){
if ($gruppy->zakrit == '1')$doc->grp(''.sm_icon(qlassik_ru('14')).' '.__('Do`stlar qo`shish').'', '?gruppy='.$gruppy->id.'&dostlar');		
$doc->grp(''.sm_icon(qlassik_ru('15')).' '.__('Gurpadan chiqish').'', '?gruppy='.$gruppy->id.'&chiqesh');
}else{
if(@$noak_b->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}elseif(@$azo_bol->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}else{
$doc->grp(''.sm_icon(qlassik_ru('17')).' '.__('Gurpaga qo`shilish').'', '?gruppy='.$gruppy->id.'&iltimos');
}
}	
}
$doc->grp(''.sm_icon(qlassik_ru('18')).' '.__('Qaytish').'', '?mening='.$gruppy->id.'');
$doc->grp(''.sm_icon(qlassik_ru('19')).' '.__('Gurpaga').'', '?gruppy='.$gruppy->id.'');

	
	exit;		
	}		
	$doc->title = __('%s grupaga do`stlar qo`shish', $gruppy->nomi);	
	echo '<center style="margin: 5px;"><table width="98%" border="0"><tr>
	<td><center><a href="?gruppy='.$gruppy->id.'&dostlar&kantak"><img src="/img/dos.png" style="width: 50px; height: 50px;" title="voo.uz" /></a></center></td>
	<td><center><a href="?gruppy='.$gruppy->id.'&dostlar&online"><img src="/img/ig.png" style="width: 50px; height: 50px;" /></a></center></td>	
	<td><center><a href="?gruppy='.$gruppy->id.'&dostlar&ide"><img src="/img/gurpa.png" style="width: 50px; height: 50px;" /></a></center></td>
	</tr></table></center>';




if ($user->id == $gruppy->admin){
$doc->grp(''.sm_icon(qlassik_ru('20')).' '.__('Azo qo`shish').'', '?mening='.$gruppy->id.'');		
$doc->grp(''.sm_icon(qlassik_ru('10')).' '.__('Foto biriktirish').'', '?gruppy='.$gruppy->id.'&surat');
$doc->grp(''.sm_icon(qlassik_ru('11')).' '.__('Ovoz biriktirish').'', '?gruppy='.$gruppy->id.'&ovoz');	
$doc->grp(''.sm_icon(qlassik_ru('12')).' '.__('Administrator qo`shish').'', '?gruppy='.$gruppy->id.'&admin');
$doc->grp(''.sm_icon(qlassik_ru('13')).' '.__('Sozlash').'', '?gruppy='.$gruppy->id.'&sozlash');
}else{
if($aktiv->id == $user->id){
if ($gruppy->zakrit == '1')$doc->grp(''.sm_icon(qlassik_ru('14')).' '.__('Do`stlar qo`shish').'', '?gruppy='.$gruppy->id.'&dostlar');		
$doc->grp(''.sm_icon(qlassik_ru('15')).' '.__('Gurpadan chiqish').'', '?gruppy='.$gruppy->id.'&chiqesh');
}else{
if(@$noak_b->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}elseif(@$azo_bol->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}else{
$doc->grp(''.sm_icon(qlassik_ru('17')).' '.__('Gurpaga qo`shilish').'', '?gruppy='.$gruppy->id.'&iltimos');
}
}	
}
$doc->grp(__('Qaytish'), '?gruppy='.$gruppy->id.'');
exit;
}





if (isset($_GET ['chiqesh'])){
$doc->title = __('%s grupadan chiqarish', $gruppy->nomi);
if (mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_user` WHERE `user` = '".$user->id."' AND `id_gruppa` = '".$gruppy->id."' AND `admin` = '".$gruppy->admin."' AND `ak` = '1' "), 0)){	
//mysql_query("INSERT INTO `gruppa_user` (`id_gruppa`, `admin`, `user`, `time`, `ak`)
//VALUES ('" . $gruppy->id. "', '" . $gruppy->admin . "', '" . $user->id . "', '" . TIME . "', '3' )");	
mysql_query("DELETE FROM `gruppa_user` WHERE `user` = '".$user->id."' AND `id_gruppa` = '".$gruppy->id."' AND `admin` = '".$gruppy->admin."' AND `ak` = '1' ");
$doc->msg(__('Siz gurpadan chiqib ketdingiz'));
header("Location: ?gruppy=".$gruppy->id."");
}else{
$doc->err(__('Bu gurpada chiqish holati yo`q.'));
header("Location: ?gruppy=".$gruppy->id."");
}
}





if (isset($_GET ['sozlash']) && $user->id == $gruppy->admin){
	$doc->title = __('%s sozlamasi', $gruppy->nomi);
if (isset($_POST ['qlassik_ru'])){
if (isset($_FILES ['file'] ['name'])){
 if (!$_FILES ['file'] ['error']) {	
$xatniki_file_name = ''.$gruppy->nomi.'_fon_'.text::for_filename($_FILES ['file'] ['name']);
$xatnikis_path = FILES . '/.gruppy'; 
$xatnikis_dir = new files($xatnikis_path);
if (preg_match('/\\.(jpg|png|gif|jepg)$/i', text::for_filename($_FILES ['file'] ['name']))) {
    if (!$img = @imagecreatefromjpeg($_FILES ['file'] ['tmp_name']) || !$img = @imagecreatefromgif($_FILES ['file'] ['tmp_name']) || !$img = @imagecreatefrompng($_FILES ['file'] ['tmp_name'])) {
        $doc->err(__('Rasim farmatda emas'));
    }elseif (!empty($_FILES ['file'])) {
    if ($_FILES ['file'] ['error']) {
        $doc->err(__('Yuklashda xatolik bor'));
    } elseif (!$_FILES ['file'] ['size']) {
        $doc->err(__('faylа yo`q'));
    } else {
        if ($xatnikis_dir->is_file($gruppy->fon)) {
            $xatniki = new files_file($xatnikis_path, $gruppy->fon);
            $xatniki->delete(); 
        }

        if ($files_ok = $xatnikis_dir->filesAdd(array($_FILES ['file'] ['tmp_name'] => $xatniki_file_name))) {
            $xatnikis_dir->group_show = 0;
            $files_ok [$_FILES ['file'] ['tmp_name']]->group_show = 0;
            $files_ok [$_FILES ['file'] ['tmp_name']]->id_user = $user->id;
            $files_ok [$_FILES ['file'] ['tmp_name']]->group_edit = max($user->group, 2);
            mysql_query("UPDATE `gruppa` SET  `fon`= '".$xatniki_file_name."' WHERE `id` = '".$gruppy->id."'  AND `admin` = '".$user->id."'");
            unset($files_ok);
		} else {
            $doc->err(__('Iloji yoq fayl saqlashga'));
        }
    }
}
}
}
}	
mysql_query("UPDATE `gruppa` SET  `nomi`= '".$_POST ['nomi']."', `matn`= '".$_POST ['matn']."', `zakrit`= '".$_POST ['zakrit']."'  WHERE `id` = '".$gruppy->id."'  AND `admin` = '".$user->id."'");
header("Location: ?gruppy=".$gruppy->id."&sozlash&".passgen()."");
$doc->msg(__('Sozlama o`zgardi'));
}
 $zakritaa = array(1 => 'Majburiy qo`shilsin', 2 => 'Ruhsatsiz qo`shilmasin', 3 => 'Ruhsatsiz kirilmasin');

$fv = new fv('?gruppy='.$gruppy->id.'&sozlash&' . passgen());
$fv->textarea('matn', __('Matn'), $gruppy->matn);
$fv->text('nomi', __('Nomi'), $gruppy->nomi);
$fv->select('zakrit', __('Holat hozirda (%s)', $zakritaa[''.$gruppy->zakrit.'']), array(array(1, __('Majburiy qo`shilsin')), array(2, __('Ruhsatsiz qo`shilmasin')), array(3, __('Ruhsatsiz kirilmasin'))));
$fv->file('file', __('Fon qo`yish'));
$fv->button(__('Saqlash'), 'qlassik_ru');
$fv->display();


if ($user->id == $gruppy->admin){
$doc->grp(''.sm_icon(qlassik_ru('20')).' '.__('Azo qo`shish').'', '?mening='.$gruppy->id.'');		
$doc->grp(''.sm_icon(qlassik_ru('10')).' '.__('Foto biriktirish').'', '?gruppy='.$gruppy->id.'&surat');
$doc->grp(''.sm_icon(qlassik_ru('11')).' '.__('Ovoz biriktirish').'', '?gruppy='.$gruppy->id.'&ovoz');	
$doc->grp(''.sm_icon(qlassik_ru('12')).' '.__('Administrator qo`shish').'', '?gruppy='.$gruppy->id.'&admin');
$doc->grp(''.sm_icon(qlassik_ru('13')).' '.__('Sozlash').'', '?gruppy='.$gruppy->id.'&sozlash');
}else{
if($aktiv->id == $user->id){
if ($gruppy->zakrit == '1')$doc->grp(''.sm_icon(qlassik_ru('14')).' '.__('Do`stlar qo`shish').'', '?gruppy='.$gruppy->id.'&dostlar');		
$doc->grp(''.sm_icon(qlassik_ru('15')).' '.__('Gurpadan chiqish').'', '?gruppy='.$gruppy->id.'&chiqesh');
}else{
if(@$noak_b->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}elseif(@$azo_bol->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}else{
$doc->grp(''.sm_icon(qlassik_ru('17')).' '.__('Gurpaga qo`shilish').'', '?gruppy='.$gruppy->id.'&iltimos');
}
}	
}
$doc->grp(__('Qaytish'), '?gruppy='.$gruppy->id.'');
exit;
}


if (isset($_GET ['admin'])){
	$doc->title = __('%s grupaga admin tayorlash', $gruppy->nomi);
$admin_nom = (int) $_GET ['admin'];

$iddd = mysql_query("SELECT * FROM `gruppa_admin_nom` WHERE `id` = '$admin_nom' LIMIT 1") ;
if ($_GET ['admin']){
if(!mysql_num_rows($iddd)){
header('Location: ?') ;
exit ;
}
$adn = mysql_fetch_object($iddd) ;


if ($_GET ['admin'] == $admin_nom){
$adminli =  mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_admin` WHERE `id_gruppa` = '".$gruppy->id."' AND `admin_nom` = '$admin_nom'"), 0);	
$doc->dost(__(''.$adn->admin_nom.' %s', '<span class="strike_k">  '.$adminli.' </span>'), '?gruppy='.$gruppy->id.'&admin=aktivmas');
if ($_GET ['admin'] == $admin_nom && $user->id == $gruppy->admin){
$pages = new pages(mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_user` WHERE `id_gruppa` = '".$gruppy->id."' AND `ak` = '1'"), 0));
$listing = new listing();
$q = mysql_query("SELECT * FROM  `gruppa_user` WHERE `id_gruppa` = '".$gruppy->id."' AND `ak` = '1' ORDER BY `time` DESC LIMIT ".$pages->limit);
}else{
$pages = new pages(mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_admin` WHERE `id_gruppa` = '".$gruppy->id."' AND `admin_nom` = '$admin_nom'"), 0));
$listing = new listing();
$q = mysql_query("SELECT * FROM  `gruppa_admin` WHERE `id_gruppa` = '".$gruppy->id."'  AND `admin_nom` = '$admin_nom' ORDER BY `id` DESC LIMIT ".$pages->limit);

}

while ($p_user = mysql_fetch_assoc($q)) {
if ($_GET ['admin'] == $admin_nom && $user->id == $gruppy->admin){
$ank2 = new user($p_user['user']);
}else{
$ank2 = new user($p_user['user_admin']);	
}
if ($ank2->id){
$kv = $listing->kv();
$kv->url = '/ID'.$ank2->id.'';
$kv->image = $ank2->getAva($doc->img_max_width());
$kv->title = $ank2->nick();
$kv->time = misc::when($p_user['time']);
$kv->admine = ''.stsID($ank2->id).'';

if ($_GET ['admin'] == $admin_nom && $user->id == $gruppy->admin){
if (isset($_GET['qoo']) && !mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_admin` WHERE `user_admin` = '".$_GET['qoo']."' AND `id_gruppa` = '".$gruppy->id."'"), 0))
    {	

if ($_GET['qoo'] == $ank2->id){
mysql_query("INSERT INTO `gruppa_admin` (`id_gruppa`, `admin`, `user_admin`, `admin_nom`, `time`)
VALUES ('" . $gruppy->id. "', '" . $gruppy->admin . "', '" . $_GET['qoo'] . "', '" . $admin_nom . "', '" . TIME . "')");	
$doc->msg(__('Qo`shildi'));
}
}

if (isset($_GET['och']) && mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_admin` WHERE `user_admin` = '".$_GET['och']."' AND `id_gruppa` = '".$gruppy->id."'"), 0)){
if ($_GET['och'] == $ank2->id){
mysql_query("DELETE FROM `gruppa_admin` WHERE  `id_gruppa` = '".$gruppy->id."' AND `admin` = '".$user->id."' AND `admin_nom` = '".$admin_nom."' AND `user_admin` = '".$_GET['och']."'");
$doc->err(__('O`chirildi'));
}
}

if (mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_admin` WHERE `admin_nom` = '".$admin_nom."' AND `user_admin` = '".$ank2->id."' AND `id_gruppa` = '".$gruppy->id."'"), 0))
    {
	$kv->action('delete', '?gruppy='.$gruppy->id.'&admin='.$admin_nom.'&och='.$ank2->id.'&adb');
	}else{
	$kv->action('create', '?gruppy='.$gruppy->id.'&admin='.$admin_nom.'&qoo='.$ank2->id.'&add');
	}

}else{
if ($user->id == $ank2->id);else{
$kv->action('shx', '/xabar?id='.$ank2->id.'');	
}	
}
}
}
 

$listing->display(__('Ro`yhat bo`sh'));
$pages->this_page();
$pages->display('?');
}	




if ($user->id == $gruppy->admin){
$doc->grp(''.sm_icon(qlassik_ru('20')).' '.__('Azo qo`shish').'', '?mening='.$gruppy->id.'');		
$doc->grp(''.sm_icon(qlassik_ru('10')).' '.__('Foto biriktirish').'', '?gruppy='.$gruppy->id.'&surat');
$doc->grp(''.sm_icon(qlassik_ru('11')).' '.__('Ovoz biriktirish').'', '?gruppy='.$gruppy->id.'&ovoz');	
$doc->grp(''.sm_icon(qlassik_ru('12')).' '.__('Administrator qo`shish').'', '?gruppy='.$gruppy->id.'&admin');
$doc->grp(''.sm_icon(qlassik_ru('13')).' '.__('Sozlash').'', '?gruppy='.$gruppy->id.'&sozlash');
}else{
if($aktiv->id == $user->id){
if ($gruppy->zakrit == '1')$doc->grp(''.sm_icon(qlassik_ru('14')).' '.__('Do`stlar qo`shish').'', '?gruppy='.$gruppy->id.'&dostlar');		
$doc->grp(''.sm_icon(qlassik_ru('15')).' '.__('Gurpadan chiqish').'', '?gruppy='.$gruppy->id.'&chiqesh');
}else{
if(@$noak_b->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}elseif(@$azo_bol->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}else{
$doc->grp(''.sm_icon(qlassik_ru('17')).' '.__('Gurpaga qo`shilish').'', '?gruppy='.$gruppy->id.'&iltimos');
}
}	
}
$doc->grp(__('Qaytish'), '?gruppy='.$gruppy->id.'&admin');
exit;
}
echo'<div id="qani">';
$result = mysql_query("SELECT * FROM `gruppa_admin_nom` WHERE  `id`");
$myrow = mysql_fetch_array($result);  
do   
{  
printf ("<div  class='gruppa' role='alert'><a href='?gruppy=".$gruppy->id."&admin=".$myrow['id']."'>  » ".sm_nick(text::toOutput($myrow["admin_nom"]))."  <span style='float:right; clear:left;' class='strike_k'> ".mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_admin` WHERE `id_gruppa` = '".$gruppy->id."' AND `admin_nom` = '".$myrow['id']."'"), 0)." </span></a>  </div>"); 
} 

while ($myrow = mysql_fetch_array($result)); 
echo'</div>';
if ($user->id == $gruppy->admin){
$doc->grp(''.sm_icon(qlassik_ru('20')).' '.__('Azo qo`shish').'', '?mening='.$gruppy->id.'');		
$doc->grp(''.sm_icon(qlassik_ru('10')).' '.__('Foto biriktirish').'', '?gruppy='.$gruppy->id.'&surat');
$doc->grp(''.sm_icon(qlassik_ru('11')).' '.__('Ovoz biriktirish').'', '?gruppy='.$gruppy->id.'&ovoz');	
$doc->grp(''.sm_icon(qlassik_ru('12')).' '.__('Administrator qo`shish').'', '?gruppy='.$gruppy->id.'&admin');
$doc->grp(''.sm_icon(qlassik_ru('13')).' '.__('Sozlash').'', '?gruppy='.$gruppy->id.'&sozlash');
}else{
if($aktiv->id == $user->id){
if ($gruppy->zakrit == '1')$doc->grp(''.sm_icon(qlassik_ru('14')).' '.__('Do`stlar qo`shish').'', '?gruppy='.$gruppy->id.'&dostlar');		
$doc->grp(''.sm_icon(qlassik_ru('15')).' '.__('Gurpadan chiqish').'', '?gruppy='.$gruppy->id.'&chiqesh');
}else{
if(@$noak_b->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}elseif(@$azo_bol->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}else{
$doc->grp(''.sm_icon(qlassik_ru('17')).' '.__('Gurpaga qo`shilish').'', '?gruppy='.$gruppy->id.'&iltimos');
}
}	
}
$doc->grp(__('Qaytish'), '?gruppy='.$gruppy->id.'');

exit;	
}
if ($user->id == $gruppy->admin){

if (isset($_GET ['ovoz'])){
	$doc->title = __('%s grupaga ovoz biriktirish', $gruppy->nomi);
if (isset($_FILES ['file'] ['name'])){
 if (!$_FILES ['file'] ['error']) {	
$xatniki_file_name = ''.$gruppy->nomi.'_ovoz_'.$_FILES ['file'] ['name'];
$xatnikis_path = FILES . '/.gruppy'; 
$xatnikis_dir = new files($xatnikis_path);
if (preg_match('/\\.(mp3|ogg|wav|MP3|OGG|WAV)$/i', $_FILES ['file'] ['name'])) {
   if (!empty($_FILES ['file'])) {
    if ($_FILES ['file'] ['error']) {
        $doc->err(__('Yuklashda xatolik bor'));
    } elseif (!$_FILES ['file'] ['size']) {
        $doc->err(__('faylа yo`q'));
    } else {
        if ($xatnikis_dir->is_file($gruppy->ovoz)) {
            $xatniki = new files_file($xatnikis_path, $gruppy->ovoz);
            $xatniki->delete(); 
        }

        if ($files_ok = $xatnikis_dir->filesAdd(array($_FILES ['file'] ['tmp_name'] => $xatniki_file_name))) {
            $xatnikis_dir->group_show = 0;
            $files_ok [$_FILES ['file'] ['tmp_name']]->group_show = 0;
            $files_ok [$_FILES ['file'] ['tmp_name']]->id_user = $user->id;
            $files_ok [$_FILES ['file'] ['tmp_name']]->group_edit = max($user->group, 2);
            $gruppy->ovoz = $xatniki_file_name;
			$doc->msg(__('Ovoz yuklandi'));
		    unset($files_ok);
		   header("Location: ?gruppy=".$gruppy->id."");
        } else {
            $doc->err(__('Iloji yoq fayl saqlashga'));
        }
    }
}
}
}
}

        $fv = new fv('?gruppy='.$gruppy->id.'&ovoz&' . passgen());
        $fv->file('file', __('MP3, OGG, WAV farmatda bo`lsin'));
        $fv->button(__('Ovoz yuklash'), 'send', false);
        $fv->display();
	
	
	
	
	
	
	
	
if ($user->id == $gruppy->admin){
$doc->grp(''.sm_icon(qlassik_ru('20')).' '.__('Azo qo`shish').'', '?mening='.$gruppy->id.'');		
$doc->grp(''.sm_icon(qlassik_ru('10')).' '.__('Foto biriktirish').'', '?gruppy='.$gruppy->id.'&surat');
$doc->grp(''.sm_icon(qlassik_ru('11')).' '.__('Ovoz biriktirish').'', '?gruppy='.$gruppy->id.'&ovoz');	
$doc->grp(''.sm_icon(qlassik_ru('12')).' '.__('Administrator qo`shish').'', '?gruppy='.$gruppy->id.'&admin');
$doc->grp(''.sm_icon(qlassik_ru('13')).' '.__('Sozlash').'', '?gruppy='.$gruppy->id.'&sozlash');
}else{
if($aktiv->id == $user->id){
if ($gruppy->zakrit == '1')$doc->grp(''.sm_icon(qlassik_ru('14')).' '.__('Do`stlar qo`shish').'', '?gruppy='.$gruppy->id.'&dostlar');		
$doc->grp(''.sm_icon(qlassik_ru('15')).' '.__('Gurpadan chiqish').'', '?gruppy='.$gruppy->id.'&chiqesh');
}else{
if(@$noak_b->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}elseif(@$azo_bol->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}else{
$doc->grp(''.sm_icon(qlassik_ru('17')).' '.__('Gurpaga qo`shilish').'', '?gruppy='.$gruppy->id.'&iltimos');
}
}	
}
$doc->grp(__('Qaytish'), '?gruppy='.$gruppy->id.'');
exit;	
}






if (isset($_GET ['surat'])){
	$doc->title = __('%s grupaga surat qo`shish', $gruppy->nomi);
	
if (isset($_FILES ['file'] ['name'])){
 if (!$_FILES ['file'] ['error']) {	
$xatniki_file_name = ''.$gruppy->nomi.'_'.$_FILES ['file'] ['name'];
$xatnikis_path = FILES . '/.gruppy'; 
$xatnikis_dir = new files($xatnikis_path);
if (preg_match('/\\.(jpg|png|gif|jepg)$/i', $_FILES ['file'] ['name'])) {
    if (!$img = @imagecreatefromjpeg($_FILES ['file'] ['tmp_name']) || !$img = @imagecreatefromgif($_FILES ['file'] ['tmp_name']) || !$img = @imagecreatefrompng($_FILES ['file'] ['tmp_name'])) {
        $doc->err(__('Rasim farmatda emas'));
    }elseif (!empty($_FILES ['file'])) {
    if ($_FILES ['file'] ['error']) {
        $doc->err(__('Yuklashda xatolik bor'));
    } elseif (!$_FILES ['file'] ['size']) {
        $doc->err(__('faylа yo`q'));
    } else {
        if ($xatnikis_dir->is_file($gruppy->rasim)) {
            $xatniki = new files_file($xatnikis_path, $gruppy->rasim);
            $xatniki->delete(); 
        }

        if ($files_ok = $xatnikis_dir->filesAdd(array($_FILES ['file'] ['tmp_name'] => $xatniki_file_name))) {
            $xatnikis_dir->group_show = 0;
            $files_ok [$_FILES ['file'] ['tmp_name']]->group_show = 0;
            $files_ok [$_FILES ['file'] ['tmp_name']]->id_user = $user->id;
            $files_ok [$_FILES ['file'] ['tmp_name']]->group_edit = max($user->group, 2);
            mysql_query("UPDATE `gruppa` SET  `rasim`= '".$xatniki_file_name."' WHERE `id` = '".$gruppy->id."'  AND `admin` = '".$user->id."'");
            $doc->msg(__('Rasim yuklandi'));
		    unset($files_ok);
		   header("Location: ?gruppy=".$gruppy->id."");
        } else {
            $doc->err(__('Iloji yoq fayl saqlashga'));
        }
    }
}
}
}
}

        $fv = new fv('?gruppy='.$gruppy->id.'&surat&' . passgen());
        $fv->file('file', __('JPG, PNG, GIF farmatda bo`lsin'));
        $fv->button(__('Rasim yuklash'), 'send', false);
        $fv->display();
	
	
	
	
	
	
	
	
if ($user->id == $gruppy->admin){
$doc->grp(''.sm_icon(qlassik_ru('20')).' '.__('Azo qo`shish').'', '?mening='.$gruppy->id.'');		
$doc->grp(''.sm_icon(qlassik_ru('10')).' '.__('Foto biriktirish').'', '?gruppy='.$gruppy->id.'&surat');
$doc->grp(''.sm_icon(qlassik_ru('11')).' '.__('Ovoz biriktirish').'', '?gruppy='.$gruppy->id.'&ovoz');	
$doc->grp(''.sm_icon(qlassik_ru('12')).' '.__('Administrator qo`shish').'', '?gruppy='.$gruppy->id.'&admin');
$doc->grp(''.sm_icon(qlassik_ru('13')).' '.__('Sozlash').'', '?gruppy='.$gruppy->id.'&sozlash');
}else{
if($aktiv->id == $user->id){
if ($gruppy->zakrit == '1')$doc->grp(''.sm_icon(qlassik_ru('14')).' '.__('Do`stlar qo`shish').'', '?gruppy='.$gruppy->id.'&dostlar');		
$doc->grp(''.sm_icon(qlassik_ru('15')).' '.__('Gurpadan chiqish').'', '?gruppy='.$gruppy->id.'&chiqesh');
}else{
if(@$noak_b->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}elseif(@$azo_bol->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}else{
$doc->grp(''.sm_icon(qlassik_ru('17')).' '.__('Gurpaga qo`shilish').'', '?gruppy='.$gruppy->id.'&iltimos');
}
}	
}
$doc->grp(__('Qaytish'), '?gruppy='.$gruppy->id.'');
exit;	
}





	
if (isset($_GET ['azolar'])){
	$doc->title = __('%s grupaga azo qo`shish', $gruppy->nomi);
if ($_GET ['azolar'] == 'doslik'){	
$doc->dost(__('Azolar %s', '<span class="strike_k">  '.$gurpamda_aktivlar.' </span>'), '?gruppy='.$gruppy->id.'&azolar');
$doc->dost(__('Kutib turganlar %s', '<span class="strike_k">  '.$gurpamga_kelib_kutyatkanlar.' </span>'), '?gruppy='.$gruppy->id.'&azolar=aktivmas');
$pages = new pages(mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_user` WHERE `id_gruppa` = '".$gruppy->id."' AND `ak` = '3'"), 0));
$listing = new listing();
$q = mysql_query("SELECT * FROM  `gruppa_user` WHERE `id_gruppa` = '".$gruppy->id."' AND `ak` = '3' ORDER BY `time` DESC LIMIT ".$pages->limit);
}elseif($_GET ['azolar'] == 'aktivmas'){
$doc->dost(__('Do`slik tashlaganlar %s', '<span class="strike_k">  '.$gurpamga_kelganlar.' </span>'), '?gruppy='.$gruppy->id.'&azolar=doslik');
$doc->dost(__('Azolar %s', '<span class="strike_k">  '.$gurpamda_aktivlar.' </span>'), '?gruppy='.$gruppy->id.'&azolar');
$pages = new pages(mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_user` WHERE `id_gruppa` = '".$gruppy->id."' AND `ak` = '2'"), 0));
$listing = new listing();
$q = mysql_query("SELECT * FROM  `gruppa_user` WHERE `id_gruppa` = '".$gruppy->id."' AND `ak` = '2' ORDER BY `time` DESC LIMIT ".$pages->limit);
}else{
$doc->dost(__('Do`slik tashlaganlar %s', '<span class="strike_k">  '.$gurpamga_kelganlar.' </span>'), '?gruppy='.$gruppy->id.'&azolar=doslik');
$doc->dost(__('Kutib turganlar %s', '<span class="strike_k">  '.$gurpamga_kelib_kutyatkanlar.' </span>'), '?gruppy='.$gruppy->id.'&azolar=aktivmas');
$pages = new pages(mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_user` WHERE `id_gruppa` = '".$gruppy->id."' AND `ak` = '1'"), 0));
$listing = new listing();
$q = mysql_query("SELECT * FROM  `gruppa_user` WHERE `id_gruppa` = '".$gruppy->id."' AND `ak` = '1' ORDER BY `time` DESC LIMIT ".$pages->limit);
}
while ($p_user = mysql_fetch_assoc($q)) {
$ank2 = new user($p_user['user']);
if ($ank2->id){
$kv = $listing->kv();
$kv->url = '/ID'.$ank2->id.'';
$kv->image = $ank2->getAva($doc->img_max_width());
$kv->title = $ank2->nick();
$kv->time = misc::when($p_user['time']);
$kv->admine = ''.stsID($ank2->id).'';
if ($_GET ['azolar'] == 'doslik'){	
    $kv->action('delete', '/grup_keldi.html?gruppy='.$gruppy->id.'&admin='.$gruppy->admin.'&och='.$ank2->id.'');
    $kv->action('nns', '');	
	$kv->action('create', '/grup_keldi.html?gruppy='.$gruppy->id.'&admin='.$gruppy->admin.'&qoo='.$ank2->id.''); 
}else{
if ($user->id == $ank2->id);else{
$kv->action('shx', '/xabar?id='.$ank2->id.'');	
}	
}
}
 }

$listing->display(__('Ro`yhat bo`sh'));
$pages->this_page();
$pages->display('?');






if ($user->id == $gruppy->admin){
$doc->grp(''.sm_icon(qlassik_ru('20')).' '.__('Azo qo`shish').'', '?mening='.$gruppy->id.'');		
$doc->grp(''.sm_icon(qlassik_ru('10')).' '.__('Foto biriktirish').'', '?gruppy='.$gruppy->id.'&surat');
$doc->grp(''.sm_icon(qlassik_ru('11')).' '.__('Ovoz biriktirish').'', '?gruppy='.$gruppy->id.'&ovoz');	
$doc->grp(''.sm_icon(qlassik_ru('12')).' '.__('Administrator qo`shish').'', '?gruppy='.$gruppy->id.'&admin');
$doc->grp(''.sm_icon(qlassik_ru('13')).' '.__('Sozlash').'', '?gruppy='.$gruppy->id.'&sozlash');
}else{
if($aktiv->id == $user->id){
if ($gruppy->zakrit == '1')$doc->grp(''.sm_icon(qlassik_ru('14')).' '.__('Do`stlar qo`shish').'', '?gruppy='.$gruppy->id.'&dostlar');		
$doc->grp(''.sm_icon(qlassik_ru('15')).' '.__('Gurpadan chiqish').'', '?gruppy='.$gruppy->id.'&chiqesh');
}else{
if(@$noak_b->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}elseif(@$azo_bol->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}else{
$doc->grp(''.sm_icon(qlassik_ru('17')).' '.__('Gurpaga qo`shilish').'', '?gruppy='.$gruppy->id.'&iltimos');
}
}	
}
$doc->grp(__('Qaytish'), '?gruppy='.$gruppy->id.'');
exit;
}
	
}else{
if (isset($_GET ['azolar'])){
	$doc->title = __('%s grupada azolani ko`rish', $gruppy->nomi);
if ($_GET ['azolar'] == 'doslik'){	
$doc->dost(__('Azolar %s', '<span class="strike_k">  '.$gurpamda_aktivlar.' </span>'), '?gruppy='.$gruppy->id.'&azolar');
$doc->dost(__('Kutib turganlar %s', '<span class="strike_k">  '.$gurpamga_kelib_kutyatkanlar.' </span>'), '?gruppy='.$gruppy->id.'&azolar=aktivmas');
$pages = new pages(mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_user` WHERE `id_gruppa` = '".$gruppy->id."' AND `ak` = '3'"), 0));
$listing = new listing();
$q = mysql_query("SELECT * FROM  `gruppa_user` WHERE `id_gruppa` = '".$gruppy->id."' AND `ak` = '3' ORDER BY `time` DESC LIMIT ".$pages->limit);
}elseif($_GET ['azolar'] == 'aktivmas'){
$doc->dost(__('Do`slik tashlaganlar %s', '<span class="strike_k">  '.$gurpamga_kelganlar.' </span>'), '?gruppy='.$gruppy->id.'&azolar=doslik');
$doc->dost(__('Azolar %s', '<span class="strike_k">  '.$gurpamda_aktivlar.' </span>'), '?gruppy='.$gruppy->id.'&azolar');
$pages = new pages(mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_user` WHERE `id_gruppa` = '".$gruppy->id."' AND `ak` = '2'"), 0));
$listing = new listing();
$q = mysql_query("SELECT * FROM  `gruppa_user` WHERE `id_gruppa` = '".$gruppy->id."' AND `ak` = '2' ORDER BY `time` DESC LIMIT ".$pages->limit);
}else{
$doc->dost(__('Do`slik tashlaganlar %s', '<span class="strike_k">  '.$gurpamga_kelganlar.' </span>'), '?gruppy='.$gruppy->id.'&azolar=doslik');
$doc->dost(__('Kutib turganlar %s', '<span class="strike_k">  '.$gurpamga_kelib_kutyatkanlar.' </span>'), '?gruppy='.$gruppy->id.'&azolar=aktivmas');
$pages = new pages(mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_user` WHERE `id_gruppa` = '".$gruppy->id."' AND `ak` = '1'"), 0));
$listing = new listing();
$q = mysql_query("SELECT * FROM  `gruppa_user` WHERE `id_gruppa` = '".$gruppy->id."' AND `ak` = '1' ORDER BY `time` DESC LIMIT ".$pages->limit);
}while ($p_user = mysql_fetch_assoc($q)) {
$ank2 = new user($p_user['user']);
if ($ank2->id){
$kv = $listing->kv();
$kv->url = '/ID'.$ank2->id.'';
$kv->image = $ank2->getAva($doc->img_max_width());
$kv->title = $ank2->nick();
$kv->time = misc::when($p_user['time']);
$kv->admine = ''.stsID($ank2->id).'';
if ($user->id == $ank2->id);else{
$kv->action('shx', '/xabar?id='.$ank2->id.'');	
} 
}
 }

$listing->display(__('Ro`yhat bo`sh'));
$pages->this_page();
$pages->display('?');






if ($user->id == $gruppy->admin){
$doc->grp(''.sm_icon(qlassik_ru('20')).' '.__('Azo qo`shish').'', '?mening='.$gruppy->id.'');		
$doc->grp(''.sm_icon(qlassik_ru('10')).' '.__('Foto biriktirish').'', '?gruppy='.$gruppy->id.'&surat');
$doc->grp(''.sm_icon(qlassik_ru('11')).' '.__('Ovoz biriktirish').'', '?gruppy='.$gruppy->id.'&ovoz');	
$doc->grp(''.sm_icon(qlassik_ru('12')).' '.__('Administrator qo`shish').'', '?gruppy='.$gruppy->id.'&admin');
$doc->grp(''.sm_icon(qlassik_ru('13')).' '.__('Sozlash').'', '?gruppy='.$gruppy->id.'&sozlash');
}else{
if($aktiv->id == $user->id){
if ($gruppy->zakrit == '1')$doc->grp(''.sm_icon(qlassik_ru('14')).' '.__('Do`stlar qo`shish').'', '?gruppy='.$gruppy->id.'&dostlar');		
$doc->grp(''.sm_icon(qlassik_ru('15')).' '.__('Gurpadan chiqish').'', '?gruppy='.$gruppy->id.'&chiqesh');
}else{
if(@$noak_b->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}elseif(@$azo_bol->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}else{
$doc->grp(''.sm_icon(qlassik_ru('17')).' '.__('Gurpaga qo`shilish').'', '?gruppy='.$gruppy->id.'&iltimos');
}
}	
}
$doc->grp(__('Qaytish'), '?gruppy='.$gruppy->id.'');
exit;
}
	
	
	
	
	
if (isset($_GET ['chiqe'])){
	$doc->title = __('%s grupadan chiqarish', $gruppy->nomi);
if (mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_user` WHERE `user` = '".$user->id."' AND `id_gruppa` = '".$gruppy->id."' AND `admin` = '".$gruppy->admin."' AND `ak` = '3' "), 0)){	
//mysql_query("INSERT INTO `gruppa_user` (`id_gruppa`, `admin`, `user`, `time`, `ak`)
//VALUES ('" . $gruppy->id. "', '" . $gruppy->admin . "', '" . $user->id . "', '" . TIME . "', '3' )");	
mysql_query("DELETE FROM `gruppa_user` WHERE `user` = '".$user->id."' AND `id_gruppa` = '".$gruppy->id."' AND `admin` = '".$gruppy->admin."' AND `ak` = '3' ");
$doc->msg(__('Siz gurpadan chiqib ketdingiz'));
header("Location: ?gruppy=".$gruppy->id."");
}else{
$doc->err(__('Bu gurpada chiqish holati yo`q.'));
header("Location: ?gruppy=".$gruppy->id."");
}
}


if (isset($_GET ['iltimos'])){
	
if (!mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_user` WHERE `user` = '".$user->id."' AND `id_gruppa` = '".$gruppy->id."' AND `admin` = '".$gruppy->admin."' AND `ak` = '3' "), 0)){	
mysql_query("INSERT INTO `gruppa_user` (`id_gruppa`, `admin`, `user`, `time`, `ak`)
VALUES ('" . $gruppy->id. "', '" . $gruppy->admin . "', '" . $user->id . "', '" . TIME . "', '3' )");	
$doc->msg(__('Gurpaga qo`shildingiz'));
header("Location: ?gruppy=".$gruppy->id."");
}else{
$doc->err(__('Siz bu gurpaga qo`shilgansiz'));	
header("Location: ?gruppy=".$gruppy->id."");
}
}	
}



if ($user->id == $gruppy->admin){
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
if(!isset($_SESSION['timesd'])){
	$_SESSION['timesd']	= TIME;
	}
	$zaxw = $_SESSION['timesd'];
		if (TIME >= $zaxw);else{
		$doc->err(__('Qaytaddan urunib ko`ring'));
	}

	
		if (TIME >= $zaxw && isset($_GET['qoo']) || TIME >= $zaxw && isset($_GET['och'])){
	    
    	if (isset($_GET['kantak'])  &&  isset($_GET['kantakk'])){	
		$doc->err(__('Hakkerlik qilmang'));
		header('Refresh: 1; url=?');	
		exit;	
		}	

		if ($user->id == $gruppy->admin && isset($_GET['kantak'])  || $user->id == $gruppy->admin && isset($_GET['ide'])  ||  $user->id == $gruppy->admin && isset($_GET['online'])){
		  $use = new user($_GET['qoo']);
		  if (mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_user` WHERE `user` = '".$use->id."' AND `id_gruppa` = '".$gruppy->id."' AND `admin` = '".$gruppy->admin."' AND `ak` = '2' "), 0)){
				$doc->err(__('Do`stingiz oldin qo`shilgan'));	
				header('Refresh: 1; url=?');	
			}else{
mysql_query("INSERT INTO `gruppa_user` (`id_gruppa`, `admin`, `user`, `time`, `ak`)
VALUES ('" . $gruppy->id. "', '" . $gruppy->admin . "', '" . $use->id . "', '" . TIME . "', '2' )");
$use->gruppa = $use->gruppa + 1;
$_SESSION['timesd'] = TIME + 3;
       $doc->msg(__('Ofaring qo`shdingiz'));	

		}
		}
		
		if ($user->id == $gruppy->admin && isset($_GET['kantakk'])  || $user->id == $gruppy->admin && isset($_GET['idee'])  ||  $user->id == $gruppy->admin && isset($_GET['onlinee'])){
		  if (!mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_user` WHERE `user` = '".$_GET['och']."' AND `id_gruppa` = '".$gruppy->id."' AND `admin` = '".$gruppy->admin."' AND `ak` = '1' "), 0)){
		  if (mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_user` WHERE `user` = '".$_GET['och']."' AND `id_gruppa` = '".$gruppy->id."' AND `admin` = '".$gruppy->admin."' AND `ak` = '2' "), 0)){	
		  mysql_query("DELETE FROM `gruppa_user` WHERE `user` = '".$_GET['och']."' AND `id_gruppa` = '".$gruppy->id."' AND `admin` = '".$gruppy->admin."' AND `ak` = '2'");
		    $_SESSION['timesd'] = TIME + 3; 
		 $us = new user($_GET['och']); 
		 if (@$aktivmas->id == $_GET['och']){
		 $us->gruppa = $us->gruppa - 1;	 
		 }
		 
		 $doc->msg(__('O`chirildi'));
		  }else{
				$doc->err(__('Bu odam mavjud emas'));	
				header('Refresh: 1; url=?');				  
			  
		  }

			}else{
           mysql_query("DELETE FROM `gruppa_user` WHERE `user` = '".$_GET['och']."' AND `id_gruppa` = '".$gruppy->id."' AND `admin` = '".$gruppy->admin."' AND `ak` = '1'");		   
           $_SESSION['timesd'] = TIME + 3; 
		 $us = new user($_GET['och']); 
		 if ($aktivmas->id == $_GET['och']){
		 $us->gruppa = $us->gruppa - 1;	 
		 }
		 $doc->msg(__('O`chirildi'));			   
        }
		}	
	
		}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	if (isset($_GET ['kantak']) || isset($_GET ['kantakk'])){
		$doc->title = __('%s ga kontak orqali qo`shish', $gruppy->nomi);	
$sql_where = array("`mail`.`id_user` = '{$user->id}'");
if (isset($_GET ['xabar_keldi'])) {
    $sql_where[] = "`mail`.`is_read` = '0'";
}

$pages = new pages ();
$pages->posts = mysql_result(mysql_query("SELECT COUNT(DISTINCT(`mail`.`id_sender`)) FROM `mail` WHERE " . implode(' AND ', $sql_where)), 0); 
$pages->this_page(); 

$q = mysql_query("SELECT `users`.`id`,
        `mail`.`id_sender`,
        MAX(`mail`.`time`) AS `time`,
        MIN(`mail`.`is_read`) AS `is_read`,
        COUNT(`mail`.`id`) AS `count`
FROM `mail`
LEFT JOIN `users` ON `mail`.`id_sender` = `users`.`id`
WHERE " . implode(' AND ', $sql_where) . "
GROUP BY `mail`.`id_sender`
ORDER BY `time` DESC
LIMIT $pages->limit");

$listing = new listing();
while ($mail = mysql_fetch_assoc($q)) {
	$ank = new user((int)$mail['id_sender']);
    $kv = $listing->kv();
	if($ank->id){
     if ($user->id == $ank->id);else{
  $kv->image = $ank->getAva($doc->img_max_width());
    $kv->url = 'xabar?id=' . $ank->id;
    $kv->title = $ank->nick();
	$kv->admine = mailsoz($ank->id);
	$kv->time = mailtime($ank->id);
	  if (mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_user` WHERE `user` = '".$ank->id."' AND `id_gruppa` = '".$gruppy->id."' AND `admin` = '".$gruppy->admin."' AND `ak` = '1' "), 0)){
    $kv->action('delete', '?gruppy='.$gruppy->id.'&och='.$ank->id.'&kantakk');
	}else{
		if (mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_user` WHERE `user` = '".$ank->id."' AND `id_gruppa` = '".$gruppy->id."' AND `admin` = '".$gruppy->admin."' AND `ak` = '2' "), 0)){
	$kv->action('delete', '?gruppy='.$gruppy->id.'&och='.$ank->id.'&kantakk');
	}else{
	$kv->action('create', '?gruppy='.$gruppy->id.'&qoo='.$ank->id.'&kantak');			
		}
	}
}
}
}  



$listing->display(__('Xabarlar yo`q'));

$pages->display('?');
	$doc->dost(__('Xamma gurpalar'), '?');
	$doc->dost(__('Mening gruppalarim'), '?mening='.$gruppy->admin.'');		
    
	
	if ($user->id == $gruppy->admin){
$doc->grp(''.sm_icon(qlassik_ru('9')).' '.__('Azolar').'', '?gruppy='.$gruppy->id.'&azolar');		
$doc->grp(''.sm_icon(qlassik_ru('10')).' '.__('Foto biriktirish').'', '?gruppy='.$gruppy->id.'&surat');
$doc->grp(''.sm_icon(qlassik_ru('11')).' '.__('Ovoz biriktirish').'', '?gruppy='.$gruppy->id.'&ovoz');	
$doc->grp(''.sm_icon(qlassik_ru('12')).' '.__('Administrator qo`shish').'', '?gruppy='.$gruppy->id.'&admin');
$doc->grp(''.sm_icon(qlassik_ru('13')).' '.__('Sozlash').'', '?gruppy='.$gruppy->id.'&sozlash');
}else{
if($aktiv->id == $user->id){
if ($gruppy->zakrit == '1')$doc->grp(''.sm_icon(qlassik_ru('14')).' '.__('Do`stlar qo`shish').'', '?gruppy='.$gruppy->id.'&dostlar');		
$doc->grp(''.sm_icon(qlassik_ru('15')).' '.__('Gurpadan chiqish').'', '?gruppy='.$gruppy->id.'&chiqesh');
}else{
if(@$noak_b->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}elseif(@$azo_bol->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}else{
$doc->grp(''.sm_icon(qlassik_ru('17')).' '.__('Gurpaga qo`shilish').'', '?gruppy='.$gruppy->id.'&iltimos');
}
}	
}
$doc->grp(''.sm_icon(qlassik_ru('18')).' '.__('Qaytish').'', '?mening='.$gruppy->id.'');
$doc->grp(''.sm_icon(qlassik_ru('19')).' '.__('Gurpaga').'', '?gruppy='.$gruppy->id.'');

	
	exit;	
	}	
	if (isset($_GET ['ide']) || isset($_GET ['idee'])){
			$doc->title = __('%s ga id raqam orqali qo`shish', $gruppy->nomi);

	switch (@$_GET['order']) {
    case 'sum':
        $order = 'sum';
        $sort = 'DESC';
        $where = "WHERE `sum` > '0'";
        $doc->title = __('Puldorlar');
        break;
    case 'group':
        $order = 'group';
        $sort = 'DESC';
        $where = "WHERE `group` >= '2'";
        $doc->title = __('Mansobdorlar');
        break;
    case 'login':
        $order = 'login';
        $sort = 'ASC';
        $where = '';
        break;
    case 'balls':
        $order = 'balls';
        $sort = 'DESC';
        $where = '';
        break;
    case 'rating':
        $order = 'rating';
        $sort = 'DESC';
        $where = '';
        break;
    default:
        $order = 'id';
        $sort = 'DESC';
        $where = '';
        break;
}

if (!empty($_GET['search']))
    $search = text::input_text($_GET['search']);
if (isset($search) && !$search)
    $doc->err(__('Malumot yo`q'));
elseif (isset($search) && $search) {
    $where = "WHERE `login` LIKE '%" . my_esc($search) . "%'";
    $doc->title = __('Izlash по запросу "%s"', $search);
}

$posts = array();
$pages = new pages;
$pages->posts = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` $where"), 0);

$ord = array();
$ord[] = array("?order=id&amp;page={$pages->this_page}" . (isset($search) ? '&amp;search=' . urlencode($search) : ''), __('ID fodalanuvchiniki'), $order == 'id');
$ord[] = array("?order=login&amp;page={$pages->this_page}" . (isset($search) ? '&amp;search=' . urlencode($search) : ''), __('Login'), $order == 'login');
$ord[] = array("?order=rating&amp;page={$pages->this_page}" . (isset($search) ? '&amp;search=' . urlencode($search) : ''), __('Reytin'), $order == 'rating');
$ord[] = array("?order=balls&amp;page={$pages->this_page}" . (isset($search) ? '&amp;search=' . urlencode($search) : ''), __('Ball'), $order == 'balls');
$ord[] = array("?order=group&amp;page={$pages->this_page}" . (isset($search) ? '&amp;search=' . urlencode($search) : ''), __('Mansobdorlar'), $order == 'group');
$ord[] = array("?order=sum&amp;page={$pages->this_page}" . (isset($search) ? '&amp;search=' . urlencode($search) : ''), __('Boylar'), $order == 'sum');
$or = new design();
$or->assign('order', $ord);
$or->display('fv.order.tpl');

$q = mysql_query("SELECT `id` FROM `users` $where ORDER BY `$order` " . $sort . " LIMIT " . $pages->limit);

$listing = new listing();
if ($order == 'sum') {
    $post = $listing->post();
    $post->url = '?info=donate';
    $post->title = __('Qaytish');
    $post->hightlight = true;
    $post->icon('donate');
}

while ($ank = mysql_fetch_assoc($q)) {
    $p_user = new user($ank['id']);
	if($p_user->id){
    $kv = $listing->kv();
   if ($user->id == $p_user->id);else{
   $kv->url = '/ID'.$p_user->id.'';
    $kv->image = $p_user->getAva($doc->img_max_width());
    $kv->title = $p_user->nick();
    $kv->time = misc::when($p_user->last_visit);
    $kv->admine = ''.stsID($p_user->id).'';
  if (mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_user` WHERE `user` = '".$p_user->id."' AND `id_gruppa` = '".$gruppy->id."' AND `admin` = '".$gruppy->admin."' AND `ak` = '1' "), 0)){
	$kv->action('delete', '?gruppy='.$gruppy->id.'&och='.$p_user->id.'&idee');
	}else{
	$kv->action('create', '?gruppy='.$gruppy->id.'&qoo='.$p_user->id.'&ide');
	}
   
    switch ($order) {
        case 'id':
            $kv->content[] = '[b]' . __('ID fodalanuvchiniki') . ': ' . $p_user->id . '[/b]';
            break;
        case 'group':
            $kv->content[] = '[b]' . __($p_user->group_name) . '[/b]';
            break;
        case 'rating':
            $kv->content[] = '[b]' . __('Reytin') . ': ' . $p_user->rating . '[/b]';
            break;
        case 'balls':
            $kv->content[] = '[b]' . __('Ball') . ': ' . ((int)$p_user->balls) . '[/b]';
            break;
        case 'sum':
            $kv->content[] = '[b]' . __('Sum: %s sum.', $p_user->sum) . '[/b]';
            break;
    }

    $kv->content[] = '[small]' . __('Ro`yxatdan otilgan vaqti') . ': ' . date('d-m-Y', $p_user->reg_date) . '[/small]';
    $kv->content[] = '[small]' . __('Oxiri saytga kirgan vaqti') . ': ' . misc::when($p_user->last_visit) . '[/small]';
   }
}
	}
$fv = new fv('?', false);
$fv->hidden('order', $order);
$fv->text('search', __('Nickni yozin'), @$search, false);
$fv->button(__('Izlash'));
$fv->display();

$listing->display($order == 'sum' ? __('Azolar xolati') : __('Azolar yo`q'));

$pages->display("?order=$order&amp;" . (isset($search) ? 'search=' . urlencode($search) . '&amp;' : '')); 
$doc->dost(__('Xamma gurpalar'), '?');
	$doc->dost(__('Mening gruppalarim'), '?mening='.$gruppy->admin.'');		
    
	
	if ($user->id == $gruppy->admin){
$doc->grp(''.sm_icon(qlassik_ru('9')).' '.__('Azolar').'', '?gruppy='.$gruppy->id.'&azolar');		
$doc->grp(''.sm_icon(qlassik_ru('10')).' '.__('Foto biriktirish').'', '?gruppy='.$gruppy->id.'&surat');
$doc->grp(''.sm_icon(qlassik_ru('11')).' '.__('Ovoz biriktirish').'', '?gruppy='.$gruppy->id.'&ovoz');	
$doc->grp(''.sm_icon(qlassik_ru('12')).' '.__('Administrator qo`shish').'', '?gruppy='.$gruppy->id.'&admin');
$doc->grp(''.sm_icon(qlassik_ru('13')).' '.__('Sozlash').'', '?gruppy='.$gruppy->id.'&sozlash');
}else{
if($aktiv->id == $user->id){
if ($gruppy->zakrit == '1')$doc->grp(''.sm_icon(qlassik_ru('14')).' '.__('Do`stlar qo`shish').'', '?gruppy='.$gruppy->id.'&dostlar');		
$doc->grp(''.sm_icon(qlassik_ru('15')).' '.__('Gurpadan chiqish').'', '?gruppy='.$gruppy->id.'&chiqesh');
}else{
if(@$noak_b->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}elseif(@$azo_bol->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}else{
$doc->grp(''.sm_icon(qlassik_ru('17')).' '.__('Gurpaga qo`shilish').'', '?gruppy='.$gruppy->id.'&iltimos');
}
}	
}
$doc->grp(''.sm_icon(qlassik_ru('18')).' '.__('Qaytish').'', '?mening='.$gruppy->id.'');
$doc->grp(''.sm_icon(qlassik_ru('19')).' '.__('Gurpaga').'', '?gruppy='.$gruppy->id.'');
exit;		
	}	
	if (isset($_GET ['online'])  || isset($_GET ['onlinee']) ){
			$doc->title = __('%s ga onlayndagilarni qo`shish', $gruppy->nomi);
	$pages = new pages(mysql_result(mysql_query("SELECT COUNT(*) FROM `users_online`"), 0));
$listing = new listing();
$q = mysql_query("SELECT `users_online`.* , `browsers`.`name` AS `browser`
 FROM `users_online`
 LEFT JOIN `browsers`
 ON `users_online`.`id_browser` = `browsers`.`id`
 ORDER BY `users_online`.`time_login` DESC LIMIT " . $pages->limit);

while ($p_user = mysql_fetch_assoc($q)) {

$ank = new user($p_user['id_user']);
    $kv = $listing->kv();
	if($ank->id){
  if ($user->id == $ank->id);else{
	
  $kv->image = $ank->getAva($doc->img_max_width());
    $kv->url = 'xabar?id=' . $ank->id;
    $kv->title = $ank->nick();
	$kv->admine = stsID($ank->id);
	$kv->time = mailtime($ank->id);
if (mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_user` WHERE `user` = '".$ank->id."' AND `id_gruppa` = '".$gruppy->id."' AND `ak` = '2' "), 0))
    {
		  $kv->action('delete', '?gruppy='.$gruppy->id.'&och='.$ank->id.'&onlinee');
	}else{
	$kv->action('create', '?gruppy='.$gruppy->id.'&qoo='.$ank->id.'&online');
	}
    }
    }
	}


     $listing->display(__('Ro`yhat bo`sh'));
     $pages->this_page();
     $pages->display('?');



	$doc->dost(__('Xamma gurpalar'), '?');
	$doc->dost(__('Mening gruppalarim'), '?mening='.$gruppy->admin.'');		
    
	
	if ($user->id == $gruppy->admin){
$doc->grp(''.sm_icon(qlassik_ru('9')).' '.__('Azolar').'', '?gruppy='.$gruppy->id.'&azolar');	
$doc->grp(''.sm_icon(qlassik_ru('10')).' '.__('Foto biriktirish').'', '?gruppy='.$gruppy->id.'&surat');	
$doc->grp(''.sm_icon(qlassik_ru('11')).' '.__('Ovoz biriktirish').'', '?gruppy='.$gruppy->id.'&ovoz');	
$doc->grp(''.sm_icon(qlassik_ru('12')).' '.__('Administrator qo`shish').'', '?gruppy='.$gruppy->id.'&admin');
$doc->grp(''.sm_icon(qlassik_ru('13')).' '.__('Sozlash').'', '?gruppy='.$gruppy->id.'&sozlash');
}else{
if($aktiv->id == $user->id){
if ($gruppy->zakrit == '1')$doc->grp(''.sm_icon(qlassik_ru('14')).' '.__('Do`stlar qo`shish').'', '?gruppy='.$gruppy->id.'&dostlar');		
$doc->grp(''.sm_icon(qlassik_ru('15')).' '.__('Gurpadan chiqish').'', '?gruppy='.$gruppy->id.'&chiqesh');
}else{
if(@$noak_b->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}elseif(@$azo_bol->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}else{
$doc->grp(''.sm_icon(qlassik_ru('17')).' '.__('Gurpaga qo`shilish').'', '?gruppy='.$gruppy->id.'&iltimos');
}
}	
}
$doc->grp(''.sm_icon(qlassik_ru('18')).' '.__('Qaytish').'', '?mening='.$gruppy->id.'');
$doc->grp(''.sm_icon(qlassik_ru('19')).' '.__('Gurpaga').'', '?gruppy='.$gruppy->id.'');

	
	exit;		
	}		
		
		
	
}

?><style>
#gurpa_rasim_qlassik_ru{
width: 60px;
height: 60px;	
}
#gurpa_nomi_qlassik_ru{
font-size: 90%;
color: green;
display: block !important;
margin-top: -15px;
}
#gurpa_admin_qlassik_ru{
font-size: 70%;
color: green;
display: block !important;
margin-top: -20px;
}


#qani_k{
    margin: 12px;
}
#sur{
display: block !important;
margin-left: 5px;	
margin-top: -5px;
font-size: 60%;
}
#sura{
display: block !important;
margin-top: -5px;
font-size: 60%;
background: #fbfcfd;
border: 1px solid #f1f1f1;
min-width: 120px;
max-width: 160px;
}
.cc_v{
    display: inline-block;
    min-width: 10px;
    padding: 2px 5px;
	margin-top: 2px;
    font-size: 10px;
    font-weight: 700;
    line-height: 1;
    color: #fff;
    text-align: center;
    white-space: nowrap;
    vertical-align: middle;
    background-color: green;
    border-radius: 10px;	
}

#gurpa_matn_qlassik_ru span{
font-size: 15px;
color: green;
display: block !important;
margin: 2px;
padding: 4px;
height:290px;
}

.video_qlasik_ru span{
	position:relative;
	padding-bottom:56.25%;
	padding-top:30px;
	height:0;
	overflow:hidden;
}

.video_qlasik_ru iframe span, .video_qlasik_ru object span, .video_qlasik_ru embed span {
	position:absolute;
	top:0;
	left:0;
	width:100%;
	height:300px;
}
#gurpa_matn_qlassik_ru_x{
font-size: 15px;
color: green;
display: block !important;
margin: 2px;
padding: 4px;
}



</style><?
$as_admin = new user($gruppy->admin);


echo '<div id="qani"><table width="100%" border="0">
<tr>
<td style="width: 70px;"> <img id="gurpa_rasim_qlassik_ru" src="/files/.gruppy/'.$gruppy->rasim.'" title="voo.uz" alt="voo.uz" /> </td>
<td> <span id="gurpa_nomi_qlassik_ru"> '.$gruppy->nomi.' </span> <br />
<span id="gurpa_admin_qlassik_ru"> <span style="color: red;">'.__('admin').':</span> '.$as_admin->nick().' </span></td>
</tr>
</table></div>';
echo '<div id="qani">';
if (md5(text::toOutput($gruppy->matn)) == md5($gruppy->matn)){
 echo '<div id="gurpa_matn_qlassik_ru_x">'.sm_icon(text::toOutput($gruppy->matn)).'</div>';
}else{
 echo '<div id="gurpa_matn_qlassik_ru">'.sm_icon(text::toOutput($gruppy->matn)).'</div>';	
}
echo '</div>';
$on = '1';
echo '<div id="qani_k"><table width="100%" border="0">
<tr>
<td id="sura">
&nbsp;  <span class="cc_v">    '.$gruppy->yomon.' </span>  <img src="/img/zor.png" title=" ('.$gruppy->zor.') " alt="voo.uz" /> 
 <img src="/img/yomon.png" title=" ('.$gruppy->yomon.') " alt="voo.uz" /> &nbsp;  <span class="cc_v">    '.$gruppy->zor.' </span> 
   &nbsp;  &nbsp;  &nbsp;  &nbsp;  <img src="/img/external.png" title="  ( '.$on.' )" alt="voo.uz" />&nbsp;  <span class="cc_v">    '.$on.' </span> 
</td>
<td id="sur">
<span style="font-size: 60%; float:right; clear:left; display: block !important; margin: 5px; margin-top: -19px;"> <ul class="unit-rating">
		<li class="current-rating" style="width:0%;">0</li>
		<li><a href="?gruppy='.$gruppy->id.'&baxo=1" title="'.__('Juda yomon').'" class="r1-unit" onclick="doRate(&#39;1&#39;, &#39;1&#39;); return false;">1</a></li>
		<li><a href="?gruppy='.$gruppy->id.'&baxo=2" title="'.__('Chidasa boladi').'" class="r2-unit" onclick="doRate(&#39;2&#39;, &#39;1&#39;); return false;">2</a></li>
		<li><a href="?gruppy='.$gruppy->id.'&baxo=3" title="'.__('Qoniqarli').'" class="r3-unit" onclick="doRate(&#39;3&#39;, &#39;1&#39;); return false;">3</a></li>
		<li><a href="?gruppy='.$gruppy->id.'&baxo=4" title="'.__('Yahshi').'" class="r4-unit" onclick="doRate(&#39;4&#39;, &#39;1&#39;); return false;">4</a></li>
		<li><a href="?gruppy='.$gruppy->id.'&baxo=5" title="'.__('Zo`r').'" class="r5-unit" onclick="doRate(&#39;5&#39;, &#39;1&#39;); return false;">5</a></li>
</ul></span>
</td>
</tr>
</table></div>';
$lenta = mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_lenta` WHERE `id_gruppa` = '".$gruppy->id."' AND `admin` = '".$gruppy->admin."'"), 0);
$mehmon = mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_mexmon` WHERE `id_gruppa` = '".$gruppy->id."' AND `admin` = '".$gruppy->admin."' AND `time` = '".time()." - 180'"), 0);
$albom =  mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_albom` WHERE `id_gruppa` = '".$gruppy->id."' AND `admin` = '".$gruppy->admin."'"), 0);
$mp3 =  mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_mp3` WHERE `id_gruppa` = '".$gruppy->id."' AND `admin` = '".$gruppy->admin."'"), 0);
$video =  mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_video` WHERE `id_gruppa` = '".$gruppy->id."' AND `admin` = '".$gruppy->admin."'"), 0);
$kitob =  mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_kitob` WHERE `id_gruppa` = '".$gruppy->id."' AND `admin` = '".$gruppy->admin."'"), 0);
$kitob_m =  mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_kitob_varaq` WHERE `id_gruppa` = '".$gruppy->id."' AND `admin` = '".$gruppy->admin."'"), 0);
$forum =  mysql_result(mysql_query("SELECT COUNT(*) FROM `forum_topics` WHERE `id_gruppa` = '".$gruppy->id."' AND `admin` = '".$gruppy->admin."'"), 0);
$forum_m =  mysql_result(mysql_query("SELECT COUNT(*) FROM `forum_themes` WHERE `id_gruppa` = '".$gruppy->id."' AND `admin` = '".$gruppy->admin."'"), 0);
$igri =  mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_igra` WHERE `id_gruppa` = '".$gruppy->id."' AND `admin` = '".$gruppy->admin."'"), 0);

echo'<div id="qani">';
echo'<div  class="gruppa" role="alert"><a href="?gruppy='.$gruppy->id.'&lenta"> '.sm_icon(qlassik_ru('8')).' '.__('Lenta').' <span style="float:right; clear:left;" class="strike_k">  ( '.$lenta.' ) </span></a>  </div>';
echo'<div  class="gruppa" role="alert"><a href="?gruppy='.$gruppy->id.'&mexmon"> '.sm_icon(qlassik_ru('1')).' '.__('Mehmon xona').' <span style="float:right; clear:left;" class="strike_k">  ( '.$mehmon.' ) </span></a>  </div>';
echo'<div  class="gruppa" role="alert"><a href="?gruppy='.$gruppy->id.'&albom"> '.sm_icon(qlassik_ru('2')).' '.__('Albo`m').' <span style="float:right; clear:left;" class="strike_k">  ( '.$albom.' ) </span></a>  </div>';
echo'<div  class="gruppa" role="alert"><a href="?gruppy='.$gruppy->id.'&mp3lar"> '.sm_icon(qlassik_ru('3')).' '.__('Mp3lar').' <span style="float:right; clear:left;" class="strike_k">  ( '.$mp3.' ) </span></a>  </div>';
echo'<div  class="gruppa" role="alert"><a href="?gruppy='.$gruppy->id.'&videolar"> '.sm_icon(qlassik_ru('4')).' '.__('Videolar').' <span style="float:right; clear:left;" class="strike_k">  ( '.$video.' ) </span></a>  </div>';
echo'<div  class="gruppa" role="alert"><a href="?gruppy='.$gruppy->id.'&kitob"> '.sm_icon(qlassik_ru('5')).' '.__('Kitoblar').' <span style="float:right; clear:left;" class="strike_k">  ( '.$kitob.' / '.$kitob_m.' ) </span></a>  </div>';
echo'<div  class="gruppa" role="alert"><a href="?gruppy='.$gruppy->id.'&forum"> '.sm_icon(qlassik_ru('6')).' '.__('Forum').' <span style="float:right; clear:left;" class="strike_k">  ( '.$forum.' / '.$forum_m.' ) </span></a>  </div>';
echo'<div  class="gruppa" role="alert"><a href="?gruppy='.$gruppy->id.'&oyinlar"> '.sm_icon(qlassik_ru('7')).' '.__('O`yinlar').' <span style="float:right; clear:left;" class="strike_k">  ( '.$igri.' ) </span></a>  </div>';
echo'</div>';














if ($user->id == $gruppy->admin){
$doc->grp(''.sm_icon(qlassik_ru('20')).' '.__('Azo qo`shish').'', '?mening='.$gruppy->id.'');		
$doc->grp(''.sm_icon(qlassik_ru('10')).' '.__('Foto biriktirish').'', '?gruppy='.$gruppy->id.'&surat');
$doc->grp(''.sm_icon(qlassik_ru('11')).' '.__('Ovoz biriktirish').'', '?gruppy='.$gruppy->id.'&ovoz');	
$doc->grp(''.sm_icon(qlassik_ru('12')).' '.__('Administrator qo`shish').'', '?gruppy='.$gruppy->id.'&admin');
$doc->grp(''.sm_icon(qlassik_ru('13')).' '.__('Sozlash').'', '?gruppy='.$gruppy->id.'&sozlash');
}else{
if($aktiv->id == $user->id){
if ($gruppy->zakrit == '1')$doc->grp(''.sm_icon(qlassik_ru('14')).' '.__('Do`stlar qo`shish').'', '?gruppy='.$gruppy->id.'&dostlar');		
$doc->grp(''.sm_icon(qlassik_ru('15')).' '.__('Gurpadan chiqish').'', '?gruppy='.$gruppy->id.'&chiqesh');
}else{
if(@$noak_b->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}elseif(@$azo_bol->id == $user->id){	
$doc->grp(''.sm_icon(qlassik_ru('16')).' '.__('Kutib turing (chiqish)').'', '?gruppy='.$gruppy->id.'&chiqe');
}else{
$doc->grp(''.sm_icon(qlassik_ru('17')).' '.__('Gurpaga qo`shilish').'', '?gruppy='.$gruppy->id.'&iltimos');
}
}	
}
$doc->grp(''.sm_icon(qlassik_ru('18')).' '.__('Qaytish').'', '?mening='.$gruppy->id.'');
exit;






}

if(isset($_GET['ocha'])){
$doc->title = __('GRUPPA YARATISH');	
if ($_GET['ocha'] == 'ok'){
	
if (mysql_result(mysql_query("SELECT COUNT(`id`) FROM `gruppa` WHERE `admin` = '".$user->id."' AND `time` > '".(time()-85000)."' LIMIT 1"),0)!=0){	
	
$doc->err(__('GRUPPA YARATILMADI SIZ 1 KUNDAN KEGIN HARAKAT QILIN!'));	

}else{
mysql_query("INSERT INTO `gruppa` (`admin`, `nomi`, `matn`, `ak`, `time`) VALUES ('" .$user->id . "', '" . my_esc($_POST['nomi']) . "', '" . my_esc($_POST['matn']) . "', '".$_POST['ak']."', '" . TIME . "')");
$sa = mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa` "), 0);
$idi = $sa + 1;
mysql_query("INSERT INTO `gruppa_user` (`id_gruppa`, `admin`, `user`, `ak`, `time`) VALUES ('" .$idi. "', '" .$user->id . "', '" . $user->id . "', '1', '" . TIME . "')");
mysql_query("INSERT INTO `gruppa_lenta` (`id_gruppa`, `admin`, `matn`, `time`) VALUES ('" .$idi. "', '" .$user->id . "', '" . my_esc($_POST['matn']) . "', '" . TIME . "')");
$doc->msg(__('GRUPPA YARATIDI!'));
header('Refresh: 1; url=?mening='.$user->id.'');
exit;
}	
}
if (mysql_result(mysql_query("SELECT COUNT(`id`) FROM `gruppa` WHERE `admin` = '".$user->id."' AND `time` > '".(time()-85000)."' LIMIT 1"),0)!=0){
$doc->err(__('GRUPPA YARATISH UCHUN SIZ 1 KUN KUTING!'));		
	
$doc->grp(__('Qaytish'), '?');
$doc->dost(__('Mening gruppalarim'), '?mening='.$user->id.'');	
exit;	
}


$fv = new fv('?ocha=ok&' . passgen());
$fv->text('nomi', __('Nomi'));
$fv->textarea('matn', __('Izoh matni'));
$fv->checkbox('ak', __('Yopiq bo`lsinmi'));
$fv->button(__('Saqlash'), 'save');
$fv->display();
$doc->grp(__('Qaytish'), '?');
$doc->dost(__('Mening gruppalarim'), '?mening='.$user->id.'');	
exit;	
}
if(isset($_GET['mening'])){
$gruppy = new user($_GET ['mening']);
if(!$gruppy->id){
	$doc->err(__('Bunday azo ro`yhatdan o`tmagan'));	
 	$doc->dost(__('Gruppa ochish'), '?ocha');
    $doc->dost(__('Mening gruppalarim'), '?mening='.$user->id.'');
	$doc->grp(__('Qaytish'), '?');
	exit;
}	
	
	
if ($user->id == $gruppy->id){
$doc->title = __('MENING GRUPPALARIM');	
}else{
$doc->title = __('%s grupalari', $gruppy->title);	
}

$pages = new pages(mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa` WHERE `admin` = '".$gruppy->id."' "), 0));
$listing = new listing();
$q = mysql_query("SELECT * FROM `gruppa` WHERE `admin` = '".$gruppy->id."' ORDER BY `time` DESC LIMIT ".$pages->limit);
while ($gruppa= mysql_fetch_assoc($q)) {
$gruppy = new user($gruppa['admin']);
$kv = $listing->kv();
$kv->url = '?gruppy='.$gruppa['id'];
if ($gruppa['rasim']){
$kv->image = '/files/.gruppy/'.$gruppa['rasim'];
}else{
$kv->image = $gruppy->getAva($doc->img_max_width());	
}
$kv->title = smiles(text::toOutput($gruppa['nomi']));
$yukla = mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_user` WHERE `id_gruppa` = '".$gruppa['id']."' AND `admin` = '".$gruppa['admin']."' AND `ak` = '1'"), 0);
 mysql_query("UPDATE `gruppa` SET  `odam`= '".$yukla."' WHERE `id` = '".$gruppa['id']."'");
            
$kv->mehmon = '<a href="?gruppy='.$gruppa['id'].'&azolar" title="voo.uz"><span style="font-size: 75%;">'.('Do`stlar').' <b style="color: green;">( '.mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_user` WHERE `id_gruppa` = '".$gruppa['id']."' AND `admin` = '".$gruppa['admin']."' AND `ak` = '1'"), 0).'</b> /  <b style="color: red;">'.mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_user` WHERE `id_gruppa` = '".$gruppa['id']."' AND `admin` = '".$gruppa['admin']."' AND `ak` = '2'"), 0).')</b></span></a>';
$kv->time = misc::when($gruppa['time']);
if (md5(text::toOutput($gruppa['matn'])) == md5($gruppa['matn'])){
$kv->admine = smiles(text::toOutput($gruppa['matn']));	
}else{
$kv->admine = '<img style="" src="/img/music_disable.png" title="voo.uz" /> '.__('Multimediya qo`yilgan').'';
}
if ($user->id == $gruppy->id){
$kv->action('settings.reg', '?gruppy='.$gruppa['id'].'&kantak');
$kv->action('nns', '');	
$kv->action('pro.support', '?gruppy='.$gruppa['id'].'&online');	
$kv->action('nns', '');	
$kv->action('search', '?gruppy='.$gruppa['id'].'&ide');
 
 } else{
$kv->hightlight = '<span style="font-size: 80%;">'.$gruppy->title_g.'</span>';		
}

 }

$listing->display(__('Ro`yhat bo`sh'));
$pages->this_page();
$pages->display('?');
$doc->dost(__('Gruppa ochish'), '?ocha');
$doc->dost(__('Xamma gurpalar'), '?');	

$doc->grp(__('Qaytish'), '?');

exit;	
}
$pages = new pages(mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa`"), 0));
$listing = new listing();
$q = mysql_query("SELECT * FROM `gruppa` WHERE `id` ORDER BY `odam` DESC LIMIT ".$pages->limit);
while ($gruppa= mysql_fetch_assoc($q)) {
$gruppy = new user($gruppa['admin']);
$kv = $listing->kv();
$kv->url = '?gruppy='.$gruppa['id'];
if ($gruppa['rasim']){
$kv->image = '/files/.gruppy/'.$gruppa['rasim'];
}else{
$kv->image = $gruppy->getAva($doc->img_max_width());	
}

$kv->title = smiles(text::toOutput($gruppa['nomi']));
$kv->mehmon = '<a href="?gruppy='.$gruppa['id'].'&azolar" title="voo.uz"><span style="font-size: 75%;">'.('Do`stlar').' <b style="color: green;">( '.mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_user` WHERE `id_gruppa` = '".$gruppa['id']."' AND `admin` = '".$gruppa['admin']."' AND `ak` = '1'"), 0).'</b> /  <b style="color: red;">'.mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_user` WHERE `id_gruppa` = '".$gruppa['id']."' AND `admin` = '".$gruppa['admin']."' AND `ak` = '2'"), 0).')</b></span></a>';
$kv->time = misc::when($gruppa['time']);
if (md5(text::toOutput($gruppa['matn'])) == md5($gruppa['matn'])){
$kv->admine = smiles(text::toOutput($gruppa['matn']));	
}else{
$kv->admine = '<img style="" src="/img/music_disable.png" title="voo.uz" /> '.__('Multimediya qo`yilgan').'';
}
if ($user->id == $gruppy->id){
$kv->action('settings.reg', '?gruppy='.$gruppy->id.'&kantak');
$kv->action('nns', '');	
$kv->action('pro.support', '?gruppy='.$gruppy->id.'&online');	
$kv->action('nns', '');	
$kv->action('search', '?gruppy='.$gruppy->id.'&ide');	
}else{
$kv->hightlight = '<span style="font-size: 80%;">'.sm_nick(text::toOutput($gruppy->title)).'</span>';		
} 

 }

$listing->display(__('Ro`yhat bo`sh'));
$pages->this_page();
$pages->display('?');
$doc->dost(__('Gruppa ochish'), '?ocha');
$doc->dost(__('Mening gruppalarim'), '?mening='.$user->id.'');
?>