<?php

include_once '../sys/inc/yadro.php';
admin::check_access();
$doc = new document(5);
$doc->title = __('Asosiy sozlamalar');
$languages = languages::getList();

$browser_types = array('mobilni','planshet', 'androit', 'komp');

if (isset($_POST ['save'])) {
$uzcms->xiz_1 = $_POST ['xiz_1'];
$uzcms->xiz_2 = $_POST ['xiz_2'];
$uzcms->xiz_3 = $_POST ['xiz_3'];
$uzcms->xiz_4 = $_POST ['xiz_4'];
$uzcms->xiz_5 = $_POST ['xiz_5'];
$uzcms->mo_1 = $_POST ['mo_1'];
$uzcms->mo_2 = $_POST ['mo_2'];
$uzcms->mo_3 = $_POST ['mo_3'];
$uzcms->mo_4 = $_POST ['mo_4'];
$uzcms->mo_5 = $_POST ['mo_5'];	
$uzcms->xiz_11 = $_POST ['xiz_11'];
$uzcms->xiz_12 = $_POST ['xiz_12'];
$uzcms->xiz_13 = $_POST ['xiz_13'];
$uzcms->xiz_14 = $_POST ['xiz_14'];
$uzcms->xiz_15 = $_POST ['xiz_15'];
$uzcms->mo_11 = $_POST ['mo_11'];
$uzcms->mo_12 = $_POST ['mo_12'];
$uzcms->mo_13 = $_POST ['mo_13'];
$uzcms->mo_14 = $_POST ['mo_14'];
$uzcms->mo_15 = $_POST ['mo_15'];	
    $uzcms->save_settings($doc);
}


$form = new form('?' . passgen());
$form->text('xiz_1', __('Xizmatlar nomi 1'), $uzcms->xiz_1);
$form->text('xiz_11', __('Xizmatlar 1'), $uzcms->xiz_1);

$form->text('xiz_2', __('Xizmatlar nomi 2'), $uzcms->xiz_2);
$form->text('xiz_12', __('Xizmatlar 2'), $uzcms->xiz_2);

$form->text('xiz_3', __('Xizmatlar nomi 3'), $uzcms->xiz_3);
$form->text('xiz_13', __('Xizmatlar 3'), $uzcms->xiz_3);

$form->text('xiz_4', __('Xizmatlar nomi 4'), $uzcms->xiz_4);
$form->text('xiz_14', __('Xizmatlar 4'), $uzcms->xiz_4);

$form->text('xiz_5', __('Xizmatlar nomi 5'), $uzcms->xiz_5);
$form->text('xiz_15', __('Xizmatlar 5'), $uzcms->xiz_5);


$form->text('mo_1', __('Modullar  nomi 1'), $uzcms->mo_1);  
$form->text('mo_11', __('Modullar 1'), $uzcms->mo_1);

$form->text('mo_2', __('Modullar  nomi 2'), $uzcms->mo_2);
$form->text('mo_12', __('Modullar 2'), $uzcms->mo_2);

$form->text('mo_3', __('Modullar  nomi 3'), $uzcms->mo_3);
$form->text('mo_13', __('Modullar 3'), $uzcms->mo_3);

$form->text('mo_4', __('Modullar  nomi 4'), $uzcms->mo_4);
$form->text('mo_14', __('Modullar 4'), $uzcms->mo_4);

$form->text('mo_5', __('Modullar  nomi 5'), $uzcms->mo_5);
$form->text('mo_15', __('Modullar 5'), $uzcms->mo_5);

$form->button(__('Saqlash'), 'save');
$form->display();


?>
