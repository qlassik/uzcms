<?php

include_once '../sys/inc/yadro.php';
$doc = new document(2);
$doc->title = __('Manba');

$user_actions = new menu('user_actions');

if (isset($_GET['id']))
    $ank = new user($_GET['id']);
else
    $ank = $user;

if (!$ank->group) {
    if (isset($_GET['return']))
        header('Refresh: 1; url=' . $_GET['return']);
    else
        header('Refresh: 1; url=/');
    $doc->err(__('Malumot yo`q'));
    exit;
}

$doc->title .= ' "' . $ank->title . '"';

$user_actions->value_add('id', $ank->id);

if ($ank->group >= $user->group) {
    if (isset($_GET['return'])) {
        header('Refresh: 1; url=' . $_GET['return']);
    } else {
        header('Refresh: 1; url=/');
    }

    $doc->err(__('Sizni mansabingiz bilan bog`lana olmaymiz'));

    exit;
}

$user_actions->display();

$doc->ret(__('Anketa "%s"', $ank->title), '/ID' . $ank->id);

?>
