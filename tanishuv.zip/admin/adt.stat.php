<?php

include_once '../sys/inc/yadro.php';
$doc = new document(5);
$doc->title = __('Informatsa');
$browser_types = array('mobilni','planshet', 'androit', 'komp');


if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Refresh: 1; url=adt.settings.php');
    $doc->ret(__('Reklamma и banerы'), 'adt.php');
    
    $doc->err(__('Tollanish turida xato mavjud'));
    exit;
}
$id_adt = (int) $_GET['id'];

$q = mysql_query("SELECT * FROM `advertising` WHERE `id` = '$id_adt'");

if (!mysql_num_rows($q)) {
    header('Refresh: 1; url=adt.php?id=' . $id_adt);
    $doc->ret('<img src="/img/answer.png"> '.__('Orqaga qaytish'), 'adt.php?id=' . $id_adt);
    $doc->ret(__('Reklamma и banerы'), 'adt.php');
    
    $doc->err(__('Reklamma bu turda yo`q'));
    exit;
}

$adt = mysql_fetch_assoc($q);


$listing = new listing();

$post = $listing->post();
$post->icon('adt');
$post->title = text::toValue($adt['name']);
$post->hightlight = true;


if ($adt['time_create']) {
    $post = $listing->post();
    $post->title = __('Qo`shilgan vaqti');
    $post->content = misc::when($adt['time_create']);
}

$post = $listing->post();
$post->title = __('Ko`rsatish vaqti');
if (!$adt['time_start']) {
    $post->content = __('Malumot yo`q');
} elseif ($adt['time_start'] > TIME) {
    $post->hightlight = true;
    $post->content = misc::when($adt['time_start']);
} else {
    $post->content = misc::when($adt['time_start']);
}

$post = $listing->post();
$post->title = __('Tugash vaqti');
if (!$adt['time_end'])
    $post->content = __('Abadiy');
else
    $post->content = misc::when($adt['time_end']);

$listing->display();


$listing = new listing();
$post = $listing->post();
$post->title = __('Vaqtinchalik');
$post->icon('info');
$post->hightlight = true;

foreach ($browser_types AS $b_type) {
    $key = 'count_show_' . $b_type;
    $post = $listing->post();
    $post->title = strtoupper($b_type);
    $post->content = __('%s korsatil' . misc::number($adt[$key], '', 'yapti', 'di'), $adt[$key]);
}

$listing->display();


$listing = new listing();
$post = $listing->post();
$post->title = __('O`tishlar');
$post->icon('info');
$post->hightlight = true;

foreach ($browser_types AS $b_type) {
    $key = 'count_out_' . $b_type;
    $post = $listing->post();
    $post->title = strtoupper($b_type);
    $post->content = __('%s ko`rsatil' . misc::number($adt[$key], '', 'yapdi', 'di'), $adt[$key]);
}

$listing->display();


$doc->ret(__('Orqaga qaytish'), "adt.php?id=$adt[space]");
$doc->ret(__('Reklamma'), 'adt.php');

?>
