<?php
include_once '../sys/inc/yadro.php';
admin::check_access();
$doc = new document(6);
$doc->title = __('Bo`limlar sozlamasi');

if (isset($_GET['soz'])){
$idga = (int) $_GET['soz'];	
if (isset($_GET['sozi'])){
if ($_GET['sozi'] == 'ok'){


if ($_POST['bolimlarga'] == $_GET['soz']){
$bolimlarga = '';
$manzil = $_SESSION['manzil'];	
}else{
$bolimlarga = $_POST['bolimlarga'];	
if (isset($_POST['bolimlarga'])){
$manzil = ''.bolim_sisilka($_POST['bolimlarga']).''.$_SESSION['manzil'].'';	
}else{
$manzil = $_SESSION['manzil'];		
}
}

mysql_query("UPDATE `bolimlarga` SET `nomi` = '".$_POST['nomi']."', `manzil` = '".$manzil."', `style` = '".$_POST['style']."', `bolimlarga` = '".$bolimlarga."', `gogle` = '".$_POST['gogle']."'  WHERE `id` = '" .$idga. "' LIMIT 1");
$doc->msg(__('Yuklandi'));	
header('Refresh: 1; url=?');	
}
}
$qmanzilx = mysql_query("SELECT * FROM `bolimlarga` WHERE  `id` = '" .$idga. "' LIMIT 1");
while ($usx = mysql_fetch_assoc($qmanzilx)) {
$nomi = $usx['nomi'];
$bolimlarga = $usx['bolimlarga'];
$_SESSION['manzil'] = $usx['e_manzil'];
$gogle = $usx['gogle'];
}


?><form method="post" action="?soz=<?=$idga?>&sozi=ok&<?= passgen()?>" class="form-horizontal">
<div class="box">
  <div class="panel panel-default">
    <div class="panel-heading"><?=__('Bo`lim sozlamasini saqlash')?> <a style="margin-top: -5px; height: 30px; font-size: 90%;" class="btn btn-primary right" role="button" data-toggle="collapse" href="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
  <?=__('Bo`lim sozlamasini sozlash')?>
</a></div>
  </div>
 
	<div class="row box-section" style="margin-left: 15px;">
		<div class="form-group">
		  <label class="control-label col-lg-2"><?=__('Имя')?>:</label>
		  <div class="col-lg-10">
			<input style="width:100%;max-width:350px;" type="text" value="<?=$nomi?>" name="nomi">
		  </div>
		 </div>
		<div class="form-group">
		  <label class="control-label col-lg-2"><?=__('Ключевые слова для метатегов (метатеги keywords)')?></label>
		  <div class="col-lg-10">
			<textarea name="gogle" style="width:100%;max-width:350px;" rows="5"><?=$gogle?></textarea>
		  </div>
		 </div>
		<div class="form-group">
		  <label class="control-label col-lg-2"><?=__('Основная категория')?>:</label>
		  <div class="col-lg-10">
			<div class="selector fixedWidth"><span style="user-select: none;"></span>	<select class="uniform btn" style="font-size: 100%;"  name="bolimlarga"> <option value="<?=$bolimlarga?>"> <?=bolim_nomi($bolimlarga)?></option><?    
$result = mysql_query("SELECT * FROM `bolimlarga` WHERE `id`"); 
$myrow = mysql_fetch_array($result);  
do   
{  
printf ("<option value='%s'>%s</option>",$myrow["id"],$myrow["nomi"]); 
} 
while ($myrow = mysql_fetch_array($result)); 
?> 
</select></div>
		  </div>
		 </div>
		<div class="form-group">
		  <label class="control-label col-lg-2"><?=__('Ko`rinish style')?>:</label>
		  <div class="col-lg-10">
			<div class="selector fixedWidth"><span style="user-select: none;"></span>	<select class="uniform btn" style="font-size: 100%;"  name="style"> <option> </option><?    
$resultt = mysql_query("SELECT * FROM `style` WHERE `id`"); 
$myrowt = mysql_fetch_array($resultt);  
do   
{  
printf ("<option value='%s'>%s</option>",$myrowt["id"],$myrowt["nomi"]); 
} 
while ($myrow = mysql_fetch_array($resultt)); 
?> 
</select></div>
		  </div>
		 </div>
		<div class="form-group">
		  <label class="control-label col-lg-2"></label>
		  <div class="col-lg-10">
			<input type="submit" class="btn btn-green" value="<?=__('Добавить')?>">
		  </div>
		 </div>
		 
	</div>
 
</div>
</form><?






	
$doc->ret(__('Orqaga'), '/admin/bolimlar.php');
$doc->ret(__('Adminka'), './?' . passgen());	
exit;
}



if (isset($_GET['och'])){
	$idgaz = $_GET['och'];
if (isset($_GET['oche'])){

if ($_GET['oche'] == 'ok' && $_GET['och']){
mysql_query("UPDATE `html` SET  `bolimlarga` = ''  WHERE `bolimlarga` = '" .$_GET['och']. "'");
mysql_query("DELETE FROM `tegi` WHERE `bolimlarga` = '" .$_GET['och']. " LIMIT 1") ;
mysql_query("DELETE FROM `bolimlarga` WHERE `id` = '" .$_GET['och']. "' LIMIT 1") ;
mysql_query("DELETE FROM `bolimlar` WHERE `bolimlarga` = '" .$_GET['och']. "' LIMIT 1") ;
$doc->msg(__('Bo`lim o`chirildi'));
header('Refresh: 1; url=?');	
}
}
echo '<div class="panel panel-default">
  <div class="panel-heading">'.__('Siz bu bo`limni o`chirmoqchimisiz?').'</div>
  <div class="panel-body">
 
 
 <p><a href="?och='.$idgaz.'&oche=ok" class="btn btn-primary" role="button">'.__('XA').'</a> <a href="?" class="btn btn-default" role="button">'.__('YO`Q').'</a></p>
 
 
  </div>
</div>';
$doc->ret(__('Orqaga'), '/admin/bolimlar.php');
$doc->ret(__('Adminka'), './?' . passgen());	
exit;
}


if (isset($_POST['nomi']) && isset($_POST['manzil'])){
if (isset($_SESSION['time'])){
$tuga = $_SESSION['time'] + '4';	
}else{
$tuga = TIME;	
}


if (TIME >= $tuga){

	$fff = "" . my_esc(''.$_POST['manzil'].'');
if (preg_match('#^([a-z0-9\-\_\ ])+$#ui', $fff) == '0'){
             $doc->err(__('Bo`lim manziliga simmol ishlatmang'));	
}elseif (mysql_result(mysql_query("SELECT COUNT(*) FROM `bolimlarga` WHERE `nomi` = '" . my_esc($_POST['nomi']) . "' "), 0)) {
             $doc->err(__('Bu bo`lim mavjud'));
        }elseif (mysql_result(mysql_query("SELECT COUNT(*) FROM `bolimlarga` WHERE `manzil` = '" . my_esc($_POST['manzil']) . "' "), 0)) {
             $doc->err(__('Bu manzil mavjud'));
        }else{
			if (isset($_POST['bolimlarga'])){
			$manzil = ''.bolim_sisilka($_POST['bolimlarga']).''.$_POST['manzil'].'';	
			}else{
			$manzil = $_POST['manzil'];		
			}
			mysql_query("INSERT INTO `bolimlarga` (`nomi`, `manzil`, `e_manzil`, `gogle`, `bolimlarga`, `style`)values('" . my_esc($_POST['nomi']) . "', '" . my_esc($manzil) . "', '" . my_esc($_POST['manzil']) . "', '" . my_esc($_POST['gogle']) . "', '" . my_esc($_POST['bolimlarga']) . "', '" . my_esc($_POST['style']) . "')");
		     $doc->msg(__('Bo`lim qo`shildi'));
			 $_SESSION['time'] = TIME;
	         header('Refresh: 1; url=?');
	}

}else{
         $doc->msg(__('Boshqatdan urunib ko`ring'));	
		 header('Refresh: 1; url=?');
}
}


     
?>

  <div class="collapse" id="collapseExample">

<form method="post" action="?<?= passgen()?>" class="form-horizontal">
<div class="box">
  <div class="panel panel-default">
    <div class="panel-heading"><?=__('Bo`lim qo`shish')?> <a style="margin-top: -5px; height: 30px; font-size: 90%;" class="btn btn-primary right" role="button" data-toggle="collapse" href="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
  <?=__('Bo`lim qo`shish yopish')?>
</a></div>
  </div>
 
	<div class="row box-section" style="margin-left: 15px;">
		<div class="form-group">
		  <label class="control-label col-lg-2"><?=__('Имя')?>:</label>
		  <div class="col-lg-10">
			<input style="width:100%;max-width:350px;" type="text" name="nomi">
		  </div>
		 </div>
		<div class="form-group">
		  <label class="control-label col-lg-2"><?=__('Альтернативное имя')?>:</label>
		  <div class="col-lg-10">
			<input style="width:100%;max-width:350px;" type="text" name="manzil">
		  </div>
		 </div>
		<div class="form-group">
		  <label class="control-label col-lg-2"><?=__('Ключевые слова для метатегов (метатеги keywords)')?></label>
		  <div class="col-lg-10">
			<textarea name="gogle" style="width:100%;max-width:350px;" rows="5"></textarea>
		  </div>
		 </div>
		<div class="form-group">
		  <label class="control-label col-lg-2"><?=__('Основная категория')?>:</label>
		  <div class="col-lg-10">
			<div class="selector fixedWidth"><span style="user-select: none;"></span>	<select class="uniform btn" style="font-size: 100%;"  name="bolimlarga"> <option> </option><?    
$result = mysql_query("SELECT * FROM `bolimlarga` WHERE `id`"); 
$myrow = mysql_fetch_array($result);  
do   
{  
printf ("<option value='%s'>%s</option>",$myrow["id"],$myrow["nomi"]); 
} 
while ($myrow = mysql_fetch_array($result)); 
?> 
</select></div>
		  </div>
		 </div>
<div class="form-group">
		  <label class="control-label col-lg-2"><?=__('Ko`rinish style')?>:</label>
		  <div class="col-lg-10">
			<div class="selector fixedWidth"><span style="user-select: none;"></span>	<select class="uniform btn" style="font-size: 100%;"  name="style"> <option> </option><?    
$resultt = mysql_query("SELECT * FROM `style` WHERE `id`"); 
$myrowt = mysql_fetch_array($resultt);  
do   
{  
printf ("<option value='%s'>%s</option>",$myrowt["id"],$myrowt["nomi"]); 
} 
while ($myrow = mysql_fetch_array($resultt)); 
?> 
</select></div>
		  </div>
		 </div>
		<div class="form-group">
		  <label class="control-label col-lg-2"></label>
		  <div class="col-lg-10">
			<input type="submit" class="btn btn-green" value="<?=__('Добавить')?>">
		  </div>
		 </div>
		 
	</div>
 
</div>
</form>
</div>


<div class="panel panel-default">

  <div class="panel-heading"><?=__('Bo`limlar')?>  <a style="margin-top: -5px; height: 30px; font-size: 90%;" class="btn btn-primary right" role="button" data-toggle="collapse" href="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
  <?=__('Bo`lim qo`shish')?>
</a></div>




 <table class="table">
 <thead> <tr> <th> № </th> <th><?=__('Bo`limlar nomi')?></th> <th><?=__('Bo`limlar manzili')?></th> <th><?=__('Fayllar soni')?></th> </tr> </thead>
 <tbody> 
 <?
$q = mysql_query("SELECT * FROM `bolimlarga` WHERE  `id`");
$s = '0';
while ($us = mysql_fetch_assoc($q)) {

echo'<tr> <th scope="row"> '.++$s.')</th> <td>'.bolim_ozi($us['id']).'</td> <td>'.$us['manzil'].'</td> <td>'.$us['fayl_necta'].'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | <a href="?soz='.$us['id'].'" style="color: green"><b> C    </b></a> | <a href="?och='.$us['id'].'" style="color: red"><b> X </b></a> |</td> </tr>';

}
 
 ?>

 </tbody>
 </table> 
 </div> 









