<?php

include_once '../sys/inc/yadro.php';
admin::check_access();
$smiles = smiles::get_ini();
$doc = new document(5);
$doc->title = __('Smail');
if (isset($_GET['cat'])){
$id = (int) $_GET['cat'];
$doc -> title = __('Smayllar papkasi');

if ($_GET['us'] == '1' || $_GET['us'] == '2' || $_GET['us'] == '3' || $_GET['us'] == '4' || $_GET['us'] == '5' || $_GET['us'] == '6' || $_GET['us'] == '7' || $_GET['us'] == '8' || $_GET['us'] == '9' || $_GET['us'] == '10'){
$sil = 's_c'.$_GET['us'].'';
$sl = 's_r'.$_GET['us'].'';
$uzcms->$sl = text::for_name($_GET['ud']);
$vq = mysql_query("SELECT * FROM `smile` WHERE `id` = '".$_GET['ud']."'");
while ($smz = mysql_fetch_assoc($vq)) {
$uzcms->$sil = $smz['smile'];
}
$doc->msg(__('Qo`yildi'));
$uzcms->save_settings($doc);
}

$pages = new pages(mysql_result(mysql_query("SELECT COUNT(*) FROM `smile`"), 0));
$listing = new listing();
$q = mysql_query("SELECT * FROM `smile` WHERE `id`  ORDER BY `dir` = '".$id."' DESC LIMIT ".$pages->limit);
while ($sm = mysql_fetch_assoc($q)) {
$post = $listing->post();
$post->title = '<img src="/files/.smiles/'.$sm['id'].'.gif" title="voo.uz" /> '.$sm['smile'].'';
$post->action('1', '?cat='.$_GET['cat'].'&ud='.$sm['id'].'&us=1&amp;' . passgen());
$post->action('2', '?cat='.$_GET['cat'].'&ud='.$sm['id'].'&us=2&amp;' . passgen());
$post->action('3', '?cat='.$_GET['cat'].'&ud='.$sm['id'].'&us=3&amp;' . passgen());
$post->action('4', '?cat='.$_GET['cat'].'&ud='.$sm['id'].'&us=4&amp;' . passgen());
$post->action('5', '?cat='.$_GET['cat'].'&ud='.$sm['id'].'&us=5&amp;' . passgen());
$post->action('6', '?cat='.$_GET['cat'].'&ud='.$sm['id'].'&us=6&amp;' . passgen());
$post->action('7', '?cat='.$_GET['cat'].'&ud='.$sm['id'].'&us=7&amp;' . passgen());
$post->action('8', '?cat='.$_GET['cat'].'&ud='.$sm['id'].'&us=8&amp;' . passgen());
$post->action('9', '?cat='.$_GET['cat'].'&ud='.$sm['id'].'&us=9&amp;' . passgen());
$post->action('10', '?cat='.$_GET['cat'].'&ud='.$sm['id'].'&us=10&amp;' . passgen());
}
$listing->display(__('Ro`yhat bo`sh'));
$pages->this_page();
$pages->display('?cat='.$_GET['cat'].'&');


exit;
}


$doc -> title = __('Smayllar papkasi');
$pages = new pages(mysql_result(mysql_query("SELECT COUNT(*) FROM `smile_dir`"), 0));
$listing = new listing();
$q = mysql_query("SELECT * FROM `smile_dir` WHERE `id`  ORDER BY `id` DESC LIMIT ".$pages->limit);
while ($sm = mysql_fetch_assoc($q)) {
$post = $listing->post();
$post->icon('authentication');
$post->url = '?cat='.$sm['id'].'';
$post->title = $sm['name'];
$post->time = ''.mysql_result(mysql_query("SELECT COUNT(*) FROM `smile` WHERE `dir` = '".$sm['id']."'"), 0).'';

} 
$listing->display(__('Ro`yhat bo`sh'));
$pages->this_page();
$pages->display('?cat='.$_GET['cat'].'&');
$doc->ret('<img src="/img/answer.png"> '.__('Bo`lim yaratish'), '?act=add_kat');