<?php

include_once '../sys/inc/yadro.php';
admin::check_access();
$advertisement = new adt();
$doc = new document(5);
$doc->title = __('Reklamma baneri');

if (isset($_GET['id'])) {
    $id_space = (string) $_GET['id'];

    if (!$name = $advertisement->getNameById($id_space)) {
        header('Refresh: 1; url=?');
        $doc->ret('<img src="/img/answer.png"> '.__('Orqaga qaytish'), '?');
        $doc->err(__('Tollanishda imkoniyat bo`lmadi'));
        exit;
    }

    $doc->title = __('Reklamma');

    switch (@$_GET['filter']) {
        case 'new':$filter = 'new';
            $sql = " AND `time_start` > '" . TIME . "' AND (`time_end` > '" . TIME . "' OR `time_end` = '0')";
            break;
        case 'old':$filter = 'old';
            $sql = " AND (`time_start` < '" . TIME . "' OR `time_start` = '0') AND (`time_end` < '" . TIME . "' AND `time_end` != '0')";
            break;
        case 'all':$filter = 'all';
            $sql = '';
            break;
        default:$filter = 'active';
            $sql = " AND (`time_start` < '" . TIME . "' OR `time_start` = '0') AND (`time_end` > '" . TIME . "' OR `time_end` = '0')";
            break;
    }


    $pages = new pages;
    $pages->posts = mysql_result(mysql_query("SELECT COUNT(*) FROM `advertising` WHERE `space` = '$id_space'$sql"), 0);
    $pages->this_page(); 
    $ord = array();
    $ord[] = array("?id=$id_space&amp;filter=all&amp;page={$pages->this_page}", __('Hammasi'), $filter == 'all');
    $ord[] = array("?id=$id_space&amp;filter=active&amp;page={$pages->this_page}", __('Faol'), $filter == 'active');
    $ord[] = array("?id=$id_space&amp;filter=old&amp;page={$pages->this_page}", __('Tugatilgan'), $filter == 'old');
    $ord[] = array("?id=$id_space&amp;filter=new&amp;page={$pages->this_page}", __('Kutilyatkan'), $filter == 'new');
    $or = new design();
    $or->assign('order', $ord);
    $or->display('design.order.tpl');

    $listing = new listing();

    $q = mysql_query("SELECT * FROM `advertising` WHERE `space` = '$id_space'$sql ORDER BY `time_start` ASC LIMIT $pages->limit");
    while ($adt = mysql_fetch_assoc($q)) {
        $post = $listing->post();
        $post->url = 'adt.stat.php?id=' . $adt['id'];
        $post->title = text::toValue($adt['name'] ? $adt['name'] : 'Reklamma #' . $adt['id']) . ($adt['url_img'] ? ' (' . __('baner') . ')' : null);
        $post->icon('adt');
        $post->action('edit', "adt.edit.php?id={$adt['id']}");
        $post->action('delete', "adt.edit.php?id={$adt['id']}&amp;delete");

        if ($filter == 'all') {
            if ((!$adt['time_start'] || $adt['time_start'] < TIME) && (!$adt['time_end'] || $adt['time_end'] > TIME)) {
                $post->content[] = __('Reklamma faol');
            } elseif ($adt['time_start'] > TIME && (!$adt['time_end'] || $adt['time_end'] > TIME)) {
                $post->content[] = __('Kutilyatkan');
            } elseif ((!$adt['time_start'] || $adt['time_start'] < TIME) && $adt['time_end'] < TIME) {
                $post->content[] = __('Tugatilgan');
            }
        }

        if ($adt['time_start'] > TIME) {
            $post->content[] = __("Boshlanish: %s", misc::when($adt['time_start']));
        }

        if (!$adt['time_end']) {
            $post->content[] = __('Vaqt');
        } elseif ($adt['time_end'] > TIME) {
            $post->content[] = __("Tugash vaqti: %s", misc::when($adt['time_end']));
        } else {
            $post->content[] = __("Tugash vaqti: %s", misc::when($adt['time_end']));
        }

        if ($adt['bold']) {
            $post->content[] = "[b]" . __('Qalin xarifda') . "[/b]";
        }

        $post->content[] = __('Adres: %s', text::toValue($adt['url_link']));
        if ($adt['url_img']) {
            $post->content[] = __('Manzil foto: %s', text::toValue($adt['url_img']));
        }

        if ($adt['page_main'] && $adt['page_other']) {
            $post->content[] = __('Hamma joyda');
        } elseif (!$adt['page_main'] && $adt['page_other']) {
            $post->content[] = __('Bosh sahifa pasida');
        } elseif ($adt['page_main'] && !$adt['page_other']) {
            $post->content[] = __('Bosh sahifada');
        } else {
            $post->content[] = __("Ko`rsatilmagan");
        }
    }
    $listing->display(__('Reklamma yo`q'));

    $pages->display("?id=$id_space&amp;filter=$filter&amp;"); // вывод страниц

    $doc->act(__('Yaratish'), 'adt.new.php?id=' . $id_space);
    $doc->act(__('Uchotchik'), 'adt.new.banner.php?id=' . $id_space);
    $doc->ret(__('Reklamma holat'), '?');
    
    exit;
}

$doc->title = __('Reklamma');

$advertisement->display();


?>
