<?php

include_once '../sys/inc/yadro.php';
admin::check_access();
$doc = new document(5);
$doc->title = __('Azo bolish sozlamasi');
    if ($uzcms->reg_open == '1'){
		$be = 'bekig';
	}else{
		$be = 'ochiq';		
	}
    if ($uzcms->reg_kir == '1'){
		$bez = 'kirmedi';
	}else{
		$bez = 'kiradi';		
	}	
	
if (isset($_POST ['save'])) {
	$uzcms->xabarchi = text::input_text($_POST ['xabarchi']);
    $uzcms->summ = text::input_text($_POST ['summ']);
    $uzcms->xabarnoma = text::input_text($_POST ['xabarnoma']);
    $uzcms->reg_open = (int) !empty($_POST ['reg_open']);
    $uzcms->reg_kir = (int) !empty($_POST ['reg_kir']);
    $uzcms->onlinega = text::input_text($_POST ['onlinega']);	
    $uzcms->chat_onlinega = text::input_text($_POST ['chat_onlinega']);	
    $uzcms->saytdan_och = text::input_text($_POST ['saytdan_och']);		
    $uzcms->mexmonga = text::input_text($_POST ['mexmonga']);	  
	$uzcms->input = text::input_text($_POST ['input']);	  
	$uzcms->save_settings($doc);
}


$form = new form('?' . passgen());
$form->text('xabarchi', __('Sayt xabachisi'), $uzcms->xabarchi);
$form->text('summ', __('Ro`yhatdan o`tkanlarga sovga (UZS)'), $uzcms->summ);
$form->textarea('xabarnoma', __('Ro`yhatdan o`tkanlarga  (XABAR)'), $uzcms->xabarnoma);
$form->select('reg_open', __('Ro`yhatdan o`tishni berkitish? hozirda (%s)', $be), array(array(1, __('Xa bekitaman')), array(0, __('Yo`q ochiq qolsin'))));    
$form->select('reg_kir', __('Saytda azo bo`lmaganlar kira olsinmi? hozirda (%s)', $bez), array(array(1, __('Xa kirmasin')), array(0, __('Yo`q kiraversin'))));    
$form->text('onlinega', __('Saytda azolar qancha daqiqa onlineda bo`lsin (Minutda)'), $uzcms->onlinega);
$form->text('chat_onlinega', __('Chatda azolar qancha daqiqa onlineda bo`lsin (Minutda)'), $uzcms->chat_onlinega);
$form->text('saytdan_och', __('Ishlamagan profillarni bilish  (Kunda)'), $uzcms->saytdan_och);
$form->select('mexmonga', __('Saydga kirish formasi'), array(array('kir_fon', __('Fonlik bo`lsin')), array('kir_t', __('Oddiy hollat'))));    
$form->text('input', __('Input rangi foydalanuvchilarga'), $uzcms->input);
$form->button(__('Saqlash'), 'save');
$form->display();

$doc->ret(__('Adminka'), './');
?>
