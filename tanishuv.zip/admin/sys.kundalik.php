<?php
include_once '../sys/inc/yadro.php';
admin::check_access();
$doc = new document(5);
$doc->title = __('Kundalik sozlamasi');

if (isset($_POST['save'])) {
    $uzcms->kundalik_theme_captcha = (int) !empty($_POST['kundalik_theme_captcha']);
    $uzcms->kundalik_message_captcha = (int) !empty($_POST['kundalik_message_captcha']);
    $uzcms->kundalik_search_captcha = (int) !empty($_POST['kundalik_search_captcha']);
    $uzcms->kundalik_search_reg = (int) !empty($_POST['kundalik_search_reg']);
    $uzcms->kundalik_files_upload_size = (int) ($_POST['kundalik_files_upload_size'] * 1024);
    $uzcms->save_settings($doc);
}

$form = new form('?' . passgen());
$form->checkbox('kundalik_theme_captcha', __('Xotira daftar kapchu orqalik yozilsin') . ' *', $uzcms->kundalik_theme_captcha);
$form->checkbox('kundalik_message_captcha', __('Xabar kapchu orqalik yozilsin') . ' *', $uzcms->kundalik_message_captcha);
$form->text('kundalik_files_upload_size', __('Birlashtiriladigon fayl razmeri'), (int) ($uzcms->kundalik_files_upload_size / 1024));
$form->checkbox('kundalik_search_captcha', __('Izlash kapchu orqalik bo`lsin'), $uzcms->kundalik_search_captcha);
$form->checkbox('kundalik_search_reg', __('Faqat foydalanuvchilar izlay olsin'), $uzcms->kundalik_search_reg);
$form->button(__('Saqlash'), 'save');
$form->display();


?>
