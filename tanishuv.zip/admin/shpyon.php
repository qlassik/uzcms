<?php
include_once '../sys/inc/yadro.php';
admin::check_access();
$doc = new document(6);
$doc->title = __('Arizalar');


if (isset($_GET['id_shundan'])){
	
	
	if (isset($_GET['toza'])){	
		$xatnikis_path = FILES . '/.mail'; 
        $xatnikis_dir = new files($xatnikis_path);
		
		$ochim = mysql_query("SELECT * FROM `mail` ORDER BY  `id_user` = '".$_GET['id_shundan']."'");
            while ($top = mysql_fetch_assoc($ochim)) {
		 $xatniki = new files_file($xatnikis_path, $top['file']);
          $xatniki->delete();
        }

	
		
	mysql_query("DELETE FROM `mail` WHERE `id_user` = '".$_GET['toza']."'");
       
        $doc->msg(__('O`chirildi'));
	
	
	}
	
if (isset($_GET['id_ozim'])){	
    $id_kont = (int)$_GET['id_ozim'];
    $ank = new user($id_kont);
    $accept_send = 1;
	$ank2 = new user((int)$_GET['id_ozim']);
	$ank3 = new user((int)$_GET['id_shundan']);	
    $doc->title = __('Siz -> (%s) bo`lim sms yozishinggiz mumkin', $ank->title());
	if($_GET['id_shundan']){
	echo'<style>
.ana{
    background: url("/files/.foni/'.$user->foni.'") 100% 100% no-repeat;
    background-size: cover; 
}
</style>';
}

	
	
	
	if (isset($_GET['ariza'])){	
$qa = mysql_query("SELECT * FROM `mail` WHERE `id` = '".$_GET['ariza']."' AND `id_sender` = '".$_GET['id_shundan']."' ORDER BY `id` DESC LIMIT 1");
        while ($ochh = mysql_fetch_assoc($qa)) {
		$files = $ochh['file'];
		$ar = ''.$ochh['mess'].' , Admin iltimos bu xabarni ko`rin';
		$men = $ochh['id_sender'];
		$u = $ochh['id_user'];
		}
	if (mysql_result(mysql_query("SELECT COUNT(`id`) FROM `ariza` WHERE `id_shundan` = '".$_GET['id_shundan']."' AND `time` > '".(time()-60)."' LIMIT 1"),0)!=0){
		 $doc->err(__('1 minutdan so`ng ariza jo`nata olasiz'));
	}elseif(isset($_GET['ok'])){
		    mysql_query("INSERT INTO `ariza` (`id_ozim`, `id_shundan`, `time`, `mess`, `ariza`, `file`)
VALUES ('" . $u . "', '".$men."', '" . TIME . "', '" . my_esc($ar) . "', '" . my_esc($_POST['ariza']) . "', '" . my_esc($files) . "' )");
            $doc->msg(__('Ariza yuborildi'));
			header('Refresh: 3; url=?id=' . $_GET['id']);
		exit;
		}
	
	if ($files == ''.$ank->login.'_') {
echo'<center class="kv2"><img class="foto" src="/files/.mail/'.text::toOutput($files).'" title="voo.uz" alt="voo.uz"></center>';	
	}  
echo'</div>';
$fv = new fv('?id='.$_GET['id'].'&ariza='.$_GET['ariza'].'&ok=ok&' . passgen());
$fv->textarea('ariza', __('Fon nomi'), $ar);
$fv->button(__('Saqlash'), 'save');
$fv->display();
	exit;
	}
	 if ($ank->mail_only_friends && !$ank->is_friend($user)) {
        $accept_send = false;
        $doc->err(__('Do`stlarim yozishi mumkin'));
        if ($user->group > $ank->group) {
            $accept_send = true;
            $doc->msg(__('Siz vaqtincha nazorattasiz'));
        }
    } elseif ($ank->id && $user->mail_only_friends && !$user->is_friend($ank) && $user->group >= $ank->group) {
        $doc->err(__('Javob yoza olmedi'));
    }

    if (mysql_result(mysql_query("SELECT COUNT(`id`) FROM `mail` WHERE `id_sender` = '".$_GET['id_shundan']."' AND `time` > '".(time()-6)."' LIMIT 1"),0)!=0){
		 $doc->err(__('Haskerlik qilmang men elyorbek nickm qlassik_ru hammayoqni oldini olganman'));
	}elseif ($accept_send && isset($_POST ['post']) && isset($_POST ['mess'])) {
        $mess = (string)$_POST ['mess'];
        text::nickSearch($mess); 
        $mess = text::input_text($mess);
        		
		
        if ($user->group <= $ank->group  && !$ank->ak == '1' && (empty($_POST ['captcha']) || empty($_POST ['captcha_session']) || !captcha::check($_POST ['captcha'], $_POST ['captcha_session'])))
            $doc->err(__('Raqam to`gri holatda kiritilmadi'));
        elseif (!$mess)
            $doc->err(__('Xabar yo`q')); else {
if (isset($_FILES ['file'] ['name'])){		
$xatniki_file_name = ''.$ank3->login.'_'.text::for_filename($_FILES ['file'] ['name']);
$xatnikis_path = FILES . '/.mail'; 
$xatnikis_dir = new files($xatnikis_path);
if (preg_match('/\\.(jpg|png|gif|jepg)$/i', text::for_filename($_FILES ['file'] ['name']))) {
    if (!$img = @imagecreatefromjpeg($_FILES ['file'] ['tmp_name']) || !$img = @imagecreatefromgif($_FILES ['file'] ['tmp_name']) || !$img = @imagecreatefrompng($_FILES ['file'] ['tmp_name'])) {
        $doc->err(__('Rasim farmatda emas'));
    }elseif (!empty($_FILES ['file'])) {
    if ($_FILES ['file'] ['error']) {
        $doc->err(__('Yuklashda xatolik bor'));
    } elseif (!$_FILES ['file'] ['size']) {
        $doc->err(__('faylа yo`q'));
    } else {
        if ($xatnikis_dir->is_file($xatniki_file_name)) {
            $xatniki = new files_file($xatnikis_path, $xatniki_file_name);
            $xatniki->delete(); 
        }

        if ($files_ok = $xatnikis_dir->filesAdd(array($_FILES ['file'] ['tmp_name'] => $xatniki_file_name))) {
            $xatnikis_dir->group_show = 0;
            $files_ok [$_FILES ['file'] ['tmp_name']]->group_show = 0;
            $files_ok [$_FILES ['file'] ['tmp_name']]->id_user = $_GET['id_shundan'];
            $files_ok [$_FILES ['file'] ['tmp_name']]->group_edit = max($user->group, 2);

            unset($files_ok);
        } else {
            $doc->err(__('Iloji yoq fayl saqlashga'));
        }
    }
}
}
}
if(isset(text::for_filename($_FILES ['file'] ['name']))){
	$files = $xatniki_file_name;
}else{
	$files = '';	
}
    mysql_query("UPDATE `users` SET `mail_new_count` = `mail_new_count` + '1' WHERE `id` = '" . $ank->id . "' LIMIT 1");
    mysql_query("INSERT INTO `mail` (`id_user`, `id_sender`, `time`, `mess`, `file`)
VALUES ('" . $ank->id . "', '".$_GET['id_shundan']."', '" . TIME . "', '" . my_esc($mess) . "', '" . my_esc($files) . "' )");
        
        }

        $doc->ret(__('Xabarlarim'), '?id=' . $id_kont);
    }



    if ($accept_send) {
	    $mailniki = new mailniki("?id_shundan=".$_GET['id_shundan']."&id_ozim=".$_GET['id_ozim']."&amp;" . passgen());
        $mailniki->textarea('mess', __('Xabar'));
        $mailniki->file('file', '');
        $mailniki->button(__('Yuborish'), 'post', false);
        $mailniki->refresh_url("/xabar?id=$id_kont&amp;" . passgen());
		echo'<a href="/fon.html"><img style="float:right; clear:left; margin-right: 30px; margin-top: 10px;" src="/img/empty_bubble.png" title="voo.uz" /></a>';
        $mailniki->display();
    }


    $pages = new pages ();
    $pages->posts = mysql_result(mysql_query("SELECT COUNT(*) FROM `mail` WHERE (`id_user` = '{$_GET['id_shundan']}' AND `id_sender` = '$id_kont') OR (`id_user` = '$id_kont' AND `id_sender` = '{$_GET['id_shundan']}')"), 0); 
    $pages->this_page();


    $q = mysql_query("SELECT * FROM `mail`
WHERE (`id_user` = '{$_GET['id_shundan']}' AND `id_sender` = '$id_kont')
      OR (`id_user` = '$id_kont' AND `id_sender` = '{$_GET['id_shundan']}')
ORDER BY `id` DESC
LIMIT " . $pages->limit);
    
    mysql_query("UPDATE `mail` SET `is_read` = '1' WHERE `id_user` = '{$_GET['id_shundan']}' AND `id_sender` = '$id_kont'");
    if (preg_match('#Changed: ([0-9]+)#i', mysql_info(), $ch)) {
        if ($ch [1]) {
            $user->mail_new_count = $user->mail_new_count - $ch [1];
        }
    }
    $mg = array('1' => "et.png", '0' => "etm.png");
    $listing = new listing();
    while ($maisl = mysql_fetch_assoc($q)) {
        $ank2 = new user((int)$maisl ['id_sender']);
        $is = new user((int)$_GET['id_shundan']);		
		$mail = $listing->mail();
        
			if ($_GET['id_shundan'] == $ank2->id){
			$men = 'men';
			}else{
			$men = 'menga';
			}
?><style>
.menga{
    overflow: hidden;
    border-radius: 3px 3px 3px 3px;
    background-color: #F2FCD7;
    color: #222222;
    float: right;
    border: 1px solid #F2FCD7;
    border-bottom: 2px solid #f0f0f0;
    margin: 2px;
    padding: 6px;
    margin-top: 15px;
    max-width: 75%;
}
.men{
    overflow: hidden;
    border-radius: 3px 3px 3px 3px;
    background-color: #F5F5F5;
    color: #222222;
    float: left;
    border: 1px solid #F5F5F5;
    border-bottom: 2px solid #f0f0f0;
    margin: 2px;
    padding: 6px;
    margin-top: 15px;
    max-width: 75%;
}
.php {
    line-height: 16px;
    font-size: small;
    background-color: #e0e6e9;
    border: 1px solid #e0e6e9;
    padding: 0;
    overflow: auto;
}
.foto{
	border: 2px solid #F5FcF9;
    border-radius: 2px solid #f0f0f0;
    margin-right: 2px;
	max-width: 98%;
	width: 270px;	
}

</style>
<?
 if ($_GET['id_shundan'] == $ank2->id){
	echo '<style>.ochi_'.$maisl['id'].'{display: none;}</style>';  
  }
  if ($maisl['file'] == ''.$ank->login.'_'){
	echo '<style>.och_'.$maisl['id'].'{display: none;}</style>';  
  }  
  if ($maisl['file'] == ''.$is->login.'_'){
	echo '<style>.och_'.$maisl['id'].'{display: none;}</style>';  
  }    
 $mail->title = '<table width="100%" class="mes">
<td class="'.$men.'"><a href="/ID' . $ank2->id.'">
        <img class="media-object" style="width: 40px; border-radius: 35px;" src="'.$ank->getAva($doc->img_max_width()).'" alt="voo.uz">
      </a>
	  
	  
   <span class="one"><a href="?id_shundan='.$_GET['id_shundan'].'&id_ozim='.$_GET['id_ozim'].'&oche='.$maisl['id'].'" title="voo.uz"><img src="/img/close-gr.png" /></a><a href="?id_shundan='.$_GET['id_shundan'].'&id_ozim='.$_GET['id_ozim'].'&ariza='.$maisl['id'].'" title="voo.uz"><img style="    padding: 0px;
    display: block !important;
   overflow: hidden; margin-top: 4px;  float:right; clear:left;" src="/img/closed-g.png" /></a></span>
   
   
   </td>
	  <td class="'.$men.'">  
	  <center class="och_'.$maisl['id'].'"><img class="foto" src="/files/.mail/'.text::toOutput($maisl['file']).'" title="voo.uz" alt="voo.uz"></center>
	  
 '.text::toOutput($maisl['mess']).'<br><div style="float:right; clear:left;">
<img src="/img/'.$mg[''.$maisl['is_read'].''].'" class="icon">
' .  misc::when($maisl ['time']) . '</div>
</td></tr>
</table>';

    }
    $listing->display(__('Xabarlar yo`q'));

    $pages->display('?id_shundan='.$_GET['id_shundan'].'&id_ozim='.$_GET['id_ozim'].'&amp;'); // qale

	

	
	
	
	
echo'</div>';	
	
	
	
	
$doc->ret('<img src="/img/extreme.png">  '.__('Xamma xabarlar'), '?');
$doc->ret('<img src="/img/competition.png">  '.__('Yangi habarlarni ko`rish %s ni', $ank2->nick), '?id_shundan='.$_GET['id_ozim'].'&ot');
$doc->ret('<img src="/img/extreme.png">  '.__('Xamma xabar %s', $ank2->nick), '/admin/shpyon.php?id_shundan='.$_GET['id_ozim'].'');	
$doc->ret('<img src="/img/competition.png">  '.__('Yangi habarlarni ko`rish %s ni', $ank->nick), '?id_shundan='.$_GET['id_shundan'].'&ot');
$doc->ret('<img src="/img/extreme.png">  '.__('Xamma xabar %s', $ank->nick), '/admin/shpyon.php?id_shundan='.$_GET['id_shundan'].'');	

    exit();
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

$sql_where = array("`mail`.`id_user` = '{$_GET['id_shundan']}'");
if (isset($_GET ['ot'])) {
    $sql_where[] = "`mail`.`is_read` = '0'";
}

$pages = new pages ();
$pages->posts = mysql_result(mysql_query("SELECT COUNT(DISTINCT(`mail`.`id_sender`)) FROM `mail` WHERE " . implode(' AND ', $sql_where)), 0); 
$pages->this_page(); 

$q = mysql_query("SELECT `users`.`id`,
        `mail`.`id_sender`,
        MAX(`mail`.`time`) AS `time`,
        MIN(`mail`.`is_read`) AS `is_read`,
        COUNT(`mail`.`id`) AS `count`
FROM `mail`
LEFT JOIN `users` ON `mail`.`id_sender` = `users`.`id`
WHERE " . implode(' AND ', $sql_where) . "
GROUP BY `mail`.`id_sender`
ORDER BY `time` DESC
LIMIT $pages->limit");

$listing = new listing();
while ($mail = mysql_fetch_assoc($q)) {
	$ank = new user((int)$mail['id_sender']);
    $kv = $listing->kv();
    $kv->image = $ank->getAva($doc->img_max_width());
    $kv->url = '?id_shundan=' . $_GET['id_shundan'].'&id_ozim='.$ank->id.'';
    $kv->title = $ank->nick();
	$kv->admine = mailsoz($ank->id);
	if (isset($_GET ['ot'])){
	$kv->hightlight = ''.$mail['count'];
    }else{
	if (!$mail['is_read']){
    $kv->hightlight = '<marquee><b style="">'.__('NEW').'</b></marquee>';
    }else{
	$kv->hightlight = isset($_GET ['ot']) ? '+' . $mail['count'] : $mail['count'];
    }
	}
	$kv->time = mailtime($ank->id);
	
}
    



$listing->display(__('Xabarlar yo`q'));

$pages->display('?id_shundan='.$_GET['id_shundan'].'&');
$doc->ret('<img src="/img/competition.png">  '.__('Yangi habarlarni ko`rish'), '?id_shundan='.$_GET['id_shundan'].'&ot');
$doc->ret('<img src="/img/delete.png">  '.__('Habarlarini o`chirish'), '?id_shundan='.$_GET['id_shundan'].'&toza='.$_GET['id_shundan'].'');


exit;
}
























$sql_where = array("`mail`.`id_user`");
if (isset($_GET ['ot'])) {
    $sql_where[] = "`mail`.`is_read` = '0'";
}

$pages = new pages ();
$pages->posts = mysql_result(mysql_query("SELECT COUNT(DISTINCT(`mail`.`id_sender`)) FROM `mail` WHERE " . implode(' AND ', $sql_where)), 0); 
$pages->this_page(); 

$q = mysql_query("SELECT `users`.`id`,
        `mail`.`id_sender`,
        MAX(`mail`.`time`) AS `time`,
        MIN(`mail`.`is_read`) AS `is_read`,
        COUNT(`mail`.`id`) AS `count`
FROM `mail`
LEFT JOIN `users` ON `mail`.`id_sender` = `users`.`id`
WHERE " . implode(' AND ', $sql_where) . "
GROUP BY `mail`.`id_sender`
ORDER BY `time` DESC
LIMIT $pages->limit");

$listing = new listing();
while ($mail = mysql_fetch_assoc($q)) {
	$ank = new user((int)$mail['id_sender']);
    $kv = $listing->kv();
    $kv->image = $ank->getAva($doc->img_max_width());
    $kv->url = '?id_shundan=' . $ank->id.'';
    $kv->title = $ank->nick();
	$kv->admine = mailsoz($ank->id);
	if (isset($_GET ['ot'])){
	$kv->hightlight = ''.$mail['count'];
    }else{
	if (!$mail['is_read']){
    $kv->hightlight = '<marquee><b style="">'.__('NEW').'</b></marquee>';
    }else{
	$kv->hightlight = isset($_GET ['ot']) ? '+' . $mail['count'] : $mail['count'];
    }
	}
	$kv->time = mailtime($ank->id);
	
}
    



$listing->display(__('Xabarlar yo`q'));

$pages->display('?');
$doc->ret('<img src="/img/competition.png">  '.__('Yangi habarlarni ko`rish'), '?ot');

exit;