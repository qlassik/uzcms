<?php

include_once '../sys/inc/yadro.php';
admin::check_access();
$smiles = smiles::get_ini();
$doc = new document(5);
$doc->title = __('Smail');









		
if(isset($_GET['act']) && $_GET['act'] == 'add_kat')
{
	if(isset($_POST['save']))
	{
		$name = mysql_real_escape_string($_POST['name']);
		$qzazasa = mysql_query("SELECT * FROM `smile` WHERE `id`  ORDER BY `id` DESC LIMIT 1");
while ($sm = mysql_fetch_assoc($qzazasa)) {
		$x = $sm['id'];
	}
       
		if(isset($_POST['name']))
		{
		mysql_query("INSERT INTO `smile_dir` (`id`, `name` ) VALUES ('$x + 1', '$name')");
		header("Location: ?");
		exit;
		}
	}
	
$listing = new listing();
$form = new form("?act=add_kat&" . passgen());
$form->input('name', __('Bo`lim nomi'));
$form->button(__('Yuborish'), 'save', false);
$doc->grp(__('Smail'), '?');	
$doc->grp(__('Smail qo`shish'), '?cat='.$_GET['cat'].'&act=qosh');		
$form->display();
echo'</div>';
exit;	
}



if (isset($_GET['cat'])){
$id = (int) $_GET['cat'];
$doc -> title = __('Smayllar papkasi');
if (isset($_GET['oz'])){
if (isset($_POST['smile']))
{
mysql_query("UPDATE `smile` SET `smile` = '".my_esc($_POST['smile'])."' WHERE `id` = '".$_GET['oz']."'");
$doc->msg(__('Smail nomi o`zgardi'));
header("Location: ?cat=".$_GET['cat']."&oz=".$_GET['oz']."&" . passgen()."");
exit;
}
$q = mysql_query("SELECT * FROM `smile` WHERE `id` = '".$_GET['oz']."'  ORDER BY `dir` = '".$id."' DESC LIMIT 1");
while ($sss = mysql_fetch_assoc($q)) {
$ss = $sss['smile'];
}


$listing = new listing();
$form = new form("?cat=".$_GET['cat']."&oz=".$_GET['oz']."&" . passgen());
$form->input('smile', __('Smail nomi'), $ss);
$form->button(__('Yuborish'), 'post', false);
$doc->grp(__('Smail'), '?');	
$doc->grp(__('Smail qo`shish'), '?act=qosh');	
$form->display();

echo '</div>';
exit;
}

if (isset($_GET['act'])){
if ($_GET['act'] == 'qosh')
{
if (isset(text::for_filename($_FILES ['file'] ['name']))){
 if (!$_FILES ['file'] ['error']) {	
	$name = mysql_real_escape_string($_POST['name']);
				$qzazasa = mysql_query("SELECT * FROM `smile` WHERE `id`  ORDER BY `id` DESC LIMIT 1");
while ($sm = mysql_fetch_assoc($qzazasa)) {
		$xz = $sm['id'];
	}
	$zaa = $xz + 1;		    
$xatniki_file_name = $zaa.'.gif';
$xatnikis_path = FILES . '/.smiles'; 
$xatnikis_dir = new files($xatnikis_path);
if (preg_match('/\\.(jpg|png|gif|jepg)$/i', text::for_filename($_FILES ['file'] ['name']))) {
    if (!$img = @imagecreatefromjpeg($_FILES ['file'] ['tmp_name']) || !$img = @imagecreatefromgif($_FILES ['file'] ['tmp_name']) || !$img = @imagecreatefrompng($_FILES ['file'] ['tmp_name'])) {
        $doc->err(__('Rasim farmatda emas'));
    }elseif (!empty($_FILES ['file'])) {
    if ($_FILES ['file'] ['error']) {
        $doc->err(__('Yuklashda xatolik bor'));
    } elseif (!$_FILES ['file'] ['size']) {
        $doc->err(__('faylа yo`q'));
    } else {
       

        if ($files_ok = $xatnikis_dir->filesAdd(array($_FILES ['file'] ['tmp_name'] => $xatniki_file_name))) {
            $xatnikis_dir->group_show = 0;
            $files_ok [$_FILES ['file'] ['tmp_name']]->group_show = 0;
            $files_ok [$_FILES ['file'] ['tmp_name']]->id_user = $user->id;
            $files_ok [$_FILES ['file'] ['tmp_name']]->group_edit = max($user->group, 2);
				$qzazasa = mysql_query("SELECT * FROM `smile` WHERE `id`  ORDER BY `id` DESC LIMIT 1");
while ($sm = mysql_fetch_assoc($qzazasa)) {
		$xz = $sm['id'];
	}
	$zaa = $xz + 1;

			mysql_query("INSERT INTO `smile` (`id`, `smile`, `dir`) VALUES ('$zaa', '".$_POST['smile']."', '".$_GET['cat']."')");
			header("Location: ?cat=".$_GET['cat']."&" . passgen()."");
			unset($files_ok);
		} else {
            $doc->err(__('Iloji yoq fayl saqlashga'));
        }
    }
}
}
}
}	




$listing = new listing();
$form = new form("?cat=".$_GET['cat']."&act=qosh&" . passgen());
$form->text('smile', __('Smail codi .PPP. ga oxshatib yozin'));
$form->file('file', __('Smail yuklang'));
$form->button(__('Yuborish'), 'post', false);
$doc->grp(__('Smail'), '?');	
$doc->grp(__('Smail qo`shish'), '?act=qosh');	
$form->display();

echo '</div>';
exit;
}
}
if (isset($_GET['ud'])){	
mysql_query("DELETE FROM `smile` WHERE `id` = '" . $_GET['ud'] . "'");
$doc->msg(__('Smail o`chirildi'));
header("Location: ?cat=".$_GET['cat']."");
exit;

}

$pages = new pages(mysql_result(mysql_query("SELECT COUNT(*) FROM `smile` WHERE  `dir` = '".$id."'"), 0));
$listing = new listing();
$q = mysql_query("SELECT * FROM `smile` WHERE  `dir` = '".$id."' ORDER BY `id` DESC LIMIT ".$pages->limit);
while ($sm = mysql_fetch_assoc($q)) {
$post = $listing->post();
$post->title = '<img src="/files/.smiles/'.$sm['id'].'.gif" title="voo.uz" /> '.$sm['smile'].'';
$post->action('developers', '?cat='.$_GET['cat'].'&oz='.$sm['id'].'&amp;' . passgen());
$post->action('delete', '?cat='.$_GET['cat'].'&ud='.$sm['id'].'&amp;' . passgen());
}
$listing->display(__('Ro`yhat bo`sh'));
$pages->this_page();
$pages->display('?cat='.$_GET['cat'].'&');
$doc->grp(__('Bo`lim yaratish'), '?act=add_kat');	
$doc->grp(__('Smail qo`shish'), '?cat='.$_GET['cat'].'&act=qosh');	


exit;
}


$doc -> title = __('Smayllar papkasi');
$pages = new pages(mysql_result(mysql_query("SELECT COUNT(*) FROM `smile_dir`"), 0));
$listing = new listing();
$q = mysql_query("SELECT * FROM `smile_dir` WHERE `id`  ORDER BY `id` DESC LIMIT ".$pages->limit);
while ($sm = mysql_fetch_assoc($q)) {
$post = $listing->post();
$post->url = '?cat='.$sm['id'].'';
$post->title = $sm['name'];
$post->time = ''.mysql_result(mysql_query("SELECT COUNT(*) FROM `smile` WHERE `dir` = '".$sm['id']."'"), 0).'';

}
$listing->display(__('Ro`yhat bo`sh'));
$pages->this_page();
$pages->display('?');
$doc->grp(__('Bo`lim yaratish'), '?act=add_kat');