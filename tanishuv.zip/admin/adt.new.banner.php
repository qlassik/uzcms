<?php

include_once '../sys/inc/yadro.php';
admin::check_access();
$advertisement = new adt();
$doc = new document(5);
$doc->title = __('Yangi baner');

if (!isset($_GET['id'])) {
    header('Refresh: 1; url=adt.php');
    $doc->ret(__('Reklamma и banerы'), 'adt.php');
    
    $doc->err(__('Tollangan tur xato'));

    exit;
}
$id_space = (string) $_GET['id'];

if (!$name = $advertisement->getNameById($id_space)) {
    header('Refresh: 1; url=?');
    $doc->err(__('Tollangan tur yo`q'));
    exit;
}

if (isset($_POST['create'])) {
    $code_main = text::input_text(@$_POST['code_main']);
    $code_other = text::input_text(@$_POST['code_other']);
    $pattern = '#<a +href\="(.+?)"><img +src\="(.+?)" *(alt\="(.+?)")? ?/></a>#ui';

    if (empty($_POST['captcha']) || empty($_POST['captcha_session']) || !captcha::check($_POST['captcha'], $_POST['captcha_session'])) {
        $doc->err(__('Raqam to`gri holatda kiritilmadi'));
    } else {
        if (preg_match($pattern, $code_main, $main)) {
            $uzcms->log('Reklamma', 'Banerа [url=/admin/adt.php?id=' . $id_space . ']' . $main[1] . '[/url]');

            if ($code_main == $code_other) {
                mysql_query("INSERT INTO `advertising` (`space`, `url_link`, `name`, `url_img`, `page_main`, `page_other`, `time_create`, `time_start`, `time_end`, `bold`)
VALUES ('" . my_esc($id_space) . "', '" . my_esc($main[1]) . "', '" . my_esc($main[4]) . "', '" . my_esc($main[2]) . "', '1', '1', '" . TIME . "', '0', '0', '0')");
                header('Refresh: 1; url=adt.settings.php?id=' . $id_space);

                $doc->msg(__('Baner o`rnatildi'));
                $doc->ret(__('Orqaga qaytish'), "adt.php?id=$id_space");
                $doc->ret(__('Reklamma'), 'adt.php');
                
                exit;
            } else {
                mysql_query("INSERT INTO `advertising` (`space`, `url_link`, `name`, `url_img`, `page_main`, `page_other`, `time_create`, `time_start`, `time_end`, `bold`)
VALUES ('" . my_esc($id_space) . "', '" . my_esc($main[1]) . "', '" . my_esc($main[4]) . "', '" . my_esc($main[2]) . "', '1', '0', '" . TIME . "', '0', '0', '0')");
                $doc->msg(__('Baner glavniga qo1yildi'));

                if (preg_match($pattern, $code_other, $other)) {
                    mysql_query("INSERT INTO `advertising` (`space`, `url_link`, `name`, `url_img`, `page_main`, `page_other`, `time_create`, `time_start`, `time_end`, `bold`)
VALUES ('" . my_esc($id_space) . "', '" . my_esc($other[1]) . "', '" . my_esc($other[4]) . "', '" . my_esc($other[2]) . "', '0', '1', '" . TIME . "', '0', '0', '0')");
                    $doc->msg(__('Baner qolgan saxifalarga qo1yildi'));
                }

                header('Refresh: 1; url=adt.php?id=' . $id_space);

                $doc->ret(__('Orqaga qaytish'), "adt.php?id=$id_space");
                $doc->ret(__('Reklamma'), 'adt.php');
                
                exit;
            }
        }else
            $doc->err(__('Qo`d to`gri emas yoki xatolik bor'));
    }
}

$form = new form("?id=$id_space&amp;" . passgen());
$form->textarea('code_main', __('HTML - qod (Bosh sahifaga)'));
$form->textarea('code_other', __('HTML - qod (Qolgan sahifaga)'));
$form->captcha();
$form->bbcode('[notice] ' . __('Masalan site.voo.uz'));
$form->button(__('Yaratish'), 'create');
$form->display();

$doc->ret(__('Orqaga qaytish'), "adt.php?id=$id_space");
$doc->ret(__('Reklamma'), 'adt.php');

?>
