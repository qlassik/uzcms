<?php

include_once '../sys/inc/yadro.php';
admin::check_access();
$advertisement = new adt();
$doc = new document(5);
$doc->title = __('Reklamma');

if (!isset($_GET['id'])) {
    header('Refresh: 1; url=adt.php');
    $doc->ret(__('Reklamma и banerы'), 'adt.php');
    
    $doc->err(__('Tollanmadi'));
    exit;
}
$id_space = (string) $_GET['id'];

if (!$name = $advertisement->getNameById($id_space)) {
    header('Refresh: 1; url=?');
    $doc->err(__('Tollanish yo`q'));
    exit;
}

if (isset($_POST['create'])) {
    $name_adt = text::input_text(@$_POST['name']);
    $url = text::input_text(@$_POST['url_link']);
    $url_img = text::input_text(@$_POST['url_img']);
    $bold = (int) (isset($_POST['bold']) && $_POST['bold']);
    $on_main = (int) (isset($_POST['page_main']) && $_POST['page_main']);
    $on_other = (int) (isset($_POST['page_other']) && $_POST['page_other']);

    if (isset($_POST['always']) && $_POST['always']) {
        
        $time1 = 0;
        $time2 = 0;
    } else {
        $starttime = (int) @$_POST['starttime'];
        $start = (int) @$_POST['start'];
        $lifetime = (int) @$_POST['lifetime'];
        $life = (int) @$_POST['life'];
       
        $time1 = max(TIME + $starttime * $start * 60, TIME);
        
        $time2 = $time1 + $lifetime * $life * 60 * 60 * 24;
    }

    if (empty($_POST['captcha']) || empty($_POST['captcha_session']) || !captcha::check($_POST['captcha'], $_POST['captcha_session'])) {
        $doc->err(__('Raqam to`gri holatda kiritilmadi'));
    } elseif ($name_adt && $url && $url != 'http://') {
        mysql_query("INSERT INTO `advertising` (`space`, `url_link`, `name`, `url_img`, `page_main`, `page_other`, `time_create`, `time_start`, `time_end`, `bold`)
VALUES ('" . my_esc($id_space) . "', '" . my_esc($url) . "', '" . my_esc($name_adt) . "', '" . my_esc($url_img) . "', '$on_main', '$on_other', '" . TIME . "', '$time1', '$time2', '$bold')");

        header('Refresh: 1; url=adt.php?id=' . $id_space);

        $uzcms->log('Reklamma', 'Rekilamma joylandi [url=/admin/adt.php?id=' . $id_space . ']' . $name_adt . '[/url]');

        $doc->msg(__('Qabul qilindi'));
        $doc->ret(__('Orqaga qaytish'), "adt.php?id=$id_space");
        $doc->ret(__('Reklamma'), 'adt.php');
        
        exit;
    }else
        $doc->err(__('Yoylammalar to`ldirilmagan'));
}

$form = new form("?id=$id_space&amp;" . passgen());

$form->text('name', __('Nomi'));
$form->checkbox('bold', __('Qalin yoziszh'));
$form->text('url_link', __('Manzil sisilki'), 'http://');
$form->text('url_img', __('Manzil rasim'), 'http://');

$form->checkbox('page_main', __('Bosh sahifaga'), true);
$form->checkbox('page_other', __('Qolgan sahifaga'), true);

$form->text('lifetime', __('Amal qillish vaqti'), 1, false, 3);
$options = array();
$options[] = array('1', __('Kun'));
$options[] = array('7', __('Xafta'), 1);
$options[] = array('31', __('Oy'));
$form->select('life', false, $options);

$form->text('starttime', __('Ko`rsatish vaqti'), 1, false, 3);
$options = array();
$options[] = array(0, __('Sequnt'));
$options[] = array(1, __('Minut'));
$options[] = array(60, __('Soat'));
$options[] = array(60 * 24, __('Kun'));
$options[] = array(60 * 24 * 7, __('Xafta'));
$form->select('start', false, $options);

$form->checkbox('always', __('Abadiy'));
$form->captcha();
$form->button(__('Yaratish'), 'create');
$form->display();


$doc->ret(__('Orqaga qaytish'), "adt.php?id=$id_space");
$doc->ret(__('Reklamma'), 'adt.php');

?>
