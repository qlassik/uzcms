<?php

include_once '../sys/inc/yadro.php';
admin::check_access();
$doc = new document(6);
$doc->title = __('Tema sozlamalari');
if($user->id == '1'){
$createaxs = stripcslashes(htmlspecialchars(@iconv_substr(MANZIL_U, 27, 99999999999, 'utf-8')));
$koringangaochmapapkaaza = stripcslashes(htmlspecialchars(@iconv_substr(MANZIL_U, 30, 99999999999, 'utf-8')));
$upaxs = stripcslashes(htmlspecialchars(@iconv_substr(MANZIL_U, 23, 99999999999, 'utf-8')));
$deldiraza = stripcslashes(htmlspecialchars(@iconv_substr(MANZIL_U, 27, 99999999999, 'utf-8')));
$renacd = stripcslashes(htmlspecialchars(@iconv_substr(MANZIL_U, 24, 99999999999, 'utf-8')));
$chmodac = stripcslashes(htmlspecialchars(@iconv_substr(MANZIL_U, 26, 99999999999, 'utf-8')));
$downloadaz = stripcslashes(htmlspecialchars(@iconv_substr(MANZIL_U, 29, 99999999999, 'utf-8')));
$faz = stripcslashes(htmlspecialchars(@iconv_substr(MANZIL_U, 22, 99999999999, 'utf-8')));
$daa = stripcslashes(htmlspecialchars(@iconv_substr(MANZIL_U, 22, 99999999999, 'utf-8')));
$ana = stripcslashes(htmlspecialchars(@iconv_substr(MANZIL_U, 23, 99999999999, 'utf-8')));
$renamb = stripcslashes(htmlspecialchars(@iconv_substr(MANZIL_U, 27, 99999999999, 'utf-8')));

$mana1 = str_replace('../', 'FFYHDJYFTJHFYEETRDYJJFGYRDYHFYFX', $ana);
$mana2 = str_replace('../', 'FFYHDJYFTJHFYEETRDYJJFGYRDYHFYFX', $daa);
$mana3 = str_replace('../', 'FFYHDJYFTJHFYEETRDYJJFGYRDYHFYFX', $faz);
$mana4 = str_replace('../', 'FFYHDJYFTJHFYEETRDYJJFGYRDYHFYFX', $downloadaz);
$mana5 = str_replace('../', 'FFYHDJYFTJHFYEETRDYJJFGYRDYHFYFX', $chmodac);
$mana6 = str_replace('../', 'FFYHDJYFTJHFYEETRDYJJFGYRDYHFYFX', $renacd);
$mana7 = str_replace('../', 'FFYHDJYFTJHFYEETRDYJJFGYRDYHFYFX', $deldiraza);
$mana8 = str_replace('../', 'FFYHDJYFTJHFYEETRDYJJFGYRDYHFYFX', $koringangaochmapapkaaza);
$mana9 = str_replace('../', 'FFYHDJYFTJHFYEETRDYJJFGYRDYHFYFX', $createaxs);
$mana11 = str_replace('../', 'FFYHDJYFTJHFYEETRDYJJFGYRDYHFYFX', $upaxs);
$mana12 = str_replace('../', 'FFYHDJYFTJHFYEETRDYJJFGYRDYHFYFX', $renamb);

$createaxs1 = stripcslashes(htmlspecialchars(@iconv_substr(MANZIL_U, 0, 24, 'utf-8'))); //admin/editon.php?create
$koringangaochmapapkaaza1 = stripcslashes(htmlspecialchars(@iconv_substr(MANZIL_U, 0, 27, 'utf-8'))); //admin/editon.php?koringangaochmapapka
$upaxs1 = stripcslashes(htmlspecialchars(@iconv_substr(MANZIL_U, 0, 20, 'utf-8'))); //admin/editon.php?up
$deldiraza1 = stripcslashes(htmlspecialchars(@iconv_substr(MANZIL_U, 0, 24, 'utf-8'))); //admin/editon.php?deldir
$renacd1 = stripcslashes(htmlspecialchars(@iconv_substr(MANZIL_U, 0, 21, 'utf-8'))); //admin/editon.php?ren
$chmodac1 = stripcslashes(htmlspecialchars(@iconv_substr(MANZIL_U, 0, 23, 'utf-8'))); //admin/editon.php?chmod
$downloadaz1 = stripcslashes(htmlspecialchars(@iconv_substr(MANZIL_U, 0, 26, 'utf-8'))); //admin/editon.php?download
$faz1 = stripcslashes(htmlspecialchars(@iconv_substr(MANZIL_U, 0, 19, 'utf-8'))); //admin/editon.php?f
$daa1 = stripcslashes(htmlspecialchars(@iconv_substr(MANZIL_U, 0, 19, 'utf-8'))); //admin/editon.php?d
$ana1 = stripcslashes(htmlspecialchars(@iconv_substr(MANZIL_U, 0, 17, 'utf-8'))); //admin/editon.php
$renamb1 = stripcslashes(htmlspecialchars(@iconv_substr(MANZIL_U, 0, 24, 'utf-8'))); //admin/editon.php?rename

if ($renamb1 == '/admin/editon.php?rename'){
	if ($renamb == $mana12);else{
	$doc->err(__('Sayt qattiq himoyalangan. qlassik_ru bu sistemani zashita qilish uchun 3 yillik mexnatini natijasi siz o`zizcha boshqa papkaga o`tishni o`ylayapsimi bo`lmaydi umuman tamom'));
	$doc->dost(__('Fayl yaratish'), '?create='.$d.'');		
$doc->dost(__('Fayl qo`shish'), '?up='.$d.'');		
$doc->dost(__('Papka ochish'), '?koringangaochmapapka='.$d.'');	
	exit;
}
}elseif ($createaxs1 == '/admin/editon.php?create'){
	if ($createaxs == $mana9);else{
	$doc->err(__('Sayt qattiq himoyalangan. qlassik_ru bu sistemani zashita qilish uchun 3 yillik mexnatini natijasi siz o`zizcha boshqa papkaga o`tishni o`ylayapsimi bo`lmaydi umuman tamom'));
	$doc->dost(__('Fayl yaratish'), '?create='.$d.'');		
$doc->dost(__('Fayl qo`shish'), '?up='.$d.'');		
$doc->dost(__('Papka ochish'), '?koringangaochmapapka='.$d.'');	
	exit;
}
}elseif ($koringangaochmapapkaaza1 == '/admin/editon.php?koringangaochmapapka'){
	if ($koringangaochmapapkaaza == $mana8);else{
		
	$doc->err(__('Sayt qattiq himoyalangan. qlassik_ru bu sistemani zashita qilish uchun 3 yillik mexnatini natijasi siz o`zizcha boshqa papkaga o`tishni o`ylayapsimi bo`lmaydi umuman tamom'));
	$doc->dost(__('Fayl yaratish'), '?create='.$d.'');		
$doc->dost(__('Fayl qo`shish'), '?up='.$d.'');		
$doc->dost(__('Papka ochish'), '?koringangaochmapapka='.$d.'');	
	exit;
}
}elseif ($upaxs1 == '/admin/editon.php?up'){
	if ($upaxs == $mana11);else{
	$doc->err(__('Sayt qattiq himoyalangan. qlassik_ru bu sistemani zashita qilish uchun 3 yillik mexnatini natijasi siz o`zizcha boshqa papkaga o`tishni o`ylayapsimi bo`lmaydi umuman tamom'));
	$doc->dost(__('Fayl yaratish'), '?create='.$d.'');		
$doc->dost(__('Fayl qo`shish'), '?up='.$d.'');		
$doc->dost(__('Papka ochish'), '?koringangaochmapapka='.$d.'');	
	exit;
}
}elseif ($deldiraza1 == '/admin/editon.php?deldir'){
	if ($deldiraza == $mana7);else{
	$doc->err(__('Sayt qattiq himoyalangan. qlassik_ru bu sistemani zashita qilish uchun 3 yillik mexnatini natijasi siz o`zizcha boshqa papkaga o`tishni o`ylayapsimi bo`lmaydi umuman tamom'));
	$doc->dost(__('Fayl yaratish'), '?create='.$d.'');		
$doc->dost(__('Fayl qo`shish'), '?up='.$d.'');		
$doc->dost(__('Papka ochish'), '?koringangaochmapapka='.$d.'');	
	exit;
}
}elseif ($renacd1 == '/admin/editon.php?ren'){
	if ($renacd == $mana6);else{
	$doc->err(__('Sayt qattiq himoyalangan. qlassik_ru bu sistemani zashita qilish uchun 3 yillik mexnatini natijasi siz o`zizcha boshqa papkaga o`tishni o`ylayapsimi bo`lmaydi umuman tamom'));
	$doc->dost(__('Fayl yaratish'), '?create='.$d.'');		
$doc->dost(__('Fayl qo`shish'), '?up='.$d.'');		
$doc->dost(__('Papka ochish'), '?koringangaochmapapka='.$d.'');	
	exit;
}
}elseif ($chmodac1  == '/admin/editon.php?chmod'){
	if ($chmodac  == $mana5);else{
	$doc->err(__('Sayt qattiq himoyalangan. qlassik_ru bu sistemani zashita qilish uchun 3 yillik mexnatini natijasi siz o`zizcha boshqa papkaga o`tishni o`ylayapsimi bo`lmaydi umuman tamom'));
	$doc->dost(__('Fayl yaratish'), '?create='.$d.'');		
$doc->dost(__('Fayl qo`shish'), '?up='.$d.'');		
$doc->dost(__('Papka ochish'), '?koringangaochmapapka='.$d.'');	
	exit;
}
}elseif ($downloadaz1  == '/admin/editon.php?download'){
	if ($downloadaz  == $mana4);else{
	$doc->err(__('Sayt qattiq himoyalangan. qlassik_ru bu sistemani zashita qilish uchun 3 yillik mexnatini natijasi siz o`zizcha boshqa papkaga o`tishni o`ylayapsimi bo`lmaydi umuman tamom'));
	$doc->dost(__('Fayl yaratish'), '?create='.$d.'');		
$doc->dost(__('Fayl qo`shish'), '?up='.$d.'');		
$doc->dost(__('Papka ochish'), '?koringangaochmapapka='.$d.'');	
	exit;
}
}elseif ($faz1  == '/admin/editon.php?f'){
	if ($faz == $mana3);else{ 	
	$doc->err(__('Sayt qattiq himoyalangan. qlassik_ru bu sistemani zashita qilish uchun 3 yillik mexnatini natijasi siz o`zizcha boshqa papkaga o`tishni o`ylayapsimi bo`lmaydi umuman tamom'));
	$doc->dost(__('Fayl yaratish'), '?create='.$d.'');		
$doc->dost(__('Fayl qo`shish'), '?up='.$d.'');		
$doc->dost(__('Papka ochish'), '?koringangaochmapapka='.$d.'');	
	exit;
}
}elseif ($daa1 == '/admin/editon.php?d'){
	if ($daa == $mana2);else{
	$doc->err(__('Sayt qattiq himoyalangan. qlassik_ru bu sistemani zashita qilish uchun 3 yillik mexnatini natijasi siz o`zizcha boshqa papkaga o`tishni o`ylayapsimi bo`lmaydi umuman tamom'));
	$doc->dost(__('Fayl yaratish'), '?create='.$d.'');		
$doc->dost(__('Fayl qo`shish'), '?up='.$d.'');		
$doc->dost(__('Papka ochish'), '?koringangaochmapapka='.$d.'');	
	exit;
}
}elseif ($ana1 == '/admin/editon.php?d'){
	if ($ana == $mana1);else{
	$doc->err(__('Sayt qattiq himoyalangan. qlassik_ru bu sistemani zashita qilish uchun 3 yillik mexnatini natijasi siz o`zizcha boshqa papkaga o`tishni o`ylayapsimi bo`lmaydi umuman tamom'));
	$doc->dost(__('Fayl yaratish'), '?create='.$d.'');		
$doc->dost(__('Fayl qo`shish'), '?up='.$d.'');		
$doc->dost(__('Papka ochish'), '?koringangaochmapapka='.$d.'');	
	exit;
}
}






Error_reporting(1); 
header('Content-type:text/html; charset=utf-8'); 
function changetime($FileName, $Fmtime) 
 { 
if(@strtotime($Fmtime)=='') 
{ return "<br/>Время не корректное!<br/>";} else { $mtime = strtotime($Fmtime); } 

if (@exec("touch {$FileName}")) $exec=1; 
else 
 { 
if (@touch ($FileName, $mtime)) 
{ 
$msg = "<b>Время последней модификации файла:</b>: ".(date("d.m.Y H:i:s", filemtime($FileName)))."<br/><b>Время последнего доступа к файлу:</b> ".(date("d.m.Y H:i:s", fileatime($FileName)))."<br/><b>Время создания файла:</b>: ".(date("d.m.Y H:i:s", filectime($FileName))); 
} 
 } 

 if($exec==1) return "Время изменено из командной строки<br/>"; 
 elseif($msg) return "Время изменено средствами РНР<br/>$msg"; 
 else return "Не удалось изменить время последней модификации файла <b>$FileName</b><br/>"; 
 } 
// end 
if(empty($_GET['zip']) and empty($_GET['download']) & empty($_GET['img'])){ 
list($msec,$sec)=explode(chr(32),microtime()); 
$HeadTime=$sec+$msec; 
echo'<html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"> 
<style type="text/css"> 
body { 
font-family: verdana; 
font-size: 11px; 
color: #B4B4B4; 
background-color:#000000;} 
a { 
color: #B6FF48; 
text-decoration:none;} 
a:hover { 
color: yellow; 
text-decoration: underline; 
} 
table{ 
padding: 0px; 
margin: 0px; 
border: 0px #B6FF48; 
background-color: #000; 
} 

td { 
 border: 1px solid #B6FF48; 
 font-family: verdana, geneva, lucida, arial; 
 background-color: #333; 
 color: #B4B4B4; 
 text-decoration: none; 
 font-size: 11px; 
 font-weight: bold; 
 width:100%; 
 padding-left: 2px; 
 padding-right: 2px; 
 padding-top: 1px; 
 padding-bottom: 2px; 
 text-align: left; 
} 

textarea 
{font: normal 11px verdana, geneva, lucida, arial, helvetica, sans-serif; 
min-height:400px;
color: #B4B4B4; 
background-color: #333333; 
border-color: #424242; 
border-left: 1px solid #0A0A0A; 
border-top: 1px solid #0A0A0A; 
border-right: 1px solid #2C2C2C; 
border-bottom: 1px solid #2C2C2C;} 
input:hover, textarea:hover {border-color: #B6FF48; 
color: red;} 
input:focus, textarea:focus { 
border-color: #B6FF48; 
color: red;} 

submit{font: normal 11px verdana, geneva, lucida, arial, helvetica, sans-serif; 
color: #B4B4B4; 
background-color: #333333; 
border-color: #424242; 
border-left: 1px solid #0A0A0A; 
border-top: 1px solid #0A0A0A; 
border-right: 1px solid #2C2C2C; 
border-bottom: 1px solid #2C2C2C; 
font-weight: bold; 
} 
submit:hover { 
border-color: #11A3EA; 
color: #11A3EA;} 
submit:focus { 
border-color: #11A3EA; 
color: #ffffff;} 

</style> 
</head><body>


';} 
if(empty($_GET['r']) & empty($_GET['input']) & empty($_GET['ren']) & empty($_GET['setchmod']) & empty($_GET['download']) & empty($_GET['up']) & empty($_GET['upload']) & empty($_GET['chmod']) & empty($_GET['rename']) & empty($_GET['rmdir']) & empty($_GET['made']) & empty($_GET['madedir']) & empty($_GET['create']) & empty($_GET['koringangaochmapapka']) & empty($_GET['del']) & empty($_GET['deldir']) & empty($_GET['f']) & empty($_GET['edit']) & empty($_GET['zip'])& empty($_GET['img']) & empty($_GET['touchfile']) & empty($_GET['touch'])){ 
if(empty($_GET['d'])){$d="../style/themes/";} 
else{$d=$_GET['d'];} 


$doc->dost(__('Fayl yaratish'), '?create='.$d.'');		
$doc->dost(__('Fayl qo`shish'), '?up='.$d.'');		
$doc->dost(__('Papka ochish'), '?koringangaochmapapka='.$d.'');		
echo '<div id="qani" class="ana"><b>'.__('Papka').':</b><table>'; 
$dir = opendir($d); 
while($file = readdir($dir)){ 
if(is_dir($d.'/'.$file)){ 
if($file != "." && $file != ".."){ 
$mod=substr(sprintf("%o",fileperms($d.'/'.$file)),-3); 
echo'<tr><td width="400"><img src="?img=1" alt=""><a href="?d='.$d.$file.'/">'.$file.'</a></td><td> DIR </td><td>'.(date("d.m.Y/H:i:s", filemtime($d))).'</td><td>'.$mod.'</td><td><a href="?zip='.$d.$file.'/">[zip]</a></td><td><a href="?deldir='.$d.$file.'/"><font color="#FF0000">[UD.]</font></a></td><td><a href="?ren='.$d.$file.'/">[NOM.]</a></td><td><a href="?chmod='.$d.$file.'/">[CH]</a></td></a></td></tr>';}}} 
echo'</table><br/><b> File:</b><table>'; 
$dir = opendir($d); 
while($file = readdir($dir)){ 
if(is_file($d.'/'.$file)){ 
$mod=substr(sprintf("%o",fileperms($d.'/'.$file)),-3); 
echo'<tr><td width="350"><img src="?img=2" alt=""><a href="?r='.$d.$file.'">'.$file.'</a></td><td>'.(date("d.m.Y", filemtime($d.$file))).'</td><td>'; echo round(filesize("$d/$file")/1024,1); echo'&nbsp;КБ</td><td>'.$mod.'</td><td><a href="?f='.$d.$file.'">[SOZLASH.]</a></td><td><a href="?del='.$d.$file.'"><font color="#FF0000">[UD.]</font></a></td><td><a href="?ren='.$d.$file.'">[NOM.]</a></td><td><a href="?chmod='.$d.$file.'">[CHM]</a></td><td><a href="?download='.$d.$file.'">[SQ]</a></td></tr>';}} 
echo'</table>';} 











if(isset($_GET['ren'])){ 
$fv = new fv('?rename='.$_GET['ren'].'&' . passgen());
$fv->text('new_name', __('Ko`chirish'),$_GET['ren']);
$fv->button(__('Saqlash'), 'save');
$fv->display();
$doc->dost(__('Fayl yaratish'), '?create='.$d.'');		
$doc->dost(__('Fayl qo`shish'), '?up='.$d.'');		
$doc->dost(__('Papka ochish'), '?koringangaochmapapka='.$d.'');
} 


if(isset($_GET['up'])){ 


$doc->dost(__('Fayl yaratish'), '?create='.$d.'');		
$doc->dost(__('Fayl qo`shish'), '?up='.$d.'');		
$doc->dost(__('Papka ochish'), '?koringangaochmapapka='.$d.'');



$fv = new fv('?&' . passgen());
$fv->text('new_name', __('Fayl nomi'), $mod);
$fv->file('file', '');
$fv->button(__('Saqlash'), 'save');
$fv->display();

} 


if(isset($_POST['upload'])){ 


$doc->dost(__('Fayl yaratish'), '?create='.$d.'');		
$doc->dost(__('Fayl qo`shish'), '?up='.$d.'');		
$doc->dost(__('Papka ochish'), '?koringangaochmapapka='.$d.'');
$new_name=trim($_POST['new_name']); 
if(copy($_FILES["file"]["tmp_name"], $_POST['upload'].$new_name)){ 
$doc->msg(__('Yuklandi'));
} 
else{
$doc->err(__('Yuklanmadi'));	

}} 


if(isset($_GET['download'])){ 
$file = file_get_contents($_GET['download']); 
$name = explode("/",$_GET['download']); 
$name = $name[count($name)-1]; 
header('Content-type: text/plain'); 
header("Content-disposition: attachment; filename=$name"); 
echo $file;} 





if(isset($_GET['touch'])) 
{ 
$doc->dost(__('Fayl yaratish'), '?create='.$d.'');		
$doc->dost(__('Fayl qo`shish'), '?up='.$d.'');		
$doc->dost(__('Papka ochish'), '?koringangaochmapapka='.$d.''); 
echo changetime($_GET['touch'], $_POST['mtime']); 
} 

 
if(isset($_GET['chmod'])){ 
$doc->dost(__('Fayl yaratish'), '?create='.$d.'');		
$doc->dost(__('Fayl qo`shish'), '?up='.$d.'');		
$doc->dost(__('Papka ochish'), '?koringangaochmapapka='.$d.'');
$mod=substr(sprintf("%o",fileperms($_GET['chmod'])),-3); 
$fv = new fv('?setchmod='.$_GET['chmod'].'&' . passgen());
$fv->text('text', __('Chmod'), $mod);
$fv->button(__('Saqlash'), 'save');
$fv->display();

} 


if(isset($_GET['setchmod'])){ 


$doc->dost(__('Fayl yaratish'), '?create='.$d.'');		
$doc->dost(__('Fayl qo`shish'), '?up='.$d.'');		
$doc->dost(__('Papka ochish'), '?koringangaochmapapka='.$d.'');

if(chmod($_GET['setchmod'],octdec($_POST['chmods']))){$doc->msg(__('CHmod %s ga o`zgardi.'),$_POST['chmods']);} 
else {$doc->err(__('CHmod %s ga o`zgarmadi'),$_POST['chmods']);}} 


if(isset($_GET['rmdir'])){ 


$doc->dost(__('Fayl yaratish'), '?create='.$d.'');		
$doc->dost(__('Fayl qo`shish'), '?up='.$d.'');		
$doc->dost(__('Papka ochish'), '?koringangaochmapapka='.$d.'');
$dir = opendir($_GET['rmdir']); 
while($dirs = readdir($dir)){ 
if(is_dir($_GET['rmdir'].$dirs)){ 
if($dirs != "." && $dirs != ".."){ 
$poddir = rmdir($_GET['rmdir'].$dirs);}}} 
closedir($dir); 
$ddir = rmdir($_GET['rmdir']); 
if($ddir){$doc->msg(__('O`chirildi'));	} 
if(!$ddir){$doc->err(__('Xato mavjud'));	} 
if($poddir){$doc->err(__('O`chirilmaydi'));	} 
if(!$poddir){$doc->err(__('Bunday nom mavjud emasi'));	}} 


if(isset($_GET['rename'])){ 
$doc->dost(__('Fayl yaratish'), '?create='.$d.'');		
$doc->dost(__('Fayl qo`shish'), '?up='.$d.'');		
$doc->dost(__('Papka ochish'), '?koringangaochmapapka='.$d.'');
$name = rename($_GET['rename'],$_POST['new_name']); 
if($name){
$doc->msg(__('O`zgardi'));	
	} 
if(!$name){
$doc->err(__('O`zgarmadi'));
	}} 

if(isset($_GET['r'])) 
{ 


$doc->dost(__('Fayl yaratish'), '?create='.$d.'');		
$doc->dost(__('Fayl qo`shish'), '?up='.$d.'');		
$doc->dost(__('Papka ochish'), '?koringangaochmapapka='.$d.'');

$file=file($_GET['r']); 
 if(function_exists('iconv')) 
 { 
 echo '<small>'; 
 $filegc=file_get_contents($_GET['r']); 
 if(!empty($filegc)) 
 { 
 if(function_exists('mb_check_encoding')) 
 { 
 if(!mb_check_encoding ($filegc, 'UTF-8')) 
 { 
for($i=0; $i<count($file); $i++) 
{ 
echo $file[$i] = htmlspecialchars(iconv("Windows-1251", "UTF-8", $file[$i])).'<br/>'; 
} 
 } 
 else 
 { 
for($i=0; $i<count($file); $i++) 
{ 
echo htmlspecialchars($file[$i]).'<br/>'; 
} 
 } 
 } 
 } 
 echo '</small>'; 
 } 
 else 
 { 
 echo "utf: "; 
if($file){ 
echo '<small>'; 
for($i=0; $i<count($file); $i++){ 
$file[$i] = htmlspecialchars($file[$i]); 
echo ''.$file[$i].'<br>';} 
echo '</small>';} 
if(!$file){$doc->err(__('Fayldi o`qi olmadim'));} 
 } 
echo '<hr>'; 
} 

if(isset($_GET['del'])){ 


$doc->dost(__('Fayl yaratish'), '?create='.$d.'');		
$doc->dost(__('Fayl qo`shish'), '?up='.$d.'');		
$doc->dost(__('Papka ochish'), '?koringangaochmapapka='.$d.'');
$delete = unlink($_GET['del']); 
if($delete){$doc->msg(__('Fayl %s o`chirildi'),$_GET['del']);} 
if(!$delete){$doc->err(__('Fayl %s o`chirilmadidi'),$_GET['del']);}} 



if(isset($_GET['deldir'])){ 


$doc->dost(__('Fayl yaratish'), '?create='.$d.'');		
$doc->dost(__('Fayl qo`shish'), '?up='.$d.'');		
$doc->dost(__('Papka ochish'), '?koringangaochmapapka='.$d.'');
$dir = opendir($_GET['deldir']); 
while($files = readdir($dir)){ 
if(is_file($_GET['deldir'].$files)){ 
$del = unlink($_GET['deldir'].$files);} 
if(is_dir($_GET['deldir'].$files) && $files !="." && $files !=".."){ 
$odir = opendir($_GET['deldir'].$files); 
while($reddir = readdir($odir)){ 
if(is_file($_GET['deldir'].$files.'/'.$reddir)){ 
$delet = unlink($_GET['deldir'].$files.'/'.$reddir);}}}} 
if($del){$doc->msg(__('O`chirildi'));	} 
if(!$del){$doc->err(__('Xato mavjud'));	} 
if($delet){$doc->err(__('O`chirilmaydi'));	} 
if(!$delet){$doc->err(__('Bunday nom mavjud emasi'));	}} 

if(isset($_GET['f'])){ 


$doc->dost(__('Fayl yaratish'), '?create='.$d.'');		
$doc->dost(__('Fayl qo`shish'), '?up='.$d.'');		
$doc->dost(__('Papka ochish'), '?koringangaochmapapka='.$d.'');
$file = file_get_contents($_GET['f']); 
 if(function_exists('mb_check_encoding')) 
 { 
 if(!mb_check_encoding ($file, 'UTF-8')) 
$file = htmlspecialchars(iconv("Windows-1251", "UTF-8", $file)); 
 else 
$file = htmlspecialchars($file); 
 } 
 else 
 { 
$file = htmlspecialchars($file); 
 } 
$fv = new fv('?edit='.$_GET['f'].'&' . passgen());
$fv->text('text', __('Fayl vaqti'), (filemtime($_GET['f'])));
$fv->textarea('mt', __('Fayl codi'), $file);
$fv->button(__('Tahrirlash'), 'save');
$fv->display();
}
if(isset($_GET['edit'])){ 
$fp = fopen($_GET['edit'],"w"); 
fputs($fp,$_POST['text']); 
fclose($fp); 
if(!empty($_POST['mt'])) 
{ 
if (@touch ($_GET['edit'], $_POST['mt'])) $msg = ''; 
} else $msg = ''; 
if($fp){$doc->msg(__('Fayl sozlandi'));} 
if(!$fp){$doc->err(__('Fayl sozlamasi saqlanmadi'));} 
} 

if(isset($_GET['create'])){ 
$fv = new fv('?made='.$_GET['create'].'&' . passgen());
$fv->text('new_name', __('Fayl nomi'));
$fv->textarea('new_file', __('Fayl codi'), '\r\n\r\n\r\n');
$fv->button(__('Saqlash'), 'save');
$fv->display();
}
if(isset($_GET['made'])){  
$fp = fopen($_GET['made'].$_POST['new_name'],"w"); 
fputs($fp,$_POST['new_file']); 
fclose($fp); 
chmod($_GET['made'].$_POST['new_name'], 0777); 
if($fp){$doc->msg(__('Yaratildi'));} 
if(!$fp){$doc->err(__('Bu papka nomi bor yoki serwerda hatolik bor'));}
} 


if(isset($_GET['koringangaochmapapka'])){ 
$fv = new fv('?madedir='.$_GET['koringangaochmapapka'].'&' . passgen());
$fv->text('new_dirname', __('Nomi'), __('Papka nomini yozin'));
$fv->button(__('Saqlash'), 'save');
$fv->display();
}
if(isset($_GET['madedir'])){ 




if(mkdir($_GET['madedir'].$_POST['new_dirname'],0777)){$doc->msg(__('papka yaratildi'));} else {$doc->err(__('Bu papka nomi bor yoki serwerda hatolik bor'));} 
} 


if(isset($_GET['zip'])){ 

class zipfile 
{ 

 var $datasec = array(); 
 var $ctrl_dir = array(); 
 var $eof_ctrl_dir = "\x50\x4b\x05\x06\x00\x00\x00\x00"; 
 var $old_offset = 0; 

 function add_dir($name) 

 { 
 $name = str_replace("\\", "/", $name); 

 $fr = "\x50\x4b\x03\x04"; 
 $fr .= "\x0a\x00"; 
 $fr .= "\x00\x00"; 
 $fr .= "\x00\x00"; 
 $fr .= "\x00\x00\x00\x00"; 
 $fr .= pack("V",0); 
 $fr .= pack("V",0); 
 $fr .= pack("V",0); 
 $fr .= pack("v", strlen($name) ); 
 $fr .= pack("v", 0 ); 
 $fr .= $name; 
 $fr .= pack("V",$crc); 
 $fr .= pack("V",$c_len); 
 $fr .= pack("V",$unc_len); 
 $this -> datasec[] = $fr; 
 $new_offset = strlen(implode("", $this->datasec)); 
 $cdrec = "\x50\x4b\x01\x02"; 
 $cdrec .="\x00\x00"; 
 $cdrec .="\x0a\x00"; 
 $cdrec .="\x00\x00"; 
 $cdrec .="\x00\x00"; 
 $cdrec .="\x00\x00\x00\x00"; 
 $cdrec .= pack("V",0); 
 $cdrec .= pack("V",0); 
 $cdrec .= pack("V",0); 
 $cdrec .= pack("v", strlen($name) ); 
 $cdrec .= pack("v", 0 ); 
 $cdrec .= pack("v", 0 ); 
 $cdrec .= pack("v", 0 ); 
 $cdrec .= pack("v", 0 ); 
 $ext = "\x00\x00\x10\x00"; 
 $ext = "\xff\xff\xff\xff"; 
 $cdrec .= pack("V", 16 ); 
 $cdrec .= pack("V", $this -> old_offset ); 
 $this -> old_offset = $new_offset; 
 $cdrec .= $name; 
 $this -> ctrl_dir[] = $cdrec; 
 } 


 function add_file($data, $name) 
 { $name = str_replace("\\", "/", $name); 
$fr = "\x50\x4b\x03\x04"; 
 $fr .= "\x14\x00"; 
 $fr .= "\x00\x00"; 
 $fr .= "\x08\x00"; 
 $fr .= "\x00\x00\x00\x00"; 

 $unc_len = strlen($data); 
 $crc = crc32($data); 
 $zdata = gzcompress($data); 
 $zdata = substr( substr($zdata, 0, strlen($zdata) - 4), 2); 
 $c_len = strlen($zdata); 
 $fr .= pack("V",$crc); 
 $fr .= pack("V",$c_len); 
 $fr .= pack("V",$unc_len); 
 $fr .= pack("v", strlen($name) ); 
 $fr .= pack("v", 0 ); 
 $fr .= $name; 
 $fr .= $zdata; 
 $fr .= pack("V",$crc); 
 $fr .= pack("V",$c_len); 
 $fr .= pack("V",$unc_len); 
 $this -> datasec[] = $fr; 
 $new_offset = strlen(implode("", $this->datasec)); 
 $cdrec = "\x50\x4b\x01\x02"; 
 $cdrec .="\x00\x00"; 
 $cdrec .="\x14\x00"; 
 $cdrec .="\x00\x00"; 
 $cdrec .="\x08\x00"; 
 $cdrec .="\x00\x00\x00\x00"; 
 $cdrec .= pack("V",$crc); 
 $cdrec .= pack("V",$c_len); 
 $cdrec .= pack("V",$unc_len); 
 $cdrec .= pack("v", strlen($name) ); 
 $cdrec .= pack("v", 0 ); 
 $cdrec .= pack("v", 0 ); 
 $cdrec .= pack("v", 0 ); 
 $cdrec .= pack("v", 0 ); 
 $cdrec .= pack("V", 32 ); 

 $cdrec .= pack("V", $this -> old_offset ); 
 $this -> old_offset = $new_offset; 

 $cdrec .= $name; 
 $this -> ctrl_dir[] = $cdrec; 
 } 

 function file() { 
 $data = implode("", $this -> datasec); 
 $ctrldir = implode("", $this -> ctrl_dir); 
 return 
 $data. 
 $ctrldir. 
 $this -> eof_ctrl_dir. 
 pack("v", sizeof($this -> ctrl_dir)). 
 pack("v", sizeof($this -> ctrl_dir)). 
 pack("V", strlen($ctrldir)). 
 pack("V", strlen($data)). 
 "\x00\x00"; }} 
$abort = ignore_user_abort(1); 
$zipfile = new zipfile(); 
$fdir = opendir($_GET['zip']); 
while($file = readdir($fdir)){ 
if ($file != '.' and $file != '..'){ 
if (is_file($_GET['zip'].$file)){$zipfile->add_file(file_get_contents($_GET['zip'].$file),$file);} 
if (is_dir($_GET['zip'].$file)){ 
$sdir = opendir($_GET['zip'].$file); 
while($sfile = readdir($sdir)){ 
if ($sfile != '.' and $sfile != '..'){ 
if (is_file($_GET['zip'].$file.'/'.$sfile)){$zipfile->add_file(file_get_contents($_GET['zip'].$file.'/'.$sfile), $file.'/'.$sfile);}}}}}} 
$name = explode("/",$_GET['zip']); 
$file = $name[count($name)-2]; 
header('Content-type: application/octet-stream'); 
header("Content-disposition: attachment; filename=$file.zip"); 
echo $zipfile->file();} 

 

echo'</div>';
}
?>
