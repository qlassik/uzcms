<?php

include_once '../sys/inc/yadro.php';
admin::check_access();
$doc = new document(5);
$doc->title = __('Sovga');









		
if(isset($_GET['act']) && $_GET['act'] == 'add_kat')
{
	if(isset($_POST['save']))
	{
		$name = mysql_real_escape_string($_POST['name']);
       $x = mysql_result(mysql_query("SELECT COUNT(*) FROM `id` "), 0);
		
		if(isset($_POST['name']))
		{
		mysql_query("INSERT INTO `id` (`id`, `name` ) VALUES ('$x + 1', '$name')");
		header("Location: ?");
		exit;
		}
	}
	
$listing = new listing();
$form = new form("?act=add_kat&" . passgen());
$form->input('name', __('Bo`lim nomi'));
$form->button(__('Yuborish'), 'save', false);
$doc->ret(__('Smail'), '?');	
$doc->ret(__('Smail qo`shish'), '?act=qosh');	
$form->display();
echo'</div>';
exit;	
}



if (isset($_GET['cat'])){
$id = (int) $_GET['cat'];
$doc -> title = __('Smayllar papkasi');
if (isset($_GET['oz'])){
if (isset($_POST['gift_list']))
{
mysql_query("UPDATE `gift_list` SET `sum` = '".my_esc($_POST['gift_list'])."' WHERE `id` = '".$_GET['oz']."'");
$doc->msg(__('Smail nomi o`zgardi'));
header("Location: ?cat=".$_GET['cat']."&" . passgen()."");
exit;
}
$q = mysql_query("SELECT * FROM `gift_list` WHERE `id` = '".$_GET['oz']."'  ORDER BY `id_bolim` = '".$id."' DESC LIMIT 1");
while ($sss = mysql_fetch_assoc($q)) {
$ss = $sss['sum'];
}


$listing = new listing();
$form = new form("?cat=".$_GET['cat']."&oz=".$_GET['oz']."&" . passgen());
$form->input('gift_list', __('Summani kiriting'), $ss);
$form->button(__('Yuborish'), 'post', false);
$doc->ret('<img src="/img/badge.png"> '.__('Smail'), '?');	
$doc->ret('<img src="/img/badge.png"> '.__('Smail qo`shish'), '?act=qosh');	
$form->display();

echo '</div>';
exit;
}
if (isset($_GET['ud'])){	
mysql_query("DELETE FROM `gift_list` WHERE `id` = '" . $_GET['ud'] . "'");
$doc->msg(__('Sovg`ani o`chirildi'));
header("Location: ?cat=".$_GET['cat']."");
exit;

}

$pages = new pages(mysql_result(mysql_query("SELECT COUNT(*) FROM `gift_list`"), 0));
$listing = new listing();
$q = mysql_query("SELECT * FROM `gift_list` WHERE `id`  ORDER BY `id_bolim` = '".$id."' DESC LIMIT ".$pages->limit);
while ($sm = mysql_fetch_assoc($q)) {
$post = $listing->post();
$post->title = '<img src="/style/images/gift/'.$sm['id'].'.png" title="voo.uz" />  '.__('Bahosi').': '.$sm['sum'].'';
$post->action('developers', '?cat='.$_GET['cat'].'&oz='.$sm['id'].'&amp;' . passgen());
$post->action('nns', '');
$post->action('delete', '?cat='.$_GET['cat'].'&ud='.$sm['id'].'&amp;' . passgen());
}
$listing->display(__('Ro`yhat bo`sh'));
$pages->this_page();
$pages->display('?cat='.$_GET['cat'].'&');

exit;
}


$doc -> title = __('Sovgalar papkasi');
$pages = new pages(mysql_result(mysql_query("SELECT COUNT(*) FROM `gift_categories`"), 0));
$listing = new listing();
$q = mysql_query("SELECT * FROM `gift_categories` WHERE `id`  ORDER BY `id` DESC LIMIT ".$pages->limit);
while ($sm = mysql_fetch_assoc($q)) {
$post = $listing->post();
$post->icon('authentication');
$post->url = '?cat='.$sm['id'].'';
$post->title = $sm['name'];
$post->time = ''.mysql_result(mysql_query("SELECT COUNT(*) FROM `gift_list` WHERE `id_bolim` = '".$sm['id']."'"), 0).'';

}
$listing->display(__('Ro`yhat bo`sh'));
$pages->this_page();
$pages->display('?');