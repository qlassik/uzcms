<?php
include_once '../sys/inc/yadro.php';
$doc = new document(2);
$doc->title = __('Adminkaga o`tish');
if (!$user->group_pass){
$doc->err(__('Sizga paro`l berilmagan'));
header('Refresh: 1; url=/admin_parol.html?' . SID);
exit;		
}elseif ($user->group <= '2'){
$doc->err(__('Siz bu erda kirish imkoniyatingiz yo`q'));
header('Refresh: 1; url=/?' . SID);
exit;
}
if (!isset($_SESSION['xaydal']) && !admin::is_access() && (empty($_POST['captcha_session']) || empty($_POST['captcha']))) {
    $doc->msg(__('Rasimdagi qo`dni kiritin'));
} elseif (!admin::is_access() && !captcha::check($_POST['captcha'], $_POST['captcha_session'])) {
    $doc->err(__('Rasim notori kiritildi'));
} else {
	if ($user->group_pass == $_POST['paroll']){
    admin::access();

    $doc->msg(__('Omad'));
	unset($_SESSION['xayda']);
	unset($_SESSION['xaydal']);

    if (!empty($_GET['return'])) {
        header('Refresh: 1; url=' . $_GET['return']);
        $doc->ret(__('Orqaga qaytish'), text::toValue($_GET['return']));
    } else {
        header('Refresh: 1; url=./?' . SID);
        $doc->ret(__('Adminkaga'), '/admin/');
    }

    exit;
	}else{
		if (!isset($_SESSION['xayda'])){
		$_SESSION['xayda']	= 1;
		}
		$_SESSION['xayda'] = $_SESSION['xayda'] + 1;
	    $doc->err(__('Parolni notogri kiritdingiz'));	
	}
}
if(!isset($_SESSION['xaydal'])){
if(isset($_SESSION['xayda'])){
if($_SESSION['xayda'] == '3'){	
header('Refresh: 1; url=/user/x.php?' . SID);
$_SESSION['xaydal'] = TIME + 40;
unset($_SESSION['xayda']);
}
}

$form = new form('?' . passgen() . (isset($_GET['return']) ? '&amp;return=' . urlencode($_GET['return']) : null));
$form->text('paroll', __('Parolni yozing'));
$form->captcha();
if (preg_match('#Opera mobile#ui', $uzcms->browser))
    $form->bbcode('[notice] '.__('Sizda turbo funsiyasi o`chiq'));
$form->button(__('Kirish'));
$form->display();
}else{
if($_SESSION['xaydal'] >= TIME){
unset($_SESSION['xaydal']);
}	
}
?>
