<?php

include_once '../sys/inc/yadro.php';
admin::check_access();
$doc = new document(5);
$doc->title = __('Ro`yhatdan o`tish sozlamasi');

if (isset($_POST['save'])) {
    $uzcms->reg_open = (int) !empty($_POST['reg_open']);
    $uzcms->reg_with_mail = (int) !empty($_POST['reg_with_mail']);
    $uzcms->clear_users_not_verify = (int) !empty($_POST['clear_users_not_verify']);
    $uzcms->reg_with_rules = (int) !empty($_POST['reg_with_rules']);
    $uzcms->reg_with_invite = (int) !empty($_POST['reg_with_invite']);
    $uzcms->balls_for_invite = (int) $_POST['balls_for_invite'];
    $uzcms->user_write_limit_hour = (int) $_POST['user_write_limit_hour'];    
    $uzcms->save_settings($doc);
}

$form = new form('?' . passgen());
$form->checkbox('reg_open', __('Qoida qo`yilsin'), $uzcms->reg_open);
$form->checkbox('reg_with_mail', __('E-mail orqalik'), $uzcms->reg_with_mail);
$form->checkbox('clear_users_not_verify', __('Agar emalorqalik aktiv bo`lmasa ID o`chirilsin'), $uzcms->clear_users_not_verify);
$form->checkbox('reg_with_rules', __('Ogoxlantirish'), $uzcms->reg_with_rules);
$form->text('user_write_limit_hour', __('Ro`yhatdan otkandan kegin qancha minutda habar yoza olsin'), $uzcms->user_write_limit_hour);
$form->button(__('Saqlash'), 'save');
$form->display();


?>
