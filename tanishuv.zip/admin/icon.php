<?php

include_once '../sys/inc/yadro.php';
admin::check_access();
$smiles = smiles::get_ini();
$doc = new document(5);
$doc->title = __('Rasim qo`yish');






if (isset($_GET['id'])){
if (isset($_POST['save']))
{
mysql_query("UPDATE `iconca` SET `nomi` = '".my_esc($_POST['nomi'])."', `rasmi` = '".my_esc($_POST['rasmi'])."' WHERE `id` = '".$_GET['id']."'");
$doc->msg(__('Smail nomi o`zgardi'));
header("Location: ?" . passgen()."");
exit;
}
$q = mysql_query("SELECT * FROM `iconca` WHERE `id` = '".$_GET['id']."'  ORDER BY `id` DESC LIMIT 1");
while ($sss = mysql_fetch_assoc($q)) {
$iu = $sss['nomi'];
$ia = $sss['rasmi'];
}

$listing = new listing();
$form = new form("?id=".$_GET['id']."&" . passgen());
$form->input('nomi', __('Nomi'), $iu);
$form->input('rasmi', __('Codi'), $ia);
$form->button(__('Yuborish'), 'save', false);
$doc->grp(__('Qaytish'), '?');	
$form->display();
exit;
}




if(isset($_GET['act']) && $_GET['act'] == 'add_kat')
{
	if(isset($_POST['save']))
	{
		
		if(isset($_POST['nomi']) && isset($_POST['rasmi']))
		{
		mysql_query("INSERT INTO `iconca` (`nomi`, `rasmi`) VALUES ('".$_POST['nomi']."', '".$_POST['rasmi']."')");
		header("Location: ?");
		exit;
		}
	}
	
$listing = new listing();
$form = new form("?act=add_kat&" . passgen());
$form->input('nomi', __('Nomi'));
$form->input('rasmi', __('Codi'));
$form->button(__('Yuborish'), 'save', false);
$doc->grp(__('Qaytish'), '?');	
$form->display();
exit;	
}



$doc -> title = __('Iconka');
$pages = new pages(mysql_result(mysql_query("SELECT COUNT(*) FROM `iconca`"), 0));
$listing = new listing();
$q = mysql_query("SELECT * FROM `iconca` WHERE `id`  ORDER BY `id` DESC LIMIT ".$pages->limit);
while ($sm = mysql_fetch_assoc($q)) {
$post = $listing->post();
$post->title = ''.sm_icon($sm['rasmi']).' '.$sm['nomi'];
$post->action('developers', '?id='.$sm['id'].'&amp;' . passgen());

}
$listing->display(__('Ro`yhat bo`sh'));
$pages->this_page();
$pages->display('?');
$doc->grp(__('Iconka bo`lim yaratish'), '?act=add_kat');