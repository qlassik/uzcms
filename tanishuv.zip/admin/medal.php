<?php
include_once '../sys/inc/yadro.php';
admin::check_access();
$doc = new document(1); 
$doc->title = __('Medal summasi');

if (isset($_GET['okey'])){
	$sa = (int) $_GET['okey'];
if ($_GET['okey'] == $_GET['okey'] && isset($_POST['save'])){	
mysql_query("UPDATE `medal` SET `sum` = '".$_POST['sum']."', `nomi` = '".$_POST['nomi']."'  WHERE `id` = '".$_GET['okey']."' LIMIT 1");
$doc->msg(__('Qo`yildi'));
header('Refresh: 1; url=?');
exit;
}
	
$form = new form('?okey='.$_GET['okey'].'&' . passgen());
$form->text('nomi', __('Nomi'));
$form->text('sum', __('Summasi'));
$form->button(__('Saqlash'), 'save');
$form->display();
exit;	
}
$pages = new pages(mysql_result(mysql_query("SELECT COUNT(*) FROM `medal`"), 0));
$listing = new listing();
$q = mysql_query("SELECT * FROM `medal` WHERE `id` ORDER BY `id` DESC LIMIT ".$pages->limit);
while ($ok = mysql_fetch_assoc($q)) {
$kv = $listing->kv();
$kv->url = '?okey='.$ok['id'].'';
$kv->image = '/style/images/medal/'.$ok['id'].'.gif';
$kv->title = $ok['nomi'];
$kv->mehmon = ''.__('Summasi').' ('.$ok['sum'].')';
 }

$listing->display(__('Ro`yhat bo`sh'));
$pages->this_page();
$pages->display('?');



$qa = mysql_query("SELECT * FROM `medal` WHERE `id` ORDER BY `id` DESC LIMIT 1");
while ($okz = mysql_fetch_assoc($qa)) {
$ds	= $okz['id'];
}		
if ($ds <= '29'){
mysql_query("INSERT INTO `medal` (`nomi`) VALUES ('Nom yo`q')") ;	
} 
$doc->ret(__('Adminka'), './');