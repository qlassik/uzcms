<?php

include_once '../sys/inc/yadro.php';
admin::check_access();
$doc = new document(2);
$doc->title = __('Ban');

$ank = new user(@$_GET ['id_ank']);

if (!$ank->group) {
    if (isset($_GET ['return']))
        header('Refresh: 1; url=' . $_GET ['return']);
    else
        header('Refresh: 1; url=/');

    $doc->err(__('Malumot yo`q'));
    exit;
}

if ($ank->group >= $user->group) {
    if (isset($_GET ['return']))
        header('Refresh: 1; url=' . $_GET ['return']);
    else
        header('Refresh: 1; url=/');

    $doc->err(__('Joylashmagan'));
    exit;
}

$doc->title = __('Ban "%s"', $ank->title);

$link = !empty($_GET ['link']) ? $_GET ['link'] : (!empty($_POST ['link']) ? $_POST ['link'] : false);
$code = !empty($_GET ['code']) ? $_GET ['code'] : (!empty($_POST ['code']) ? $_POST ['code'] : false);

$codes = new menu_code('main');

if (!$code && !isset($_GET ['skip'])) {

    $fv = new fv('?id_ank=' . $ank->id . '&amp;link=' . urlencode($link) . (isset($_GET ['return']) ? '&amp;return=' . urlencode($_GET ['return']) : null));
    $fv->text('link', __('Adres'), $link);
    if ($link)
        $fv->bbcode('[url="' . $link . '"]' . __('Перейти к нарушению') . '[/url]');
    $fv->select('code', __('Narushena'), $codes->options());
    $fv->button(__('Keyingisiga o`tish'));
    $fv->display();

    if (isset($_GET ['return'])) {
        $doc->ret(__('Orqaga qaytish'), text::toValue($_GET ['return']));
    }
    $doc->ret(__('Anketaga qaytish'), '/ID' . $ank->id);
    
    exit;
}
list ( $min, $max ) = $codes->get_time($code);

if (isset($_POST ['ban'])) {
    $comm = text::input_text(@$_POST ['comment']);
    $access_view = (int) empty($_POST ['full']);

    $time_1 = abs((int) @$_POST ['time']);
    switch (@$_POST ['timem']) {
        case 'forever':
            $time_ban_end = 'NULL';
            break;
        case 'm' :
            $time_ban_end = $time_1 * 60 + TIME;
            break;
        case 'h' :
            $time_ban_end = $time_1 * 3600 + TIME;
            break;
        case 'd' :
            $time_ban_end = $time_1 * 86400 + TIME;
            break;
        case 'ms' :
            $time_ban_end = $time_1 * 2592000 + TIME;
            break;
    }

    if (!$time_1)
        $doc->err(__('Vaqit qisqa'));
    elseif (!isset($codes->menu_arr [$code]))
        $doc->err(__('Jazo holati yo`q'));
    elseif (!$comm)
        $doc->err(__('Xatolik'));
    elseif ($link && mysql_result(mysql_query("SELECT COUNT(*) FROM `ban` WHERE `id_user` = '$ank->id' AND `link` = '" . my_esc($link) . "' AND `code` = '" . my_esc($code) . "'"), 0))
        $doc->err(__('Нельзя банить fodalanuvchiniki несколько раз за одно и то же Narushena'));
    else {
        
        mysql_query("UPDATE `complaints` SET `processed` = '1' WHERE `id_ank` = '$ank->id' AND `link` = '" . my_esc($link) . "' AND `code` = '" . my_esc($code) . "'");
       
        mysql_query("INSERT INTO `ban` (`id_user`, `id_adm`, `link`, `code`, `comment`, `time_start`, `time_end`, `access_view`)
VALUES ('$ank->id', '$user->id', '" . my_esc($link) . "', '" . my_esc($code) . "', '" . my_esc($comm) . "', '" . TIME . "', $time_ban_end, '$access_view') ");
        mysql_query("UPDATE `users` SET `is_ban` = '1' WHERE `id` = '$ank->id'");

        $uzcms->log('Foydalanuvchi', 'Ban oldi [user]' . $ank->id . '[/user] на' . ($time_ban_end == 'NULL' ? 'Abadiy' : (' ' . misc::when($time_ban_end) )) . "\nXolat: $comm");

        if ($time_ban_end == 'NULL') {
            $doc->msg(__('Abadiy ban bo`ldi'));
        } else {
            $doc->msg(__('Bandan %s chi ozod bo`ldi', misc::when($time_ban_end)));
        }
    }
}

if (!empty($_GET['ban_delete'])) {
    $id_ban_delete = (int) $_GET['ban_delete'];
    $q = mysql_query("SELECT * FROM `ban` WHERE `id_user` = '$ank->id' AND `id` = '$id_ban_delete'");
    if (!mysql_num_rows($q)) {
        $doc->err(__('Ozod bo`lmadi'));
    } else {
        $ban = mysql_fetch_assoc($q);
        $adm = new user($ban['id_adm']);
        if ($adm->group < $user->group || $adm->id == $user->id) {

            mysql_query("DELETE FROM `ban` WHERE `id` = '$id_ban_delete' LIMIT 1");

            $doc->msg(__('Malades'));
        } else {
            $doc->err(__('Holat yakulanmagan'));
        }
    }
}

$listing = new listing();

$q = mysql_query("SELECT * FROM `ban` WHERE `id_user` = '$ank->id' ORDER BY `id` DESC");
while ($c = mysql_fetch_assoc($q)) {
    $post = $listing->post();
    $adm = new user($c ['id_adm']);
    $post->action('delete', '?id_ank=' . $ank->id . '&amp;ban_delete=' . $c['id'] . '&amp;skip');
    $post->title = $adm->nick();
    $post->time = misc::when($c ['time_start']);
    $post->content[] = __('Narushena: %s', text::toValue($c['code']));

    if ($c ['time_start'] && TIME < $c ['time_start'])
        $post->content[] = '[b]' . __('Boshlanish vaqti') . ':[/b]' . misc::when($c ['time_start']);

    if ($c['time_end'] === NULL)
        $post->content[] = '[b]' . __('Tosilgan') . "[/b]";
    elseif (TIME < $c['time_end'])
        $post->content[] = __('Qolgan: %s', misc::when($c['time_end']));

    if ($c['link'])
        $post->content[] = __('Sisilka: %s', $c['link']);
    $post->content[] = __('Sharh: %s', $c['comment']);
}

$listing->display(__('Holat yo`q'));

$fv = new fv('?id_ank=' . $ank->id . '&amp;code=' . urlencode($code) . '&amp;link=' . urlencode($link) . (isset($_GET ['return']) ? '&amp;return=' . urlencode($_GET ['return']) : null));
$fv->text('link', __('Adres'), $link);
if ($link)
    $fv->bbcode('[url="' . $link . '"]' . __('O`tish') . '[/url]');
$fv->select('code', __('Narushena'), $codes->options($code));

if (!$min || $min < 3600) {
    $time = max(round($min / 60), 10);
    $timem = 'm';
} elseif ($min < 86400) {
    $time = max(round($min / 3600), 1);
    $timem = 'h';
} elseif ($min < 2592000) {
    $time = max(round($min / 86400), 1);
    $timem = 'd';
} else {
    $time = max(round($min / 2592000), 1);
    $timem = 'ms';
}

$fv->text('time', __('Yakulanish vaqti'), $time, false, 3);
$options = array();
$options[] = array('m', __('Minut'), $timem == 'm');
$options[] = array('h', __('Soat'), $timem == 'h');
$options[] = array('d', __('Kun'), $timem == 'd');
$options[] = array('ms', __('Oy'), $timem == 'ms');
$options[] = array('forever', __('Abadiy'));
$fv->select('timem', false, $options);
$fv->checkbox('full', __('Umuman holatda emas') . ' *');
$fv->textarea('comment', __('Sharh'));
$fv->button(__('Zaban'), 'ban');
$fv->display();


if (isset($_GET ['return'])) {
    $doc->ret(__('Orqaga qaytish'), text::toValue($_GET ['return']));
}

$doc->ret(__('Anketaga qaytish'), '/ID' . $ank->id);

?>
