<?php

include_once '../sys/inc/yadro.php';
$doc = new document(5);
$doc->title = __('Infarmatsa');
/*
if (!$uzcms->log_of_visits) {
    $doc->err(__('O`chirilgan'));
}

if (isset($log_of_visits) && mysql_result(mysql_query("SELECT COUNT(*) FROM `log_of_visits_today` WHERE `time` <> '" . DAY_TIME . "' LIMIT 1"), 0)) {
    $log_of_visits->tally();
}
*/
$pages = new pages;
$pages->posts = mysql_result(mysql_query("SELECT COUNT(*) FROM `log_of_visits_for_days`"), 0);
$pages->this_page(); 

$listing = new listing();
$q = mysql_query("SELECT * FROM `log_of_visits_for_days` ORDER BY `time_day` DESC LIMIT $pages->limit");
while ($st = mysql_fetch_assoc($q)) {
    $post = $listing->post();
    $post->title = date('d-m-Y', $st['time_day']);
    $post->icon('statistics');
    $post->content = "<table border='1' style='border-collapse: collapse'>\n";
    $post->content .= "<tr><td></td><td>mobilni</td><td>planshet</td><td>androit</td><td>komp</td><td>" . __('Kunlik') . "</td></tr>\n";
    $post->content .= "<tr><td>" . __('Xoct') . "</td><td>$st[hosts_mobilni]</td><td>$st[hosts_planshet]</td><td>$st[hosts_androit]</td><td>$st[hosts_komp]</td><td>" . ($st['hosts_mobilni'] + $st['hosts_planshet'] + $st['hosts_androit'] + $st['hosts_komp']) . "</td></tr>\n";
    $post->content .= "<tr><td>" . __('Xit') . "</td><td>$st[hits_mobilni]</td><td>$st[hits_planshet]</td><td>$st[hits_androit]</td><td>$st[hits_komp]</td><td>" . ($st['hits_mobilni'] + $st['hits_planshet'] + $st['hits_androit'] + $st['hits_komp']) . "</td></tr>\n";
    $post->content .= "</table>\n";
}
$listing->display(__('Malumot yo`q'));

$pages->display('?');

if (!$uzcms->log_of_visits) {
    $doc->act(__('Sozlash'), 'sys.daemons.php');
}


?>
