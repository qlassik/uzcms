<?php

include_once '../sys/inc/yadro.php';
admin::check_access();
$groups = groups::load_ini();
$doc = new document(4);
$doc->title = __('Mansabni o`zgartirish');

if (isset($_GET['id_ank']))
    $ank = new user($_GET['id_ank']);
else
    $ank = $user;

if (!$ank->group) {
    if (isset($_GET['return']))
        header('Refresh: 1; url=' . $_GET['return']);
    else
        header('Refresh: 1; url=/');

    $doc->err(__('Malumot yo`q'));
    exit;
}

$doc->title .= ' "' . $ank->title . '"';

if ($ank->group >= $user->group) {
    if (isset($_GET['return']))
        header('Refresh: 1; url=' . $_GET['return']);
    else
        header('Refresh: 1; url=/');

    $doc->err(__('Bu holatda darajez etmaydi'));
    exit;
}

if (isset($_POST['save']) && !empty($_POST['group'])) {
    $group_now = (int) $_POST['group'];
    if ($group_now >= $user->group)
        $doc->err(__('Bu holatda darajez etmaydi'));
    else {
        $group_last = $ank->group;
        if ($group_last != $group_now) {
            mysql_query("INSERT INTO `log_of_user_status` (`id_user`, `id_adm`, `time`, `type_last`, `type_now`) VALUES ('$ank->id', '$user->id', '" . TIME . "', '$group_last', '$group_now')");
            $ank->group = $group_now;
            $ank->group_nom = $_SEESION['groupp'];
            $ank->group_pass =	$_POST['parol'];		
			unset($_SEESION['group']);
             unset($_SEESION['groupp']);			 
            $uzcms->log('Foydalanuvchini', 'o`zgartirildi [url=/ID' . $ank->id . ']' . $ank->title . '[/url] с ' . groups::name($group_last) . ' на ' . groups::name($ank->group));

            $doc->msg(__('Foydalanuvchini "%s" endi "%s" ga aylandi', $ank->title, groups::name($ank->group)));
        }
    }
}
if (isset($_GET['id_ank']) && isset($_GET['group'])){
	
$q = mysql_query("SELECT * FROM `admin_mansab` WHERE  `id` = '".$_GET['group']."' ORDER BY `id` DESC LIMIT 1");
while ($us = mysql_fetch_assoc($q)) {
$_SEESION['groupp'] = $us['nomi'];	
}
$fv = new fv("?id_ank=$ank->id&amp;" . passgen() . (isset($_GET['return']) ? '&amp;return=' . urlencode($_GET['return']) : null));
$options = array();
foreach ($groups as $group => $value) {
    if ($group && $user->group > $group)
        $options[] = array($group, __($value['name']), $group == $ank->group);
}
$fv->select('group', __('Mansab'), $options);
$fv->text('parol', __('Parol'));
$fv->button(__('Saqlash'), 'save');
$fv->display();
$doc->ret(__('Malumotiga'), 'user.actions.php?id=' . $ank->id);
$doc->ret(__('Anketa "%s"', $ank->title), '/ID' . $ank->id);
exit;
}




$_SEESION['group'] = 'ok';

$pages = new pages(mysql_result(mysql_query("SELECT COUNT(*) FROM `admin_mansab`"), 0));
$listing = new listing();
$q = mysql_query("SELECT * FROM `admin_mansab` WHERE  `id` ORDER BY `id` DESC LIMIT ".$pages->limit);
while ($us = mysql_fetch_assoc($q)) {
$post = $listing->post();
$post->url = '?id_ank=' . $_GET['id_ank'].'&group='.$us['id'].'';
$post->title = sm_nick(text::toOutput($us['nomi']));
}
$listing->display(__('Ro`yhat bo`sh'));
$pages->this_page();
$pages->display('?');








$doc->ret(__('Malumotiga'), 'user.actions.php?id=' . $ank->id);
$doc->ret(__('Anketa "%s"', $ank->title), '/ID' . $ank->id);

?>
