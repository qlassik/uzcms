<?php
include_once '../sys/inc/yadro.php';
admin::check_access();
$doc = new document(6);
$doc->title = __('Azo yaratish');
if($user->id == '1'){
if (isset($_POST['save'])) {
if (!isset($_SESSION['message_time'])){
		$_SESSION['message_time']  =  TIME;		
	}
	$saq = $_SESSION['message_time'];
if (TIME >= $saq && isset($_POST['save'])) {
if (mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `login` = '" . my_esc($_POST['login']) . "'"), 0))
	$doc->err(__('Bu login bazada bor boshqa tanlang'));
elseif (isset($_POST ['save'])) {
mysql_query("INSERT INTO `users` (`login`, `username`, `userfam`, `sex`, `pacc`,  `password`, `reg_date`)values('" . my_esc($_POST['login']) . "','" . my_esc($_POST['username']) . "', '" . my_esc($_POST['userfam']) . "', '1',   '" . my_esc($_POST['password']) . "',  '" . crypt::hash($_POST['password'], $uzcms->salt) . "', '" . TIME . "')");
$doc->msg(__('Azo yaratildi'));
$_SESSION['message_time'] = TIME + 40;
header('Refresh: 1; url=?');	
}
}else{
$doc->err(__('40 sequnddan kegin yana urunib ko`ring'));	
}
}
$form = new form('?' . passgen());
$form->text('login', __('Login'));
$form->text('username', __('Ismi'));
$form->text('userfam', __('Familyasi') );
$form->text('password', __('Paroll') );
$form->button(__('Saqlash'), 'save');
$form->display();

}