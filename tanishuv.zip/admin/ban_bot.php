<?php
include_once '../sys/inc/yadro.php';
admin::check_access();
$doc = new document(6);
$doc->title = __('Azolar');
if($user->id == '1'){
echo'<div style="margin: 2px; margin-top: 5px;"  class="row"><div class="col-xs-12"><table id="simple-table" class="table  table-bordered table-hover">
<thead><tr><th class="center"><label class="pos-rel"></th><th>'.__('Habar').'</th><th>'.__('Yuborish').'</th><th>'.__('Bot holati').'</th><th class="detail-col"><i class="ace-icon fa fa-clock-o bigger-110 hidden-480"></i> '.__('Qo`yildi').' </th> </tr> </thead><tbody>';
													
$pages = new pages(mysql_result(mysql_query("SELECT COUNT(*) FROM `mail`"), 0));
$listing = new listing();
$q = mysql_query("SELECT * FROM `mail` WHERE `id` ORDER BY `time` DESC LIMIT ".$pages->limit);
while ($p_user = mysql_fetch_assoc($q)) {
$bor = stripcslashes(htmlspecialchars(@iconv_substr($p_user['mess'], 0, 13, 'utf-8')));
if($bor == 'Foydalanuvchi');elseif ($p_user['mess'])if (!$p_user['file']){
$tabelga = $listing->tabelga();
$tabelga->admine = $p_user['id'].')';
$tabelga->tabela = sm_nick(text::toOutput($p_user['mess']));
if(isset($_GET['ot'])){
	$ank->narxi = $_POST['narxi'];
	mysql_query("UPDATE `mail` SET `bot` = '".$_POST['bot']."' WHERE `id` = '".$_GET['ot']."'");
    header("Location: ?");
}
$tabelga->tabelb = '<form action="?ot='.$p_user['id'].'" method="post"><div class="radio">
													<label>
													 <input name="bot" value="0" type="radio" class="ace">
													 <span class="lbl"> X </span>
													 </label>
													 <label>
													 <input name="bot" value="1" type="radio" class="ace">
													 <span class="lbl"> Q </span>
													 </label>
													 <label>
													 <input name="bot" value="2" type="radio" class="ace">
													 <span class="lbl"> O` </span>
													 </label>
													 <label>
													 <input name="bot" value="3" type="radio" class="ace">
													 <span class="lbl"> B <button onclick="myFunction()">'.__('ok').' </button></span>
													</label>
												</div></form>';
if ($p_user['bot'] == '0'){
$tabelga->tabeld = '<img src="/img/advertising.png" title="voo.uz" />';
}else{
$tabelga->tabeld = '<img src="/img/et.png" title="voo.uz" />';	
}
if ($p_user['bot'] == '0'){
$tabelga->tabelc = __('Bo`tni matinidamas');
}elseif ($p_user['bot'] == '1'){
$tabelga->tabelc = __('Qiz bola bo`t matinida');
}elseif ($p_user['bot'] == '2'){
$tabelga->tabelc = __('O`gil bola bo`t matinida');
}if ($p_user['bot'] == '3'){
$tabelga->tabelc =  __('Ban berilgan');
}
}
}

$listing->display(__('Ro`yhat bo`sh'));
$pages->this_page();
$pages->display('?');												
										
													
													
													
echo'</tbody></table></div></div>';
			
}