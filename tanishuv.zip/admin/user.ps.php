<?php

include_once '../sys/inc/yadro.php';
admin::check_access();
$doc = new document(6);
$doc->title = __('Parol sozlamasi');

if (isset($_GET['id_ank']))
    $ank = new user($_GET['id_ank']);
else
    $ank = $user;

if (!$ank->group) {
    if (isset($_GET['return']))
        header('Refresh: 1; url=' . $_GET['return']);
    else
        header('Refresh: 1; url=/');

    $doc->err(__('Malumot yo`q'));
    exit;
}

$doc->title .= ' "' . $ank->title . '"';

if ($ank->group >= $user->group) {
    if (isset($_GET['return']))
        header('Refresh: 1; url=' . $_GET['return']);
    else
        header('Refresh: 1; url=/');

    $doc->err(__('Bu holatda darajez etmaydi'));
    exit;
}

if (isset($_POST['save']) && !empty($_POST['password'])) {
    $password = $_POST['password'];

    
        $uzcms->log('Foydalanuvchini', 'Nickni o`zgartirtirildi ' . $ank->password . ' на [url=/ID' . $ank->id . ']' . $password . '[/url]');

        $ank->password = $password;
        $ank->pacc = crypt::hash($password, $uzcms->salt);	
        $doc->msg(__('Malades'));
    
}

$form = new form("?id_ank=$ank->id&amp;" . passgen() . (isset($_GET['return']) ? '&amp;return=' . urlencode($_GET['return']) : null));
$form->text('password', __('Yangi parolni kiriting'));
$form->button(__('Saqlash'), 'save');
$form->display();

$doc->ret(__('Malumotiga'), 'user.actions.php?id=' . $ank->id);

?>
