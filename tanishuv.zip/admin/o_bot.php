<?php

include_once '../sys/inc/yadro.php';
admin::check_access();
$doc = new document(3);
$doc->title = __('Fon qo`shish');

$doc->msg(__('Azolar etarli emas oddiy bot ishlashga'));