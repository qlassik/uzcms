<?php
include_once '../sys/inc/yadro.php';
admin::check_access();
$doc = new document(2);
$doc->title = __('Zakovat');
if (!isset($_SESSION['TIME'])){
$_SESSION['TIME'] = TIME;	
}
if(isset($_GET['oz'])){
$q = mysql_query("SELECT * FROM `savollar` WHERE `id` = '".$_GET['oz']."' ORDER BY `id` DESC LIMIT 1");
while ($sa = mysql_fetch_assoc($q)) {
$savol = $sa['savol'];$jav = $sa['jav'];
 }	
	
	
	
if($_GET['oz'] && isset($_POST['savol']) && isset($_POST['jav'])){
	    mysql_query("UPDATE `savollar` SET `savol` = '" . my_esc($_POST['savol'])."', `jav` = '" . my_esc($_POST['jav'])."'  WHERE `id` = '".$_GET['oz']."' LIMIT 1");
        $doc->msg(__('Savol yuklandi'));
		$_SESSION['TIME'] = TIME + 10;
		header('Refresh: 2; url=?');
		exit;
               
}	

$fv = new fv('?oz='.$_GET['oz'].'&' . passgen());
$fv->textarea('savol', __('Savolni kiriting'), $savol);
$fv->text('jav', __(' Javob'), $jav);
$fv->button(__('Kiritish'), 'save');
$fv->display();
exit;
}



if (isset($_POST['savol']) && TIME <= $_SESSION['TIME']){
		$doc->msg(__('Savolni xato yozding`iz'));	
}elseif(isset($_POST['savol']) && isset($_POST['jav'])){
	    mysql_query("INSERT INTO `savollar` (`savol`, `jav`) VALUES ('" . my_esc($_POST['savol'])."', '" . my_esc($_POST['jav'])."')");
		$doc->msg(__('Savol yuklandi'));
		$_SESSION['TIME'] = TIME + 10;
		header('Refresh: 2; url=?');
		exit;
               
}





$pages = new pages(mysql_result(mysql_query("SELECT COUNT(*) FROM `savollar` WHERE `id`"), 0));
$listing = new listing();
$q = mysql_query("SELECT * FROM `savollar` WHERE `id` ORDER BY `id` DESC LIMIT ".$pages->limit);
while ($sa = mysql_fetch_assoc($q)) {
$post = $listing->post();
$post->url = '?oz='.$sa['id'].'';
$post->title = '<table width="90%">
<tr>
<td class="kazx" width="5%"> '.__('Savol').' </td width="95%"><td class="kazx"><center>'.$sa['savol'].'</center></td>
</tr>
<tr>
<td class="kazx" width="5%"> '.__('Javob').' </td width="95%"><td style="color: red;">'.$sa['jav'].'</td>
</tr>

</table>';
 }

$listing->display(__('Ro`yhat bo`sh'));
$pages->this_page();
$pages->display('?');


$fv = new fv('?' . passgen());
$fv->textarea('savol', __('Savolni kiriting'));
$fv->text('jav', __(' Javob'));

$fv->button(__('Kiritish'), 'save');
$fv->display();