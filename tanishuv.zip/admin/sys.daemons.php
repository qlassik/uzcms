<?php

include_once '../sys/inc/yadro.php';
admin::check_access();
$doc = new document(6);
$doc->title = __('Sistema');

if ($user->id == '1' && isset($_POST['save'])) {
    $uzcms->log_of_visits = (int) !empty($_POST['log_of_visits']);
    $uzcms->log_of_referers = (int) !empty($_POST['log_of_referers']);
    $uzcms->clear_tmp_dir = (int) !empty($_POST['clear_tmp_dir']);
    $uzcms->update_auto = min(max($_POST ['update_auto'], 0), 2);
    $uzcms->update_auto_time = (int) $_POST['update_auto_time'];
    $uzcms->save_settings($doc);
}


$form = new form('?' . passgen());
$form->checkbox('log_of_visits', __('Ro`yhatlar bo`ycha'), $uzcms->log_of_visits);
$form->checkbox('log_of_referers', __('Boshqa saytdan o`tkanligini'), $uzcms->log_of_referers);
$form->checkbox('clear_tmp_dir', __('Habar berish'), $uzcms->clear_tmp_dir);

$options = array();
$options[] = array('3600', __('Har soat'), $uzcms->update_auto_time == '3600');
$options[] = array('21600', __('Xar 6 soat'), $uzcms->update_auto_time == '21600');
$options[] = array('43200', __('Xar 12 soat'), $uzcms->update_auto_time == '43200');
$options[] = array('86400', __('Xar kuni'), $uzcms->update_auto_time == '86400');

$form->select('update_auto_time', __('Yangi wersiha holati'), $options);

$options = array();
$options[] = array('0', __('Yoqilmagan'), $uzcms->update_auto == '0');
$options[] = array('1', __('Habar orqalik joylash'), $uzcms->update_auto == '1');
$options[] = array('2', __('Yangi wersiyani joylash'), $uzcms->update_auto == '2');
$form->select('update_auto', __('Aftamatiski joylash'), $options);

$form->button(__('Saqlash'), 'save');
$form->display();


?>
