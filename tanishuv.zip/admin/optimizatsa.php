<?php

include_once '../sys/inc/yadro.php';
admin::check_access();
$doc = new document(6);
$doc->title = __('Saytni engil ishlatish');
$db_select = 'SHOW DATABASES';
$db_result = MYSQL_QUERY($db_select);
 WHILE ($db_row = MYSQL_FETCH_ARRAY($db_result)) {
  IF (MYSQL_SELECT_DB($db_row[0])) {
ECHO "<b><center class='post'>";
               ECHO $db_row[0];
               ECHO "</center></b>";
$tbl_status = 'SHOW TABLE STATUS FROM ' . $db_row[0];
 $tbl_result = MYSQL_QUERY($tbl_status);
 IF(MYSQL_NUM_ROWS($tbl_result)) {
 WHILE ($tbl_row = MYSQL_FETCH_ARRAY($tbl_result)) {
$opt_table = 'OPTIMIZE TABLE ' . $tbl_row[0];
$opt_result = MYSQL_QUERY($opt_table);
 ECHO "  <i class='post'>";
ECHO $tbl_row[0];
ECHO "   <span style='float:right; clear:left; margin-left: -10px;'><img src='/img/et.png' /></span></i>";
 }
 } ELSE {
$doc->err(__('Tabellar yo`q'));
}
}
} 
 
