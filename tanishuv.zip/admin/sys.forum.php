<?php

include_once '../sys/inc/yadro.php';
admin::check_access();
$doc = new document(5);
$doc->title = __('Forum sozlamasi');

if (isset($_POST['save'])) {
    $uzcms->forum_theme_captcha = (int) !empty($_POST['forum_theme_captcha']);
    $uzcms->forum_message_captcha = (int) !empty($_POST['forum_message_captcha']);
    $uzcms->forum_search_captcha = (int) !empty($_POST['forum_search_captcha']);
    $uzcms->forum_search_reg = (int) !empty($_POST['forum_search_reg']);
    $uzcms->forum_files_upload_size = (int) ($_POST['forum_files_upload_size'] * 1024);
    $uzcms->save_settings($doc);
}

$form = new form('?' . passgen());
$form->checkbox('forum_theme_captcha', __('Xotira daftar kapchu orqalik yozilsin') . ' *', $uzcms->forum_theme_captcha);
$form->checkbox('forum_message_captcha', __('Xabar kapchu orqalik yozilsin') . ' *', $uzcms->forum_message_captcha);
$form->text('forum_files_upload_size', __('Birlashtiriladigon fayl razmeri'), (int) ($uzcms->forum_files_upload_size / 1024));
$form->checkbox('forum_search_captcha', __('Izlash kapchu orqalik bo`lsin'), $uzcms->forum_search_captcha);
$form->checkbox('forum_search_reg', __('Faqat foydalanuvchilar izlay olsin'), $uzcms->forum_search_reg);
$form->button(__('Saqlash'), 'save');
$form->display();


?>
