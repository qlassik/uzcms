<?php

include_once '../sys/inc/yadro.php';
admin::check_access();
$doc = new document(6);
$doc->title = __('Summa o`tkazish');

if (isset($_GET['id_ank']))
    $ank = new user($_GET['id_ank']);
else
    $ank = $user;

if (!$ank->group) {
    if (isset($_GET['return']))
        header('Refresh: 1; url=' . $_GET['return']);
    else
        header('Refresh: 1; url=/');

    $doc->err(__('Malumot yo`q'));
    exit;
}

$doc->title .= ' "' . $ank->title . '"';

if ($ank->group >= $user->group) {
    if (isset($_GET['return']))
        header('Refresh: 1; url=' . $_GET['return']);
    else
        header('Refresh: 1; url=/');

    $doc->err(__('Bu holatda darajez etmaydi'));
    exit;
}

if (isset($_POST['save']) && !empty($_POST['sum']) && $_POST['sum'] != $ank->sum) {
    $sum = (int) $_POST['sum'];

    
        $uzcms->log('Foydalanuvchini', 'Nickni o`zgartirtirildi ' . $ank->sum . ' на [url=/ID' . $ank->id . ']' . $sum . '[/url]');

        $ank->sum = $sum;
        $doc->msg(__('Malades'));
    
}

$form = new form("?id_ank=$ank->id&amp;" . passgen() . (isset($_GET['return']) ? '&amp;return=' . urlencode($_GET['return']) : null));
$form->text('sum', __('Summani kiriting'), $ank->sum);
$form->button(__('Saqlash'), 'save');
$form->display();

$doc->ret(__('Malumotiga'), 'user.actions.php?id=' . $ank->id);
$doc->ret(__('Anketa "%s"', $ank->sum), '/ID' . $ank->id);

?>
