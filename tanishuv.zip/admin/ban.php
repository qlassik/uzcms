<?php
include_once '../sys/inc/yadro.php';
admin::check_access();
$doc = new document(6);
$doc->title = __('Ban list');
echo'<div style="margin: 2px; margin-top: 5px;"  class="row"><div class="col-xs-12"><table id="simple-table" class="table  table-bordered table-hover">
<thead><tr><th class="center"><label class="pos-rel"></th><th>'.__('Ismi familyasi').'</th><th>'.__('Narxi').'</th><th>'.__('Sotilish holti').'</th><th class="detail-col"><i class="ace-icon fa fa-clock-o bigger-110 hidden-480"></i> '.__('Holat').' </th> </tr> </thead><tbody>';
													
$pages = new pages(mysql_result(mysql_query("SELECT COUNT(*) FROM `ban` WHERE `access_view` = '0'"), 0));
$listing = new listing();
$q = mysql_query("SELECT * FROM `ban` WHERE `access_view` = '0' ORDER BY `access_view` DESC LIMIT ".$pages->limit);
while ($p_user = mysql_fetch_assoc($q)) {
$ank = new user($p_user['id_user']);
$tabelga = $listing->tabelga();
$tabelga->admine = 'ID '.$ank->id;
$tabelga->tabela = $ank->nick();
if($ank->sotiladi == '2' && isset($_GET['sotaman'])){echo $_POST['narxi'];
	$ank->narxi = $_POST['narxi'];
	header("Location: ?");
	}
$tabelga->tabelb = '<form action="?sotaman='.$ank->id.'" method="post"><input type="range" name="narxi" min="1" max="100000" value="'.$ank->narxi.'"><button onclick="myFunction()">'.__('Summasi %s', $ank->narxi).' </button></form>';

if ($ank->sotiladi == '1'){
	if($ank->sotiladi == '1' && isset($_GET['sot'])){
	$ank->sotiladi = 2;
	header("Location: ?");
	}
$tabelga->tabelc = '<a href="?sot='.$ank->id.'" style="color: red;"> '. __('Sotuvga qo`yilmagan').'</a>';
}elseif ($ank->sotiladi == '2'){
	if($ank->sotiladi == '2' && isset($_GET['sotma'])){
	$ank->sotiladi = 1;
	$ank->narxi = '';	
	header("Location: ?");
	}
$tabelga->tabelc = '<a href="?sotma='.$ank->id.'" style="color: green;"> '. __('Sotuvga qo`yilgan').'</a>';
}

if ($ank->id == '1'){
$tabelga->tabeld = '<a href="/ID'.$ank->id.'&ok=3" style="color: red;"> '. __('Aktiv').'</a>';
}elseif ($ank->id == '2'){
$tabelga->tabeld = '<a href="/ID'.$ank->id.'&ok=2" style="color: red;"> '. __('Faolmas').'</a>';
}elseif ($ank->id == '3'){
$tabelga->tabeld = '<a href="/ID'.$ank->id.'&ok=2" style="color: red;"> '. __('Xaydalgan').'</a>';
}
}

$listing->display(__('Ro`yhat bo`sh'));
$pages->this_page();
$pages->display('?');							
echo'</tbody></table></div></div>';					