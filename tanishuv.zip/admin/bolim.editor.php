<?php

include_once '../sys/inc/yadro.php';
admin::check_access();
$doc = new document(6);
$groups = groups::load_ini();
$doc->title = __('Menyular sozlamasi');

$bolim_files = (array) glob(H . '/sys/dat/bolim.*.ini');
$bolims = array();
foreach ($bolim_files as $bolim_path) {
    if (!preg_match('#bolim\.(.+?)\.ini$#ui', $bolim_path, $m))
        continue;
    $bolims[] = $m[1];
}

if (!empty($_GET['bolim'])) {
    $bolim = (string) $_GET['bolim'];

    if (!in_array($bolim, $bolims)) {
        $doc->err(__('Menyu topilmadi'));
        exit;
    }
    $doc->title = __(' "%s"ni - sozlash', $bolim);
    $m_obj = new bolim($bolim);

    if (!empty($_GET['item'])) {
        $item_name = (string) $_GET['item'];
        if (!isset($m_obj->bolim_arr[$item_name])) {
            $doc->err(__('Tollanishda xato mavjud'));
        }

        $item = $m_obj->bolim_arr[$item_name];
        $doc->title = __('Menyu "%s" - %s', $bolim, $item_name);
        if (!empty($_POST['delete'])) {
            if (empty($_POST['captcha']) || empty($_POST['captcha_session']) || !captcha::check($_POST['captcha'], $_POST['captcha_session'])) {
                $doc->err(__('Raqam to`gri holatda kiritilmadi'));
            } else {
                $ini = ini::read(H . '/sys/dat/bolim.' . $bolim . '.ini', true);
                unset($ini[$item_name]);
                if (ini::save(H . '/sys/dat/bolim.' . $bolim . '.ini', $ini, true)) {
                    $doc->msg(__('Saqlandi'));
                } else {
                    $doc->err(__('Saqlanmadi'));
                }
                header('Refresh: 1; url=?bolim=' . urlencode($bolim) . '&amp;' . passgen());
                $doc->ret(__('Menyu "%s"', $bolim), '?bolim=' . urlencode($bolim) . '&amp;' . passgen());
                $doc->ret(__('Menyu bolimlari'), '?' . passgen());
                
                exit;
            }
        }
        if (!empty($_POST['save'])) {
            $name = text::input_text(@$_POST['name']);
            $url = text::input_text(@$_POST['url']);
            $icon = text::input_text(@$_POST['icon']);
            $razdel = text::input_text(@$_POST['razdel']);
            $group = (int) @$_POST['group'];
            $position = (int) @$_POST['position'];
            if (empty($name)) {
                $doc->err(__('Bunday holatda menyu yo`q'));
            } elseif ($name != $item_name && isset($m_obj->bolim_arr[$name])) {
                $doc->err(__('Menyu nomi mavjud'));
            } else {
                $ini = ini::read(H . '/sys/dat/bolim.' . $bolim . '.ini', true);
                if ($name != $item_name) {
                    unset($ini[$item_name]);
                }



                $ini[$name] = array('url' => $url,
                    'razdel' => $razdel,
                    'group' => $group
                );
                arraypos::setPosition($ini, $name, $position);
                if (ini::save(H . '/sys/dat/bolim.' . $bolim . '.ini', $ini, true)) {
                    $doc->msg(__('OKey'));
                } else {
                    $doc->err(__('Saqlanmadi'));
                }
                header('Refresh: 1; url=?bolim=' . urlencode($bolim) . '&amp;' . passgen());
                $doc->ret(__('Menyu "%s"', $bolim), '?bolim=' . urlencode($bolim) . '&amp;' . passgen());
                $doc->ret(__('Menyular to`plami'), '?' . passgen());
                
                exit;
            }
        }



        if (isset($_GET['act']) && $_GET['act'] == 'delete') {
            $doc->title = __('O`chirilyatkan %s', $item_name);
            $form = new form('?bolim=' . urlencode($bolim) . '&amp;item=' . urlencode($item_name) . '&amp;' . passgen());
            $form->captcha();
            $form->button(__('O`chirish'), 'delete');
            $form->display();
        } else {

            $form = new form('?bolim=' . urlencode($bolim) . '&amp;item=' . urlencode($item_name) . '&amp;' . passgen());

            $form->text('name', __('Nomi'), $item_name);
            $form->text('position', __('Tafsif'), arraypos::getPosition($m_obj->bolim_arr, $item_name));
            $form->text('url', __('Adres'), $item['url']);

          
            $form->text('razdel', __('Bo`lim'), @$item['razdel']);
           
            $options = array();
            foreach ($groups as $group => $value) {
                $options[] = array($group, $value['name'], $group == @$item['group']);
            }
            $form->select('group', __('Kimlarga ko`rinsin') . '*', $options);
            $form->button(__('Saqlash'), 'save');
            $form->display();
        }

        $doc->ret(__('Menyu "%s"', $bolim), '?bolim=' . urlencode($bolim) . '&amp;' . passgen());
        $doc->ret(__('Menyular to`plami'), '?' . passgen());
        
        exit;
    }

    if (isset($_GET['item_add'])) {
        $doc->title = __('Yangi Bo`lim Menyu %s', $bolim);
        if (!empty($_POST['create'])) {
            $name = text::input_text(@$_POST['name']);
            $url = text::input_text(@$_POST['url']);
            $razdel = text::input_text(@$_POST['razdel']);
            $group = (int) @$_POST['group'];
            $position = (int) @$_POST['position'];
            if (empty($name)) {
                $doc->err(__('Nomlanishda xato bor'));
            } elseif (isset($m_obj->bolim_arr[$name])) {
                $doc->err(__('Bu nom bilan qo`yilgan bolim bor'));
            } else {
                $ini = ini::read(H . '/sys/dat/bolim.' . $bolim . '.ini', true);


                $ini[$name] = array('url' => $url,
                    'razdel' => $razdel,
                    'group' => $group
                );
                arraypos::setPosition($ini, $name, $position);
                if (ini::save(H . '/sys/dat/bolim.' . $bolim . '.ini', $ini, true)) {
                    $doc->msg(__('Malumotingiz saqlandi'));
                } else {
                    $doc->err(__('Saqlanmadi'));
                }
                header('Refresh: 1; url=?bolim=' . urlencode($bolim) . '&amp;' . passgen());
                $doc->ret(__('Menyu "%s"', $bolim), '?bolim=' . urlencode($bolim) . '&amp;' . passgen());
                $doc->ret(__('Menyular to`plami'), '?' . passgen());
                
                exit;
            }
        }

        $form = new form('?bolim=' . urlencode($bolim) . '&amp;item_add&amp;' . passgen());
        $form->text('name', __('Nomi'));
        $form->text('position', __('Tafsif'), count($m_obj->bolim_arr) + 1);
        $form->text('url', __('Adres'), 'http://');
          $form->text('razdel', __('Bo`lim'));
                $options = array();
        foreach ($groups as $group => $value) {
            $options[] = array($group, $value['name']);
        }
        $form->select('group', __('Kimlarga ko`rinsin') . '*', $options);
        $form->button(__('Yaratish'), 'create');
        $form->display();


        $doc->ret(__('Menyu "%s"', $bolim), '?bolim=' . urlencode($bolim) . '&amp;' . passgen());
        $doc->ret(__('Menyular to`plami'), '?' . passgen());
        
        exit;
    }



    if (isset($_GET['sortable'])) {

        $ini = ini::read(H . '/sys/dat/bolim.' . $bolim . '.ini', true);
        $doc->clean();

       
        $sortable = explode(',', $_POST['sortable']);

        foreach ($sortable as $position => $key) {
        
            arraypos::setPosition($ini, $key, $position + 1);
        }

        header('Content-type: application/json');
        if (ini::save(H . '/sys/dat/bolim.' . $bolim . '.ini', $ini, true)) {
            echo json_encode(array('result' => 1, 'description' => __('Etab bo`ycha saqlandi')));
        } else {
            echo json_encode(array('result' => 0, 'description' => __('Saqlanmadi')));
        }


        exit;
    }



    if (isset($_GET['up']) || isset($_GET['down'])) {
        $ini = ini::read(H . '/sys/dat/bolim.' . $bolim . '.ini', true);

        if (isset($_GET['up'])) {
            $item_name = $_GET['up'];
            if (misc::array_key_move($ini, $item_name, - 1)) {
                $doc->msg(__('Bo`lim "%s"ga menyusi tepaga ko`tarildi', $item_name));
            } else {
                $doc->err(__('Bo`lim "%s"ga menyusi tepaga ko`tarilgan', $item_name));
            }
        }

        if (isset($_GET['down'])) {
            $item_name = $_GET['down'];
            if (misc::array_key_move($ini, $item_name, 1)) {
                $doc->msg(__('Bo`lim "%s"ga menyusi pastka tushdi', $item_name));
            } else {
                $doc->err(__('Bo`lim "%s"ga menyusi pastka tushgan', $item_name));
            }
        }
        if (ini::save(H . '/sys/dat/bolim.' . $bolim . '.ini', $ini, true)) {
            $doc->msg(__('Malumotingiz saqlandi'));
        } else {
            $doc->err(__('Saqlanmadi'));
        }
        $m_obj = new bolim($bolim);
    }


    $listing = new listing();

    $position = 0;
    foreach ($m_obj->bolim_arr as $name => $item) {
        $position++;

        $post = $listing->post();
        $post->id = $name;
        $post->url = '?bolim=' . urlencode($bolim) . '&amp;item=' . urlencode($name);
        $post->title = text::toValue($name);

        $post->icon(@$item['icon']);

        $post->action('up', '?bolim=' . urlencode($bolim) . '&amp;up=' . urlencode($name) . '&amp;' . passgen());
        $post->action('down', '?bolim=' . urlencode($bolim) . '&amp;down=' . urlencode($name) . '&amp;' . passgen());
        $post->action('delete', '?bolim=' . urlencode($bolim) . '&amp;item=' . urlencode($name) . '&amp;act=delete&amp;' . passgen());



        if (empty($item['razdel'])) {
            $post->content = __('Adres') . ": $item[url]\n";
            if (!empty($item['icon'])) {
                $icon = array('size' => 'small', 'src' => '/style/images/icons/' . $item['icon']);
            }
        } else {
            $post->content = "[b]" . __('Bo`lim') . "[/b]\n";
            $post->hightlight = true;
        }

        if (!empty($item['for_vip'])) {
            $post->content .= __('[b]VIP[/b]') . "\n";
        }

        if (!empty($item['group'])) {
            $post->content .= __('Faqat [b]%s[/b] mansabdorlar ko`radi (%s)', groups::name($item['group']), $item['group']) . " \n";
        }
        $post->content = text::toOutput($post->content);
    }


    $listing->sortable = '?sortable&amp;bolim=' . urlencode($bolim);
    $listing->display(__('Menyu yo`q'));

    $doc->act(__('Bo`lim qo`shish'), '?bolim=' . urlencode($bolim) . '&amp;item_add&amp;' . passgen());


    $doc->ret(__('Menyular to`plami'), '?' . passgen());
    
    exit;
}


$listing = new listing();
foreach ($bolims as $bolim) {
    $post = $listing->post();
    $post->title = text::toValue($bolim);
    $post->url = '?bolim=' . urlencode($bolim);
    $post->icon('bolim.editor');
}
$listing->display(__('Malumot yo`q'));



?>