<?php

include_once '../sys/inc/yadro.php';
admin::check_access();
$doc = new document(5);
$doc->title = __('Asosiy sozlamalar');
if($user->id == '1'){
$browser_types = array('mobilni','planshet', 'androit', 'komp');

if ($user->id == '1' && isset($_POST ['save'])) {
	$uzcms->https_only = (int) !empty($_POST ['https_only']);
    $uzcms->https_hsts = (int) !empty($_POST ['https_hsts']);
    $uzcms->debug = (int) !empty($_POST ['debug']);
    $uzcms->align_html = (int) !empty($_POST ['align_html']);
    $uzcms->new_time_as_date = (int) !empty($_POST ['new_time_as_date']);
    $uzcms->censure = (int) !empty($_POST ['censure']);
    $uzcms->save_settings($doc);
}


$form = new form('?' . passgen());
$form->tashida_chek_tu_c('new_time_as_date', __('Yangi fayl ko`rsatilsinmi') . ' **', $uzcms->new_time_as_date);
$form->tashida_chek_tu_c('debug', __('Xatolar ko`rsatish holati') . ' ***', $uzcms->debug);
$form->tashida_chek_tu_c('align_html', __('Html qoida holati bilan'), $uzcms->align_html);
$form->checkbox('https_hsts', __('HSTS ni https ga o`tsin'), $uzcms->https_hsts);
$form->checkbox('https_only', __('Yoqilsin %s', 'https'), $uzcms->https_only);
$form->tashida_chek_tu_c('censure', __('Antimat') . ' ****', $uzcms->censure);
$form->text('copyright', __('Ko`chirish'), $uzcms->copyright);

$form->button(__('Saqlash'), 'save');
$form->display();
}

?>
