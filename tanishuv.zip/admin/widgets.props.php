<?php

include_once '../sys/inc/yadro.php';
admin::check_access();
$doc = new document(5);
$doc->title = __('Widjet');


$types = array('mobilni','planshet', 'androit', 'komp');

if (isset($_POST ['save'])) {

    foreach ($types AS $type) {
        $prop_name = "widget_items_count_" . $type;
        $uzcms->$prop_name = min(max((int) $_POST [$prop_name], 0), 50);
    }

    if ($uzcms->save_settings()) {
        $doc->msg(__('Sozlamangiz saqlandi'));
    } else {
        $doc->err(__('Chmodni tekshirin'));
    }
}


$form = new form('?' . passgen());
foreach ($types AS $type) {
    $prop_name = "widget_items_count_" . $type;
    $form->text($prop_name, __('Eng ko`pi') . ' [0-50] '. __('oshmasin') . ' (' . strtoupper($type) . ')', $uzcms->$prop_name);
}
$form->button(__('Saqlash'), 'save');
$form->display();
?>