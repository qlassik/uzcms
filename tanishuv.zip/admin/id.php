<?php
include_once '../sys/inc/yadro.php';
admin::check_access();
$doc = new document(6);
$doc->title = __('Summa o`tkazish');
if (isset($_GET['id']))
    $ank = new user($_GET['id']);
else
    $ank = $user;
	
if (isset($_POST ['save'])) {
if ($ank->id == $user->id){
$user->sum = text::for_name($_POST ['sum']);	
}else{
$ank->sum = text::for_name($_POST ['sum']);	
}
$doc->msg(__('O`tdi'));
header('Refresh: 2; url=?');
exit;
}




$form = new form('?' . passgen());
$form->text('sum', __('Qancha pul kere'), $ank->sum);
$form->button(__('Saqlash'), 'save');
$form->display();


?>
