<?php

include_once '../sys/inc/yadro.php';
admin::check_access();
$doc = new document(5);
$doc->title = __('Asosiy sozlamalar');
if($user->id == '1'){
$languages = languages::getList();

$browser_types = array('mobilni','planshet', 'androit', 'komp');

if ($user->id == '1' && isset($_POST ['save'])) {
	$uzcms->censure = (int) !empty($_POST ['censure']);

    foreach ($browser_types as $b_types) {
        $key = 'theme_' . $b_types;
        if (!empty($_POST [$key])) {
            $theme_set = (string) $_POST [$key];
            if (themes::exists($theme_set, $b_types))
                $uzcms->$key = $theme_set;
        }
    }

    $lang = text::input_text($_POST ['language']);
    if (isset($languages[$lang]))
        $uzcms->language = $lang;

    $uzcms->title = text::for_name($_POST ['title']);
    $uzcms->sitename = text::for_name($_POST ['sitename']);
    $uzcms->copyright = text::input_text($_POST ['copyright']);
    $uzcms->system_nick = text::for_name($_POST ['system_nick']);
    $uzcms->save_settings($doc);
}


$form = new form('?' . passgen());
$form->textmi('title', __('Tepa ko`rinishi'), $uzcms->title);
$form->text('sitename', __('Sayt nomi'), $uzcms->sitename);
$form->text('system_nick', __('VOO.UZ') . ' *', $uzcms->system_nick);

foreach ($browser_types as $b_types) {
    $key = 'theme_' . $b_types;
    $options = array();
    $themes_list = themes::getList($b_types);
    foreach ($themes_list as $theme)
        $options [] = array($theme ['dir'], $theme ['name'], $uzcms->$key === $theme ['dir']);
    $form->select($key, __('Mavzu sozlamasi') . ' (' . $b_types . ')', $options);
}

$options = array();
foreach ($languages as $key => $l) {
    $options [] = array($key, $l['name'], $uzcms->language === $key);
}
$form->select('language', __('Til ko`rsatkichlari'), $options);
$form->text('copyright', __('Ko`chirish'), $uzcms->copyright);

$form->button(__('Saqlash'), 'save');
$form->display();
}

?>
