<?php
include_once '../sys/inc/yadro.php';
admin::check_access();
$doc = new document(6);
$doc->title = __('CSS sozlamasi');

if (isset($_GET['och'])){
$id = (int) $_GET['och'];
$doc->title = __('CSS o`chirish');
if ($user->id == '1' && isset($_POST['ochirilar'])){
		mysql_query("DELETE FROM `css` WHERE `id` = '".$id."'");
		$doc->msg(__('CSS stroyka o`chdi'));
	header('Refresh: 1; url=?');
	exit;
	}


$listing = new listing();
$q = mysql_query("SELECT * FROM `css` WHERE  `id` = '".$id."'  ORDER BY `id` DESC LIMIT 1");
while ($uss = mysql_fetch_assoc($q)) {
$post = $listing->post();
$post->title = '<span style="color: red;">'.__('O`chiriladigon css').' : </span>('.text::toValue($uss['cod']).')';
}
$listing->display(__('CSS codi yozilmagan'));
$form = new form('?och='.$_GET['och'].'' . passgen());
$form->button(__('O`chirish'), 'ochirilar');
$form->display();
$doc->ret(__('Adminka'), './');
$doc->ret(__('Orqaga'), '?');exit;
}


if ($user->id == '1' && isset($_GET['ozgar'])){
$doc->title = __('CSS o`zgartirish');
$id = (int) $_GET['ozgar'];
if (isset($_POST['codee']) && isset($_POST['save'])){
mysql_query("UPDATE `css` SET `cod` = '" . my_esc($_POST['codee']) . "' WHERE `id` = '".$id."' LIMIT 1");
		$doc->msg(__('CSS o`zgardi'));
	header('Refresh: 1; url=?');
	exit;
}
$listing = new listing();
$q = mysql_query("SELECT * FROM `css` WHERE  `id` = '".$id."'  ORDER BY `id` DESC LIMIT 1");
while ($uss = mysql_fetch_assoc($q)) {
$post = $listing->post();
$post->title = text::toValue($uss['cod']);
$post->action('delete', '?och=' . urlencode($uss['id']) . '&amp;' . passgen());
$code = $uss['cod'];
}
$listing->display(__('CSS codi yozilmagan'));
	     


$form = new form('?ozgar='.$_GET['ozgar'].'' . passgen());
$form->textarea('codee', __('Code'), $code);
$form->button(__('Saqlash'), 'save');
$form->display();
$doc->ret(__('Adminka'), './');
$doc->ret(__('Orqaga'), '?');
exit;
}
if (isset($_GET['shu'])){
$uzcms->css = (int) $_GET['shu'];
$uzcms->save_settings($doc);
header('Refresh: 1; url=?');
exit;
}
if ($user->id == '1' && isset($_POST['save'])){
if (empty($_POST['cod'])) {
            $doc->err(__('CSS cod yozilmadi'));
        }elseif (mysql_result(mysql_query("SELECT COUNT(*) FROM `css` WHERE `cod` = '" . my_esc($_POST['cod']) . "'"), 0)) {
        $doc->err(__('Maydonda bu qod yozilgan'));
    }else{
		
		     mysql_query("INSERT INTO `css` (`cod`)values('" . my_esc($_POST['cod']) . "')");
		     $doc->msg(__('Qo`shildi'));
	header('Refresh: 1; url=?');
	}

}



$pages = new pages(mysql_result(mysql_query("SELECT COUNT(*) FROM `css`"), 0));
$listing = new listing();
$q = mysql_query("SELECT * FROM `css` WHERE  `id` ORDER BY `id` DESC LIMIT ".$pages->limit);
while ($us = mysql_fetch_assoc($q)) {
$post = $listing->post();
$post->title = text::toValue($us['cod']);
$post->action('cms', '?ozgar=' . urlencode($us['id']) . '&amp;' . passgen());
$post->action('delete', '?och=' . urlencode($us['id']) . '&amp;' . passgen());
}
$listing->display(__('CSS codi yozilmagan'));
$pages->this_page();
$pages->display('?');

		     


$form = new form('?' . passgen());
$form->textarea('cod', __('Code'));
$form->button(__('Saqlash'), 'save');
$form->display();


$doc->ret(__('Adminka'), './');
?>