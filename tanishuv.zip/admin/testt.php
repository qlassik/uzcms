<?php
include_once '../sys/inc/yadro.php';
admin::check_access();
$doc = new document(2);
$doc->title = __('Zakovat');
if (!isset($_SESSION['TIME'])){
$_SESSION['TIME'] = TIME;	
}
if(isset($_GET['oz'])){
$q = mysql_query("SELECT * FROM `zakovat` WHERE `id` = '".$_GET['oz']."' ORDER BY `id` DESC LIMIT 1");
while ($sa = mysql_fetch_assoc($q)) {
$savol = $sa['savol'];
$a = $sa['a'];
$b = $sa['b'];
$c = $sa['c'];
 }	
	
	
	
if($_GET['oz'] && isset($_POST['savol']) && isset($_POST['a']) && isset($_POST['b']) && isset($_POST['c']) && isset($_POST['jav'])){
	    mysql_query("UPDATE `zakovat` SET `savol` = '" . my_esc($_POST['savol'])."', `a` = '" . my_esc($_POST['a'])."', `b` = '" . my_esc($_POST['b'])."', `c` = '" . my_esc($_POST['c'])."', `jav` = '" . my_esc($_POST['jav'])."'  WHERE `id` = '".$_GET['oz']."' LIMIT 1");
        $doc->msg(__('Savol yuklandi'));
		$_SESSION['TIME'] = TIME + 10;
		header('Refresh: 2; url=?');
		exit;
               
}	

$fv = new fv('?oz='.$_GET['oz'].'&' . passgen());
$fv->textarea('savol', __('Savolni kiriting'), $savol);
$fv->text('a', __('A) javobni yozing'), $a);
$fv->text('b', __('B) javobni yozing'), $b);
$fv->text('c', __('C) javobni yozing'), $c);
$fv->select('jav', __('To`gri javobni tanlang'), array(array('a', __('A) javob')), array('b', __('B) javob')), array('c', __('C) javob'))));    

$fv->button(__('Kiritish'), 'save');
$fv->display();
exit;
}

if (isset($_POST['savolq']) && TIME <= $_SESSION['TIME']){
		$doc->msg(__('Savolni xato yozding`iz'));	
}elseif(isset($_POST['savolq'])&& isset($_POST['aq']) && isset($_POST['bq']) && isset($_POST['cq']) && isset($_POST['javq'])){
	    mysql_query("INSERT INTO `zakovat` (`savol`, `a`, `b`, `c`, `jav`) VALUES ('" . my_esc($_POST['savolq'])."', '" . my_esc($_POST['aq'])."', '" . my_esc($_POST['bq'])."', '" . my_esc($_POST['cq'])."', '" . my_esc($_POST['javq'])."')");
		$doc->msg(__('Savol yuklandi'));
		$_SESSION['TIME'] = TIME + 10;
		header('Refresh: 2; url=?');
		exit;
               
}





$pages = new pages(mysql_result(mysql_query("SELECT COUNT(*) FROM `zakovat` WHERE `id`"), 0));
$listing = new listing();
$q = mysql_query("SELECT * FROM `zakovat` WHERE `id` ORDER BY `id` DESC LIMIT ".$pages->limit);
while ($sa = mysql_fetch_assoc($q)) {
$post = $listing->post();
$post->url = '?oz='.$sa['id'].'';
$post->title = '<table width="90%">
<tr>
<td class="kazx" width="5%"> № </td width="95%"><td class="kazx"><center>'.$sa['savol'].'</center></td>
</tr>
<tr>
<td width="5%"> A) </td width="95%"><td>'.$sa['a'].'</td>
</tr>
<tr>
<td width="5%"> B) </td width="95%"><td>'.$sa['b'].'</td>
</tr>
<tr>
<td width="5%"> C) </td width="95%"><td>'.$sa['c'].'</td>
</tr>
</table>';
 }

$listing->display(__('Ro`yhat bo`sh'));
$pages->this_page();
$pages->display('?');


$fv = new fv('?' . passgen());
$fv->textarea('savolq', __('Savolni kiriting'));
$fv->text('aq', __('A) javobni yozing'));
$fv->text('bq', __('B) javobni yozing'));
$fv->text('cq', __('C) javobni yozing'));
$fv->select('javq', __('To`gri javobni tanlang'), array(array('a', __('A) javob')), array('b', __('B) javob')), array('c', __('C) javob'))));    

$fv->button(__('Kiritish'), 'save');
$fv->display();