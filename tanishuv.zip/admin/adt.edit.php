<?php

include_once '../sys/inc/yadro.php';
admin::check_access();
$doc = new document(5);
$doc->title = __('Reklammani o`zgartirish');

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Refresh: 1; url=adt.php');
    $doc->ret(__('Reklamma и banerы'), 'adt.php');
    
    $doc->err(__('Tollanish turida xato mavjud'));
    exit;
}
$id_adt = (int) $_GET['id'];

$q = mysql_query("SELECT * FROM `advertising` WHERE `id` = '$id_adt'");

if (!mysql_num_rows($q)) {
    header('Refresh: 1; url=adt.php?id=' . $id_adt);
    $doc->ret('<img src="/img/answer.png"> '.__('Orqaga qaytish'), 'adt.php?id=' . $id_adt);
    $doc->ret(__('Reklamma и banerы'), 'adt.php');
    
    $doc->err(__('Reklamma bu turda yo`q'));
    exit;
}

$adt = mysql_fetch_assoc($q);

if (isset($_POST['delete'])) {
    if (empty($_POST['captcha']) || empty($_POST['captcha_session']) || !captcha::check($_POST['captcha'], $_POST['captcha_session'])) {
        $doc->err(__('Raqam to`gri holatda kiritilmadi'));
    } else {
        mysql_query("DELETE FROM `advertising` WHERE `id` = '$adt[id]'");

        header('Refresh: 1; url=adt.php?id=' . $adt['space']);
        $doc->msg(__('Rekilamma o`chirildi'));

        $uzcms->log('Reklamma', 'O`chirilgan joy ' . $adt['name'] . ' (' . $adt['url_link'] . ')');

        $doc->ret(__('Orqaga qaytish'), "adt.php?id=$adt[space]");
        $doc->ret(__('Reklamma'), 'adt.php');
        
        exit;
    }
}

if (isset($_POST['common'])) {
    if (isset($_POST['name'])) {
        $name = text::input_text($_POST['name']);
        if ($name && $name != $adt['name']) {
            $uzcms->log('Reklamma', 'O`zgartirilgan joy ' . $adt['name'] . ' на [url="/admin/adt.edit.php?id=' . $id_adt . '"]' . $name . '[/url]');

            $adt['name'] = $name;
            mysql_query("UplanshetTE `advertising` SET `name` = '" . my_esc($adt['name']) . "' WHERE `id` = '$id_adt' LIMIT 1");

            $doc->msg(__('Nomi o`zgardi'));
        } elseif (!$name)
            $doc->err(__('Nomiga yozmadingiz'));
    }

    $bold = (int) !empty($_POST['bold']);

    if ($adt['bold'] != $bold) {
        $adt['bold'] = $bold;

        mysql_query("UplanshetTE `advertising` SET `bold` = '$bold' WHERE `id` = '$id_adt' LIMIT 1");
        if ($adt['bold']) {
            $uzcms->log('Reklamma', 'Reklamma baner o`zgardi [url="/admin/adt.edit.php?id=' . $id_adt . '"]' . $name . '[/url] (установка жирности)');
            $doc->msg(__('Reklamma будет выделяться жирным шрифтом'));
        } else {
            $uzcms->log('Reklamma', 'Reklamma baner o`zgardi [url="/admin/adt.edit.php?id=' . $id_adt . '"]' . $name . '[/url] (снятие жирности)');
            $doc->msg(__('Reklamma не будет выделяться жирным шрифтом'));
        }
    }

    if (isset($_POST['url_link'])) {
        $url_link = text::input_text($_POST['url_link']);
        if ($url_link && $url_link != $adt['url_link']) {
            $adt['url_link'] = $url_link;
            mysql_query("UplanshetTE `advertising` SET `url_link` = '" . my_esc($adt['url_link']) . "' WHERE `id` = '$id_adt' LIMIT 1");
            $uzcms->log('Reklamma', 'Reklamma baner o`zgardi [url="/admin/adt.edit.php?id=' . $id_adt . '"]' . $name . '[/url] (ссылка: ' . $adt['url_link'] . ')');
            $doc->msg(__('Manzil qabul qilindi'));
        } elseif (!$url_link)
            $doc->err(__('Адрес ссылки не может быть bo`sh'));
    }

    if (isset($_POST['url_img'])) {
        $url_img = text::input_text($_POST['url_img']);
        if ($url_img != $adt['url_img']) {
            $adt['url_img'] = $url_img;
            mysql_query("UplanshetTE `advertising` SET `url_img` = '" . my_esc($adt['url_img']) . "' WHERE `id` = '$id_adt' LIMIT 1");
            $uzcms->log('Reklamma', 'Reklamma baner o`zgardi [url="/admin/adt.edit.php?id=' . $id_adt . '"]' . $name . '[/url] (адрес изображения: ' . $adt['url_img'] . ')');
            $doc->msg(__('Manzil qabul qilindi'));
        }
    }

    $page_main = (int) (isset($_POST['page_main']) && $_POST['page_main']);
    $page_other = (int) (isset($_POST['page_other']) && $_POST['page_other']);

    if (!$page_main && !$page_other)
        $doc->err(__('Reklamma должна же где-то отображаться'));
    elseif ($page_main != $adt['page_main'] || $page_other != $adt['page_other']) {
        $adt['page_main'] = $page_main;
        $adt['page_other'] = $page_other;
        mysql_query("UplanshetTE `advertising` SET `page_main` = '{$adt['page_main']}', `page_other` = '{$adt['page_other']}' WHERE `id` = '$id_adt' LIMIT 1");
        $uzcms->log('Reklamma', 'Reklamma baner o`zgardi [url="/admin/adt.edit.php?id=' . $id_adt . '"]' . $name . '[/url] (место отображения)');
        $doc->msg(__('Manzil qabul qilindi'));
    }
}

if (isset($_POST['time'])) {
    $always = (int) (isset($_POST['always']) && $_POST['always']);
    if ($adt['time_end']) {
        if ($always) {
            $adt['time_end'] = 0;
            mysql_query("UplanshetTE `advertising` SET `time_end` = '0' WHERE `id` = '$id_adt' LIMIT 1");
            $uzcms->log('Reklamma', 'Reklamma baner o`zgardi [url="/admin/adt.edit.php?id=' . $id_adt . '"]' . $adt['name'] . '[/url] (вечный показ)');
            $doc->msg(__('OKEY'));
        } else {
            if (isset($_POST['add']) && isset($_POST['mn'])) {
                $add = (int) $_POST['add'];
                $mn = (int) $_POST['mn'];
                
                if ($adt['time_start'] && $adt['time_start'] > TIME || $adt['time_end'] && $adt['time_end'] < TIME) {
                    $doc->msg(__('Счетчики показов и переходов сброшены'));
                    $clear_counters_sql = "`count_show_mobilni` =  '0', `count_out_mobilni` =  '0', `count_show_planshet` =  '0', `count_out_planshet` =  '0', `count_show_komp` =  '0', `count_out_komp` =  '0', ";
                }else
                    $clear_counters_sql = '';

                if ($add && $mn) {
                    if ($adt['time_end'] > TIME)
                        $adt['time_end'] = $adt['time_end'] + $add * $mn * 60 * 60 * 24;
                    else {
                        $adt['time_start'] = TIME;
                        $adt['time_end'] = TIME + $add * $mn * 60 * 60 * 24;
                    }

                    mysql_query("UplanshetTE `advertising` SET $clear_counters_sql`time_end` = '{$adt['time_end']}', `time_start` = '{$adt['time_start']}' WHERE `id` = '$id_adt' LIMIT 1");
                    $doc->msg(__('OKEY'));
                }else
                    $doc->err(__('Vaqit qisqa'));
            }
        }
    }else {
        if (!$always) {
            $adt['time_end'] = TIME;
            $uzcms->log('Reklamma', 'Reklamma baner o`zgardi [url="/admin/adt.edit.php?id=' . $id_adt . '"]' . $adt['name'] . '[/url] (вечный показ отключен)');
            mysql_query("UplanshetTE `advertising` SET `time_end` = '" . TIME . "' WHERE `id` = '$id_adt' LIMIT 1");
            $doc->msg(__('OKEY'));
        }
    }
}

$listing = new listing();

$post = $listing->post();
$post->icon('adt');
$post->title = text::toValue($adt['name']);
$post->hightlight = true;


if ($adt['time_create']) {
    $post = $listing->post();
    $post->title = __('Vaqti');
    $post->content = misc::when($adt['time_create']);
}

$post = $listing->post();
$post->title = __('Boshlanish vaqti');
if (!$adt['time_start']) {
    $post->content = __('Malumot yo`q');
} elseif ($adt['time_start'] > TIME) {
    $post->hightlight = true;
    $post->content = misc::when($adt['time_start']);
} else {
    $post->content = misc::when($adt['time_start']);
}

$post = $listing->post();
$post->title = __('Tugash vaqti');
if (!$adt['time_end'])
    $post->content = __('Abadiy bo`ldi');
else
    $post->content = misc::when($adt['time_end']);

$listing->display();

if (!isset($_GET['delete'])) {

    $form = new form("?id=$id_adt&amp;" . passgen());
    $form->text('name', __('Nomi'), $adt['name']);
    $form->checkbox('bold', __('Qalin yozish'), $adt['bold']);
    $form->text('url_link', __('Manzil'), $adt['url_link']);
    $form->text('url_img', __('Rasim manzili'), $adt['url_img']);
    $form->checkbox('page_main', __('Bosh sahifaga'), $adt['page_main']);
    $form->checkbox('page_other', __('Qolgan sahifalarga'), $adt['page_other']);
    $form->button(__('Saqlash'), 'common');
    $form->display();

    $form = new form("?id=$id_adt&amp;" . passgen());
    if ($adt['time_end']) {
        $form->text('add', __('Vaqtini ko`rsatish'), 1, false, 3);
        $options = array();
        $options[] = array('1', __('Kun'));
        $options[] = array('7', __('Xafta'), 1);
        $options[] = array('31', __('Oy'));
        $form->select('mn', false, $options);
    }
    $form->checkbox('always', __('Abadiy'), !$adt['time_end']);
    if ($adt['time_start'] && $adt['time_start'] >= TIME || $adt['time_end'] && $adt['time_end'] <= TIME)
        $form->bbcode('[notice] ' . __('Baner'));
    $form->button(__('Saqlash'), 'time');
    $form->display();
}else {
    $form = new form("?id=$id_adt&amp;delete&amp;" . passgen());
    $form->captcha();
    $form->bbcode(__('O`chirishni tastiqlash'));
    $form->button(__('O`chirish'), 'delete');
    $form->display();
}

$doc->ret(__('Orqaga qaytish'), "adt.php?id=$adt[space]");
$doc->ret(__('Reklamma'), 'adt.php');

?>