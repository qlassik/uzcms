<?php

include_once '../sys/inc/yadro.php';
admin::check_access();
$doc = new document(6);
$doc->title = __('Fon qo`shish');


echo'<div class="container">';
	
	
if (isset($_POST['captcha']) && isset($_POST['title']) && isset($_FILES ['file'] ['name'])){
	
$xatniki_file_name = ''. TIME .'_'.text::for_filename($_FILES ['file'] ['name']).'.png';
$xatnikis_path = FILES . '/.foni'; 
$xatnikis_dir = new files($xatnikis_path);

	
if (!empty($_FILES ['file'])) {
    if ($_FILES ['file'] ['error']) {
        $doc->err(__('Fayl yuklanmadi'));
    } elseif (!$_FILES ['file'] ['size']) {
        $doc->err(__('faylа yo`q'));
    } elseif(!preg_match("/\.(gif|png|jpg|GIF|PNG|JPG)$/", text::for_filename($_FILES ['file'] ['name']))){
        $doc->err(__('Rasim farmatda emas'));
    } elseif (!$img = @imagecreatefromjpeg($_FILES ['file'] ['tmp_name']) || !$img = @imagecreatefrompng($_FILES ['file'] ['tmp_name']) || !$img = @imagecreatefromgif($_FILES ['file'] ['tmp_name'])) {
        $doc->err(__('Sizdan iltimos rasim yuklang'));
    }else {
        if ($xatnikis_dir->is_file($xatniki_file_name)) {
            $xatniki = new files_file($xatnikis_path, $xatniki_file_name);
            $xatniki->delete(); 
        }

        if ($files_ok = $xatnikis_dir->filesAdd(array($_FILES ['file'] ['tmp_name'] => $xatniki_file_name))) {
            $xatnikis_dir->group_show = 0;
            $files_ok [$_FILES ['file'] ['tmp_name']]->group_show = 0;
            $files_ok [$_FILES ['file'] ['tmp_name']]->id_user = $user->id;
            $files_ok [$_FILES ['file'] ['tmp_name']]->group_edit = max($user->group, 2);

            unset($files_ok);
            $doc->msg(__('Saqlandi'));
        } else {
                $doc->err(__('Fayl yuklanmadi'));
        }
    }
}

	
if (empty($_POST['captcha']) || empty($_POST['captcha_session']) || !captcha::check($_POST['captcha'], $_POST['captcha_session'])) {
        $doc->err(__('Raqam to`gri holatda kiritilmadi'));
    }else{
		
		     mysql_query("INSERT INTO `foni` (`nomi`, `manzil`, `time`)values('" . my_esc($_POST['title']) . "', '" . my_esc($xatniki_file_name) . "', '" . TIME . "')");
		     $doc->msg(__('Fon qo`shildi'));
	         header('Refresh: 1; url=?');
	}

}

echo'<div style="margin: 9px;"></div>';
    if (isset($_GET['och'])){
    if (isset($_GET['ochi'])){		
		$xatnikis_path = FILES . '/.foni'; 
        $xatnikis_dir = new files($xatnikis_path);
		if (isset($_GET['och'])) {
	 $xatniki = new files_file($xatnikis_path, $_GET['ochi']);
        if (empty($_POST ['captcha']) || empty($_POST ['captcha_session']) || !captcha::check($_POST ['captcha'], $_POST ['captcha_session']))
            $doc->err(__('Raqam to`gri holatda kiritilmadi'));
        elseif ($xatniki->delete()) {
            mysql_query("DELETE FROM `foni` WHERE `manzil` = '".$_GET['och']."'");
            $doc->msg(__('Fon o`chirildi'));
            header('Refresh: 1; url=?' . passgen());
			echo'</div>';
            exit;
        } else {
            $doc->err(__('Fon o`chirishni iloji yo`q'));
        }
		echo'</div>';
		exit;
    }
	}
	echo '<center><img class="ana" width="100" height="100" src="/files/.foni/' . $_GET['och'] . '" alt="'.__('Mening fotoim').'" /></center><br />';
	$form = new form('?och='.$_GET['och'].'&ochi='.$_GET['och'].'&' . passgen());
    $form->captcha();
    $form->button(__('O`chirish'), 'delete');
    $form->display();
	echo'</div>';
	exit;
	}
	    if (isset($_GET['soz'])){
    if (isset($_GET['sozi']) && isset($_POST['nomi'])){		
     if (empty($_POST ['captcha']) || empty($_POST ['captcha_session']) || !captcha::check($_POST ['captcha'], $_POST ['captcha_session']))
            $doc->err(__('Raqam to`gri holatda kiritilmadi'));
        else {
        mysql_query("UPDATE `foni` SET `nomi` = '".$_POST['nomi']."'  WHERE `manzil` = '".$_GET['soz']."' LIMIT 1");

		$doc->msg(__('Fon nomi o`zgardi'));
		header('Refresh: 1; url=?' . passgen());
		echo'</div>';
		exit;
    }
	}
	$qs = mysql_query("SELECT * FROM `foni`  ORDER BY `nomi` = '".$_GET['soz']."' DESC LIMIT 1");
    while ($uss = @mysql_fetch_assoc($qs)) {
	$ism = $uss['nomi'];
    }
	echo '<center><img class="ana" width="100" height="100" src="/files/.foni/' . $_GET['soz'] . '" alt="'.__('Mening fotoim').'" /></center><br /></div>';
	$form = new form('?soz='.$_GET['soz'].'&sozi='.$_GET['soz'].'&' . passgen());
	$form->text('nomi', __('Fon nomi'), $ism);
    $form->captcha();
    $form->button(__('Yo`llash'));
    $form->display();
	echo'</div>';
	exit;
	}
$pages = new pages(mysql_result(mysql_query("SELECT COUNT(*) FROM `foni`"), 0));
$listing = new listing();
$q = mysql_query("SELECT * FROM `foni`  ORDER BY `time` DESC LIMIT ".$pages->limit);
while ($us = @mysql_fetch_assoc($q)) {
$galareya = $listing->galareya();
$galareya->image = '/files/.foni/'.$us['manzil'].'';
$galareya->title = $us['nomi'];
$galareya->time = misc::when($us['time']);
$galareya->action('delete', '?och='.$us['manzil'].'&' . passgen());
$galareya->action_t('authentication', '?soz='.$us['manzil'].'&' . passgen());
}

$listing->display(__('Ro`yhat bo`sh'));
$pages->this_page();
$pages->display('?');
echo'</div>';
$fv = new fv('?' . passgen());
$fv->text('title', __('Fon nomi'));
$fv->file('file', __('JPG, GIF, PNG, farmatdagi fon suratlar yuklanadi'));
$fv->captcha();
$fv->button(__('Saqlash'), 'save');
$fv->display();
echo'</div>';