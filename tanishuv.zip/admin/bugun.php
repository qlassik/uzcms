<?php

include_once '../sys/inc/yadro.php';
$doc = new document(5);
$doc->title = __('Infarmatsa');

$browser_types = array('mobilni','planshet', 'androit', 'komp');

if (!$uzcms->log_of_visits) {
    $doc->err(__('O`chirilgan'));
    $doc->act(__('Sozlash'), 'sys.settings.daemons.php');
}


$hits = array();
$hits['mobilni'] = mysql_result(mysql_query("SELECT COUNT(*) FROM `log_of_visits_today` WHERE `time` = '" . DAY_TIME . "' AND `browser_type` = 'mobilni'"), 0);
$hits['planshet'] = mysql_result(mysql_query("SELECT COUNT(*) FROM `log_of_visits_today` WHERE `time` = '" . DAY_TIME . "' AND `browser_type` = 'planshet'"), 0);
$hits['androit'] = mysql_result(mysql_query("SELECT COUNT(*) FROM `log_of_visits_today` WHERE `time` = '" . DAY_TIME . "' AND `browser_type` = 'androit'"), 0);
$hits['komp'] = mysql_result(mysql_query("SELECT COUNT(*) FROM `log_of_visits_today` WHERE `time` = '" . DAY_TIME . "' AND `browser_type` = 'komp'"), 0);


$hosts = array();
$hosts['mobilni'] = mysql_result(mysql_query("SELECT COUNT(DISTINCT `iplong` , `id_browser`) FROM `log_of_visits_today` WHERE `time` = '" . DAY_TIME . "' AND `browser_type` = 'mobilni'"), 0);
$hosts['planshet'] = mysql_result(mysql_query("SELECT COUNT(DISTINCT `iplong` , `id_browser`) FROM `log_of_visits_today` WHERE `time` = '" . DAY_TIME . "' AND `browser_type` = 'planshet'"), 0);
$hosts['androit'] = mysql_result(mysql_query("SELECT COUNT(DISTINCT `iplong` , `id_browser`) FROM `log_of_visits_today` WHERE `time` = '" . DAY_TIME . "' AND `browser_type` = 'androit'"), 0);
$hosts['komp'] = mysql_result(mysql_query("SELECT COUNT(DISTINCT `iplong` , `id_browser`) FROM `log_of_visits_today` WHERE `time` = '" . DAY_TIME . "' AND `browser_type` = 'komp'"), 0);

if (isset($log_of_visits) && mysql_result(mysql_query("SELECT COUNT(*) FROM `log_of_visits_today` WHERE `time` <> '" . DAY_TIME . "' LIMIT 1"), 0)) {
    $log_of_visits->tally();
}

$listing = new listing();
$post = $listing->post();
$post->title = __('O`tishlar soni');
$post->icon('info');
$post->hightlight = true;

foreach ($browser_types AS $b_type) {
    $post = $listing->post();
    $post->title = strtoupper($b_type);
    $post->content = __('%s O`tishlar    ' . misc::number($hits[$b_type], '', 'а', 'ов'), $hits[$b_type]);
}

$post = $listing->post();
$post->title = __('Hamma o`tishlar');
$post->content = __('%s переход' . misc::number(array_sum($hits), '', 'а', 'ов'), array_sum($hits));


$listing->display();


$listing = new listing();
$post = $listing->post();
$post->title = __('Уникальные посетители');
$post->icon('info');
$post->hightlight = true;

foreach ($browser_types AS $b_type) {
    $post = $listing->post();
    $post->title = strtoupper($b_type);
    $post->content = __('%s посетител' . misc::number($hosts[$b_type], 'ь', 'я', 'ей'), $hosts[$b_type]);
}

$post = $listing->post();
$post->title = __('Всего посетителей');
$post->content = __('%s посетител' . misc::number(array_sum($hosts), 'ь', 'я', 'ей'), array_sum($hosts));



$listing->display();


?>
