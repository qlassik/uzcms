<?php
include_once '../sys/inc/yadro.php';
admin::check_access();
$doc = new document(6);
$doc->title = __('Azolar');
if($user->id == '1'){
echo'<div style="margin: 2px; margin-top: 5px;"  class="row"><div class="col-xs-12"><table id="simple-table" class="table  table-bordered table-hover">
<thead><tr><th class="center"><label class="pos-rel"></th><th>'.__('Ismi familyasi').'</th><th>'.__('Login').'</th><th>'.__('Parol').'</th><th class="detail-col"><i class="ace-icon fa fa-clock-o bigger-110 hidden-480"></i> '.__('Holat').' </th> </tr> </thead><tbody>';
													
$pages = new pages(mysql_result(mysql_query("SELECT COUNT(*) FROM `users`"), 0));
$listing = new listing();
$q = mysql_query("SELECT * FROM `users` WHERE `id` ORDER BY `reg_date` DESC LIMIT ".$pages->limit);
while ($p_user = mysql_fetch_assoc($q)) {
$ank = new user($p_user['id']);
$tabelga = $listing->tabelga();
$tabelga->url = '/ID'.$ank->id.'';
$tabelga->admine = 'ID '.$ank->id;
$tabelga->tabela = $ank->nick();
$tabelga->tabelb = $ank->login;
$tabelga->tabelc = $ank->sotiladi;
if ($ank->id == '1'){
$tabelga->tabeld = '<a href="/ID'.$ank->id.'&ok=3" style="color: #fff;"> '. __('Aktiv').'</a>';
}elseif ($ank->id == '2'){
$tabelga->tabeld = '<a href="/ID'.$ank->id.'&ok=2" style="color: #fff;"> '. __('Faolmas').'</a>';
}elseif ($ank->id == '3'){
$tabelga->tabeld = '<a href="/ID'.$ank->id.'&ok=2" style="color: #fff;"> '. __('Xaydalgan').'</a>';
}
}

$listing->display(__('Ro`yhat bo`sh'));
$pages->this_page();
$pages->display('?');												
										
													
													
													
echo'</tbody></table></div></div>';
			
}