<?php

include_once '../sys/inc/yadro.php';
admin::check_access();
$doc = new document(6);
$doc->title = __('Sahifa ochish');

if (isset($_GET['bloqla'])){
$idga = (int) $_GET['bloqla'];	
mysql_query("UPDATE `html` SET `bloq` = '2' WHERE `id` = '" .$idga. "' LIMIT 1");
$doc->msg(__('Bloqlandi'));
header('Refresh: 1; url=?');	
$doc->ret(__('Orqaga'), '/file.html?' . passgen());		
	
exit;
}

if (isset($_GET['bloqdan_ol'])){
$idga = (int) $_GET['bloqdan_ol'];	
mysql_query("UPDATE `html` SET `bloq` = '1' WHERE `id` = '" .$idga. "' LIMIT 1");
$doc->msg(__('Bloqdan olindi'));
header('Refresh: 1; url=?');		
$doc->ret(__('Orqaga'), '/file.html?' . passgen());		
	
exit;
}


if (isset($_GET['sh'])){
	$idgaz = $_GET['sh'];
if (isset($_GET['sharh'])){

if ($_GET['sharh'] == 'ok' && $_GET['id']){
$idga = $_GET['id'];	
mysql_query("DELETE FROM `fayl_sharx` WHERE `id_file` = '$idga'");
$doc->msg(__('Sharglar o`chirildi'));
header('Refresh: 1; url=?');	
}
}
echo '<div class="panel panel-default">
  <div class="panel-heading">'.__('Siz bu fayilni sharhlarini o`chirmoqchimisiz?').'</div>
  <div class="panel-body">
 
 
 <p><a href="?sh='.$idgaz.'&sharh=ok&id='.$idgaz.'" class="btn btn-primary" role="button">'.__('XA').'</a> <a href="?" class="btn btn-default" role="button">'.__('YO`Q').'</a></p>
 
 
  </div>
</div>';
$doc->ret(__('Orqaga'), '/file.html?' . passgen());		
	
exit;
}




if (isset($_GET['och'])){
	$idgaz = $_GET['och'];
if (isset($_GET['oche'])){

if ($_GET['oche'] == 'ok' && $_GET['id']){
$idga = $_GET['id'];	
mysql_query("UPDATE `bolimlarga` SET `fayl_necta` = `fayl_necta` - '1' WHERE `id` = '" .$_GET['och']. "' LIMIT 1");
mysql_query("DELETE FROM `html` WHERE `id` = '" .$idga. "' LIMIT 1") ;
$doc->msg(__('Ok'));
header('Refresh: 1; url=?');	
}
}
echo '<div class="panel panel-default">
  <div class="panel-heading">'.__('Siz bu fayilni o`chirmoqchimisiz?').'</div>
  <div class="panel-body">
 
 
 <p><a href="?och='.$idgaz.'&oche=ok&id='.$_GET['id'].'" class="btn btn-primary" role="button">'.__('XA').'</a> <a href="?" class="btn btn-default" role="button">'.__('YO`Q').'</a></p>
 
 
  </div>
</div>';
$doc->ret(__('Orqaga'), '/file.html?' . passgen());		
	
exit;
}



if (isset($_GET['soz'])){
$idga = (int) $_GET['soz'];	
if (isset($_GET['sozi'])){
if ($_GET['sozi'] == 'ok'){
	
if (!mysql_result(mysql_query("SELECT COUNT(*) FROM `bolimlar` WHERE  `id` = '" . my_esc($_POST['bolimlarga']) . "' "), 0)){
		    mysql_query("INSERT INTO `bolimlar` (`bolimlarga`, `time`) VALUES ('" . my_esc($_POST['bolimlarga']) . "', ' " . TIME . " ')");
		}else{
			mysql_query("UPDATE `bolimlar` SET `time` = ' " . TIME . " ' WHERE `id` = '" .$_POST['bolimlarga']. "' LIMIT 1");
            
		}
		if (!mysql_result(mysql_query("SELECT COUNT(*) FROM `tegi` WHERE  `nomi` = '".$_POST['tegi']."' "), 0)){
			mysql_query("INSERT INTO `tegi` (`nomi`, `time`) VALUES ('" . my_esc($_POST['tegi']) . "', ' " . TIME . " ')");
		    }else{
			mysql_query("UPDATE `tegi` SET `time` = ' " . TIME . " ' WHERE `nomi` = '" .$_POST['tegi']. "' LIMIT 1");
            
		   }
			mysql_query("UPDATE `bolimlarga` SET `fayl_necta` = `fayl_necta` + '1' WHERE `id` = '" .$_POST['bolimlarga']. "' LIMIT 1");
            mysql_query("UPDATE `bolimlarga` SET `fayl_necta` = `fayl_necta` - '1' WHERE `id` = '" .$idga. "' LIMIT 1");	
	
	
	

	
if (isset($_POST['bolimlarga'])){
$manzil = ''.bolim_sisilka($_POST['bolimlarga']).''.$_SESSION['manzil'].'';	
}else{
$manzil = $_SESSION['manzil'];		
}

	if (isset($_POST['rasm'])){
			$codga = $_POST['rasm'];	
			}else{
			$codga = '<img class="multik" src="/img/file.png">';		
			}
mysql_query("UPDATE `html` SET `nomi` = '".$_POST['nomi']."',  `ismi` = '".$user->nick."', `mul` = '".$codga."', `manzil` = '".$manzil."', `bolimlarga` = '".$_POST['bolimlarga']."', `ichki_txt` = '".$_POST['ichki_txt']."', `tashqi_txt` = '".$_POST['tashqi_txt']."', `gogle` = '".$_POST['gogle']."', `tegi` = '".$_POST['tegi']."'  WHERE `id` = '" .$idga. "' LIMIT 1");
$doc->msg(__('Yuklandi'));	
header('Refresh: 1; url=?');	
}
}
$qx = mysql_query("SELECT * FROM `html` WHERE  `id` = '" .$idga. "' LIMIT 1");
while ($usx = mysql_fetch_assoc($qx)) {
$nomi = $usx['nomi'];
$bolimlarga = $usx['bolimlarga'];
$tashqi_txt = $usx['tashqi_txt'];
$ichki_txt = $usx['ichki_txt'];
$_SESSION['manzil'] = $usx['e_manzil'];
$gogle = $usx['gogle'];
$tegi = $usx['tegi'];
$mul = $usx['mul'];
}

echo'<form method="post" action="?soz='.$idga.'&sozi=ok&'.passgen().'" class="form-horizontal">';
?><div class="box">
  <div class="panel panel-default">
    <div class="panel-heading"><?=__('Fayl qo`shish')?> <a style="margin-top: -5px; height: 30px; font-size: 90%;" class="btn btn-primary right" role="button" data-toggle="collapse" href="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
  <?=__('Fayl qo`shish yopish')?>
</a></div>
  </div>
 
	<div class="row box-section" style="margin-left: 15px;">
		<div class="form-group">
		  <label class="control-label col-lg-2"><?=__('Nomi')?>:</label>
		  <div class="col-lg-10">
			<input style="width:100%;max-width:350px;" type="text"  value="<?=$nomi?>" name="nomi">
		  </div>
		 </div>
		 	<div class="form-group">
		  <label class="control-label col-lg-2"><?=__('Surat yoki video codini qo`yish')?>:</label>
		  <div class="col-lg-10">
    <div class="input-group">
      <span class="input-group-addon">
        <input type="checkbox" name="rasm">
      </span>
      <input type="text" class="form-control" name="mul" style="width:100%;max-width:312px;">
    </div>
  </div>
		 </div>	
		 <div class="form-group">
		  <label class="control-label col-lg-2"><?=__('Bo`lim tanlash')?>:</label>
		  <div class="col-lg-10">
			<div class="selector fixedWidth"><span style="user-select: none;"></span>	<select class="uniform btn" style="font-size: 100%;"  name="bolimlarga"> <option value="">   </option><?    
$result = mysql_query("SELECT * FROM `bolimlarga` WHERE `id`"); 
$myrow = mysql_fetch_array($result);  
do   
{  
printf ("<option value='%s'>%s</option>",$myrow["id"],$myrow["nomi"]); 
} 
while ($myrow = mysql_fetch_array($result)); 
?> 
</select></div>
		  </div>
		 </div>
		<div class="form-group">
		  <label class="control-label col-lg-2"><?=__('Qisqacha ko`rinish uchun tavsif')?></label>
		  <div class="col-lg-10">
			
			<textarea name="tashqi_txt" style="width:100%;max-width:350px;"  rows="5"><?=$tashqi_txt?></textarea>
		  </div>
		 </div>
		 <div class="form-group">
		  <label class="control-label col-lg-2"><?=__('To`liq ko`rinish uchun tavsif')?></label>
		  <div class="col-lg-10">
			<textarea name="ichki_txt" style="width:100%;max-width:350px;" rows="5"><?=$ichki_txt?></textarea>
		  </div>
		 </div>
		 <div class="form-group">
		  <label class="control-label col-lg-2"><?=__('Tegi')?>:</label>
		  <div class="col-lg-10">
			<input style="width:100%;max-width:350px;" type="text"  value="<?=$tegi?>" name="tegi">
		  </div>
		 </div>
		 <div class="form-group">
		  <label class="control-label col-lg-2"><?=__('Xalqaro sistemadan izlaganda')?></label>
		  <div class="col-lg-10">
			<textarea name="gogle" style="width:100%;max-width:350px;" rows="5"><?=$gogle?></textarea>
		  </div>
		 </div>
		 
          <div class="form-group">
		  <label class="control-label col-lg-2"><?=__('Sharh yozilsinmi?')?>:</label>
		  <div class="col-lg-10">
		  <div class="selector fixedWidth"><span style="user-select: none;"></span>	<select class="uniform btn" style="font-size: 100%;"  name="sharx_t"> <option value='2'><?=__('YOQ YOZILMASIN')?></option> 
		  <option value='1'><?=__('XA YOZILSIN')?></option> 
          </select></div>
		  </div>
		 </div>
		
		<div class="form-group">
		  <label class="control-label col-lg-2"></label>
		  <div class="col-lg-10">
			<input type="submit" class="btn btn-green" value="<?=__('Добавить')?>">
		  </div>
		 </div>
		 
	</div>
 
</div>
</form><?


	
$doc->ret(__('Orqaga'), '/file.html?' . passgen());		
	
exit;
}



if (isset($_POST['nomi'])){
$_POST['manzil'] = $_POST['nomi'];
}
if (isset($_POST['nomi']) && isset($_POST['manzil'])){
$tuga = $_SESSION['time'] + '4';
if (TIME >= $tuga){

	$fff = "" . my_esc(''.$_POST['manzil'].'');
if (preg_match('#^([a-z0-9\-\_\ ])+$#ui', $fff) == '0'){
             $doc->err(__('Bo`lim manziliga simmol ishlatmang'));	
}elseif (mysql_result(mysql_query("SELECT COUNT(*) FROM `html` WHERE `nomi` = '" . my_esc($_POST['nomi']) . "' "), 0)) {
             $doc->err(__('Bu bo`lim mavjud'));
        }elseif (mysql_result(mysql_query("SELECT COUNT(*) FROM `html` WHERE `manzil` = '" . my_esc($_POST['manzil']) . "' "), 0)) {
             $doc->err(__('Bu manzil mavjud'));
        }else{
		 $data = date("Y-m-d"); 
		if (!mysql_result(mysql_query("SELECT COUNT(*) FROM `bolimlar` WHERE  `id` = '" . my_esc($_POST['bolimlarga']) . "' "), 0)){
		    mysql_query("INSERT INTO `bolimlar` (`bolimlarga`, `time`) VALUES ('" . my_esc($_POST['bolimlarga']) . "', ' " . TIME . " ')");
		}else{
			mysql_query("UPDATE `bolimlar` SET `time` = ' " . TIME . " ' WHERE `id` = '" .$_POST['bolimlarga']. "' LIMIT 1");
            
		}
		if (!mysql_result(mysql_query("SELECT COUNT(*) FROM `tegi` WHERE  `nomi` = '".$_POST['tegi']."' "), 0)){
			mysql_query("INSERT INTO `tegi` (`nomi`, `time`) VALUES ('" . my_esc($_POST['tegi']) . "', ' " . TIME . " ')");
		}else{
			mysql_query("UPDATE `tegi` SET `time` = ' " . TIME . " ' WHERE `nomi` = '" .$_POST['tegi']. "' LIMIT 1");
            
		}
			mysql_query("UPDATE `bolimlarga` SET `fayl_necta` = `fayl_necta` + '1' WHERE `id` = '" .$_POST['bolimlarga']. "' LIMIT 1");
            if (isset($_POST['bolimlarga'])){
			$manzil = ''.bolim_sisilka($_POST['bolimlarga']).''.$_POST['manzil'].'';	
			}else{
			$manzil = $_POST['manzil'];		
			}
			 if (isset($_POST['rasm'])){
			if (isset($_POST['mul'])){
			$codga = $_POST['mul'];	
			}else{
			$codga = '<img class="multik" src="/img/file.png">';		
			}
			}else{
			$codga = '<img class="multik" src="/img/file.png">';		
			}
			
			mysql_query("INSERT INTO `html` (`nomi`, `ismi`, `mul`, `tashqi_txt`, `ichki_txt`, `manzil`, `e_manzil`, `bolimlarga`, `gogle`, `tegi`,`sharx_t`,  `data`, `time`)values('" . my_esc($_POST['nomi']) . "', '" . my_esc($user->nick) . "', '" . my_esc($codga) . "', '" . my_esc($_POST['tashqi_txt']) . "', '" . my_esc($_POST['ichki_txt']) . "',  '" . my_esc($manzil) . "',  '" . my_esc($_POST['manzil']) . "', '" . my_esc($_POST['bolimlarga']) . "', '" . my_esc($_POST['gogle']) . "', '" . my_esc($_POST['tegi']) . "', '" . my_esc($_POST['sharx_t']) . "', '".$data."', '" . TIME . "')");
		     $doc->msg(__('Bo`lim qo`shildi'));
			 $_SESSION['time'] = TIME;
	         header('Refresh: 1; url=?');
	}

}else{
         $doc->msg(__('Boshqatdan urunib ko`ring'));	
		 header('Refresh: 1; url=?');
}
}


     
?>

  <div class="collapse" id="collapseExample">

<form method="post" action="?<?= passgen()?>" class="form-horizontal">
<div class="box">
  <div class="panel panel-default">
    <div class="panel-heading"><?=__('Fayl qo`shish')?> <a style="margin-top: -5px; height: 30px; font-size: 90%;" class="btn btn-primary right" role="button" data-toggle="collapse" href="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
  <?=__('Fayl qo`shish yopish')?>
</a></div>
  </div>
 
	<div class="row box-section" style="margin-left: 15px;">
		<div class="form-group">
		  <label class="control-label col-lg-2"><?=__('Nomi')?>:</label>
		  <div class="col-lg-10">
			<input style="width:100%;max-width:350px;" type="text" name="nomi" title="<?=__('Fayl nomini kriting')?>">
		  </div>
		 </div>
		<div class="form-group">
		  <label class="control-label col-lg-2"><?=__('Surat yoki video codini qo`yish')?>:</label>
		  <div class="col-lg-10">
    <div class="input-group">
      <span class="input-group-addon">
        <input type="checkbox" name="rasm" title="<?=__('Siz surat yo video codini qo`yasizmi? U holda ptichka qo`ying')?>">
      </span>
      <input type="text" class="form-control" name="mul" style="width:100%;max-width:312px;" aria-label="Previous" aria-hidden="true" title="<?=__('Surat yo video codi qo`yin')?>">
    </div>
  </div>
		 </div>		 
		 <div class="form-group">
		  <label class="control-label col-lg-2"><?=__('Bo`lim tanlang')?>:</label>
		  <div class="col-lg-10">
			<div class="selector fixedWidth"><span style="user-select: none;"></span>	<select  title="<?=__('Bo`lim tanlang')?>" class="uniform btn" style="font-size: 100%;"  name="bolimlarga"> <option value="/"> </option><?    
$result = mysql_query("SELECT * FROM `bolimlarga` WHERE `id`"); 
$myrow = mysql_fetch_array($result);  
do   
{  
printf ("<option value='%s'>%s</option>",$myrow["id"],$myrow["nomi"]); 
} 
while ($myrow = mysql_fetch_array($result)); 
?> 
</select></div>
		  </div>
		 </div>
		<div class="form-group">
		  <label class="control-label col-lg-2"><?=__('Qisqacha ko`rinish uchun tavsif')?></label>
		  <div class="col-lg-10">
			<textarea name="tashqi_txt" style="width:100%;max-width:350px;" rows="5"   title="<?=__('Listingda ko`rinuvchiga qisqacha tavsif yozing')?>"></textarea>
		  </div>
		 </div>
		 <div class="form-group">
		  <label class="control-label col-lg-2"><?=__('To`liq ko`rinish uchun tavsif')?></label>
		  <div class="col-lg-10">
			<textarea name="ichki_txt" style="width:100%;max-width:350px;" rows="5"  title="<?=__('Yakka ko`rinuvchiga to`liq tavsif yozing')?>"></textarea>
		  </div>
		 </div>
		 <div class="form-group">
		  <label class="control-label col-lg-2"><?=__('Tegi')?>:</label>
		  <div class="col-lg-10">
			<input style="width:100%;max-width:350px;" type="text" name="tegi"  title="<?=__('Sarlavha orqali izlash uchun so`z biriktiring')?>">
		  </div>
		 </div>
		 <div class="form-group">
		  <label class="control-label col-lg-2"><?=__('Xalqaro sistemadan izlaganda')?></label>
		  <div class="col-lg-10">
			<textarea name="gogle" style="width:100%;max-width:350px;" rows="5"  title="<?=__('Xalqaro sistemadan izlaganda ko`rinishga tavsif yozing')?>"></textarea>
		  </div>
		 </div>
		 
          <div class="form-group">
		  <label class="control-label col-lg-2"><?=__('Sharh yozilsinmi?')?>:</label>
		  <div class="col-lg-10">
		  <div class="selector fixedWidth"><span style="user-select: none;"></span>	<select title="<?=__('Bu faylga sharh qoldirilsinmi?')?>" class="uniform btn" style="font-size: 100%;"  name="sharx_t"> <option value='2'><?=__('YOQ YOZILMASIN')?></option> 
		  <option value='1'><?=__('XA YOZILSIN')?></option> 
          </select></div>
		  </div>
		 </div>
		
		<div class="form-group">
		  <label class="control-label col-lg-2"></label>
		  <div class="col-lg-10">
			<input type="submit" class="btn btn-green" value="<?=__('Добавить')?>">
		  </div>
		 </div>
		 
	</div>
 
</div>
</form>
</div>


<div class="panel panel-default">

  <div class="panel-heading"><?=__('Fayllar')?>  <a style="margin-top: -5px; height: 30px; font-size: 90%;" class="btn btn-primary right" role="button" data-toggle="collapse" href="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
  <?=__('Fayl qo`shish')?>
</a></div>




 <table class="table">
 <thead> <tr> <th> № </th>  <th><?=__('Fayl manzili')?></th> <th><?=__('Ko`rilgan soni')?></th> <th><?=__('Bloq')?></th> <th><?=__('Sozlash')?></th></tr> </thead>
 <tbody> 
 <?
$q = mysql_query("SELECT * FROM `html` WHERE  `id` ORDER BY `time`");
$s = '0';
while ($us = mysql_fetch_assoc($q)) {

echo'<tr> <th scope="row">  '.++$s.') </th> <td><a href="/'.$us['manzil'].'.html">'.$us['nomi'].'.html</a></td>  <td>'.$us['korildi'].'</td>';
if ($us['bloq'] == '1'){
 echo'<td><a href="?bloqla='.$us['id'].'" style="color: green">'.__('Bloqlash').'</a></td> ';
}else{
 echo'<td><a href="?bloqdan_ol='.$us['id'].'" style="color: red">'.__('Bloqdan olish').'</a></td> ';	
}
 
 echo'<td>'.misc::when($us['time']).'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | <a href="?sh='.$us['id'].'" style="color: bluee"><b> sh    </b></a>  | <a href="?soz='.$us['id'].'" style="color: green"><b> C    </b></a> | <a href="?och='.$us['bolimlarga'].'&id='.$us['id'].'" style="color: red"><b> X </b></a> |</td> </tr>';

}
 


 echo'</tbody>
 </table> 
 </div>'; 


?>