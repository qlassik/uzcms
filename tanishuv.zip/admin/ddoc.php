<?php

include_once '../sys/inc/yadro.php';
admin::check_access();
$doc = new document(5);
$doc->title = __('Asosiy sozlamalar');
if($user->id == '1'){
$browser_types = array('mobilni','planshet', 'androit', 'komp');

if ($user->id == '1' && isset($_POST ['save'])) {
	$uzcms->ddos = (int) !empty($_POST ['ddos']);
    $uzcms->ddos_bil = (int) !empty($_POST ['ddos_bil']);
    $uzcms->save_settings($doc);
}


$form = new form('?' . passgen());
$form->tashida_chek_tu_c1('ddos', __('Saytni DDOSini  yoqsangiz sayt qotibroq ishlashi mumkin') . ' **', $uzcms->ddos);
$form->tashida_chek_tu_c6('ddos_bil', __('DDOS qilinyatgan api adreslar habar bo`lib kelsinmi') . ' **', $uzcms->ddos_bil);
$form->button(__('Saqlash'), 'save');
$form->display();
}

?>
