<?php

include_once '../sys/inc/yadro.php';
$doc = new document(5);
$doc->title = __('CHMOD');
$nw = ini::read(H . '/sys/dat/chmod.ini');

$listing = new listing();

$err = array();
foreach ($nw as $path) {
    $e = check_sys::getChmodErr($path, true);
    $post = $listing->post();
    $post->icon($e ? 'error' : 'checked');
    $post->title = $path;
    $err = array_merge($err, $e);
}

$listing->display();

if ($err) { 
    $form = new form();
    $form->textarea('', '', implode("\r\n", $err));
    $form->bbcode('* ' . __('Skrib fayllari 644 dan 666 gacha bo`lgani maqul'));
    $form->display();
}else
    $doc->msg( __('CHMOD okey'));


?>
