<?php

include_once '../sys/inc/yadro.php';
admin::check_access();
$groups = groups::load_ini();
$doc = new document(5);
$doc->title = __('Tiket ochiq');
	
switch (@$_GET['down']) {
    case 'all':
        $down='all';
		$where = null;
		$doc->title = __('Hamma tiketlar');
        break;
    case 'zak':
        $down='zak';
		$where = "WHERE `down` = '0'";
		$doc->title = __('Tiketni berkitish');
        break;
    default:
        $down='otk';
		$where = "WHERE `down` = '1'";
        break;
}


$pages = new pages(mysql_result(mysql_query("SELECT COUNT(*) FROM `tiket`"), 0));
$ord = array();
$ord[] = array("?down=otk&amp;page={$pages->this_page}" , __('Ochiq tiketlar'), $down == 'otk');
$ord[] = array("?down=zak&amp;page={$pages->this_page}" , __('Berkitilganlar'), $down == 'zak');
$ord[] = array("?down=all&amp;page={$pages->this_page}" , __('Hamma tiketlar'), $down == 'all');

$or = new design();
$or->assign('order', $ord);
$or->display('design.order.tpl');
$listing = new listing();

$q = mysql_query("SELECT * FROM `tiket` ".$where." ORDER BY `time` DESC LIMIT " . $pages->limit);
$after_id = false;
while ($tiket = mysql_fetch_assoc($q)) {
    $ank = new user($tiket['id_user']);
    $post = $listing->post();
    $post->url = '/support/tiket.php?id=' . $tiket['id'];
    $post->time = misc::when($tiket['time']);
    $post->title = text::toValue($tiket['name']);
    $post->post = text::toOutput(mb_substr($tiket['msg'],0,100,'utf-8')).'<br />';
	$k_kom=mysql_result(mysql_query("SELECT COUNT(*) FROM `tiket_kom` WHERE `id_list` = '$tiket[id]' AND `otv` = '1'"),0);
	$post->post .= __(misc::number($k_kom, 'Javob', 'Javob bermoqda', 'Ko`rib chiqilyapti') .': %s', $k_kom);;
    $post->icon("tiket.{$tiket['down']}");
	$post->bottom = __('Qo`shish' . ($ank->sex? '':'а').': %s',$ank->show());
	if (($user->group >= 2)&& $tiket['down']==1)
	$post->action('tiket.0', '/support/act.php?id='.$tiket['id'].'?act=clous');
	if (($user->group >= 2)&& $tiket['down']==0)
	$post->action("tiket.1", '/support/act.php?id='.$tiket['id'].'?act=clous');
	if ($user->group >= 2)
	$post->action("delete", '/support/act.php?id='.$tiket['id'].'?act=delete');
	
}

$listing->display(__('Ochiq tiketlar yo`q'));
$pages->display('?down=otk'); 
