<?php

include_once '../sys/inc/yadro.php';
include_once '../sys/inc/update.php';
admin::check_access();
$doc = new document(groups::max());

$skips = ini::read(H . '/sys/dat/update_skips.ini', true);

$doc->title = __('Sistema sozlamasi');

if (!@function_exists('ignore_user_abort')) {
    $doc->err(__('Sizda ignore_user_abort funsiya shakillanmagan.'));
    
    exit;
}

if (!@function_exists('set_time_limit')) {
    $doc->err(__('Sizda set_time_limit yoqilmagan.'));
    
    exit;
}

$update = new update();

if (($ver = $update->is_updateble()) !== false) {
    $list = $update->getUpdatebleFiles();

    $can_skip = array();
    foreach ($list as $file) {
        if (isset($skips[$file]['name'])) {
            $can_skip[$file] = $skips[$file]['name'];
        }
    }

    if (!empty($_POST['update'])) {
        $skip = array();
        foreach ($can_skip as $key => $value) {
            if (empty($_POST[$key])) {
                $skip[] = $key;
            }
        }

        $update->setSkipFiles($skip);
        if ($update->start()) {
            $doc->msg(__('Yakullandi'));
            $doc->ret('<img src="/img/answer.png"> '.__('Orqaga qaytish'), '?');
            
            exit;
        } else {
            $doc->err(__('xatolik mavjud'));
        }
    }

    $doc->msg(__('Majud wersiya: %s > %s', $uzcms->version, $ver));

    $form = new form('?' . passgen());
    foreach ($can_skip as $key => $value)
        $form->checkbox($key, $value, true);
    $form->textarea(false, __('Hamma wersiya'), implode("\r\n", $list));
    $form->button(__('Yangilash'), 'update');
    $form->display();
} else {
    $doc->msg(__('Sizdagi wersiya: %s', $uzcms->version));

    $listing = new listing();
    $post = $listing->post();
    $post->title = __('Informatsa');
    $post->icon('info');
    $post->content[] = __('Xolatni ko`satilmaydi');
    $listing->display();
}

