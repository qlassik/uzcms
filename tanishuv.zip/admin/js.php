<?php

include_once '../sys/inc/yadro.php';
$doc = new document(groups::max());
$doc->title = __('Sozlash js');



if (isset($_POST['qlassik_ru'])) {
    $jsbuild = new js_assembly(H . '/style/js/sources/');
    $jsbuild->buildTo(H . '/style/js/js.js');
    unset($jsbuild);
}

$listing = new listing();
$post = $listing->post();
$post->icon('info');
$post->title = __('Infarmatsa');
$post->content[] = 'Fayl js.js - joylashkan joyi /style/js/sources';
$post->content[] = 'O`zgarishlari: /style/js/build/js.js';

$post = $listing->post();
$post->icon('js');
$post->title = __('Oxirgi xolatga:');
$time = filemtime(H . '/style/js/js.js');
$post->content[] = $time ? misc::when($time) : __('Yakullanmagan joy');
$listing->display();



$form = new form();
$form->button(__('Sozlash'), 'qlassik_ru');
$form->display();
?>
