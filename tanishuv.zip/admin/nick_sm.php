<?php

include_once '../sys/inc/yadro.php';
admin::check_access();
$doc = new document(4);
$doc->title = __('Nicklarni zararlantrish');


if(isset($_GET['delete'])){
	$id_spam = (int) $_GET['delete'] ;
	
$q = mysql_query("SELECT * FROM `nick_z` WHERE `id` = '$id_spam' LIMIT 1");

if (!mysql_num_rows($q)) {
    if (isset($_GET ['return']))
        header('Refresh: 1; url=' . $_GET ['return']);
    else
        header('Refresh: 1; url=./');
    $doc->err(__('Xato'));
    exit();
}

$spam = mysql_fetch_assoc($q);
mysql_query("DELETE FROM `nick_z` WHERE `id` = '$spam[id]' LIMIT 1");
$doc->msg(__('O`chirildi'));

if (isset($_GET ['return']))
    header('Refresh: 1; url=' . $_GET ['return']);
else
    header('Refresh: 1; url=./?' . SID);
	exit () ;
}
if(isset($_GET['add'])){
if (isset($_POST['nick_z'])) {
   $nick_z = text::for_name($_POST['nick_z']);


    if (!$nick_z) {
        $doc->err(__('Bunday manba yo`q'));
    } else {
        mysql_query("INSERT INTO `nick_z` (`nick_z`) VALUES ('" . my_esc($nick_z) . "')");

        $doc->msg(__('Qo`shildi'));

		$doc->ret(__('Qaytish'), '?');
if (isset($_GET ['return']))
    header('Refresh: 1; url=' . $_GET ['return']);
else
    header('Refresh: 1; url=?' . SID);
	exit () ;
        exit() ;
	}
}

$form = new form('?add&amp;' . passgen() . (isset($_GET['return']) ? '&amp;return=' . urlencode($_GET['return']) : null));
$form->text('nick_z', __('Loginni kiriting'));
$form->button(__('Qo`shish'));
$form->display();
$doc->ret(__('Qaytish'), '?');
}

if(empty($_GET)){
$pages = new pages(mysql_result(mysql_query("SELECT COUNT(*) FROM `nick_z`"), 0));
$pages->this_page();

$listing = new listing();
$q = mysql_query("SELECT * FROM `nick_z` ORDER BY `id` DESC LIMIT $pages->limit");
while ($spam = mysql_fetch_assoc($q)) {
    $post = $listing->post();
    $post->title = $spam['nick_z'] ;
    $post->icon('forum.theme.0.1');
	$post->action('delete', "?delete=$spam[id]&amp;return=" . URL);
}
$listing->display(__('Ro`yhat bo`sh'));
$pages->display('?'); 
}
$doc->dost(__('Login qo`shish'), '?add');


