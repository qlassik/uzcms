<?php

include_once '../sys/inc/yadro.php';
admin::check_access();
$smiles = smiles::get_ini();
$doc = new document(5);
$doc->title = __('Widjet');

$widgets_conf = (array) ini::read(H . '/sys/dat/widgets.ini');
$widgets = array();
$wod = opendir(H . '/style/widgets');
while ($rd = readdir($wod)) {
    if ($rd {
            0} === '.')
        continue;
    if (!is_file(H . '/style/widgets/' . $rd . '/config.ini'))
        continue;

    $widgets[$rd] = new widget(H . '/style/widgets/' . $rd);
}
closedir($wod);
foreach ($widgets_conf as $widget => $show) {
    if (!isset($widgets[$widget])) {
        $widgets_conf_need_save = true; 
        unset($widgets_conf[$widget]);
    }
}
foreach ($widgets as $widget_name => $widget) {
    if (!isset($widgets_conf[$widget_name])) {
        $widgets_conf_need_save = true; 
        $widgets_conf[$widget_name] = 0;
    }
}

if (!empty($widgets_conf_need_save)) {
    if (ini::save(H . '/sys/dat/widgets.ini', $widgets_conf))
        $doc->msg(__('Malades'));
    else
        $doc->err(__('Saqlanmadi'));
    unset($widgets_conf_need_save);
}


if (isset($_GET['sortable'])) {
    $doc->clean();
    $sortable = explode(',', $_POST['sortable']);

    foreach ($sortable as $position => $key) {
  
        arraypos::setPosition($widgets_conf, $key, $position + 1);
    }

    header('Content-type: application/json');
    if (ini::save(H . '/sys/dat/widgets.ini', $widgets_conf)) {
        echo json_encode(array('result' => 1, 'description' => __('Saqlandi')));
    } else {
        echo json_encode(array('result' => 0, 'description' => __('Saqlanmadi')));
    }
    exit;
}


if (!empty($_GET['widget']) && isset($widgets_conf[$_GET['widget']]) && !empty($_GET['act'])) {
    switch ($_GET['act']) {
        case 'up':
            if (misc::array_key_move($widgets_conf, $_GET['widget'], - 1)) {
                $widgets_conf_need_save = true;
                $doc->msg(__('Widjet "%s" Tepaga ko`tarildi', $widgets[$_GET['widget']]->runame));
            }else
                $doc->err(__('Widjet "%s" Tepaga ko`tarilgan', $widgets[$_GET['widget']]->runame));
            break;

        case 'down':
            if (misc::array_key_move($widgets_conf, $_GET['widget'], 1)) {
                $widgets_conf_need_save = true;
                $doc->msg(__('Widjet "%s" Pastga tushdi', $widgets[$_GET['widget']]->runame));
            }else
                $doc->err(__('Widjet "%s" Pastga tushgan', $widgets[$_GET['widget']]->runame));
            $widgets_conf_need_save = true;
            break;

        case 'hide':
            $doc->msg(__('Widjet "%s" bekitildi', $widgets[$_GET['widget']]->runame));
            $widgets_conf[$_GET['widget']] = 0;
            $widgets_conf_need_save = true;
            break;

        case 'show':
            $doc->msg(__('Widjet "%s" Ochildi', $widgets[$_GET['widget']]->runame));
            $widgets_conf[$_GET['widget']] = 1;
            $widgets_conf_need_save = true;
            break;
    }

    if (!empty($widgets_conf_need_save)) {
        if (ini::save(H . '/sys/dat/widgets.ini', $widgets_conf))
            $doc->msg(__('Malades'));
        else
            $doc->err(__('Nimagadur saqlanmadi'));
        unset($widgets_conf_need_save);
    }
    $doc->ret('Orqaga qaytish', '?' . passgen());
    header('Refresh: 1; url=?' . passgen());
    exit;
}



$listing = new listing();

foreach ($widgets_conf as $name => $show) {
    $widget = $widgets[$name];

    $post = $listing->post();
    $post->icon('widget');
    $post->title = $widget->runame;
    $post->id = urlencode($name);




    $post2 = array();
    if ($autor = $widget->autor) {
        $post2[] = __('Aftor: %s', text::toValue($autor));
    }

    if ($version = $widget->version) {
        $post2[] = __('Wersiya: %s', text::toValue($version));
    }
    $post->content = implode("<br />\n", $post2);



    if ($show) {
        $post->action('hide', '?widget=' . urlencode($name) . '&amp;act=hide');
        $post->hightlight = true;
    } else {
        
        $post->action('show', '?widget=' . urlencode($name) . '&amp;act=show');
   }

    $post->action('up', '?widget=' . urlencode($name) . '&amp;act=up');
    $post->action('down', '?widget=' . urlencode($name) . '&amp;act=down');

    
}

$listing->sortable = '?sortable';
$listing->display(__('Widjet yo`q'));