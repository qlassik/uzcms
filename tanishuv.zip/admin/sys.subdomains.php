<?php

include_once '../sys/inc/yadro.php';
admin::check_access();
$doc = new document(groups::max());
$doc->title = __('Subdomen');

$browser_types = array('mobilni','planshet', 'androit', 'komp');

if (!$uzcms->check_domain_work)
    $uzcms->check_domain_work = passgen();

function domain_check($domain) {
    global $uzcms;
    $http = new http_client('http://' . $domain . '/?check_domain_work');
    $http->timeout = 10;
    return $uzcms->check_domain_work === $http->getContent();
}

if (isset($_POST ['save'])) {

    $subdomain_theme_redirect_old = $uzcms->subdomain_theme_redirect;
    $uzcms->subdomain_theme_redirect = (int) !empty($_POST ['subdomain_theme_redirect']);
    $uzcms->subdomain_replace_url = (int) !empty($_POST ['subdomain_replace_url']);

    $subdomain_mobilni_enable_old = $uzcms->subdomain_mobilni_enable;
    $uzcms->subdomain_mobilni_enable = (int) !empty($_POST ['subdomain_mobilni_enable']);

    $subdomain_planshet_enable_old = $uzcms->subdomain_planshet_enable;
    $uzcms->subdomain_planshet_enable = (int) !empty($_POST ['subdomain_planshet_enable']);

    $subdomain_androit_enable_old = $uzcms->subdomain_androit_enable;
    $uzcms->subdomain_androit_enable = (int) !empty($_POST ['subdomain_androit_enable']);

    $subdomain_komp_enable_old = $uzcms->subdomain_komp_enable;
    $uzcms->subdomain_komp_enable = (int) !empty($_POST ['subdomain_komp_enable']);


    $uzcms->subdomain_main = text::input_text($_POST ['subdomain_main']);    
    
    $subdomain_mobilni_old = $uzcms->subdomain_mobilni;
    $uzcms->subdomain_mobilni = text::input_text($_POST ['subdomain_mobilni']);

    $subdomain_planshet_old = $uzcms->subdomain_planshet;
    $uzcms->subdomain_planshet = text::input_text($_POST ['subdomain_planshet']);

    $subdomain_androit_old = $uzcms->subdomain_androit;
    $uzcms->subdomain_androit = text::input_text($_POST ['subdomain_androit']);

    $subdomain_komp_old = $uzcms->subdomain_komp;
    $uzcms->subdomain_komp = text::input_text($_POST ['subdomain_komp']);

    if ($uzcms->subdomain_theme_redirect && $uzcms->subdomain_theme_redirect != $subdomain_theme_redirect_old) {
        if (!$uzcms->subdomain_main) {
            $doc->err(__('Asosiy domen ko`rinmayapti'));
            $uzcms->subdomain_theme_redirect = 0;
        } elseif (!domain_check($uzcms->subdomain_main)) {
            $doc->err(__('Asosiy domen joylashmagan'));
            $uzcms->subdomain_theme_redirect = 0;
        }
    }

    if ($uzcms->subdomain_mobilni_enable && ($uzcms->subdomain_mobilni_enable != $subdomain_mobilni_enable_old || $subdomain_mobilni_old != $uzcms->subdomain_mobilni )) {
        if (!$uzcms->subdomain_mobilni) {
            $doc->err(__('mobilni wersiyaga mo`jjallangan subdomendagi komp saytda joylashmagan'));
            $uzcms->subdomain_mobilni_enable = 0;
        } elseif (!domain_check($uzcms->subdomain_mobilni . '.' . $uzcms->subdomain_main)) {
            $doc->err(__('mobilni wersiyaga subdomen shakillanmagan yoki skrib sub domenda birhilmas'));
            $uzcms->subdomain_mobilni_enable = 0;
        }
    }

    if ($uzcms->subdomain_planshet_enable && ( $uzcms->subdomain_planshet_enable != $subdomain_planshet_enable_old || $subdomain_planshet_old != $uzcms->subdomain_planshet )) {
        if (!$uzcms->subdomain_planshet) {
            $doc->err(__('planshet wersiyaga mo`jjallangan subdomendagi komp saytda joylashmagan'));
            $uzcms->subdomain_planshet_enable = 0;
        } elseif (!domain_check($uzcms->subdomain_planshet . '.' . $uzcms->subdomain_main)) {
            $doc->err(__('planshet wersiyaga subdomen shakillanmagan yoki skrib sub domenda birhilmas'));
            $uzcms->subdomain_planshet_enable = 0;
        }
    }
    if ($uzcms->subdomain_androit_enable && ($uzcms->subdomain_androit_enable != $subdomain_androit_enable_old || $subdomain_androit_old != $uzcms->subdomain_androit )) {
        if (!$uzcms->subdomain_androit) {
            $doc->err(__('androit wersiyaga mo`jjallangan subdomendagi komp saytda joylashmagan'));
            $uzcms->subdomain_androit_enable = 0;
        } elseif (!domain_check($uzcms->subdomain_androit . '.' . $uzcms->subdomain_main)) {
            $doc->err(__('androit wersiyaga subdomen shakillanmagan yoki skrib sub domenda birhilmas'));
            $uzcms->subdomain_androit_enable = 0;
        }
    }

    if ($uzcms->subdomain_komp_enable && ($uzcms->subdomain_komp_enable != $subdomain_komp_enable_old || $subdomain_komp_old != $uzcms->subdomain_komp )) {
        if (!$uzcms->subdomain_komp) {
            $doc->err(__('komp wersiyaga mo`jjallangan subdomendagi komp saytda joylashmagan'));
            $uzcms->subdomain_komp_enable = 0;
        } elseif (!domain_check($uzcms->subdomain_komp . '.' . $uzcms->subdomain_main)) {
            $doc->err(__('Komp wersiyaga subdomen shakillanmagan yoki skrib sub domenda birhilmas'));
            $uzcms->subdomain_komp_enable = 0;
        }
    }


    $uzcms->save_settings($doc);
}


$form = new form('?' . passgen());
$form->text('subdomain_main', __('Asosiy domen'), $uzcms->subdomain_main);
$form->on_of_katta('subdomain_theme_redirect', __('O`tish vaqtida bravzerdagi muommo hisoblangandagi ko`rsatiluvchi sayt'), $uzcms->subdomain_theme_redirect);
$form->on_of_katta('subdomain_replace_url', __('Sub do`menni o`chirish'), $uzcms->subdomain_replace_url);

foreach ($browser_types as $b_type) {
    $key_subdomain = 'subdomain_' . $b_type;
    $key_enable = 'subdomain_' . $b_type . '_enable';
    $form->text($key_subdomain, __('Podomen %s (*.%s)', strtoupper($b_type), $uzcms->subdomain_main), $uzcms->$key_subdomain);
    $form->on_of_katta($key_enable, __('Tema tanlangan bolsa  %s chi temada ko`rinchin', strtoupper($b_type)), $uzcms->$key_enable);
}

$form->button(__('Saqlash'), 'save');
$form->display();


?>
