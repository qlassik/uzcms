<?php
include_once '../sys/inc/yadro.php';
admin::check_access();
$doc = new document(6);
$doc->title = __('Chorni profilga korinish tayorlash');

if (isset($_GET['grs'])){
	$er = (int) $_GET['grs'];
	if ($er == '0');else{
	$uzcms->chorni_k = $er;	
	$uzcms->save_settings($doc);
	}
}
if (isset($_GET['och'])){
$id = (int) $_GET['och'];
$doc->title = __('Html title o`chirish');
if (isset($_POST['ochirilar'])){
		mysql_query("DELETE FROM `chorni` WHERE `id` = '".$id."'");
		$doc->msg(__('Html title stroyka o`chdi'));
	header('Refresh: 1; url=?');
	exit;
	}


$listing = new listing();
$q = mysql_query("SELECT * FROM `chorni` WHERE  `id` = '".$id."'  ORDER BY `id` DESC LIMIT 1");
while ($uss = mysql_fetch_assoc($q)) {
$post = $listing->post();
$post->title = '<span style="color: red;">'.__('O`chiriladigon css').' : </span>('.text::toValue($uss['cod']).')';
}
$listing->display(__('Html title codi yozilmagan'));
$form = new form('?och='.$_GET['och'].'' . passgen());
$form->button(__('O`chirish'), 'ochirilar');
$form->display();
$doc->ret(__('Adminka'), './');
$doc->ret(__('Orqaga'), '?');exit;
}


if (isset($_GET['ozgar'])){
$doc->title = __('Html title o`zgartirish');
$id = (int) $_GET['ozgar'];
if (isset($_POST['codee']) && isset($_POST['save'])){
mysql_query("UPDATE `chorni` SET `cod` = '" . my_esc($_POST['codee']) . "' WHERE `id` = '".$id."' LIMIT 1");
		$doc->msg(__('Html title o`zgardi'));
	header('Refresh: 1; url=?');
	exit;
}
$listing = new listing();
$q = mysql_query("SELECT * FROM `chorni` WHERE  `id` = '".$id."'  ORDER BY `id` DESC LIMIT 1");
while ($uss = mysql_fetch_assoc($q)) {
$post = $listing->post();
$post->title = text::toValue($uss['cod']);
$post->action('delete', '?och=' . urlencode($uss['id']) . '&amp;' . passgen());
$code = $uss['cod'];
}
$listing->display(__('Html title codi yozilmagan'));
	     


$form = new form('?ozgar='.$_GET['ozgar'].'' . passgen());
$form->textarea('codee', __('Code'), $code);
$form->button(__('Saqlash'), 'save');
$form->display();
$doc->ret(__('Adminka'), './');
$doc->ret(__('Orqaga'), '?');
exit;
}
if (isset($_GET['shu'])){
$uzcms->css = (int) $_GET['shu'];
$uzcms->save_settings($doc);
header('Refresh: 1; url=?');
exit;
}
if (isset($_POST['save'])){
if (empty($_POST['cod'])) {
            $doc->err(__('Html title cod yozilmadi'));
        }elseif (mysql_result(mysql_query("SELECT COUNT(*) FROM `chorni` WHERE `cod` = '" . my_esc($_POST['cod']) . "'"), 0)) {
        $doc->err(__('Maydonda bu qod yozilgan'));
    }else{
		
		     mysql_query("INSERT INTO `chorni` (`cod`)values('" . my_esc($_POST['cod']) . "')");
		     $doc->msg(__('Qo`shildi'));
	header('Refresh: 1; url=?');
	}

}


$pages = new pages(mysql_result(mysql_query("SELECT COUNT(*) FROM `chorni`"), 0));
$listing = new listing();
$q = mysql_query("SELECT * FROM `chorni` WHERE  `id` ORDER BY `id` DESC LIMIT ".$pages->limit);
while ($us = mysql_fetch_assoc($q)) {
$post = $listing->post();
$post->title = $us['cod'];
if  ($uzcms->chorni_k == $us['id']){
$post->action('authentication', '');
}else{
$post->action('bb.fix', '?grs=' . urlencode($us['id']) . '&amp;' . passgen());	
}
$post->action('nns', '');
$post->action('cms', '?ozgar=' . urlencode($us['id']) . '&amp;' . passgen());
$post->action('nns', '');

$post->action('delete', '?och=' . urlencode($us['id']) . '&amp;' . passgen());
}
$listing->display(__('Html title codi yozilmagan'));
$pages->this_page();
$pages->display('?');

		     


$form = new form('?' . passgen());
$form->textarea('cod', __('Code'));
$form->button(__('Saqlash'), 'save');
$form->display();
$doc->dost(__('Hamma saxifa aftomatik'), '?grs=12345');
$doc->ret(__('Adminka'), './');
?>