<?php

include_once '../sys/inc/yadro.php';
admin::check_access();
$doc = new document(6);
$doc->title = __('Ichki fayllar ko`rinishi');

if (isset($_GET['och'])){
$id = (int) $_GET['och'];

if (isset($_POST['captcha'])){
if (empty($_POST['captcha']) || empty($_POST['captcha_session']) || !captcha::check($_POST['captcha'], $_POST['captcha_session'])) {
        $doc->err(__('Raqam to`gri holatda kiritilmadi'));
    }else{
		mysql_query("DELETE FROM `ichki` WHERE `id` = '".$id."' AND `azo` = '".$uzcms->azo."'");
		$doc->msg(__('Foydalik saylar qo`shilmasi o`chirildi'));
	header('Refresh: 1; url=?');
	}

}


$form = new form('?och='.$_GET['och'].'' . passgen());
$form->captcha();
$form->button(__('Saqlash'), 'save');
$form->display();


exit;
}


if (isset($_GET['ozgar'])){
$id = (int) $_GET['ozgar'];


if (isset($_POST['captcha'])){
if (empty($_POST['captcha']) || empty($_POST['captcha_session']) || !captcha::check($_POST['captcha'], $_POST['captcha_session'])) {
        $doc->err(__('Raqam to`gri holatda kiritilmadi'));
    }else{
		mysql_query("UPDATE `ichki` SET `cod` = '" . my_esc($_POST['codee']) . "', `runame` = '" . my_esc($_POST['runamee']) . "'   WHERE `id` = '".$id."' AND `azo` = '".$uzcms->azo."' LIMIT 1");
		$doc->msg(__('Foydalik saylar qo`shilmasi o`zgartirildi'));
	header('Refresh: 1; url=?');
	}

}



$q = mysql_query("SELECT * FROM `ichki` WHERE  `id` = '".$id."' AND `sayti` = '".$uzcms->sayti."' AND `azo` = '".$uzcms->azo."' ORDER BY `id` DESC LIMIT 1");
while ($uss = mysql_fetch_assoc($q)) {

echo ''.$uss['cod'].'
<center><a href="?shu='.$uss['id'].'"> <span class="btn">'.$uss['runame'].' '.__('bosh sahifaga qo`yish').'</span></a> <a href="?och='.$uss['id'].'"><span class="btn">'.$uss['runame'].' '.__('modulni sozlash').'</span></a></center><hr />';
$code = $uss['cod'];
$runame = $uss['runame'];

}



		     


$form = new form('?ozgar='.$_GET['ozgar'].'' . passgen());
$form->textarea('codee', __('Code'), $code);
$form->text('runamee', __('Nomi'), $runame);
$form->captcha();
$form->button(__('Saqlash'), 'save');
$form->display();


exit;
}
if (isset($_GET['shu'])){
$uzcms->ichki = (int) $_GET['shu'];
$uzcms->save_settings($doc);
header('Refresh: 1; url=?');
exit;
}
if (isset($_POST['captcha'])){
if (empty($_POST['captcha']) || empty($_POST['captcha_session']) || !captcha::check($_POST['captcha'], $_POST['captcha_session'])) {
        $doc->err(__('Raqam to`gri holatda kiritilmadi'));
    }else{
		
		     mysql_query("INSERT INTO `ichki` (`runame`, `cod`, `sayti`, `maktab`, `azo`)values('" . my_esc($_POST['runame']) . "', '" . my_esc($_POST['cod']) . "', '".$uzcms->sayti."', '".$uzcms->maktab."', '".$uzcms->azo."')");
		     $doc->msg(__('Qo`shildi'));
	header('Refresh: 1; url=?');
	}

}



$pages = new pages(mysql_result(mysql_query("SELECT COUNT(*) FROM `ichki` WHERE `sayti` = '".$uzcms->sayti."' AND `azo` = '".$uzcms->azo."' "), 0));
$q = mysql_query("SELECT * FROM `ichki` WHERE  `sayti` = '".$uzcms->sayti."' AND `azo` = '".$uzcms->azo."' ORDER BY `id` DESC LIMIT ".$pages->limit);
while ($us = mysql_fetch_assoc($q)) {

echo ''.$us['cod'].'
<center><a href="?shu='.$us['id'].'"> <span class="btn">'.$us['runame'].' '.__('bosh sahifaga qo`yish').'</span></a><a href="?ozgar='.$us['id'].'"> <span class="btn">'.$us['runame'].' '.__('modulni o`gartirish').'</span></a> <a href="?och='.$us['id'].'"><span class="btn">'.$us['runame'].' '.__('modulni sozlash').'</span></a></center><hr />';
}

$pages->this_page();
$pages->display('?');

		     


$form = new form('?' . passgen());
$form->textarea('cod', __('Code'));
$form->text('runame', __('Nomi'));
$form->captcha();
$form->button(__('Saqlash'), 'save');
$form->display();



?>