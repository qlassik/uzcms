<?php

include_once '../sys/inc/yadro.php';
admin::check_access();
$doc = new document(groups::max());
$doc->title = __('SQL bazani saqlash');
if($user->id == '1'){
$tables = new tables();

if (!empty($_POST)) {
    foreach ($_POST as $table => $val) {
       
        if (!$val)
            continue;
        if (in_array($table, $tables->tables)) {
            if (function_exists('set_time_limit'))
                set_time_limit(600);

            if (!empty($_POST['create'])) {
                $tab = new table_structure();
                $tab->loadFromBase($table);
                $tab->saveToIniFile(H . '/sys/db_tables/base.create.' . $table . '.ini');
            }
            if (!empty($_POST['data'])) {
                $tables->save_data(H . '/sys/db_tables/base.data.' . $table . '.sql', $table);
            }
        }
    }

    if (!empty($_POST['create'])) {
        $doc->msg(__("Tablitsa mufaqiyatlik saqlandi"));
    }
    if (!empty($_POST['data'])) {
        $doc->msg(__("Tablitsa malumotlari olindi"));
    }

    if (@copy(H . '/sys/dat/yadro.ini', H . '/sys/db_tables/yadro.ini')) {
        $doc->msg(__("Yadro narmanlashdi"));
    }
}

$listing = new listing();
foreach ($tables->tables as $table) {
    if ($table {0} == '~') {
        continue;
    }
    $ch = $listing->checkbox();
    $ch->name = $table;
    $ch->title = $table;
    $ch->checked = true;
}

$form = new form('?' . passgen());
$form->html($listing->fetch());
$form->button(__('Tablitsa saqlansin'), 'create', false);
$form->button(__('Malumotlar to`liq ko`chirilsin'), 'data', false);
$form->display();
}

?>
