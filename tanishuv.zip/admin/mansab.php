<?php

include_once '../sys/inc/yadro.php';
admin::check_access();
$doc = new document(6);
$doc->title = __('Mansab sozlamasi');

if (isset($_GET['och'])){
$id = (int) $_GET['och'];

if (isset($_POST['captcha'])){
if (empty($_POST['captcha']) || empty($_POST['captcha_session']) || !captcha::check($_POST['captcha'], $_POST['captcha_session'])) {
        $doc->err(__('Raqam to`gri holatda kiritilmadi'));
    }else{
		mysql_query("DELETE FROM `admin_mansab` WHERE `id` = '".$id."'");
		$doc->msg(__('Mansab o`chirildi'));
	header('Refresh: 1; url=?');
	}

}


$form = new form('?och='.$_GET['och'].'' . passgen());
$form->captcha();
$form->button(__('Saqlash'), 'save');
$form->display();


exit;
}


if (isset($_GET['ozgar'])){
$id = (int) $_GET['ozgar'];


if (isset($_POST['captcha'])){
if (empty($_POST['captcha']) || empty($_POST['captcha_session']) || !captcha::check($_POST['captcha'], $_POST['captcha_session'])) {
        $doc->err(__('Raqam to`gri holatda kiritilmadi'));
    }else{
		mysql_query("UPDATE `admin_mansab` SET `nomi` = '" . my_esc($_POST['nomini']) . "'  WHERE `id` = '".$id."'  LIMIT 1");
		$doc->msg(__('Mansab o`zgartirildi'));
	header('Refresh: 1; url=?');
	}

}
$listing = new listing();
$q = mysql_query("SELECT * FROM `admin_mansab` WHERE  `id` = '".$id."' ORDER BY `id` DESC LIMIT 1");
while ($us = mysql_fetch_assoc($q)) {
$post = $listing->post();
$post->title = sm_nick(text::toOutput($us['nomi']));
$post->action('cms', '?ozgar=' . urlencode($us['id']) . '&amp;' . passgen());
$post->action('nns', '');
$post->action('delete', '?och=' . urlencode($us['id']) . '&amp;' . passgen());
$nomi = sm_nick(text::toOutput($us['nomi']));
}
$listing->display(__('Ro`yhat bo`sh'));

		     


$form = new form('?ozgar='.$_GET['ozgar'].'' . passgen());
$form->text('nomini', __('Mansab nomi (smaillar ham qo`shsangiz bo`ladi)'), $nomi);
$form->captcha();
$form->button(__('Saqlash'), 'save');
$form->display();


exit;
}
if (isset($_POST['captcha'])){
if (empty($_POST['captcha']) || empty($_POST['captcha_session']) || !captcha::check($_POST['captcha'], $_POST['captcha_session'])) {
        $doc->err(__('Raqam to`gri holatda kiritilmadi'));
    }elseif (mysql_result(mysql_query("SELECT COUNT(*) FROM `admin_mansab` WHERE `nomi` = '" . my_esc($_POST['nomi']) . "'"), 0)) {
        $doc->err(__('Maydonda bu mansab yozilgan'));
    }else{
		
		     mysql_query("INSERT INTO `admin_mansab` (`nomi`)values('" . my_esc($_POST['nomi']) . "')");
		     $doc->msg(__('Mansab qo`shildi'));
	header('Refresh: 1; url=?');
	}

}



$pages = new pages(mysql_result(mysql_query("SELECT COUNT(*) FROM `admin_mansab`"), 0));
$listing = new listing();
$q = mysql_query("SELECT * FROM `admin_mansab` WHERE  `id` ORDER BY `id` DESC LIMIT ".$pages->limit);
while ($us = mysql_fetch_assoc($q)) {
$post = $listing->post();
$post->title = sm_nick(text::toOutput($us['nomi']));
$post->action('cms', '?ozgar=' . urlencode($us['id']) . '&amp;' . passgen());
$post->action('nns', '');
$post->action('delete', '?och=' . urlencode($us['id']) . '&amp;' . passgen());
}
$listing->display(__('Ro`yhat bo`sh'));
$pages->this_page();
$pages->display('?');

		     


$form = new form('?' . passgen());
$form->text('nomi', __('Mansab nomi (smaillar ham qo`shsangiz bo`ladi)'));
$form->captcha();
$form->button(__('Saqlash'), 'save');
$form->display();



?>