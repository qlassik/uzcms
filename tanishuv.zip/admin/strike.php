<?php
include_once '../sys/inc/yadro.php';
admin::check_access();
$doc = new document(6);
$doc->title = __('Strike sozlammasi');


if(isset($_GET['cat']))
{ 
 if($_GET['cat'] == 'yuk' && isset($_GET['id'])){
	$doc->title = __('Strike yuklash'); 
	 
	  $xz = mysql_result(mysql_query("SELECT COUNT(*) FROM `strike` "), 0);
	  $xzz = $xz + 1;
	  
$avatar_file_name = $xzz . '.png';
$avatars_path = FILES . '/.strike'; 
$avatars_dir = new files($avatars_path);

 if (!isset($_SESSION['timess'] )){
	$_SESSION['timess'] = TIME - 2;
    }
   $sa = $_SESSION['timess'] ;
	if(TIME >= $sa && !empty($_FILES ['file'])) {
    if ($_FILES ['file'] ['error']) {
        $doc->err(__('Fayl yuklanmadi'));
    } elseif (!$_FILES ['file'] ['size']) {
        $doc->err(__('faylа yo`q'));
    } elseif(!preg_match("/\.(gif|png|jpg|GIF|PNG|JPG)$/", text::for_filename($_FILES ['file'] ['name']))){
        $doc->err(__('Rasim farmatda emas'));
    } elseif (!$img = @imagecreatefromjpeg($_FILES ['file'] ['tmp_name']) || !$img = @imagecreatefrompng($_FILES ['file'] ['tmp_name']) || !$img = @imagecreatefromgif($_FILES ['file'] ['tmp_name'])) {
        $doc->err(__('Sizdan iltimos rasim yuklang'));
    }else {
        if ($avatars_dir->is_file($avatar_file_name)) {
            $avatar = new files_file($avatars_path, $avatar_file_name);
            $avatar->delete(); 
        }

        if ($files_ok = $avatars_dir->filesAdd(array($_FILES ['file'] ['tmp_name'] => $avatar_file_name))) {
            $avatars_dir->group_show = 0;
            $files_ok [$_FILES ['file'] ['tmp_name']]->group_show = 0;
            $files_ok [$_FILES ['file'] ['tmp_name']]->id_user = $user->id;
            $files_ok [$_FILES ['file'] ['tmp_name']]->group_edit = max($user->group, 2);

            		

			

		$name = (int) $_GET['id'];
        $x = ''.$xzz.'.png';
		mysql_query("INSERT INTO `strike` (`id`, `user`, `dir`, `strike`) VALUES ('$x', '$user->id', '$name', 'oq' )");
		$_SESSION['timess'] = TIME + 2;
	    unset($files_ok);
		header("Location: ?cat=yuk&id=".$_GET['id']."&" . passgen()."");
      } else {
                $doc->err(__('Fayl yuklanmadi'));
        }
    }
}

echo '<center>';
$pages = new pages(mysql_result(mysql_query("SELECT COUNT(*) FROM `strike` WHERE  `strike` = 'oq' AND `dir` = '".$_GET['id']."' "), 0));
$listing = new listing();
$q = mysql_query("SELECT * FROM `strike` WHERE `strike` = 'oq' AND `dir` = '".$_GET['id']."'  ORDER BY `id` DESC LIMIT ".$pages->limit);
while ($sm = mysql_fetch_assoc($q)) {

$fotos = $listing->fotos();
$fotos->url = '?ochir='.$sm['id'].'';
$fotos->image = '/files/.strike/'.$sm['id'];

}
$listing->display(__('Ro`yhat bo`sh'));
$pages->this_page();
$pages->display('?');

echo '</center>';


$fv = new fv("?cat=yuk&id=".$_GET['id']."&" . passgen());
$fv->file('file', __('Foto').' (*.jpg  .gif .png)');
$fv->button(__('Yuklash'));
$fv->display();

 
	 
	 
	 
	 
	 
	 
$doc->ret(__('Bo`limni ochirish'), '?cat=och&id='.$_GET['id'].'');
$doc->ret(__('Bo`limni sozlash'), '?cat=oz&id='.$_GET['cat'].'');
$doc->ret(__('Qaytish'), '?');
exit;
}
	 
	 
	 
	 
if($_GET['cat'] == 'oz' && isset($_GET['id']))
{ 
$doc -> title = __('Strike papkasini spzlash ');
$qa = mysql_query("SELECT * FROM `strike_dir` WHERE `id`='".$_GET['id']."'  ORDER BY `id` DESC LIMIT 1");
while ($sma = mysql_fetch_assoc($qa)) {
$ds = $sma['name'];
$id = $sma['id'];
} 
 if (!isset($_SESSION['timess'] )){
	$_SESSION['timess'] = TIME - 2;
 }
   $sa = $_SESSION['timess'] ;
	if(TIME >= $sa && isset($_POST['save']))
	{
		if(isset($_POST['name']))
		{
		 mysql_query("UPDATE `strike_dir` SET  `name` = '".$_POST['name']."' WHERE `id` = '" . $id . "'");	
		$_SESSION['timess'] = TIME + 2;
		header("Location: ?");
		exit;
		}
	}
		
		


$listing = new listing();
$fv = new fv("?cat=oz&id=".$_GET['id']."&" . passgen());
$fv->input('name', __('Bo`lim nomi'), $ds);
$fv->button(__('O`zgartirish'), 'save', false);
$fv->display();
$doc->ret(__('Bo`limni sozlash'), '?id='.$_GET['id'].'');
$doc->ret(__('Strike yuklash'), '?cat=yuk');
$doc->ret(__('Qaytish'), '?');
exit;
}





if($_GET['cat'] == 'strke' && isset($_GET['yoo']))
{ 
mysql_query("UPDATE `strike` SET  `strike` = 'oq' WHERE `id` = '".$_GET['yoo']."' ");	
$doc->msg(__('Qo`shildi'));
header("Location: ?act=azo_kat");
$doc->ret(__('Strike yuklash'), '?cat=yuk');
$doc->ret(__('Qaytish'), '?');
exit;
}

if($_GET['cat'] == 'strke' && isset($_GET['yooo']))
{ 
mysql_query("UPDATE `strike` SET  `strike` = 'oo' WHERE `id` = '".$_GET['yooo']."' ");	
$doc->err(__('Bloqlandi'));
header("Location: ?cat=".$_GET['id']."");
$doc->ret(__('Strike yuklash'), '?cat=yuk');
$doc->ret(__('Qaytish'), '?');
exit;
}





if($_GET['cat'] == 'strke' && isset($_GET['ochir']))
{ 
$doc -> title = __('Strike papkasini o`chirish');
		$strker_path = FILES . '/.strike';
        $strker_dir = new files($strker_path);
if (!empty($_POST ['delete'])) {
        if (empty($_POST ['captcha']) || empty($_POST ['captcha_session']) || !captcha::check($_POST ['captcha'], $_POST ['captcha_session']))
            $doc->err(__('Raqam to`gri holatda kiritilmadi'));
        else {
       $nom = $_GET['ochir'];
	   $strke = new files_file($strker_path, $nom);
       $strke->delete();
        
        
	mysql_query("DELETE FROM `strike` WHERE `id` = '".$_GET['ochir']."' ");		
		$doc->err(__('O`chirildi'));
		header("Location: ?cat=".$_GET['id']."");
	exit;
	}


    }  

	$fv = new fv("?id=".$_GET['id']."&cat=strke&ochir=".$_GET['ochir']."&" . passgen());
    $fv->captcha();
    $fv->button(__('Siz bu bo`limdi o`chirasizmi'), 'delete');
    $fv->display();



$doc->ret(__('Strike yuklash'), '?cat=yuk');
$doc->ret(__('Qaytish'), '?');
exit;
}














if($_GET['cat'] == 'och' && isset($_GET['id']))
{ 
$doc -> title = __('Strike papkasini o`chirish');
		$strker_path = FILES . '/.strike';
        $strker_dir = new files($strker_path);
if (!empty($_POST ['delete'])) {
        if (empty($_POST ['captcha']) || empty($_POST ['captcha_session']) || !captcha::check($_POST ['captcha'], $_POST ['captcha_session']))
            $doc->err(__('Raqam to`gri holatda kiritilmadi'));
        else {
		$result = mysql_query("SELECT * FROM `strike` WHERE `dir`='".$_GET['id']."' ORDER BY `id`");
        $myrow = mysql_fetch_array($result);  
        do   
       {  
       $nom = $myrow["id"];
       $strke = new files_file($strke_path, $nom);
       $strke->delete();
        
        
	
	}
	while ($myrow = mysql_fetch_array($result)); 
	}
	mysql_query("DELETE FROM `strike` WHERE `dir` = '".$_GET['id']."' ");		
	mysql_query("DELETE FROM `strike_dir` WHERE `id` = '".$_GET['id']."' ");
		$_SESSION['timess'] = TIME + 2; 
		$doc->msg(__('O`chirildi'));
		header("Location: ?");
	exit;
    }  

	$fv = new fv("?cat=och&id=".$_GET['id']."&" . passgen());
    $fv->captcha();
    $fv->button(__('Siz bu bo`limdi o`chirasizmi'), 'delete');
    $fv->display();



$doc->ret(__('Bo`limni sozlash'), '?cat=oz&id='.$_GET['id'].'');
$doc->ret(__('Strike yuklash'), '?cat=yuk');
$doc->ret(__('Qaytish'), '?');
exit;
}










echo '<center>';
$pages = new pages(mysql_result(mysql_query("SELECT COUNT(*) FROM `strike` WHERE `strike` = 'oq' AND `dir`= '".$_GET['cat']."' "), 0));
$listing = new listing();
$q = mysql_query("SELECT * FROM `strike` WHERE `strike` = 'oq' AND `dir`= '".$_GET['cat']."'   ORDER BY `id`  DESC LIMIT ".$pages->limit);
while ($sm = mysql_fetch_assoc($q)) {

$fotos = $listing->fotos();
$fotos->image = '/files/.strike/'.$sm['id'];
$fotos->action('delete', '?id='.$_GET['cat'].'&cat=strke&ochir='.$sm['id'].'');	
$fotos->action('nns', '');	
$fotos->action('unlock', '?id='.$_GET['cat'].'&cat=strke&yooo='.$sm['id'].'');	
}
$listing->display(__('Ro`yhat bo`sh'));
$pages->this_page();
$pages->display('?');

echo '</center>';







$doc->ret(__('Bo`limni ochirish'), '?cat=och&id='.$_GET['cat'].'');
$doc->ret(__('Bo`limni sozlash'), '?cat=oz&id='.$_GET['cat'].'');
$doc->ret(__('Strike yuklash'), '?cat=yuk&id='.$_GET['cat'].'');
$doc->ret(__('Qaytish'), '?');
exit;
}


		
if(isset($_GET['act']) && $_GET['act'] == 'azo_kat')
{  



echo '<center>';
$pages = new pages(mysql_result(mysql_query("SELECT COUNT(*) FROM `strike` WHERE `strike` = 'oo'"), 0));
$listing = new listing();
$q = mysql_query("SELECT * FROM `strike` WHERE `strike` = 'oo'  ORDER BY `dir` DESC LIMIT ".$pages->limit);
while ($sm = mysql_fetch_assoc($q)) {

$fotos = $listing->fotos();
$fotos->image = '/files/.strike/'.$sm['id'];
$fotos->action('delete', '?cat=strke&ochir='.$sm['id'].'');	
$fotos->action('nns', '');	
$fotos->action('approve', '?cat=strke&yoo='.$sm['id'].'');	
}
$listing->display(__('Ro`yhat bo`sh'));
$pages->this_page();
$pages->display('?');

echo '</center>';	

$doc->ret(__('Bo`lim yaratish'), '?act=add_kat');
$doc->ret(__('Qaytish'), '?');
exit;
}






		
if(isset($_GET['act']) && $_GET['act'] == 'add_kat')
{  
 if (!isset($_SESSION['timess'] )){
	$_SESSION['timess'] = TIME - 2;
 }
   $sa = $_SESSION['timess'] ;
	if(TIME >= $sa && isset($_POST['save']))
	{
		$name = mysql_real_escape_string($_POST['name']);
       // $x = mysql_result(mysql_query("SELECT COUNT(*) FROM `strike_dir` "), 0);
		if(isset($_POST['name']))
		{
		mysql_query("INSERT INTO `strike_dir` (`name`) VALUES ('$name')");
		$_SESSION['timess'] = TIME + 2;
		header("Location: ?");
		exit;
		}
	}
	
$listing = new listing();
$fv = new fv("?act=add_kat&" . passgen());
$fv->input('name', __('Bo`lim nomi'));
$fv->button(__('Yuborish'), 'save', false);
$fv->display();
exit;	






}







$doc -> title = __('Smayllar papkasi');
$pages = new pages(mysql_result(mysql_query("SELECT COUNT(*) FROM `strike_dir`"), 0));
$listing = new listing();
$q = mysql_query("SELECT * FROM `strike_dir` WHERE `id`  ORDER BY `id` DESC LIMIT ".$pages->limit);
while ($sm = mysql_fetch_assoc($q)) {
$post = $listing->post();
$post->icon('authentication');
$post->url = '?cat='.$sm['id'].'';
$post->title = $sm['name'];
if (mysql_result(mysql_query("SELECT COUNT(*) FROM `strike` WHERE `dir` = '".$sm['id']."' AND `strike` = 'oo'"), 0)){
$post->time = ''.__('Azolar tashladi').': ('.mysql_result(mysql_query("SELECT COUNT(*) FROM `strike` WHERE `dir` = '".$sm['id']."' AND `strike` = 'oo'"), 0).') / '.mysql_result(mysql_query("SELECT COUNT(*) FROM `strike` WHERE `dir` = '".$sm['id']."'"), 0).'';
}else{
$post->time = ''.mysql_result(mysql_query("SELECT COUNT(*) FROM `strike` WHERE `dir` = '".$sm['id']."'"), 0).'';	
}
} 
$listing->display(__('Ro`yhat bo`sh'));
$pages->this_page();
$pages->display('?');
$doc->ret(__('Bo`lim yaratish'), '?act=add_kat');
$doc->ret(__('Azolar tashagan strikerlar'), '?act=azo_kat');