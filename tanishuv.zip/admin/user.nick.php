<?php

include_once '../sys/inc/yadro.php';
admin::check_access();
$doc = new document(4);
$doc->title = __('Nickni o`zgartirish');

if (isset($_GET['id_ank']))
    $ank = new user($_GET['id_ank']);
else
    $ank = $user;

if (!$ank->group) {
    if (isset($_GET['return']))
        header('Refresh: 1; url=' . $_GET['return']);
    else
        header('Refresh: 1; url=/');

    $doc->err(__('Malumot yo`q'));
    exit;
}

$doc->title .= ' "' . $ank->title . '"';

if ($ank->group >= $user->group) {
    if (isset($_GET['return']))
        header('Refresh: 1; url=' . $_GET['return']);
    else
        header('Refresh: 1; url=/');

    $doc->err(__('Bu holatda darajez etmaydi'));
    exit;
}

if (isset($_POST['save']) && !empty($_POST['login']) && $_POST['login'] != $ank->login) {
    $login = (string) $_POST['login'];

    if (!is_valid::nick($login))
        $doc->err(__('Qisqa nick nomi'));
    elseif ($login != my_esc($login))
        $doc->msg(__('Simmollardan tashkil topgan'));
    elseif (mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `login` = '" . my_esc($login) . "'"), 0))
        $doc->err(__('Foydalanuvchini nomi bazada bor boshqa nick tollen'));
    else {
        $uzcms->log('Foydalanuvchini', 'Nickni o`zgartirtirildi ' . $ank->login . ' на [url=/ID' . $ank->id . ']' . $login . '[/url]');

        $ank->login = $login;
        $doc->msg(__('Malades'));
    }
}

$form = new form("?id_ank=$ank->id&amp;" . passgen() . (isset($_GET['return']) ? '&amp;return=' . urlencode($_GET['return']) : null));
$form->text('login', __('Login'), $ank->login);
$form->button(__('Saqlash'), 'save');
$form->display();

$doc->ret(__('Malumotiga'), 'user.actions.php?id=' . $ank->id);
$doc->ret(__('Anketa "%s"', $ank->login), '/ID' . $ank->id);

?>
