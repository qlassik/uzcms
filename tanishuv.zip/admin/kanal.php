<?php
include_once '../sys/inc/yadro.php';
admin::check_access();
$smiles = smiles::get_ini();
$doc = new document(5);
$doc->title = __('Kanallar');

