<?php

include_once '../sys/inc/yadro.php';
admin::check_access();
$doc = new document(6);
$doc->title = __('Mansab sozlamasi');
if($user->id == '1'){
if (isset($_GET['och'])){
$id = (int) $_GET['och'];
If ($id == '1'){
	$doc->err(__('Bu id raqamdagi bo`limni o`chirib bo`lmaydi'));
	exit;
}
if (isset($_POST['captcha'])){
if (empty($_POST['captcha']) || empty($_POST['captcha_session']) || !captcha::check($_POST['captcha'], $_POST['captcha_session'])) {
        $doc->err(__('Raqam to`gri holatda kiritilmadi'));
    }else{
		mysql_query("DELETE FROM `gruppa_admin_nom` WHERE `id` = '".$id."' AND `azo` = '".$uzcms->azo."'");
		$doc->msg(__('Mansab o`chirildi'));
	header('Refresh: 1; url=?');
	}

}


$fv = new fv('?och='.$_GET['och'].'' . passgen());
$fv->captcha();
$fv->button(__('Saqlash'), 'save');
$fv->display();


exit;
}


if (isset($_GET['ozgar'])){
$id = (int) $_GET['ozgar'];
If ($id == '1'){
	$doc->err(__('Bu id raqamdagi bo`limni o`zgartirib bo`lmaydi'));
	exit;
}

if (isset($_POST['captcha'])){
if (empty($_POST['captcha']) || empty($_POST['captcha_session']) || !captcha::check($_POST['captcha'], $_POST['captcha_session'])) {
        $doc->err(__('Raqam to`gri holatda kiritilmadi'));
    }else{
		mysql_query("UPDATE `gruppa_admin_nom` SET `admin_nom` = '" . my_esc($_POST['admin_nomni']) . "', `chat` = '" . my_esc($_POST['chat']) . "', `video` = '" . my_esc($_POST['video']) . "', `mp3` = '" . my_esc($_POST['mp3']) . "', `albom` = '" . my_esc($_POST['albom']) . "', `user` = '" . my_esc($_POST['user']) . "', `sozlama` = '" . my_esc($_POST['sozlama']) . "', `igra` = '" . my_esc($_POST['igra']) . "', `adminlar` = '" . my_esc($_POST['adminlar']) . "'  WHERE `id` = '".$id."'  LIMIT 1");
		$doc->msg(__('Mansab o`zgartirildi'));
	header('Refresh: 1; url=?');
	}

}
$listing = new listing();
$q = mysql_query("SELECT * FROM `gruppa_admin_nom` WHERE  `id` = '".$id."' ORDER BY `id` DESC LIMIT 1");
while ($us = mysql_fetch_assoc($q)) {
$post = $listing->post();
$post->title = sm_nick(text::toOutput($us['admin_nom']));
$post->action('cms', '?ozgar=' . urlencode($us['id']) . '&amp;' . passgen());
$post->action('nns', '');
$post->action('delete', '?och=' . urlencode($us['id']) . '&amp;' . passgen());
$admin_nom = sm_nick(text::toOutput($us['admin_nom']));
}
$listing->display();

$fv = new fv('?ozgar='.$_GET['ozgar'].'&' . passgen());
$fv->text('admin_nomni', __('Mansab admin_nom (smaillar ham qo`shsangiz bo`ladi)'), $admin_nom);
$fv->select('chat', __('CHAT mansabi tayorlansinmi?'), array(array(1, __('Tayorlanmasin')), array(2, __('Tayorlansin'))));    
$fv->select('video', __('VIDEO mansabi tayorlansinmi?'), array(array(1, __('Tayorlanmasin')), array(2, __('Tayorlansin'))));    
$fv->select('mp3', __('MP3 mansabi tayorlansinmi?'), array(array(1, __('Tayorlanmasin')), array(2, __('Tayorlansin'))));    
$fv->select('albom', __('ALBOM mansabi tayorlansinmi?'), array(array(1, __('Tayorlanmasin')), array(2, __('Tayorlansin'))));    
$fv->select('user', __('AZOLAR mansabi tayorlansinmi?'), array(array(1, __('Tayorlanmasin')), array(2, __('Tayorlansin'))));    
$fv->select('sozlama', __('SOZLAMALAR mansabi tayorlansinmi?'), array(array(1, __('Tayorlanmasin')), array(2, __('Tayorlansin'))));    
$fv->select('igra', __('O`YINLAR mansabi tayorlansinmi?'), array(array(1, __('Tayorlanmasin')), array(2, __('Tayorlansin'))));    
$fv->select('adminlar', __('ADMINISTRAOR mansabi tayorlansinmi?'), array(array(1, __('Tayorlanmasin')), array(2, __('Tayorlansin')))); 
$fv->captcha();
$fv->button(__('Saqlash'), 'save');
$fv->display();


exit;
}
if (isset($_POST['captcha'])){
if (empty($_POST['captcha']) || empty($_POST['captcha_session']) || !captcha::check($_POST['captcha'], $_POST['captcha_session'])) {
        $doc->err(__('Raqam to`gri holatda kiritilmadi'));
    }elseif (mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_admin_nom` WHERE `admin_nom` = '" . my_esc($_POST['admin_nom']) . "'"), 0)) {
        $doc->err(__('Maydonda bu mansab yozilgan'));
    }else{
		
		     mysql_query("INSERT INTO `gruppa_admin_nom` (`admin_nom`, `chat`, `video`, `mp3`, `albom`, `user`, `sozlama`, `adminlar`)values('" . my_esc($_POST['admin_nom']) . "', '" . my_esc($_POST['chat']) . "', '" . my_esc($_POST['video']) . "', '" . my_esc($_POST['mp3']) . "', '" . my_esc($_POST['albom']) . "', '" . my_esc($_POST['user']) . "', '" . my_esc($_POST['sozlama']) . "', '" . my_esc($_POST['adminlar']) . "')");
		     $doc->msg(__('Mansab qo`shildi'));
	header('Refresh: 1; url=?');
	}

}



$pages = new pages(mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa_admin_nom`"), 0));
$listing = new listing();
$q = mysql_query("SELECT * FROM `gruppa_admin_nom` WHERE  `id` ORDER BY `id` DESC LIMIT ".$pages->limit);
while ($us = mysql_fetch_assoc($q)) {
$post = $listing->post();
$post->title = sm_nick(text::toOutput($us['admin_nom']));
$post->action('cms', '?ozgar=' . urlencode($us['id']) . '&amp;' . passgen());
$post->action('nns', '');
$post->action('delete', '?och=' . urlencode($us['id']) . '&amp;' . passgen());
}
$listing->display(__('Ro`yhat bo`sh'));
$pages->this_page();
$pages->display('?');

		     


$fv = new fv('?' . passgen());
$fv->text('admin_nom', __('Mansab nomi (smaillar ham qo`shsangiz bo`ladi)'));
$fv->select('chat', __('CHAT mansabi tayorlansinmi?'), array(array(1, __('Tayorlanmasin')), array(2, __('Tayorlansin'))));    
$fv->select('video', __('VIDEO mansabi tayorlansinmi?'), array(array(1, __('Tayorlanmasin')), array(2, __('Tayorlansin'))));    
$fv->select('mp3', __('MP3 mansabi tayorlansinmi?'), array(array(1, __('Tayorlanmasin')), array(2, __('Tayorlansin'))));    
$fv->select('albom', __('ALBOM mansabi tayorlansinmi?'), array(array(1, __('Tayorlanmasin')), array(2, __('Tayorlansin'))));    
$fv->select('user', __('AZOLAR mansabi tayorlansinmi?'), array(array(1, __('Tayorlanmasin')), array(2, __('Tayorlansin'))));    
$fv->select('sozlama', __('SOZLAMALAR mansabi tayorlansinmi?'), array(array(1, __('Tayorlanmasin')), array(2, __('Tayorlansin'))));    
$fv->select('igra', __('O`YINLAR mansabi tayorlansinmi?'), array(array(1, __('Tayorlanmasin')), array(2, __('Tayorlansin'))));    
$fv->select('adminlar', __('ADMINISTRAOR mansabi tayorlansinmi?'), array(array(1, __('Tayorlanmasin')), array(2, __('Tayorlansin')))); 
$fv->captcha();
$fv->button(__('Saqlash'), 'save');
$fv->display();


}
?>