<?php
include_once '../sys/inc/yadro.php';
admin::check_access();
$doc = new document(6);
$doc->title = __('Arizalar');

$pages = new pages(mysql_result(mysql_query("SELECT COUNT(*) FROM `mexmon`"), 0));
$listing = new listing();
$qd = mysql_query("SELECT * FROM `ariza` WHERE `is_read` = '0' ORDER BY `time` DESC LIMIT ".$pages->limit);
while ($userga = mysql_fetch_assoc($qd)) {
$ank2 = new user($userga['id_shundan']);
$ank = new user($userga['id_ozim']);
$kv = $listing->kv();
$kv->url = '?id_shundan=' . $userga['id_shundan'].'&id_ozim='.$userga['id_ozim'].'';
$kv->image = $ank->getAva($doc->img_max_width());
$kv->title = ''.$ank->nick().'  '.__('habar berdi shu').' '.$ank2->nick().' '.__('nick tekshirin').' ';
$kv->time = misc::when($ank2->last_visit);
$kv->admine = $userga['ariza'];

 }
 $listing->display(__('Ro`yhat bo`sh'));
$pages->this_page();
$pages->display('?');