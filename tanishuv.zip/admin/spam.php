<?php

include_once '../sys/inc/yadro.php';
admin::check_access();
$doc = new document(5);
$doc->title = __('Antispam');


if(isset($_GET['delete'])){
	$id_spam = (int) $_GET['delete'] ;
	
$q = mysql_query("SELECT * FROM `antispam` WHERE `id` = '$id_spam' LIMIT 1");

if (!mysql_num_rows($q)) {
    if (isset($_GET ['return']))
        header('Refresh: 1; url=' . $_GET ['return']);
    else
        header('Refresh: 1; url=./');
    $doc->err(__('Xato'));
    exit();
}

$spam = mysql_fetch_assoc($q);
mysql_query("DELETE FROM `antispam` WHERE `id` = '$spam[id]' LIMIT 1");
$doc->msg(__('O`chirildi'));

if (isset($_GET ['return']))
    header('Refresh: 1; url=' . $_GET ['return']);
else
    header('Refresh: 1; url=./?' . SID);
	exit () ;
}
if(isset($_GET['add'])){
if (isset($_POST['spam']) && isset($_POST['antispam'])) {
    $spam = text::for_name($_POST['spam']);
    $antispam = text::for_name($_POST['antispam']);


    if (!$spam || !$antispam) {
        $doc->err(__('Bunday manba yo`q'));
    } else {
        mysql_query("INSERT INTO `antispam` (`spam`, `antispam`) VALUES ('" . my_esc($spam) . "', '" . my_esc($antispam) . "')");

        $doc->msg(__('Qo`shildi'));

		$doc->ret(__('Qaytish'), '?');
if (isset($_GET ['return']))
    header('Refresh: 1; url=' . $_GET ['return']);
else
    header('Refresh: 1; url=?' . SID);
	exit () ;
        exit() ;
	}
}

$form = new form('?add&amp;' . passgen() . (isset($_GET['return']) ? '&amp;return=' . urlencode($_GET['return']) : null));
$form->text('spam', __('O`rnidagi'));
$form->text('antispam', __('O`rniga yozilsin'));
$form->button(__('Qo`shish'));
$form->display();
$doc->ret(__('Qaytish'), '?');
}

if(empty($_GET)){
$pages = new pages(mysql_result(mysql_query("SELECT COUNT(*) FROM `antispam`"), 0));
$pages->this_page();

$listing = new listing();
$q = mysql_query("SELECT * FROM `antispam` ORDER BY `id` DESC LIMIT $pages->limit");
while ($spam = mysql_fetch_assoc($q)) {
    $post = $listing->post();
    $post->title = $spam ['spam'] . ' -> ' . $spam['antispam'] ;
    $post->icon('forum.theme.0.1');
	$post->action('delete', "?delete=$spam[id]&amp;return=" . URL);
}
$listing->display(__('Ro`yhat bo`sh'));
$pages->display('?'); 
}
$doc->dost(__('So`z qo`shish'), '?add');


