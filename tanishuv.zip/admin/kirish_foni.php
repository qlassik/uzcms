<?php
include_once '../sys/inc/yadro.php';
admin::check_access();
$doc = new document(6);
$doc->title = __('Orqa fon qo`yish');

echo'<div class="ana"><select   style="font-size:16px; padding: 4px; background: #FAFAFA; "  onchange="location = this.options[this.selectedIndex].value;"><option value="gl">'.__('Kirish yani glavnidagi rasimni k`orish').'</option><option value="?kor=reg">'.__('Ro`yhatdan o`tishdagi rasimni k`orish').'</option><option value="?kor=pt">'.__('Parol tiklashdagi rasimni k`orish').'</option><option value="?kor=ig_m">'.__('O`yinlar menyusidagi rasimni k`orish').'</option><option value="?kor=mex">'.__('Mexmonlar uchun sahifadagi rasimni k`orish').'</option><option value="?kor=mp3">'.__('MP3 bolimlaridagi rasimni k`orish').'</option><option value="?kor=video">'.__('Video bolimlaridagi rasimni k`orish').'</option><option value="?kor=kitob">'.__('Kitob bo`limlaridagi rasimni k`orish').'</option><option value="?kor=kun">'.__('Yangiliklardagi rasimni k`orish').'</option><option value="?kor=xab">'.__('Xabarlargadagi rasimni k`orish').'</option><option value="?kor=chat">'.__('Chatdagi rasimni k`orish').'</option></select></div>';

if (isset($_GET['kor'])){
	echo '<center class="ana"> <img style="margin: 15px; width: 40%;"  src="/files/.fon/'.$_GET['kor'].'.png" title="voo.uz" alt="Rasim yo`q" /></center>';
	
}

if (isset($_POST['fon'])){
$avatar_file_name = ''.$_POST['fon'].'.png';
$avatars_path = FILES . '/.fon'; 
$avatars_dir = new files($avatars_path);	
}


if (!empty($_FILES ['file'])) {
    if ($_FILES ['file'] ['error']) {
        $doc->err(__('Fayl yuklanmadi'));
    } elseif (!$_FILES ['file'] ['size']) {
        $doc->err(__('faylа yo`q'));
    } elseif(!preg_match("/\.(gif|png|jpg|GIF|PNG|JPG)$/", text::for_filename($_FILES ['file'] ['name']))){
        $doc->err(__('Rasim farmatda emas'));
    } elseif (!$img = @imagecreatefromjpeg($_FILES ['file'] ['tmp_name']) || !$img = @imagecreatefrompng($_FILES ['file'] ['tmp_name']) || !$img = @imagecreatefromgif($_FILES ['file'] ['tmp_name'])) {
        $doc->err(__('Sizdan iltimos rasim yuklang'));
    }else {
        if ($avatars_dir->is_file($avatar_file_name)) {
            $avatar = new files_file($avatars_path, $avatar_file_name);
            $avatar->delete(); 
        }

        if ($files_ok = $avatars_dir->filesAdd(array($_FILES ['file'] ['tmp_name'] => $avatar_file_name))) {
            $avatars_dir->group_show = 0;
            $files_ok [$_FILES ['file'] ['tmp_name']]->group_show = 0;
            $files_ok [$_FILES ['file'] ['tmp_name']]->id_user = $user->id;
            $files_ok [$_FILES ['file'] ['tmp_name']]->group_edit = max($user->group, 2);

            unset($files_ok);
            $doc->msg(__('Saqlandi'));
			header('Refresh: 1; url=?kor='.$_POST['fon'].'&' . passgen());
        } else {
                $doc->err(__('Fayl yuklanmadi'));
        }
    }
}


if ($path = $user->getAvatar($doc->img_max_width())) {

    if (!empty($_POST ['delete'])) {
        $avatar = new files_file($avatars_path, $avatar_file_name);
        if (empty($_POST ['captcha']) || empty($_POST ['captcha_session']) || !captcha::check($_POST ['captcha'], $_POST ['captcha_session']))
            $doc->err(__('Raqam to`gri holatda kiritilmadi'));
        elseif ($avatar->delete()) {
            $doc->msg(__('Foto o`chirildi'));

            $doc->ret(__('Mening fotoim'), '?' . passgen());
            header('Refresh: 1; url=?' . passgen());
            exit;
        } else {

            $doc->err(__('Fotoni o`chirishni iloji yo`q'));
        }
    }

    echo "<img class='UZCMS_photo' src='" . $path . "' alt='".__('Mening fotoim')."' /><br />\n";

    $fv = new fv('?' . passgen());
    $fv->captcha();
    $fv->button(__('O`chirish'), 'delete');
    $fv->display();
}

$fv = new fv('?' . passgen());
$fv->file('file', __('Foto').' (*.jpg , png, gif)');
$fv->select('fon', __('Qaysi saxifaga qo`yilsin'), array(array('gl', __('Kirish yani glavniga')), array('reg', __('Ro`yhatdan o`tishga')), array('pt', __('Parol tiklashga')), array('ig_m', __('O`yinlar menyusiga')), array('mex', __('Mexmonlar uchun sahifaga')), array('mp3', __('MP3 bolimlarga')), array('video', __('Video bolimlarga')), array('kitob', __('Kitob bo`limlariga')), array('kun', __('Yangiliklarga')), array('xab', __('Xabarlarga')), array('chat', __('Chatga'))));    
$fv->button(__('Yuklash'));
$fv->display();







$doc->ret(__('Anketam'), '/xona.html');


