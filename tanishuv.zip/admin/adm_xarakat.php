<?php

include_once '../sys/inc/yadro.php';
$doc = new document(2);
$doc->title = __('Xarkatlar');

if (isset($_GET['id_user'])) {
    $id_user = 'all';
    $sql_where = ' WHERE 1 = 1';

    if ($_GET['id_user'] !== 'all') {
        $ank = new user($_GET['id_user']);
        $doc->title .= ' "' . $ank->title . '"';
        $id_user = $ank->id;
        $sql_where = " WHERE `id_user` = '$ank->id'";
    }

    if (!empty($_GET['module'])) {
        $module = (string) $_GET['module'];
        $listing = new listing();
        $pages = new pages;
        $pages->posts = mysql_result(mysql_query("SELECT COUNT(*) FROM `action_list_administrators`$sql_where AND `module` = '" . my_esc($module) . "'"), 0); // количество
        $pages->this_page(); 
        $q = mysql_query("SELECT * FROM `action_list_administrators`$sql_where AND `module` = '" . my_esc($module) . "' ORDER BY `id` DESC LIMIT $pages->limit");
        while ($action = mysql_fetch_assoc($q)) {
            $ank = new user($action['id_user']);
            $post = $listing->post();
            $post->title = $ank->nick();
            $post->time = misc::when($action['time']);
            $post->content = text::toOutput($action['description']);
        }
        $listing->display(__('Xarkatlar yo`q'));

        $pages->display('?id_user=' . $id_user . '&amp;module=' . urlencode($module) . '&amp;'); 
        $doc->ret(__('Ko`rish'), '?id_user=' . $id_user . '&amp;' . passgen());
        $doc->ret(__('Mansabdorlar'), '?' . passgen());

        exit;
    }

    $listing = new listing();

    $pages = new pages;
    $pages->posts = mysql_result(mysql_query("SELECT COUNT(DISTINCT(`module`)) FROM `action_list_administrators`$sql_where"), 0); // количество модулей
    $pages->this_page(); 
    $q = mysql_query("SELECT `module` FROM `action_list_administrators`$sql_where GROUP BY `module` LIMIT $pages->limit");
    while ($module = mysql_fetch_assoc($q)) {
        $post = $listing->post();
        $post->title = __($module['module']);
        $post->url = '?id_user=' . $id_user . '&amp;module=' . urlencode($module['module']);
    }

    $listing->display(__('Ko`rish holatda emas'));

    $pages->display('?id_user=' . $id_user); 
    $doc->ret(__('Mansabdorlar'), '?' . passgen());
    exit;
}


$listing = new listing();
$month_time = mktime(0, 0, 0, date('n'), 0);
$q = mysql_query("SELECT *, COUNT(`id`) AS `count` FROM `action_list_administrators` WHERE `time` > '$month_time' GROUP BY `id_user` ORDER BY `count` DESC");

$post = $listing->post();
$post->title = __('Hamma mansabdorlar');
$post->url = '?id_user=all';

while ($ank_q = mysql_fetch_assoc($q)) {
    $post = $listing->post();
    $ank = new user($ank_q['id_user']);
    $post->title = $ank->nick();
    $post->counter = $ank_q['count'];
    $post->url = '?id_user=' . $ank->id;
    $post->icon($ank->icon());
}
$listing->display(__('Mansabdorlar yo`q'));


?>