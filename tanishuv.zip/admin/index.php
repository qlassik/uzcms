<?php
include_once '../sys/inc/yadro.php';
admin::check_access();
$doc = new document(2);
$doc->title = __('Adminka');

echo'<div style="margin: 0;     padding: 10px;
    background: #fbfcfd;
    border: 1px solid #f1f1f1;" class="row">
            	<div class="col-xs-13">
								<div>
									<ul class="ace-thumbnails clearfix">';	

if ($user->id == '1'){									
$listing = new listing();										
$video = $listing->video();
$video->title = __('Sayt sozlovlari');
$video->url = 'sys.common.php';
$video->image = '/img/sistema.png';	

$video = $listing->video();
$video->title = __('Sistema vaqti');
$video->url = 'sys.daemons.php';
$video->image = '/img/sitema_vaqti.png';
	
$video = $listing->video();
$video->title = __('HTTPS, HTTP va razishenya');
$video->url = 'http.php';
$video->image = '/img/ssl-image.png';


$video = $listing->video();
$video->title = __('CSS sozlamasi');
$video->url = 'css.php';
$video->image = '/img/sss.png';

$video = $listing->video();
$video->title = __('Mavzuni tahrillash');
$video->url = 'editon.php';
$video->image = '/img/themess.png';

$video = $listing->video();
$video->title = __('Ro`yxatdan o`tish');
$video->url = 'mansab.php';
$video->image = '/img/ro.png';

$video = $listing->video();
$video->title = __('Gurpaga mansab');
$video->url = 'gru_mansab.php';
$video->image = '/img/workshop.png';

$video = $listing->video();
$video->title = __('Bazani saqlash');
$video->url = 'saqlash.php';
$video->image = '/img/bazaga_s.png';

$video = $listing->video();
$video->title = __('Bazaga yuklash');
$video->url = 'yuklash.php';
$video->image = '/img/bazaga_y.png';

$video = $listing->video();
$video->title = __('Bazani yangilash');
$video->url = 'yangilash.php';
$video->image = '/img/bazaga_q.png';


$video = $listing->video();
$video->title = __('Optimizatsa');
$video->url = 'optimizatsa.php';
$video->image = '/img/bazaga_o.png';

}
if ($user->group >= '5'){	
$video = $listing->video();
$video->title = __('Panel smaili');
$video->url = 'smiles.php';
$video->image = '/img/sma.png';	

$video = $listing->video();
$video->title = __('Smail sozlovi');
$video->url = 'sm.php';
$video->image = '/img/sas.png';	

$video = $listing->video();
$video->title = __('D Doss atakaga qarshi');
$video->url = 'ddoc.php';
$video->image = '/img/ddosguard_logo.png';

$video = $listing->video();
$video->title = __('Sub domen');
$video->url = 'sys.subdomains.php';
$video->image = '/img/sub_d.png';

$video = $listing->video();
$video->title = __('Ro`xatdan o`tkanga');
$video->url = 'reg_ot.php';
$video->image = '/img/register.png';

$video = $listing->video();
$video->title = __('Spam');
$video->url = 'spam.php';
$video->image = '/img/spam.png';

$video = $listing->video();
$video->title = __('Spam ban');
$video->url = 'spam_ban.php';
$video->image = '/img/stop_spam.png';

$video = $listing->video();
$video->title = __('Azolar holati');
$video->url = 'azolar.php';
$video->image = '/img/vz.png';
}
if ($user->group == '6'){
$video = $listing->video();
$video->title = __('Azo yaratish');
$video->url = 'azo_och.php';
$video->image = '/img/dauser.png';


$video = $listing->video();
$video->title = __('REG, KIRISHI foni');
$video->url = 'kirish_foni.php';
$video->image = '/img/reg.png';

$video = $listing->video();
$video->title = __('REG, KIRISHI tepasi');
$video->url = 'kirish_html.php';
$video->image = '/img/rega.png';


}
if ($user->group >= '3'){
$video = $listing->video();
$video->title = __('Kanal nazorati');
$video->url = 'kanal.php';
$video->image = '/img/kanal.png';

$video = $listing->video();
$video->title = __('Ro`yhat bo`ycha');
$video->url = 'sys.users.reg.php';
$video->image = '/img/seta.png';

$video = $listing->video();
$video->title = __('Ban list');
$video->url = 'ban.php';
$video->image = '/img/bane.png';

$video = $listing->video();
$video->title = __('Sotiladigon ID');
$video->url = 'ban_s.php';
$video->image = '/img/sot.png';

$video = $listing->video();
$video->title = __('Ban bot');
$video->url = 'ban_bot.php';
$video->image = '/img/ban_bot.png';

$video = $listing->video();
$video->title = __('Ovozli bo`t');
$video->url = 'ovoz_bot.php';
$video->image = '/img/o_bot.png';

$video = $listing->video();
$video->title = __('Oddiy bo`t');
$video->url = 'o_bot.php';
$video->image = '/img/oddiy_b.png';

$video = $listing->video();
$video->title = __('Iconca qo`yish');
$video->url = 'icon.php';
$video->image = '/img/NeoOffice_icon.png';

$video = $listing->video();
$video->title = __('Smayl yuklash');
$video->url = 'sm.php';
$video->image = '/img/smail_y.png';

$video = $listing->video();
$video->title = __('Sovg`a yuklash');
$video->url = 'sovga.php';
$video->image = '/img/padarki.gif';

$video = $listing->video();
$video->title = __('Strike yuklash');
$video->url = 'strike.php';
$video->image = '/img/strj.png';

$video = $listing->video();
$video->title = __('Fo`n yuklash');
$video->url = 'foni.php';
$video->image = '/img/fon.png';

$video = $listing->video();
$video->title = __('NICK ban');
$video->url = 'nick_sm.php';
$video->image = '/img/Nick-logo.png';

$video = $listing->video();
$video->title = __('Kundalik sozlamasi');
$video->url = 'sys.kundalik.php';
$video->image = '/img/diary.png';

$video = $listing->video();
$video->title = __('Forum sozlamasi');
$video->url = 'sys.forum.php';
$video->image = '/img/forum-icon-31.png';

$video = $listing->video();
$video->title = __('Chat sozlamasi');
$video->url = 'chat_sozlov.php';
$video->image = '/img/chatx.png';

$video = $listing->video();
$video->title = __('Uzoqdan kelganlar');
$video->url = 'referers.php';
$video->image = '/img/uzoq.png';


$video = $listing->video();
$video->title = __('Oylik hisobat');
$video->url = 'oy.php';
$video->image = '/img/uzoq_o.png';
}

$video = $listing->video();
$video->title = __('Muallif');
$video->url = 'muallif.php';
$video->image = '/img/admin_z.png';

$video = $listing->video();
$video->title = __('Serwer');
$video->url = 'serwer.php';
$video->image = '/img/backup_256.png';

$video = $listing->video();
$video->title = __('Boshqa sozlamalar');
$video->url = 'zakritga.php';
$video->image = '/img/boshqa.png';


$video = $listing->video();
$video->title = __('Online test');
$video->url = 'testt.php';
$video->image = '/img/test_o.png';


$video = $listing->video();
$video->title = __('Zakovar');
$video->url = 'zakk.php';
$video->image = '/img/zakowat.png';
$listing->display();


echo'</ul>
								</div>
							</div>
						</div>	';





?>