<?php

include_once '../sys/inc/yadro.php';
$doc = new document(5);
$doc->title = __('Kelganlar');

if (isset($_GET['id_site'])) {
    $id = (string) $_GET['id_site'];

    $q = mysql_query("SELECT * FROM `log_of_referers_sites` WHERE `id` = '$id' LIMIT 1");

    if (!mysql_num_rows($q)) {
        header('Refresh: 1; url=?');
        $doc->ret('Orqaga qaytish', '?');
        $doc->err(__('Malumot yo`q'));
        exit;
    }

    $site = mysql_fetch_assoc($q);

    $doc->title = __('Reflesh boldi "%s" ndan', $site['domain']);

    $listing = new listing();
    $pages = new pages;
    $pages->posts = mysql_result(mysql_query("SELECT COUNT(DISTINCT `full_url`) FROM `log_of_referers` WHERE `id_site` = '$id'"), 0);
    $pages->this_page(); 
    $q = mysql_query("SELECT `full_url`, COUNT(*) AS `count`, MAX(`time`) AS `time` FROM `log_of_referers` WHERE `id_site` = '$id' GROUP BY `full_url` ORDER BY `time` DESC LIMIT $pages->limit");
    while ($ref = mysql_fetch_assoc($q)) {
        $post = $listing->post();
        $post->title = misc::when($ref['time']);
        $post->content[] = $ref['full_url'];
        $post->counter = $ref['count'];
    }
    $listing->display(__('Malumot yo`q'));

    $pages->display("?id_site=$id&amp;"); 
    $doc->ret(__('Hamma o`tishlar'), '?');
    
    exit;
}

if (!$uzcms->log_of_referers)
    $doc->err(__('Malumotlar bekitilgan'));

switch (@$_GET['order']) {
    case 'count':$filter = 'count';
        $order = "`count` DESC";
        break;
    case 'domain':$filter = 'domain';
        $order = "`domain` ASC";
        break;
    default:$filter = 'time';
        $order = '`time` DESC';
        break;
}

$pages = new pages;
$pages->posts = mysql_result(mysql_query("SELECT COUNT(*) FROM `log_of_referers_sites`"), 0);
$pages->this_page();

$ord = array();
$ord[] = array("?order=time&amp;page={$pages->this_page}", __('Oxirgi'), $filter == 'time');
$ord[] = array("?order=count&amp;page={$pages->this_page}", __('Sonlari'), $filter == 'count');
$ord[] = array("?order=domain&amp;page={$pages->this_page}", __('Manzili'), $filter == 'domain');
$or = new design();
$or->assign('order', $ord);
$or->display('design.order.tpl');

$listing = new listing();

$q = mysql_query("SELECT * FROM `log_of_referers_sites` ORDER BY $order LIMIT $pages->limit");
while ($ref = mysql_fetch_assoc($q)) {
    $post = $listing->post();
    $post->title = text::toOutput($ref['domain']);
    $post->url = '?id_site=' . $ref['id'];
    $post->time = misc::when($ref['time']);
    $post->counter = $ref['count'];
}

$listing->display(__('Malumot yo`q'));

$pages->display("?order=$filter&amp;"); 

if (!$uzcms->log_of_referers) {
    $doc->act(__('Sozlash'), 'sys.daemons.php');
}

?>