<?php

include_once '../sys/inc/yadro.php';
admin::check_access();
$doc = new document(6);
$doc->title = __('Tablitsani yangilash');
if($user->id == '1'){
$tables_exists = new tables();
$table_files = (array) glob(H . '/sys/db_tables/base.create.*.ini');
$tables = array();
foreach ($table_files as $table_file) {
    preg_match('#base.create\.(.+)\.ini#ui', $table_file, $m);
    $tables[] = $m[1];
}

if (!empty($_POST)) {
    foreach ($_POST as $table => $val) {
       
        if (!$val)
            continue;
        if (in_array($table, $tables)) {
            if (function_exists('set_time_limit'))
                set_time_limit(600);

            if (!empty($_POST['load'])) {
                if (!is_file(H . '/sys/db_tables/base.create.' . $table . '.ini'))
                    continue;

                $tab = new table_structure(H . '/sys/db_tables/base.create.' . $table . '.ini');
                if (in_array($table, $tables_exists->tables)) {
                    $tab_old = new table_structure();
                    $tab_old->loadFromBase($table);
                    $sql = $tab_old->getSQLQueryChange($tab);
                }else
                    $sql = $tab->getSQLQueryCreate();

                if (mysql_query($sql)) {
                    $doc->msg(__('Bazaga "%s" yuklandi', $table));
                    $tables_exists = new tables();
                    if (in_array($table, $tables_exists->tables))
                        $doc->msg(__('Tablitsa "%s" o`zgardi', $table));
                    else
                        $doc->err(__('Tablitsa "%s" Yakullanmagan joy', $table));
                }
            }
        }
    }
}

$listing = new listing();

foreach ($tables as $table) {

    $checked = false;
    $sql = false;
    if (!in_array($table, $tables_exists->tables)) {
        $checked = true;
    } else {
        $tab_old = new table_structure();
        $tab_old->loadFromBase($table);

        $tab_new = new table_structure(H . '/sys/db_tables/base.create.' . $table . '.ini');
        if ($sql = $tab_old->getSQLQueryChange($tab_new))
            $checked = true;
    }

    $post = empty($sql) ? '' : '<pre>' . text::toOutput($sql) . '</pre>';
    if ($post) {
        $ch = $listing->checkbox();
        $ch->checked = $checked;
        $ch->name = $table;
        $ch->title = $table;
        $ch->content = $post;
    }
}

if ($listing->count()) {
    $form = new form('?' . passgen());
    $form->html($listing->fetch());
    $form->button(__('Qabul qilish'), 'load');
    $form->display();
} else {
    $listing->display(__('Holadda hamma tablitsa'));
}

}
?>
