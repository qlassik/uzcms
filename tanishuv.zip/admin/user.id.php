<?php

include_once '../sys/inc/yadro.php';
admin::check_access();
$groups = groups::load_ini();
$doc = new document(6);
$doc->title = __('Id raqamni o`zgartirish');

if (isset($_GET['id_ank']))
    $ank = new user($_GET['id_ank']);
else
    $ank = $user;

if (!$ank->group) {
    if (isset($_GET['return']))
        header('Refresh: 1; url=' . $_GET['return']);
    else
        header('Refresh: 1; url=/');

    $doc->err(__('Malumot yo`q'));
    exit;
}

$doc->title .= ' "' . $ank->title . '"';

if ($ank->group >= $user->group) {
    if (isset($_GET['return']))
        header('Refresh: 1; url=' . $_GET['return']);
    else
        header('Refresh: 1; url=/');

    $doc->err(__('Bu holatda darajez etmaydi'));
    exit;
}


$tables = ini::read(H . '/sys/dat/user.tables.ini', true);


if (isset($_POST['change'])) {
    $id_new = (int) @$_POST['id_new'];
    $id_old = $ank->id;
    if (empty($_POST['captcha']) || empty($_POST['captcha_session']) || !captcha::check($_POST['captcha'], $_POST['captcha_session'])) {
        $doc->err(__('Raqam to`gri holatda kiritilmadi'));
    } elseif ($id_new < 0) {
        $doc->err(__('Kettma ket kelmadi baza bilan id raqam'));
    } elseif ($id_new == $id_old) {
        $doc->err(__('O`zgarmadi'));
    } elseif ($id_new == 0) {
        $doc->err(__('Xolat Yakullanmagan joy'));
    } elseif (mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `id` = '$id_new'"), 0)) {
        $doc->err(__('Bu ID mavjud'));
    } else {

        foreach ($tables AS $d) {
            mysql_query("UPDATE `" . my_esc($d['table']) . "` SET `" . my_esc($d['row']) . "` = '$id_new' WHERE `" . my_esc($d['row']) . "` = '$id_old'");
        }
        mysql_query("UPDATE `users` SET `id` = '$id_new' WHERE `id` = '$id_old'");
        $uzcms->log('Foydalanuvchini', 'ID o`zgardi ' . $ank->login . ' с ' . $id_old . ' на ' . $id_new . ')');

        $doc->msg(__('Malades'));
        
        exit;
    }
}

$fv = new fv("?id_ank=$ank->id&amp;" . passgen());
$fv->text('id_new', __('Yangi ID'), $ank->id);
$fv->captcha();
$fv->button(__('Saqlash'), 'change');
$fv->display();


$doc->ret(__('Malumotiga'), 'user.actions.php?id=' . $ank->id);
$doc->ret(__('Anketa "%s"', $ank->login), '/ID' . $ank->id);

?>
