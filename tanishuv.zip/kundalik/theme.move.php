<?php

include_once '../sys/inc/yadro.php';
$doc = new document(2);
$doc->title = __('Kundalik');

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Refresh: 1; url=./');
    $doc->err(__('Bu ID bo`ycha Xotira daftar yo`q'));
    exit;
}
$id_theme = (int) $_GET['id'];
$q = mysql_query("SELECT `kundalik_themes`.* ,
        `kundalik_categories`.`name` AS `category_name` ,
        `kundalik_topics`.`name` AS `topic_name`,
        `kundalik_topics`.`group_write` AS `topic_group_write`
FROM `kundalik_themes`
LEFT JOIN `kundalik_categories` ON `kundalik_categories`.`id` = `kundalik_themes`.`id_category`
LEFT JOIN `kundalik_topics` ON `kundalik_topics`.`id` = `kundalik_themes`.`id_topic`
WHERE `kundalik_themes`.`id` = '$id_theme' AND `kundalik_themes`.`group_show` <= '$user->group' AND `kundalik_topics`.`group_show` <= '$user->group' AND `kundalik_categories`.`group_show` <= '$user->group'");
if (!mysql_num_rows($q)) {
    header('Refresh: 1; url=./');
    $doc->err(__('Xotira daftar joylashmagan'));
    exit;
}
$theme = mysql_fetch_assoc($q);

if (isset($_POST['save'])) {

    if (isset($_POST['topic'])) {
        $topic = (int) $_POST['topic'];
        $q = mysql_query("SELECT `ft`.*, `fc`.`name` AS `category_name`
                FROM `kundalik_topics` AS `ft`
                LEFT JOIN `kundalik_categories` AS `fc` ON `ft`.`id_category` = `fc`.`id`
                WHERE `ft`.`id` = '$topic' AND `ft`.`group_show` <= '$user->group' AND `ft`.`group_write` <= '$user->group'
                LIMIT 1");

        if (mysql_num_rows($q) && $topic != $theme['id_topic']) {
            $topic = mysql_fetch_assoc($q);

            $theme['id_topic_old'] = $theme['id_topic'];
            $theme['id_topic'] = $topic['id'];
            $theme['topic_name_old'] = $theme['topic_name'];
            $theme['topic_name'] = $topic['name'];


            $theme['id_category_old'] = $theme['id_category'];
            $theme['id_category'] = $topic['id_category'];
            $theme['category_name_old'] = $theme['category_name'];
            $theme['category_name'] = $topic['category_name'];

            $group_write_open = $theme['topic_group_write'];

            if ($theme['group_write'] <= $group_write_open) {
                $theme['group_write'] = $topic['group_write'];
            } else {
                $theme['group_write'] = $topic['group_write'] + 1;
            }

            mysql_query("UPDATE `kundalik_themes` SET `id_topic` = '$theme[id_topic]',
 `id_category` = '$theme[id_category]',
  `group_show` = '$topic[group_show]',
  `group_write` = '$theme[group_write]'
  WHERE `id` = '$theme[id]' LIMIT 1");
            mysql_query("UPDATE `kundalik_messages` SET `id_topic` = '$theme[id_topic]' WHERE `id_theme` = '$theme[id]'");

            $theme_dir = new files(FILES . '/.kundalik/' . $theme['id']);
            $theme_dir->setGroupShowRecurse($topic['group_show']);

            $message = __('%s переместил' . ($user->sex ? '' : 'а') . ' Xotira daftar bo`limi %s Bo`limiga %s', '[user]' . $user->id . '[/user]', '[url=/kundalik/category.php?id=' . $theme['id_category_old'] . ']' . $theme['category_name_old'] . '[/url]/[url=/kundalik/topic.php?id=' . $theme['id_topic_old'] . ']' . $theme['topic_name_old'] . '[/url]', '[url=/kundalik/category.php?id=' . $theme['id_category'] . ']' . $theme['category_name'] . '[/url]/[url=/kundalik/topic.php?id=' . $theme['id_topic'] . ']' . $theme['topic_name'] . '[/url]');
            if ($reason = text::input_text($_POST['reason'])) {
                $message .= "\n" . __('Tafsif: %s', $reason);
            }

            $uzcms->log('Kundalik', __('Ko`chirish Xotira daftar %s bo`limdan %s bo`limga %s', '[url=/theme.php?id=' . $theme['id'] . ']' . $theme['name'] . '[/url]', '[url=/kundalik/category.php?id=' . $theme['id_category_old'] . ']' . $theme['category_name_old'] . '[/url]/[url=/kundalik/topic.php?id=' . $theme['id_topic_old'] . ']' . $theme['topic_name_old'] . '[/url]', '[url=/kundalik/category.php?id=' . $theme['id_category'] . ']' . $theme['category_name'] . '[/url]/[url=/kundalik/topic.php?id=' . $theme['id_topic'] . ']' . $theme['topic_name'] . '[/url]' . ($reason ? "\nПричина: $reason" : '')));

            mysql_query("INSERT INTO `kundalik_messages` (`id_category`, `id_topic`, `id_theme`, `id_user`, `time`, `message`, `group_show`, `group_edit`)
 VALUES ('$theme[id_category]','$theme[id_topic]','$theme[id]','0','" . TIME . "','" . my_esc($message) . "','$theme[group_show]','$theme[group_edit]')");

            $doc->msg(__('Xotira daftar qabul qilindi'));
        }
    }
}

$doc->title = __('Ko`chirishiruluvchi Xotira daftar %s', $theme['name']);

$form = new form("?id=$theme[id]&amp;" . passgen());
$options = array();
$q = mysql_query("SELECT `id`,`name` FROM `kundalik_categories` WHERE `group_show` <= '$user->group' ORDER BY `position` ASC");
while ($category = mysql_fetch_assoc($q)) {
    $options[] = array($category['name'], 'groupstart' => 1);
    $q2 = mysql_query("SELECT `id`,`name` FROM `kundalik_topics` WHERE `id_category` = '$category[id]' AND `group_show` <= '$user->group' AND `group_write` <= '$user->group' ORDER BY `time_last` DESC");
    while ($topic = mysql_fetch_assoc($q2)) 
        $options[] = array($topic['id'], $topic['name'], $topic['id'] == $theme['id_topic']);    
    $options[] = array('groupend' => 1);
}
$form->select('topic', __('Bo`lim'), $options);
$form->textarea('reason', __('Saqlashni yonlash'));
$form->button(__('Saqlash'), 'save');
$form->display();

$doc->dost(__('Malumotiga'), 'theme.actions.php?id=' . $theme['id']);
$doc->dost(__('Orqaga qaytish Xotira daftarga'), 'theme.php?id=' . $theme['id']);
$doc->dost(empty($theme['topic_name']) ? __('Bo`limga') : $theme['topic_name'], 'topic.php?id=' . $theme['id_topic']);
$doc->dost(empty($theme['category_name']) ? __('Katigoryaga') : $theme['category_name'], 'category.php?id=' . $theme['id_category']);
$doc->dost(__('Kundalik'), './');
?>
