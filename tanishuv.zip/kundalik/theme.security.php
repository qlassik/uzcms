<?php

include_once '../sys/inc/yadro.php';
$groups = groups::load_ini(); 
$doc = new document();
$doc->title = __('Редактирование темы');

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Refresh: 1; url=./');
    $doc->err(__('Bu ID bo`ycha Xotira daftar yo`q'));
    exit;
}
$id_theme = (int) $_GET['id'];

$q = mysql_query("SELECT * FROM `kundalik_themes` WHERE `id` = '$id_theme' AND `group_edit` <= '$user->group'");

if (!mysql_num_rows($q)) {
    header('Refresh: 1; url=./');
    $doc->err(__('Xotira daftar joylashmagan для редактирования'));
    exit;
}

$theme = mysql_fetch_assoc($q);

if (isset($_POST['save'])) {

    $t['top'] = (int) !empty($_POST['top']);
    if ($t['top'] != $theme['top']) {
        $theme['top'] = $t['top'];
        mysql_query("UPDATE `kundalik_themes` SET `top` = '$theme[top]' WHERE `id` = '$theme[id]' LIMIT 1");
        if ($theme['top'])
            $doc->msg(__('Xotira daftar faolyatda'));
        else
            $doc->msg(__('Xotira daftar faolyatda emas'));
    }

    if (isset($_POST['group_show'])) { 
        $group_show = (int) $_POST['group_show'];
        if (isset($groups[$group_show]) && $group_show != $theme['group_show']) {
            $theme_dir = new files(FILES . '/.kundalik/' . $theme['id']);
            $theme_dir->setGroupShowRecurse($group_show); 

            $theme['group_show'] = $group_show;
            mysql_query("UPDATE `kundalik_themes` SET `group_show` = '$theme[group_show]' WHERE `id` = '$theme[id]' LIMIT 1");
            $doc->msg(__('Читать тему endi разрешено группе "%s" и выше', groups::name($group_show)));
        }
    }

    if (isset($_POST['group_write'])) { 
        $group_write = (int) $_POST['group_write'];
        if (isset($groups[$group_write]) && $group_write != $theme['group_write']) {
            if ($theme['group_show'] > $group_write)
                $doc->err(__('faqat "%s" mansabdorlar xabar qoldiradi', groups::name($group_write)));
            else {
                $theme['group_write'] = $group_write;
                mysql_query("UPDATE `kundalik_themes` SET `group_write` = '$theme[group_write]' WHERE `id` = '$theme[id]' LIMIT 1");
                $doc->msg(__('faqat  "%s" mansabdorlar xabar qoldiradi', groups::name($group_write)));
            }
        }
    }

    if (isset($_POST['group_edit'])) { 
        $group_edit = (int) $_POST['group_edit'];
        if (isset($groups[$group_edit]) && $group_edit != $theme['group_edit']) {
            if ($theme['group_write'] > $group_edit)
                $doc->err(__('faqat "%s" mansabdorlar xabar qoldiradi', groups::name($group_edit)));
            else {
                $theme['group_edit'] = $group_edit;
                mysql_query("UPDATE `kundalik_themes` SET `group_edit` = '$theme[group_edit]' WHERE `id` = '$theme[id]' LIMIT 1");
                $doc->msg(__('faqat "%s" mansabdorlar xabar qoldiradi', groups::name($group_edit)));
            }
        }
    }
    $q = mysql_query("SELECT * FROM `kundalik_themes` WHERE `id` = '$id_theme' AND `group_edit` <= '$user->group'");
    if (!mysql_num_rows($q)) {
        header('Refresh: 1; url=./');
        $doc->err(__('Xotira daftar joylashmagan'));
        exit;
    }
    $theme = mysql_fetch_assoc($q);
}

$doc->title = __(' "%s" Xotira daftar sozlash', $theme['name']);

$form = new form("?id=$theme[id]&amp;" . passgen() . (isset($_GET['return']) ? '&amp;return=' . urlencode($_GET['return']) : null));

$options = array();
foreach ($groups as $type => $value)
    $options[] = array($type, $value['name'], $type == $theme['group_show']);
$form->select('group_show', __('O`qish'), $options);


$options = array();
foreach ($groups as $type => $value) {
    if ($type < 1)       
        continue;
    $options[] = array($type, $value['name'], $type == $theme['group_write']);
}
$form->select('group_write', __('Пишут Xotira daftarga'), $options);

$options = array();
foreach ($groups as $type => $value) {
    if ($type < 2)        
        continue;
    $options[] = array($type, $value['name'], $type == $theme['group_edit']);
}
$form->select('group_edit', __('Sozlamani o`zgartirish'), $options);
$form->checkbox('top', __('Doim tepada tursin'), $theme['top']);
$form->button(__('Saqlash'), 'save');
$form->display();

$doc->dost(__('Malumotiga'), 'theme.actions.php?id=' . $theme['id']);
$doc->dost(__('Orqaga qaytish Xotira daftarga'), 'theme.php?id=' . $theme['id']);
$doc->dost(empty($theme['topic_name']) ? __('Bo`limga') : $theme['topic_name'], 'topic.php?id=' . $theme['id_topic']);
$doc->dost(empty($theme['category_name']) ? __('Katigoryaga') : $theme['category_name'], 'category.php?id=' . $theme['id_category']);
$doc->dost(__('Kundalik'), './');
?>