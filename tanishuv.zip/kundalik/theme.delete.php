<?php

include_once '../sys/inc/yadro.php';
$doc = new document(2);
$doc->title = __('O`chiriladigan Xotira daftar');

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Refresh: 1; url=./');
    $doc->err(__('Bu ID bo`ycha Xotira daftar yo`q'));
    exit;
}
$id_theme = (int)$_GET['id'];

$q = mysql_query("SELECT * FROM `kundalik_themes` WHERE `id` = '$id_theme' AND `group_edit` <= '$user->group'");

if (!mysql_num_rows($q)) {
    header('Refresh: 1; url=./');
    $doc->err(__('Xotira daftar joylashmagan'));
    exit;
}

$theme = mysql_fetch_assoc($q);

$q = mysql_query("SELECT * FROM `kundalik_topics` WHERE `id` = '$theme[id_topic]' LIMIT 1");

$topic = mysql_fetch_assoc($q);

$doc->title .= ' "' . $theme['name'] . '"';

if (isset($_POST['delete'])) {
    if (empty($_POST['captcha']) || empty($_POST['captcha_session']) || !captcha::check($_POST['captcha'], $_POST['captcha_session'])) {
        $doc->err(__('Raqamni noto`ri kiritdingiz'));
    } else {
        mysql_query("DELETE FROM `kundalik_themes` WHERE `id` = '$theme[id]' LIMIT 1");

        mysql_query("DELETE
FROM `kundalik_messages`, `kundalik_history`
USING `kundalik_messages`
LEFT JOIN `kundalik_history` ON `kundalik_history`.`id_message` = `kundalik_messages`.`id`
WHERE `kundalik_messages`.`id_theme` = '$theme[id]'");
        mysql_query("DELETE FROM `kundalik_vote` WHERE `id_theme` = '$theme[id]'");
        mysql_query("DELETE FROM `kundalik_vote_votes` WHERE `id_theme` = '$theme[id]'");
        mysql_query("DELETE FROM `kundalik_views` WHERE `id_theme` = '$theme[id]'");
        $dir = new files(FILES . '/.kundalik/' . $theme['id']);
        $dir->delete();
        unset($dir);

        header('Refresh: 1; url=topic.php?id=' . $theme['id_topic']);
        $doc->msg(__('Xotira daftar o`chirildiа'));
        $uzcms->log('Kundalik', 'O`chiriladigan темы "' . $theme['name'] . '" из раздела [url=/kundalik/topic.php?id=' . $topic['id'] . ']' . $topic['name'] . '[/url]');
        exit;
    }
}

$form = new form("?id=$theme[id]&amp;" . passgen());
$form->captcha();
$form->bbcode('* ' . __('xammasi o`chirildi.'));
$form->button(__('O`chirish'), 'delete');
$form->display();

if (isset($_GET['return']))
    $doc->dost(__('Xotira daftarga'), text::toValue($_GET['return']));
else
    $doc->dost(__('Xotira daftarga'), 'theme.php?id=' . $theme['id']);

$doc->dost(__('Bo`limga'), 'topic.php?id=' . $theme['id_topic']);
$doc->dost(__('Katigoryaga'), 'category.php?id=' . $theme['id_category']);
$doc->dost(__('Kundalik'), './');