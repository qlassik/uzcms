<?php

include_once '../sys/inc/yadro.php';
$doc = new document(2);
$doc->title = __('Kundalik');

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Refresh: 1; url=./');
    $doc->err(__('Bu ID bo`ycha Xotira daftar yo`q'));
    exit;
}
$id_theme = (int) $_GET['id'];
$q = mysql_query("SELECT `kundalik_themes`.* ,
        `kundalik_categories`.`name` AS `category_name` ,
        `kundalik_topics`.`name` AS `topic_name`,
        `kundalik_topics`.`group_write` AS `topic_group_write`
FROM `kundalik_themes`
LEFT JOIN `kundalik_categories` ON `kundalik_categories`.`id` = `kundalik_themes`.`id_category`
LEFT JOIN `kundalik_topics` ON `kundalik_topics`.`id` = `kundalik_themes`.`id_topic`
WHERE `kundalik_themes`.`id` = '$id_theme' AND `kundalik_themes`.`group_show` <= '$user->group' AND `kundalik_topics`.`group_show` <= '$user->group' AND `kundalik_categories`.`group_show` <= '$user->group'");
if (!mysql_num_rows($q)) {
    header('Refresh: 1; url=./');
    $doc->err(__('Xotira daftar joylashmagan'));
    exit;
}
$theme = mysql_fetch_assoc($q);


$doc->dost(__('Malumotiga'), 'theme.actions.php?id=' . $theme['id']);
$doc->dost(__('Orqaga qaytish Xotira daftarga'), 'theme.php?id=' . $theme['id']);
$doc->dost(empty($theme['topic_name']) ? __('Bo`limga') : $theme['topic_name'], 'topic.php?id=' . $theme['id_topic']);
$doc->dost(empty($theme['category_name']) ? __('Katigoryaga') : $theme['category_name'], 'category.php?id=' . $theme['id_category']);
$doc->dost(__('Kundalik'), './');

$group_write_open = $theme['topic_group_write'];
$group_write_close = $theme['topic_group_write'] + 1;

$is_open = $theme['group_write'] <= $group_write_open;

$doc->title = $is_open ? __('Bekitish %s', $theme['name']) : __('Ochish %s', $theme['name']);

if (!empty($_POST['open'])) {
    if ($is_open) {
        $doc->msg(__('Xotira daftar oldin ochilgan'));
    } else {
        $theme['group_write'] = $group_write_open;
        mysql_query("UPDATE `kundalik_themes` SET `group_write` = '$theme[group_write]' WHERE `id` = '$theme[id]' LIMIT 1");

        $message = __('%s открыл' . ($user->sex ? '' : 'а') . ' тему для обсуждения', '[user]' . $user->id . '[/user]');
        if ($reason = text::input_text($_POST['reason'])) {
            $message .= "\n" . __('Sabab: %s', $reason);
        }
        $uzcms->log('Kundalik', 'berkitildi [url=/theme.php?id=' . $theme['id'] . ']' . $theme['name'] . '[/url]' . ($reason ? "\nSababi: $reason" : ''));

        mysql_query("INSERT INTO `kundalik_messages` (`id_category`, `id_topic`, `id_theme`, `id_user`, `time`, `message`, `group_show`, `group_edit`)
 VALUES ('$theme[id_category]','$theme[id_topic]','$theme[id]','0','" . TIME . "','" . my_esc($message) . "','$theme[group_show]','$theme[group_edit]')");

        $doc->msg(__('Xotira daftar berkitildi'));
        exit;
    }
}


if (!empty($_POST['close'])) {
    if (!$is_open) {
        $doc->msg(__('Xotira daftar berkitilgan'));
    } else {
        $theme['group_write'] = $group_write_close;
        mysql_query("UPDATE `kundalik_themes` SET `group_write` = '$theme[group_write]' WHERE `id` = '$theme[id]' LIMIT 1");
        $message = __('%s закрыл' . ($user->sex ? '' : 'а') . ' тему для обсуждения', '[user]' . $user->id . '[/user]');
        if ($reason = text::input_text($_POST['reason'])) {
            $message .= "\n" . __('Sabab: %s', $reason);
        }
        $uzcms->log('Kundalik', 'ochish [url=/theme.php?id=' . $theme['id'] . ']' . $theme['name'] . '[/url]' . ($reason ? "\nПричина: $reason" : ''));
        mysql_query("INSERT INTO `kundalik_messages` (`id_category`, `id_topic`, `id_theme`, `id_user`, `time`, `message`, `group_show`, `group_edit`)
 VALUES ('$theme[id_category]','$theme[id_topic]','$theme[id]','0','" . TIME . "','" . my_esc($message) . "','$theme[group_show]','$theme[group_edit]')");
        $doc->msg(__('Xotira daftar berkitilgan'));
        exit;
    }
}

$form = new form("?id=$theme[id]&amp;" . passgen());
$form->textarea('reason', $is_open ? __('Sababsiz bekitish') : __('Sababsiz ochish'));
if ($is_open)
    $form->button(__('Berkitish'), 'close');
else
    $form->button(__('Ochish'), 'open');
$form->display();


?>
