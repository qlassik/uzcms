<?php

include_once '../sys/inc/yadro.php';
$doc = new document(1);
$doc->theme = __('Xabarni o`zgartirish');

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    if (isset($_GET['return']))
        header('Refresh: 1; url=' . $_GET['return']);
    else
        header('Refresh: 1; url=./');
    $doc->err(__('Bu ID bo`ycha xabar yo`q'));
    exit;
}

$id_message = (int)$_GET['id'];
$q = mysql_query("SELECT * FROM `kundalik_messages` WHERE `id` = '$id_message'");

if (!mysql_num_rows($q)) {
    if (isset($_GET['return']))
        header('Refresh: 1; url=' . $_GET['return']);
    else
        header('Refresh: 1; url=./');
    $doc->err(__('Xabar topilmadi'));

    exit;
}
$message = mysql_fetch_assoc($q);
$autor = new user((int)$message['id_user']);

$access_edit = false;
$edit_time = $message['time'] - TIME + 600;

if ($user->group > $autor->group || $user->group == groups::max())
    $access_edit = true;
elseif ($user->id == $autor->id && $edit_time > 0) {
    $access_edit = true;
    $doc->msg(__('Для изменения Xabarlar осталось %d сек', $edit_time));
}

if (!$access_edit) {
    if (isset($_GET['return']))
        header('Refresh: 1; url=' . $_GET['return']);
    else
        header('Refresh: 1; url=./');
    $doc->err(__('Xabar joylashmagan для редактирования'));
    exit;
}


$doc->title = __('Xabar от "%s" - редактирование', $autor->login);

if (isset($_GET['act']) && $_GET['act'] == 'hide') {
    if (isset($_GET['return']))
        header('Refresh: 1; url=' . $_GET['return']);
    else
        header('Refresh: 1; url=theme.php?id=' . $message['id_theme']);
    mysql_query("UPDATE `kundalik_messages` SET `group_show` = '2' WHERE `id` = '$message[id]' LIMIT 1");
    $doc->msg(__('Xabar успешно скрыто'));
    if (isset($_GET['return']))
        $doc->dost(__('Xotira daftarga'), text::toValue($_GET['return']));
    else
        $doc->dost(__('Xotira daftarga'), 'theme.php?id=' . $message['id_theme']);
    exit;
}

if (isset($_GET['act']) && $_GET['act'] == 'show') {
    if (isset($_GET['return']))
        header('Refresh: 1; url=' . $_GET['return']);
    else
        header('Refresh: 1; url=theme.php?id=' . $message['id_theme']);
    mysql_query("UPDATE `kundalik_messages` SET `group_show` = '0' WHERE `id` = '$message[id]' LIMIT 1");
    $doc->msg(__('Xabar будет отображаться'));
    if (isset($_GET['return']))
        $doc->dost('Xotira daftarga', text::toValue($_GET['return']));
    else
        $doc->dost(__('Xotira daftarga'), 'theme.php?id=' . $message['id_theme']);
    exit;
}

if (isset($_POST['message'])) {
    $message_new = text::input_text($_POST['message']);

    if ($message_new == $message['message']) {
        $doc->err(__('Изменения не обнаружены'));
    } elseif ($uzcms->censure && $mat = is_valid::mat($message_new)) {
        $doc->err(__('ZIT: %', $mat));
    } elseif ($message_new) {
        if (isset($_GET['return']))
            header('Refresh: 1; url=' . $_GET['return']);
        else
            header('Refresh: 1; url=theme.php?id=' . $message['id_theme']);

        mysql_query("INSERT INTO `kundalik_history` (`id_message`, `id_user`, `time`, `message`) VALUES ('$message[id]', '" . ($message['edit_id_user'] ? $message['edit_id_user'] : $message['id_user']) . "', '" . ($message['edit_time'] ? $message['edit_time'] : $message['time']) . "', '" . my_esc($message['message']) . "')");
        mysql_query("UPDATE `kundalik_messages` SET `message` = '" . my_esc($message_new) . "', `edit_count` = `edit_count` + 1, `edit_id_user` = '$user->id', `edit_time` = '" . TIME . "' WHERE `id` = '$message[id]' LIMIT 1");
        $doc->msg(__('Xabar yuklatildi'));

        if (isset($_GET['return']))
            $doc->dost('Xotira daftarga', text::toValue($_GET['return']));
        else
            $doc->dost(__('Xotira daftarga'), 'theme.php?id=' . $message['id_theme']);
        exit;
    } else {
        $doc->err(__('Нельзя оставить yo`qе Xabar'));
    }
}

$form = new form("?id=$message[id]&amp;" . passgen() . (isset($_GET['return']) ? '&amp;return=' . urlencode($_GET['return']) : null));
$form->textarea('message', __('Редактирование Xabarlar'), $message['message']);
$form->button(__('Saqlash'));
$form->display();

$doc->grp(__('Вложения'), 'message.files.php?id=' . $message['id'] . (isset($_GET['return']) ? '&amp;return=' . urlencode($_GET['return']) : null));

if (isset($_GET['return']))
    $doc->dost(__('Xotira daftarga'), text::toValue($_GET['return']));
else
    $doc->dost(__('Xotira daftarga'), 'theme.php?id=' . $message['id_theme']);