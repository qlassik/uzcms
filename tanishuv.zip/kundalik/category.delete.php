<?php

include_once '../sys/inc/yadro.php';
$doc = new document();

$doc->title = __('O`chiriladigan bo`lim');

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Refresh: 1; url=./');
    $doc->err(__('Bu ID bo`ycha bo`lim'));
    $doc->dost(__('Kundalik'), './');
    exit;
}
$id_category = (int) $_GET['id'];

$q = mysql_query("SELECT * FROM `kundalik_categories` WHERE `id` = '$id_category' AND `group_edit` <= '$user->group'");

if (!mysql_num_rows($q)) {
    header('Refresh: 1; url=./');
    $doc->err(__('Bo`lim joylashmagan'));
    $doc->dost(__('Kundalik'), './');
    exit;
}

$category = mysql_fetch_assoc($q);
$doc->title = __('O`chiriladigan bo`lim "%s"', $category['name']);

if (isset($_POST['delete'])) {
    if (empty($_POST['captcha']) || empty($_POST['captcha_session']) || !captcha::check($_POST['captcha'], $_POST['captcha_session'])) {
        $doc->err(__('Raqamni noto`ri kiritdingiz'));
    } else {
     
        $q = mysql_query("SELECT `id` FROM `kundalik_themes` WHERE `id_category` = '$category[id]'");
        while ($theme = mysql_fetch_assoc($q)) {
            $dir = new files(FILES . '/.kundalik/' . $theme['id']);
            $dir->delete();
            unset($dir);
        }

        mysql_query("DELETE
FROM `kundalik_topics`, `kundalik_themes` , `kundalik_messages`, `kundalik_history`, `kundalik_files`, `kundalik_vote`, `kundalik_vote_votes`
USING `kundalik_topics`
LEFT JOIN `kundalik_themes` ON `kundalik_themes`.`id_topic` = `kundalik_topics`.`id`
LEFT JOIN `kundalik_messages` ON `kundalik_messages`.`id_topic` = `kundalik_topics`.`id`
LEFT JOIN `kundalik_history` ON `kundalik_history`.`id_message` = `kundalik_messages`.`id`
LEFT JOIN `kundalik_files` ON `kundalik_files`.`id_topic` = `kundalik_topics`.`id`
LEFT JOIN `kundalik_vote` ON `kundalik_vote`.`id_theme` = `kundalik_themes`.`id`
LEFT JOIN `kundalik_vote_votes` ON `kundalik_vote_votes`.`id_theme` = `kundalik_themes`.`id`
LEFT JOIN `kundalik_views` ON `kundalik_vote_votes`.`id_theme` = `kundalik_themes`.`id`
WHERE `kundalik_topics`.`id_category` = '$category[id]'");

        mysql_query("DELETE FROM `kundalik_categories` WHERE `id` = '$category[id]' LIMIT 1");
     
        header('Refresh: 1; url=./');
        $uzcms->log('Kundalik', 'O`chiriladigan bo`lim "' . $category['name'] . '"');
        $doc->msg(__('Bo`lim o`chirildiа'));
        $doc->dost(__('Kundalik'), './');
        exit;
    }
}

$form = new form("?id=$category[id]&amp;" . passgen() . (isset($_GET['return']) ? '&amp;return=' . urlencode($_GET['return']) : null));
$form->captcha();
$form->button(__('O`chirish'), 'delete');
$form->display();

$doc->grp(__('Sozlama Bo`lim'), 'category.edit.php?id=' . $category['id']);
$doc->dost(__('Katigoryaga'), 'category.php?id=' . $category['id']);
$doc->dost(__('Kundalik'), './');
?>