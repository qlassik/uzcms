<?php

include_once '../sys/inc/yadro.php';
$doc = new document();
$doc->title = __('Xabarlar ro`yxati');
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Refresh: 1; url=./');
    $doc->err(__('Bu ID bo`ycha xabar yo`q'));
    exit;
}
$id_theme = (int)$_GET['id'];

$q = mysql_query("SELECT * FROM `kundalik_messages` WHERE `id` = '$id_theme' AND `group_show` <= '$user->group'");

if (!mysql_num_rows($q)) {
    header('Refresh: 1; url=./');
    $doc->err(__('Xabar joylashmagan'));
    exit;
}

$message = mysql_fetch_assoc($q);
$ank2 = new user($message['id_user']);
if ($message['id_user'] != $user->id && $ank2->group >= $user->group) {
    header('Refresh: 1; url=./');
    $doc->err(__('Darajez etmaydi'));
    exit;
}
$listing = new listing();
$pages = new pages;
$pages->posts = mysql_result(mysql_query("SELECT COUNT(*) FROM `kundalik_history` WHERE `id_message` = '$message[id]'"), 0); // количество сообщений  теме

$ank = new user($message['id_user']);

$post = $listing->post();
$post->title = $ank->nick();
$post->icon($ank->icon());
$post->content = text::toOutput($message['message']);
$post->time = misc::when($message['edit_time'] ? $message['edit_time'] : $message['time']);
$post->bottom = __('Текущая Wersiya');

if ($message['edit_id_user']) {
    $post->bottom .= text::toOutput(' ([user]' . $message['edit_id_user'] . '[/user])');
}

$q = mysql_query("SELECT * FROM `kundalik_history` WHERE `id_message` = '$message[id]' ORDER BY `id` DESC LIMIT " . $pages->limit);

while ($messages = mysql_fetch_assoc($q)) {
    $post = $listing->post();
    $ank = new user($message['id_user']);
    $post->title = $ank->nick();
    $post->icon($ank->icon());
    $post->content[] = $messages['message'];
    $post->time = misc::when($messages['time']);

    if ($message['id_user'] != $messages['id_user']) {
        $post->bottom = text::toOutput('[user]' . $messages['id_user'] . '[/user]');
    }
}
$listing->display(__('Xabarlar yo`q'));

$pages->display('?id=' . $message['id'] . '&amp;' . (isset($_GET['return']) ? 'return=' . urlencode($_GET['return']) . '&amp;' : null)); // вывод страниц

if (isset($_GET['return']))
    $doc->dost(__('Xotira daftarga'), text::toValue($_GET['return']));
else
    $doc->dost(__('Xotira daftarga'), 'theme.php?id=' . $message['id_theme']);