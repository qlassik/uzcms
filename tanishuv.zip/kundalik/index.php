<?php

include_once '../sys/inc/yadro.php';
$doc = new document();
$doc->title = __('Kundalik - Bo`lim');

$listing = new listing();

$post = $listing->post();
$post->url = 'search.php';
$post->title = __('Izlash');
$post->icon('Kundalik.search');

if (false === ($new_themes = cache_counters::get('Kundalik.new_themes.' . $user->group))) {
    $new_themes = mysql_result(mysql_query("SELECT COUNT(*)
FROM `kundalik_themes` AS `th`
LEFT JOIN `kundalik_topics` AS `tp` ON `tp`.`id` = `th`.`id_topic`
LEFT JOIN `kundalik_categories` AS `cat` ON `cat`.`id` = `th`.`id_category`
WHERE `th`.`group_show` <= '{$user->group}'
AND `tp`.`group_show` <= '{$user->group}'
AND `cat`.`group_show` <= '{$user->group}'
AND `th`.`time_create` > '" . NEW_TIME . "'"), 0);
    cache_counters::set('Kundalik.new_themes.' . $user->group, $new_themes, 20);
}

$post = $listing->post();
$post->url = 'last.themes.php';
$post->title = __('Yangi Xotira daftar');
if ($new_themes) {
    $post->counter = '+' . $new_themes;
}
$post->icon('Kundalik.lt');

if (false === ($new_posts = cache_counters::get('Kundalik.new_posts.' . $user->group))) {
    $new_posts = mysql_result(mysql_query("SELECT COUNT(DISTINCT(`msg`.`id_theme`))
FROM `kundalik_messages` AS `msg`
LEFT JOIN `kundalik_themes` AS `th` ON `th`.`id` = `msg`.`id_theme`
LEFT JOIN `kundalik_topics` AS `tp` ON `tp`.`id` = `th`.`id_topic`
LEFT JOIN `kundalik_categories` AS `cat` ON `cat`.`id` = `th`.`id_category`
WHERE `th`.`group_show` <= '{$user->group}'
AND `tp`.`group_show` <= '{$user->group}'
AND `cat`.`group_show` <= '{$user->group}'
AND `msg`.`group_show` <= '{$user->group}'
AND `msg`.`time` > '" . NEW_TIME . "'"), 0);
    cache_counters::set('Kundalik.new_posts.' . $user->group, $new_posts, 20);
}

$post = $listing->post();
$post->url = 'last.posts.php';
$post->title = __('Xotira daftarlar holati');
if ($new_posts) {
    $post->counter = '+' . $new_posts;
}
$post->icon('Kundalik.lp');


if ($user->id) {
    if (false === ($my_themes = cache_counters::get('Kundalik.my_themes.' . $user->id))) {
        $my_themes = mysql_result(mysql_query("SELECT COUNT(DISTINCT(`msg`.`id_theme`))
FROM `kundalik_messages` AS `msg`
LEFT JOIN `kundalik_themes` AS `th` ON `th`.`id` = `msg`.`id_theme`
LEFT JOIN `kundalik_topics` AS `tp` ON `tp`.`id` = `th`.`id_topic`
LEFT JOIN `kundalik_categories` AS `cat` ON `cat`.`id` = `th`.`id_category`
WHERE `th`.`id_autor` = '{$user->id}'
AND `th`.`group_show` <= '{$user->group}'
AND `tp`.`group_show` <= '{$user->group}'
AND `cat`.`group_show` <= '{$user->group}'
AND `msg`.`group_show` <= '{$user->group}'
AND `msg`.`id_user` <> '{$user->id}'
AND `msg`.`time` > '" . NEW_TIME . "'"), 0);

        cache_counters::set('Kundalik.my_themes.' . $user->id, $my_themes, 20);
    }


    $post = $listing->post();
    $post->url = 'my.themes.php';
    $post->title = __('Mening Xotira daftaryim');
    if ($my_themes) {
        $post->counter = '+' . $my_themes;
    }
    $post->icon('Kundalik.my_themes');
}

$pages = new pages();
$pages->posts = mysql_result(mysql_query("SELECT COUNT(*) FROM `kundalik_categories` WHERE `group_show` <= '$user->group'"), 0); 

$q = mysql_query("SELECT * FROM `kundalik_categories` WHERE `group_show` <= '$user->group' ORDER BY `position` ASC LIMIT " . $pages->limit);
while ($category = mysql_fetch_assoc($q)) {
    $post = $listing->post();
    $post->url = "category.php?id=$category[id]";
    $post->title = text::toValue($category['name']);
    $post->icon('Kundalik.category');
    $post->post = text::for_opis($category['description']);
}

$listing->display(__('Bu katigoryaga darajangiz etmaydi'));


$pages->display('?'); 

if ($user->group >= 5) {
    $doc->dost(__('Bo`lim yaratish'), 'category.new.php');
    $doc->dost(__('Ketma ketligi bilan joylash'), 'categories.sort.php');
}