<?php

include_once '../sys/inc/yadro.php';
$doc = new document(2);
$doc->title = __('Kundalik');

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Refresh: 1; url=./');
    $doc->err(__('Bu ID bo`ycha Xotira daftar yo`q'));
    exit;
}
$id_theme = (int) $_GET['id'];
$q = mysql_query("SELECT `kundalik_themes`.* , `kundalik_categories`.`name` AS `category_name` , `kundalik_topics`.`name` AS `topic_name`
FROM `kundalik_themes`
LEFT JOIN `kundalik_categories` ON `kundalik_categories`.`id` = `kundalik_themes`.`id_category`
LEFT JOIN `kundalik_topics` ON `kundalik_topics`.`id` = `kundalik_themes`.`id_topic`
WHERE `kundalik_themes`.`id` = '$id_theme' AND `kundalik_themes`.`group_show` <= '$user->group' AND `kundalik_topics`.`group_show` <= '$user->group' AND `kundalik_categories`.`group_show` <= '$user->group'");
if (!mysql_num_rows($q)) {
    header('Refresh: 1; url=./');
    $doc->err(__('Xotira daftar joylashmagan'));
    exit;
}
$theme = mysql_fetch_assoc($q);

if (isset($_POST['save'])) {
    if (isset($_POST['name'])) {
        $name = text::for_name($_POST['name']);
        if ($name && $name != $theme['name']) {
            $uzcms->log('Kundalik', 'Изменение названия темы ' . $theme['name'] . ' на [url=/kundalik/theme.php?id=' . $theme['id'] . ']' . $name . '[/url]');

            $theme['name'] = $name;
            mysql_query("UPDATE `kundalik_themes` SET `name` = '" . my_esc($theme['name']) . "' WHERE `id` = '$theme[id]' LIMIT 1");
            $doc->msg(__('Nomi темы yuklatildi'));
        }
    }
}
$doc->title = __('Joyni o`zgartirish %s', $theme['name']);

$form = new form("?id=$theme[id]&amp;" . passgen());
$form->text('name', __('Nomi'), $theme['name']);
$form->button(__('Saqlash'), 'save');
$form->display();

$doc->dost(__('Malumotiga'), 'theme.actions.php?id=' . $theme['id']);
$doc->dost(__('Orqaga qaytish Xotira daftarga'), 'theme.php?id=' . $theme['id']);
$doc->dost(empty($theme['topic_name']) ? __('Bo`limga') : $theme['topic_name'], 'topic.php?id=' . $theme['id_topic']);
$doc->dost(empty($theme['category_name']) ? __('Katigoryaga') : $theme['category_name'], 'category.php?id=' . $theme['id_category']);
$doc->dost(__('Kundalik'), './');
?>
