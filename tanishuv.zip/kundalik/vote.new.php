<?php

include_once '../sys/inc/yadro.php';
$doc = new document();
$doc->title = __('Kundalik: ovozi');

if (!isset($_GET['id_theme']) || !is_numeric($_GET['id_theme'])) {
    if (isset($_GET['return']))
        header('Refresh: 1; url=' . $_GET['return']);
    else
        header('Refresh: 1; url=./');
    $doc->err(__('Bu ID bo`ycha Xotira daftar yo`q'));
    exit;
}
$id_theme = (int)$_GET['id_theme'];

$q = mysql_query("SELECT * FROM `kundalik_themes` WHERE `id` = '$id_theme' AND `group_edit` <= '$user->group'");

if (!mysql_num_rows($q)) {
    if (isset($_GET['return']))
        header('Refresh: 1; url=' . $_GET['return']);
    else
        header('Refresh: 1; url=theme.php?id=' . $theme['id']);
    $doc->err(__('Xotira daftar joylashmagan'));
    exit;
}

$theme = mysql_fetch_assoc($q);

if (!empty($theme['id_vote'])) {
    if (isset($_GET['return']))
        header('Refresh: 1; url=' . $_GET['return']);
    else
        header('Refresh: 1; url=theme.php?id=' . $theme['id']);
    $doc->err(__('Ovoz yaratilgan'));
    exit;
}

if (!empty($_POST['vote'])) {
    $vote = text::input_text($_POST['vote']);
    if (!$vote)
        $doc->err(__('Yakullanmagan joy yani javob yozilmagan'));

    else {
        $v = array();
        $k = array();
        foreach ($_POST as $key => $value) {
            $vv = text::input_text($value);
            if ($vv && preg_match('#^v([0-9]+)$#', $key)) {
                $v[] = "'" . my_esc($vv) . "'";
                $k[] = '`v' . count($v) . '`';
            }
        }

        if (count($v) < 2)
            $doc->err(__('Eng kami 2 ta ovoz qo`yilishi kerak'));
        else {
            mysql_query("INSERT INTO `kundalik_vote` (`id_autor`, `id_theme`, `name`, " . implode(', ', $k) . ")
VALUES ('$user->id', '$theme[id]', '$vote', " . implode(', ', $v) . ")");

            if (!$id_vote = mysql_insert_id())
                $doc->err(__('Ovoz qo`yilishida xato'));
            else {
                if (isset($_GET['return']))
                    header('Refresh: 1; url=' . $_GET['return']);
                else
                    header('Refresh: 1; url=theme.php?id=' . $theme['id']);
                mysql_query("UPDATE `kundalik_themes` SET `id_vote` = '$id_vote' WHERE `id` = '$theme[id]' LIMIT 1");
                $doc->msg('Голосование yaratildiо');

                $uzcms->log('Kundalik', 'Ovoz qo`yildi [url=/kundalik/theme.php?id=' . $theme['id'] . ']' . $theme['name'] . '[/url]');

                if (isset($_GET['return']))
                    $doc->dost(__('Xotira daftarga'), text::toValue($_GET['return']));
                else
                    $doc->dost(__('Xotira daftarga'), 'theme.php?id=' . $theme['id']);
                exit;
            }
        }
    }
}

$form = new form("?id_theme=$theme[id]&amp;" . passgen() . (isset($_GET['return']) ? '&amp;return=' . urlencode($_GET['return']) : null));
$form->textarea('vote', __('Savol'));
for ($i = 1; $i <= 10; $i++)
    $form->text("v$i", __('Ответ №') . $i);
$form->button(__('Ovoz qo`yish'));
$form->display();

if (isset($_GET['return']))
    $doc->dost(__('Xotira daftarga'), text::toValue($_GET['return']));
else
    $doc->dost(__('Xotira daftarga'), 'theme.php?id=' . $theme['id']);