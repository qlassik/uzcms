<?php

include_once '../sys/inc/yadro.php';
$doc = new document();

$doc->title = __('Kundalik');
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Refresh: 1; url=./');
    $doc->err(__('Bu ID bo`ycha bo`lim'));

    exit;
}
$id_top = (int) $_GET['id'];

$q = mysql_query("SELECT `kundalik_topics`.*, `kundalik_categories`.`name` AS `category_name` FROM `kundalik_topics`
LEFT JOIN `kundalik_categories` ON `kundalik_categories`.`id` = `kundalik_topics`.`id_category`
WHERE `kundalik_topics`.`id` = '$id_top' AND `kundalik_topics`.`group_show` <= '$user->group' AND `kundalik_categories`.`group_show` <= '$user->group'");

if (!mysql_num_rows($q)) {
    header('Refresh: 1; url=./');
    $doc->err(__('Bo`lim joylashmagan'));

    exit;
}

$topic = mysql_fetch_assoc($q);


$doc->title .= ' - ' . $topic['name'];

$posts = array();
$pages = new pages;
$pages->posts = mysql_result(mysql_query("SELECT COUNT(*) FROM `kundalik_themes` WHERE `id_topic` = '$topic[id]' AND `group_show` <= '$user->group'"), 0); // количество категорий Kundalikа

$q = mysql_query("SELECT `kundalik_themes`.* ,
        COUNT(`kundalik_messages`.`id`) AS `count`,
        (SELECT COUNT(`fv`.`id_user`) FROM `kundalik_views` AS `fv` WHERE `fv`.`id_theme` = `kundalik_themes`.`id`)  AS `views`
        FROM `kundalik_themes`
LEFT JOIN `kundalik_messages` ON `kundalik_messages`.`id_theme` = `kundalik_themes`.`id`

 WHERE `kundalik_themes`.`id_topic` = '$topic[id]' AND `kundalik_themes`.`group_show` <= '$user->group' AND `kundalik_messages`.`group_show` <= '$user->group'
 GROUP BY `kundalik_themes`.`id`
 ORDER BY `kundalik_themes`.`top`, `kundalik_themes`.`time_last` DESC LIMIT ".$pages->limit);

$listing = new listing();

while ($themes = mysql_fetch_assoc($q)) {
    $post = $listing->post();

    $is_open = (int) ($themes['group_write'] <= $topic['group_write']);

    $post->icon("Kundalik.theme.{$themes['top']}.$is_open");
    $post->title = text::toValue($themes['name']);
    $post->url = 'theme.php?id=' . $themes['id'];
    $post->counter = $themes['count'];
    $post->time = misc::when($themes['time_last']);


    $autor = new user($themes['id_autor']);
    $last_msg = new user($themes['id_last']);

    $post->content = ($autor->id != $last_msg->id ? $autor->nick . '/' . $last_msg->nick : $autor->nick) . '<br />';
    $post->content .= __('Просмотров: %s', $themes['views']);
}


$listing->display(__('Sizni Xotira daftaryingiz ko`rsatkichlari'));

$pages->display('topic.php?id=' . $topic['id'] . '&amp;'); 

if ($topic['group_write'] <= $user->group) {
    $doc->grp(__('Yangi Xotira daftar ochish'), 'theme.new.php?id_topic=' . $topic['id'] . "&amp;return=" . URL);
}

if ($topic['group_edit'] <= $user->group) {
    $doc->grp(__('Sozlama bo`lim'), 'topic.edit.php?id=' . $topic['id'] . "&amp;return=" . URL);
}

$doc->dost($topic['category_name'], 'category.php?id=' . $topic['id_category']);
$doc->dost(__('Kundalik'), './');