<?php

include_once '../sys/inc/yadro.php';
$groups = groups::load_ini(); 
$doc = new document ();
$doc->title = __('O`zgariladigon bo`lim');

if (!isset($_GET ['id']) || !is_numeric($_GET ['id'])) {
    header('Refresh: 1; url=./');
    $doc->err(__('Bu ID bo`ycha bo`lim yo`q'));
    exit();
}
$id_topic = (int) $_GET ['id'];

$q = mysql_query("SELECT * FROM `kundalik_topics` WHERE `id` = '$id_topic' AND `group_edit` <= '$user->group'");

if (!mysql_num_rows($q)) {
    header('Refresh: 1; url=./');
    $doc->err(__('Bo`lim joylashmagan'));
    exit;
}

$topic = mysql_fetch_assoc($q);

if (isset($_POST ['save'])) {
    if (isset($_POST ['name'])) {
        $name = text::for_name($_POST ['name']);
        $description = text::input_text($_POST ['description']);

        if ($name && $name != $topic ['name']) {
            $uzcms->log('Kundalik', 'O`chiriladigan bo`lim "' . $topic ['name'] . '" на [url=/kundalik/topic.php?id=' . $topic ['id'] . ']"' . $name . '"[/url]');
            $topic ['name'] = $name;
            mysql_query("UPDATE `kundalik_topics` SET `name` = '" . my_esc($topic ['name']) . "' WHERE `id` = '$topic[id]' LIMIT 1");
            $doc->msg(__('Nom bo`limga yuklatildi'));
        }
    }

    if ($description != $topic ['description']) {
        $uzcms->log('Kundalik', 'o`zgartirish  bo`lim tafsifi [url=/kundalik/topic.php?id=' . $topic ['id'] . ']"' . $topic ['name'] . '"[/url]');
        $topic ['description'] = $description;
        mysql_query("UPDATE `kundalik_topics` SET `description` = '" . my_esc($topic ['description']) . "' WHERE `id` = '$topic[id]' LIMIT 1");
        $doc->msg(__('Tafsif bo`lim yuklatildi'));
    }

    if (isset($_POST ['category'])) {
        $category = (int) $_POST ['category'];
        $q = mysql_query("SELECT * FROM `kundalik_categories` WHERE `id` = '$category' AND `group_show` <= '$user->group' AND `group_write` <= '$user->group'");

        if (mysql_num_rows($q) && $category != $topic ['id_category']) {
            $category = mysql_fetch_assoc($q);
            $topic ['id_category'] = $category ['id'];
            $uzcms->log('Kundalik', 'Ko`chirish bo`lim [url=/kundalik/topic.php?id=' . $topic ['id'] . ']' . $topic ['name'] . '[/url] Katigoryaga [url=/kundalik/category.php?id=' . $category ['id'] . ']' . $category ['name'] . '[/url]');
            mysql_query("UPDATE `kundalik_topics` SET `id_category` = '$topic[id_category]' WHERE `id` = '$topic[id]' LIMIT 1");
            mysql_query("UPDATE `kundalik_themes` SET `id_category` = '$topic[id_category]' WHERE `id_topic` = '$topic[id]'");
            mysql_query("UPDATE `kundalik_messages` SET `id_category` = '$topic[id_category]' WHERE `id_topic` = '$topic[id]'");
            $doc->msg(__('Раздел успешно перемещен'));
        }
    }

    if (isset($_POST ['group_show'])) { // просмотр
        $group_show = (int) $_POST ['group_show'];
        if (isset($groups [$group_show]) && $group_show != $topic ['group_show']) {
            $topic ['group_show'] = $group_show;
            mysql_query("UPDATE `kundalik_topics` SET `group_show` = '$topic[group_show]' WHERE `id` = '$topic[id]' LIMIT 1");
            $doc->msg(__('faqat %s shu mansabdagilarga ', groups::name($group_show)));
            $uzcms->log('Kundalik', 'o`zgartirish bo`lim tafsifi [url=/kundalik/topic.php?id=' . $topic ['id'] . ']' . $topic ['name'] . '[/url] для группы ' . groups::name($group_show));
        }
    }

    if (isset($_POST ['group_write'])) {
        $group_write = (int) $_POST ['group_write'];
        if (isset($groups [$group_write]) && $group_write != $topic ['group_write']) {
            if ($topic ['group_show'] > $group_write)
                $doc->err('Faqat "' . groups::name($group_write) . '" shu mansablar uchun');
            else {
                $topic ['group_write'] = $group_write;
                mysql_query("UPDATE `kundalik_topics` SET `group_write` = '$topic[group_write]' WHERE `id` = '$topic[id]' LIMIT 1");
                $doc->msg(__('faqat %s mansablar uchun', groups::name($group_write)));
                $uzcms->log('Kundalik', 'mansablar uchun [url=/kundalik/topic.php?id=' . $topic ['id'] . ']' . $topic ['name'] . '[/url] для группы ' . groups::name($group_write));
            }
        }
    }

    if (isset($_POST ['group_edit'])) { 
        $group_edit = (int) $_POST ['group_edit'];
        if (isset($groups [$group_edit]) && $group_edit != $topic ['group_edit']) {
            if ($topic ['group_write'] > $group_edit)
                $doc->err('Faqat shu "' . groups::name($group_edit) . '" o`zgartiradi');
            else {
                $topic ['group_edit'] = $group_edit;
                mysql_query("UPDATE `kundalik_topics` SET `group_edit` = '$topic[group_edit]' WHERE `id` = '$topic[id]' LIMIT 1");
                $doc->msg(__('faqat %s mansablar uchun', groups::name($group_edit)));
                $uzcms->log('Kundalik', 'o`zgartirish [url=/kundalik/topic.php?id=' . $topic ['id'] . ']' . $topic ['name'] . '[/url] для группы ' . groups::name($group_edit));
            }
        }
    }

    $topic_theme_create_with_wmid = (int) !empty($_POST ['theme_create_with_wmid']);
    if ($topic_theme_create_with_wmid != $topic ['theme_create_with_wmid']) {
        $topic ['theme_create_with_wmid'] = $topic_theme_create_with_wmid;
        mysql_query("UPDATE `kundalik_topics` SET `theme_create_with_wmid` = '$topic[theme_create_with_wmid]' WHERE `id` = '$topic[id]' LIMIT 1");
        if ($topic ['theme_create_with_wmid']) {
            $doc->msg(__('WMID aktiv boganlarga qo`shildi'));
        } else {
            $doc->msg(__('WMID olib tashlandi'));
        }

        $uzcms->log('Kundalik', 'WMID faollashdi  [url=/kundalik/topic.php?id=' . $topic ['id'] . ']' . $topic ['name'] . '[/url]');
    }
}

$doc->title = __('O`zgariladigon bo`lim "%s"', $topic ['name']); 

$form = new form("?id=$topic[id]&amp;" . passgen() . (isset($_GET ['return']) ? '&amp;return=' . urlencode($_GET ['return']) : null));
$form->text('name', __('Nomi'), $topic['name']);
$form->textarea('description', __('Tafsif'), $topic['description']);

$options = array();
$q = mysql_query("SELECT `id`,`name` FROM `kundalik_categories` WHERE `group_show` <= '$user->group' ORDER BY `position` ASC");
while ($category = mysql_fetch_assoc($q))
    $options [] = array($category ['id'], $category ['name'], $category ['id'] == $topic ['id_category']);
$form->select('category', __('Bo`lim'), $options);

$options = array();
foreach ($groups as $type => $value)
    $options [] = array($type, $value ['name'], $type == $topic ['group_show']);
$form->select('group_show', __('Просмотр тем'), $options);

$options = array();
foreach ($groups as $type => $value)
    $options [] = array($type, $value ['name'], $type == $topic ['group_write']);

$form->select('group_write', __('Создание тем'), $options);

$options = array();
foreach ($groups as $type => $value)
    $options [] = array($type, $value ['name'], $type == $topic ['group_edit']);
$form->select('group_edit', __('Sozlamalarni o`zgartirish'), $options);

$form->checkbox('theme_create_with_wmid', __('Создание тем только с WMID'), $topic['theme_create_with_wmid']);
$form->button(__('Saqlash'), 'save');
$form->display();

$doc->grp(__('O`chiriladigan тем'), 'topic.themes.delete.php?id=' . $topic ['id']);
$doc->grp(__('Xotira daftarni o`chirish'), 'topic.delete.php?id=' . $topic ['id']);

if (isset($_GET ['return']))
    $doc->dost(__('Bo`limga'), text::toValue($_GET ['return']));
else
    $doc->dost(__('Bo`limga'), 'topic.php?id=' . $topic ['id']);

$doc->dost(__('Katigoryaga'), 'category.php?id=' . $topic ['id_category']);
$doc->dost(__('Kundalik'), './');