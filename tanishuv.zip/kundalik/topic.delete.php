<?php

include_once '../sys/inc/yadro.php';
$doc = new document();

$doc->title = __('O`chiriladigan bo`lim');

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Refresh: 1; url=./');
    $doc->err(__('Bu ID bo`ycha bo`lim'));
    exit;
}
$id_topic = (int) $_GET['id'];
$q = mysql_query("SELECT * FROM `kundalik_topics` WHERE `id` = '$id_topic' AND `group_edit` <= '$user->group'");
if (!mysql_num_rows($q)) {
    header('Refresh: 1; url=./');
    $doc->err(__('Bo`lim ohmaydi'));
    exit;
}
$topic = mysql_fetch_assoc($q);

$q = mysql_query("SELECT * FROM `kundalik_categories` WHERE `id` = '$topic[id_category]'");
$category = mysql_fetch_assoc($q);

if (isset($_POST['delete'])) {
    if (empty($_POST['captcha']) || empty($_POST['captcha_session']) || !captcha::check($_POST['captcha'], $_POST['captcha_session'])) {
        $doc->err(__('Raqamni noto`ri kiritdingiz'));
    } else {
        $q = mysql_query("SELECT `id` FROM `kundalik_themes` WHERE `id_topic` = '$topic[id]'");
        while ($theme = mysql_fetch_assoc($q)) {
            $dir = new files(FILES . '/.kundalik/' . $theme['id']);
            $dir->delete();
            unset($dir);
        }

        mysql_query("DELETE
FROM `kundalik_themes` , `kundalik_messages`, `kundalik_history`,  `kundalik_vote`, `kundalik_vote_votes`
USING `kundalik_themes`
LEFT JOIN `kundalik_messages` ON `kundalik_messages`.`id_theme` = `kundalik_themes`.`id`
LEFT JOIN `kundalik_history` ON `kundalik_history`.`id_message` = `kundalik_messages`.`id`
LEFT JOIN `kundalik_vote` ON `kundalik_vote`.`id_theme` = `kundalik_themes`.`id`
LEFT JOIN `kundalik_vote_votes` ON `kundalik_vote_votes`.`id_theme` = `kundalik_themes`.`id`
LEFT JOIN `kundalik_views` ON `kundalik_vote_votes`.`id_theme` = `kundalik_themes`.`id`
WHERE `kundalik_themes`.`id_topic` = '$topic[id]'");
        mysql_query("DELETE FROM `kundalik_topics` WHERE `id` = '$topic[id]' LIMIT 1");

        header('Refresh: 1; url=category.php?id=' . $topic['id_category']);

        $uzcms->log('Kundalik', 'O`chiriladigan bo`lim из Bo`lim [url=/kundalik/category.php?id=' . $category['id'] . ']' . $category['name'] . '[/url]');

        $doc->msg(__('Bo`lim o`chirildi'));
        exit;
    }
}


$doc->title = __('O`chiriladigan bo`lim "%s"', $topic['name']);

$form = new form("?id=$topic[id]&amp;" . passgen() . (isset($_GET['return']) ? '&amp;return=' . urlencode($_GET['return']) : null));
$form->captcha();
$form->button(__('O`chirish'), 'delete');
$form->display();

$doc->grp(__('Sozlama bo`lim'), 'topic.edit.php?id=' . $topic['id']);
$doc->dost(__('Bo`limga'), 'topic.php?id=' . $topic['id']);
$doc->dost(__('Kundalik'), './');
?>