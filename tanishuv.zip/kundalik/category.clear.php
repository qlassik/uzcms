<?php

include_once '../sys/inc/yadro.php';
$doc = new document();
$doc->title = __('Katigoryani tozalash');

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Refresh: 1; url=./');
    $doc->err(__('Bu ID bo`ycha Bo`lim'));
    exit;
}
$id_category = (int) $_GET['id'];

$q = mysql_query("SELECT * FROM `kundalik_categories` WHERE `id` = '$id_category' AND `group_edit` <= '$user->group'");

if (!mysql_num_rows($q)) {
    header('Refresh: 1; url=./');
    $doc->err(__('Bo`lim joylashmagan'));
    exit;
}

$category = mysql_fetch_assoc($q);

$doc->title = __('Bo`lim "%s" tozalash', $category['name']); // шапка страницы

if (isset($_POST['clear'])) {
    if (empty($_POST['captcha']) || empty($_POST['captcha_session']) || !captcha::check($_POST['captcha'], $_POST['captcha_session'])) {
        $doc->err(__('Raqamni noto`ri kiritdingiz'));
    } else {
        $doc->err('Ayni paytda amalga oshirila olmaysiz');
    }
}

$form = new form("?id=$category[id]&amp;" . passgen() . (isset($_GET['return']) ? '&amp;return=' . urlencode($_GET['return']) : null));
$count['themes_all'] = mysql_result(mysql_query("SELECT COUNT(*) FROM `kundalik_themes` WHERE `id_category` = '$category[id]'"), 0);
$form->bbcode(__('Katigoryada Xotira daftarlar: %s', '[b]' . $count['themes_all'] . '[/b]'));


$count['themes_old'] = mysql_result(mysql_query("SELECT COUNT(*) FROM `kundalik_themes` WHERE `id_category` = '$category[id]' AND `top` = '0' AND `time_last` < '" . (TIME - 31536000) . "'"), 0);

$count['themes_old2'] = mysql_result(mysql_query("SELECT COUNT(*) FROM `kundalik_themes` WHERE `id_category` = '$category[id]' AND `top` = '0' AND `group_write` > '1' AND `time_last` < '" . (TIME - 7884000) . "'"), 0);
if (!$count['themes_old'] + $count['themes_old2'])
    $form->bbcode(__('[b]' . ' Bu katigorya tozalash talab qilmaydi' . '[/b]'));

$form->checkbox('themes_old', __('Bir yil davomida faoliyatsiz: %d ' . misc::number($count['themes_old'], 'Xotira daftar', 'Xotira daftar', 'Xotira daftar'), $count['themes_old']), (bool) $count['themes_old']);
$form->checkbox('themes_old2', __('3 oydan ortiq yopiq: %d ' . misc::number($count['themes_old2'], 'Xotira daftar', 'Xotira daftar', 'Xotira daftar'), $count['themes_old2']), (bool) $count['themes_old2']);
$form->captcha();
$form->bbcode('* ' . __('Ma`lumotlar butunlay o`chirib tashlanadi'));
$form->button(__('Tozalash'), 'clear');
$form->display();

$doc->grp(__('Sozlama Bo`lim'), 'category.edit.php?id=' . $category['id']);
$doc->dost(__('Katigoryaga'), 'category.php?id=' . $category['id']);
$doc->dost(__('Kundalik'), './');
?>