<?php

include_once '../sys/inc/yadro.php';
$doc = new document(1);

$doc->title = __('Yangi Xotira daftar');

if (!isset($_GET ['id_topic']) || !is_numeric($_GET ['id_topic'])) {
    if (isset($_GET ['return']))
        header('Refresh: 1; url=' . $_GET ['return']);
    else
        header('Refresh: 1; url=./');
    $doc->err(__('Bu ID bo`ycha bo`lim yo`q'));
    exit();
}
$id_topic = (int) $_GET ['id_topic'];


$q = mysql_query("SELECT * FROM `kundalik_topics` WHERE `id` = '$id_topic' AND `group_write` <= '$user->group'");

if (!mysql_num_rows($q)) {
    if (isset($_GET ['return']))
        header('Refresh: 1; url=' . $_GET ['return']);
    else
        header('Refresh: 1; url=./');
    $doc->err(__('Xozircha mumkin emas'));
    exit();
}

$topic = mysql_fetch_assoc($q);

$timelimit = (empty($_SESSION ['antiflood'] ['newtheme']) || $_SESSION ['antiflood'] ['newtheme'] < TIME - 3600) ? true : false;
$check_wmid = (empty($topic ['theme_create_with_wmid']) || $user->wmid);


$time_reg = true;
if (!$user->is_writeable) {
    $doc->msg(__('Xotira daftar yaratish tugatildi'), 'write_denied');
    $time_reg = false;
}


if ($user->group >= 2) {
    $timelimit = true; 
    $check_wmid = true; 
}

if (!$timelimit) {
    $doc->err(__("Siz keyingi soatda yana tema ochishigiz mumkin"));
}

if (!$check_wmid) {
    $doc->err(__("WMID yingizni aktivlangandan kegin siz ham ocha olasiz"));
}


$can_write = $timelimit && $check_wmid && $time_reg;

if ($can_write && isset($_POST ['message']) && isset($_POST ['name'])) {
    $message = text::input_text($_POST ['message']);
    $name = text::for_name($_POST ['name']);

    if ($uzcms->censure && $mat = is_valid::mat($message))
        $doc->err(__('ZIT: %s', $mat));
    elseif ($uzcms->censure && $mat = is_valid::mat($name))
        $doc->err(__('ZIT: %s', $mat));
    elseif ($uzcms->kundalik_theme_captcha && $user->group < 2 && (empty($_POST ['captcha']) || empty($_POST ['captcha_session']) || !captcha::check($_POST ['captcha'], $_POST ['captcha_session']))) {
        $doc->err(__('Raqamni noto`ri kiritdingiz'));
    } elseif ($message && $name) {
        $user->balls++;
        mysql_query("UPDATE `kundalik_topics` SET `time_last` = '" . TIME . "' WHERE `id` = '$id_topic' LIMIT 1");

        mysql_query("INSERT INTO `kundalik_themes` (`id_category`, `id_topic`,  `name`, `id_autor`, `time_create`, `id_last`, `time_last`, `group_show`, `group_write`, `group_edit`)
 VALUES ('$topic[id_category]','$topic[id]','" . my_esc($name) . "', '$user->id', '" . TIME . "','$user->id','" . TIME . "','$topic[group_show]','$topic[group_write]','" . max($user->group, 2) . "')");

        $theme ['id'] = mysql_insert_id();
        $theme = mysql_fetch_assoc(mysql_query("SELECT * FROM `kundalik_themes` WHERE `id` = '$theme[id]' LIMIT 1"));
        mysql_query("INSERT INTO `kundalik_messages` (`id_category`, `id_topic`, `id_theme`, `id_user`, `time`, `message`, `group_show`, `group_edit`)
 VALUES ('$theme[id_category]','$theme[id_topic]','$theme[id]','$user->id','" . TIME . "','" . my_esc($message) . "','$theme[group_show]','$theme[group_edit]')");

        $_SESSION ['antiflood'] ['newtheme'] = TIME;
        $doc->msg(__('Xotira daftar qo`shildi'));

        header('Refresh: 1; url=theme.php?id=' . $theme ['id']);
        $doc->dost(__('Xotira daftarga'), 'theme.php?id=' . $theme ['id']);
        exit();
    } else {
        $doc->err(__('Xabarlar yoki Xotira daftar yo`q'));
    }
}

$doc->title = $topic ['name'] . ' - ' . __('Yangi Xotira daftar');

if ($can_write) {
    $form = new form("?id_topic=$topic[id]&amp;" . passgen() . (isset($_GET ['return']) ? '&amp;return=' . urlencode($_GET ['return']) : null));
    $form->text('name', __('Xotira daftar nomi'));
    $form->textarea('message', __('Xabar'));
    if ($uzcms->kundalik_theme_captcha && $user->group < 2)
        $form->captcha();
    $form->button(__('Xotira daftar yaratish'));
    $form->display();
}

if (isset($_GET ['return']))
    $doc->dost(__('Bo`limga'), text::toValue($_GET ['return']));
else
    $doc->dost(__('Bo`limga'), 'theme.php?id=' . $theme ['id']);