<?php

include_once '../sys/inc/yadro.php';
$doc = new document();
$doc->title = __('Xabarni o`chirish');

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Refresh: 1; url=./');
    $doc->err(__('Bu ID bo`ycha Xotira daftar yo`q'));
    exit;
}
$id_theme = (int)$_GET['id'];

$q = mysql_query("SELECT * FROM `kundalik_themes` WHERE `id` = '$id_theme' AND `group_edit` <= '$user->group'");

if (!mysql_num_rows($q)) {
    header('Refresh: 1; url=./');
    $doc->err(__('Xotira daftar joylashmagan'));
    exit;
}

$theme = mysql_fetch_assoc($q);

$doc->title .= ' - ' . $theme['name'];

switch (@$_GET['show']) {
    case 'all':
        $show = 'all';
        break;
    default:
        $show = 'part';
        break;
}

$delete_posts = array();

foreach ($_POST as $key => $value) {
    if ($value && preg_match('#^post([0-9]+)$#ui', $key, $n))
        $delete_posts[] = "`kundalik_messages`.`id` = '$n[1]'";
}

if ($delete_posts) {
    if (isset($_POST['delete'])) {
        foreach ($_POST as $key => $value) {
            if ($value && preg_match('#^post([0-9]+)$#ui', $key, $n)) {
                $dir = new files(FILES . '/.kundalik/' . $theme['id'] . '/' . $n[1]);
                $dir->delete();
                unset($dir);
            }
        }

        mysql_query("DELETE FROM `kundalik_messages`, `kundalik_history`
USING `kundalik_messages`
LEFT JOIN `kundalik_history`
ON `kundalik_messages`.`id` = `kundalik_history`.`id_message`
WHERE `kundalik_messages`.`id_theme` = '$theme[id]' AND (" . implode(' OR ', $delete_posts) . ")");

        $uzcms->log('Kundalik', 'Xabarni o`chirish из темы [url=/kundalik/theme.php?id=' . $theme['id'] . ']' . $theme['name'] . '[/url]');

        $doc->msg(__('%d xabar o`chirildi ', count($delete_posts)));
    }

    if (isset($_POST['hide'])) {
        mysql_query("UPDATE `kundalik_messages` SET `kundalik_messages`.`group_show` = '2' WHERE `kundalik_messages`.`id_theme` = '$theme[id]' AND (" . implode(' OR ', $delete_posts) . ") LIMIT " . count($delete_posts));

        $uzcms->log('Kundalik', 'Bekitilgan tema [url=/kundalik/theme.php?id=' . $theme['id'] . ']' . $theme['name'] . '[/url]');
        $doc->msg(__('%d xabar bekitildi', count($delete_posts)));
    }
}

$ord = array();
$ord[] = array("?id=$theme[id]&amp;show=all", __('Hammasi'), $show == 'all');
$ord[] = array("?id=$theme[id]&amp;show=part", __('Ko`rsatkichdan'), $show == 'part');
$or = new design();
$or->assign('order', $ord);
$or->display('design.order.tpl');

$listing = new listing();

if ($show == 'part') {
    $pages = new pages;
    $pages->posts = mysql_result(mysql_query("SELECT COUNT(*) FROM `kundalik_messages` WHERE `id_theme` = '$theme[id]' AND `group_show` <= '$user->group'"), 0); // количество сообщений  теме
    $q = mysql_query("SELECT `id`, `id_user`, `message`, `time` FROM `kundalik_messages`  WHERE `id_theme` = '$theme[id]' AND `group_show` <= '$user->group' ORDER BY `id` ASC LIMIT " . $pages->limit);
} else
    $q = mysql_query("SELECT `id`, `id_user`, `message`, `time` FROM `kundalik_messages`  WHERE `id_theme` = '$theme[id]' AND `group_show` <= '$user->group' ORDER BY `id` ASC");

while ($messages = mysql_fetch_assoc($q)) {
    $ch = $listing->checkbox();

    $ank = new user((int)$messages['id_user']);

    $ch->title = $ank->nick;
    $ch->time = misc::when($messages['time']);
    $ch->name = 'post' . $messages['id'];
    $ch->content = text::for_opis($messages['message']);
}

$form = new form('?id=' . $theme['id']);
$form->html($listing->fetch(__('Xabarlar yo`q')));
$form->button(__('O`chirish'), 'delete', false);
$form->button(__('Bekitish'), 'hide', false);
$form->display();

if ($show == 'part')
    $pages->display('?id=' . $theme['id'] . '&amp;show=part&amp;');

$doc->dost(__('Xotira daftarga qaytish '), 'theme.php?id=' . $theme['id'] . ($show == 'part' ? '&amp;page=' . $pages->this_page : ''));

$doc->dost(__('Bo`limga'), 'topic.php?id=' . $theme['id_topic']);
$doc->dost(__('Katigoryaga'), 'category.php?id=' . $theme['id_category']);
$doc->dost(__('Kundalik'), './');
