<?php
defined('UZCMS') or die;



$new_posts = mysql_query("SELECT COUNT(*) FROM `chat` WHERE `time` > '" . NEW_TIME . "'");
$users = mysql_result(mysql_query("SELECT COUNT(*) FROM `users_online` WHERE `request` LIKE '/chat/%'"), 0);

$listing = new listing();

$post = $listing->post();
$post->hightlight = true;
$post->url = '/chat/';
$post->title = __('Chat');
if ($new_posts)
    $post->counter = '+' . $new_posts;
if ($users)
    $post->bottom = __('%s ' . misc::number($users, 'odam bor'), $users);

$listing->display();