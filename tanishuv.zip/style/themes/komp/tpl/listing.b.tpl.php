<div class="cat_menu__tm"><?
$cc = '?bolim';


$listing = new listing();

	$post = $listing->post();
if ($_GET ['bolim'] == 'uzcms'){    
	$post->icon('approve');
    $post->title = __('UZCMS papkasidasiz');
}else{	
	$post->icon('dev.save_tables');
    $post->title = __('UZCMS');    
	$post->url = ''.$cc.'=uzcms';	
	}
	
	
    
	$post = $listing->post();
if ($_GET ['bolim'] == 'cmc'){ 	
    $post->icon('approve');
    $post->title = __('Cms skript papkasidasiz');
 }else{  
   $post->icon('dev.save_tables');
    $post->title = __('Cms skript');
    $post->url = ''.$cc.'=cmc';		
	 
 }	

	
	$post = $listing->post();
if ($_GET ['bolim'] == 'talabalarga'){ 	
    $post->icon('approve');
    $post->title = __('Talabalarga papkasidasiz');
 }else{  	
    $post->icon('dev.save_tables');
    $post->title = __('Talabalarga');	
    $post->url = ''.$cc.'=talabalarga';		

	}	
		
	
	$post = $listing->post();
if ($_GET ['bolim'] == 'oqituvchilarga'){ 	
    $post->icon('approve'); 
    $post->title = __('O`qituvchilarga papkasidasiz');
 }else{ 	
	$post->icon('dev.save_tables');
    $post->title = __('O`qituvchilarga');	
    $post->url = ''.$cc.'=oqituvchilarga';	
	}	
	
		
	
	$post = $listing->post();
if ($_GET ['bolim'] == 's_a'){ 	
    $post->icon('approve'); 	
    $post->title = __('Saytlar, acauntlar, master bozor papkasidasiz');
 }else{	
    $post->icon('dev.save_tables');
    $post->title = __('Saytlar, acauntlar, master bozor');	
    $post->url = ''.$cc.'=s_a';	
	}		
	
	
	
	$post = $listing->post();
if ($_GET ['bolim'] == 'h_p_v_m'){ 	
    $post->icon('approve'); 
    $post->title = __('Html, php, video, mp3 bozor papkasidasiz');
 }else{		
    $post->icon('dev.save_tables');
    $post->title = __('Html, php, video, mp3');	
    $post->url = ''.$cc.'=h_p_v_m';	
	}		
	
		
	
	$post = $listing->post();
if ($_GET ['bolim'] == 'boshqa'){ 	
    $post->icon('approve'); 
    $post->title = __('Boshqa');
 }else{		
	$post->icon('dev.save_tables');
    $post->title = __('Boshqa');	
    $post->url = ''.$cc.'=boshqa';		
	}		

	
	$post = $listing->post();
    $post->icon('ftp');
    $post->title = __('Bosh sahifa');	
	$post->url = '/';		
			
	$listing->display();
	?>
	</div>