<style>
.men{
float: right;
    margin: 3px;
    margin-top: 0;
    /* width: 85%; */
    max-width: 80%;
    border: #abf5d3 2px solid;
    padding: 5px;
    color: #000;
    background-color: #cffce7;
    -o-border-radius: 10px;
    border-radius: 10px;
    -moz-border-radius: 10px;
    word-wrap: break-word;
}
.menga{
  float: left;
    margin: 3px;
    margin-top: 0;
    /* width: 85%; */
    max-width: 80%;
    border: #e4c6c6 2px solid;
    padding: 5px;
    color: #000;
    background-color: #f5e2e2;
    -o-border-radius: 10px;
    border-radius: 10px;
    -moz-border-radius: 10px;
    word-wrap: break-word; 

}
.php {
    line-height: 16px;
    font-size: small;
    background-color: #e0e6e9;
    border: 1px solid #e0e6e9;
    padding: 0;
    overflow: auto;
}
.foto{
	border: 2px solid #F5FcF9;
    border-radius: 2px solid #f0f0f0;
    margin-right: 2px;
	max-width: 98%;
	width: 270px;	
}


.menga{
    overflow: hidden;
    border-radius: 3px 3px 3px 3px;
    background-color: #F2FCD7;
    color: #222222;
    float: right;
    border: 1px solid #F2FCD7;
    border-bottom: 2px solid #f0f0f0;
    margin: 2px;
    padding: 6px;
    margin-top: 15px;
    max-width: 75%;
}
.men{
    overflow: hidden;
    border-radius: 3px 3px 3px 3px;
    background-color: #F5F5F5;
    color: #222222;
    float: left;
    border: 1px solid #F5F5F5;
    border-bottom: 2px solid #f0f0f0;
    margin: 2px;
    padding: 6px;
    margin-top: 15px;
    max-width: 75%;
}
.php {
    line-height: 16px;
    font-size: small;
    background-color: #e0e6e9;
    border: 1px solid #e0e6e9;
    padding: 0;
    overflow: auto;
}
.foto{
	border: 2px solid #F5FcF9;
    border-radius: 2px solid #f0f0f0;
    margin-right: 2px;
	max-width: 98%;
	width: 270px;	
}
.pageeeol{ 
display: inline-block; 
min-width: 10px;
 padding: 5px 8px; 
 font-size: 13px;
 font-weight: 700; 
 line-height: 1;
 color: #fff; 
 text-align: center; 
 white-space: nowrap; 
 vertical-align: middle; 
 background-color: red;
 border-radius: 10px;
}
.pageee{ 
display: inline-block; 
min-width: 10px;
 padding: 5px 8px; 
 font-size: 13px;
 font-weight: 700; 
 line-height: 1;
 color: #fff; 
 text-align: center; 
 white-space: nowrap; 
 vertical-align: middle; 
 background-color: red;
 border-radius: 10px;
}
.pageees{ 
display: inline-block; 
min-width: 10px;
 padding: 5px 8px; 
 font-size: 13px;
 font-weight: 700; 
 line-height: 1;
 color: #fff; 
 text-align: center; 
 white-space: nowrap; 
 vertical-align: middle; 
 background-color: yellow;
 border-radius: 10px;
}
.pageeeo{ 
display: inline-block; 
min-width: 10px;
 padding: 5px 8px; 
 font-size: 13px;
 font-weight: 700; 
 line-height: 1;
 color: #fff; 
 text-align: center; 
 white-space: nowrap; 
 vertical-align: middle; 
 background-color: green;
 border-radius: 10px;
}
</style>
<?
$actions = '<span class="actions">' . $this->section($actions, '<a href="{url}"><img src="{icon}" alt="" /></a>') . '</span>';
 echo '<table width="100%" border="0"><tr  class="mes">';
      if($image){
	  echo '<td class="'.$bottom.'">
        <img style="width: 40px; border-radius: 35px;" src="'.$image.'" alt="voo.uz">
      </td>';
	  }
	  if ($mehmon){
echo '<td class="'.$bottom.'"><center><img class="foto" src="'.$mehmon.'" title="voo.uz" alt="voo.uz"></center>';
	  }else{
echo '<td class="'.$bottom.'"><center></center>';		  
		  
	  }
if (MANZIL_S == '/user/xizmatlar/mail_k.php' || MANZIL_S == '/user/xizmatlar/mail.php'){  
echo $admine;
echo '<br>';
echo '<div style="float:right; clear:left; font-size: 85%;">';
echo '<img src="'.$content.'" class="icon">';
echo '<span style="font-size: 70%; margin: 2px;">'.$time.'</span>';	
}else{
echo '<a href="'.$url.'">'.$admine;
echo '<br>';
echo '<div style="float:right; clear:left; font-size: 85%;">';
echo '<img src="'.$content.'" class="icon">';
echo '  <span style="font-size: 70%; margin: 2px;">'.$time.'</span></a>';
}
echo '</div>';
echo $actions;
echo '</td>';
echo '</tr>
</table>';

?>

























