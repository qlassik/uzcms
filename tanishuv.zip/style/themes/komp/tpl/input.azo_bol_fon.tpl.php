
    <?=
    '<div class="ana"><form id="' . $id . '"' .
    ($method ? ' method="' . $method . '"' : '') .
    ($action ? ' action="' . $action . '"' : '') .
    ($files ? ' enctype="multipart/form-data"' : '')
    . '>'
    ?>

    <?
    foreach ($el AS $element) {
        if ($element['title'])
            echo ' <label for="nick"> '.$element['title'] . ' </label>';
        switch ($element['type']) {
            case 'text': echo ' <label for="nick"> '.$element['value']. ' </label>';
                break;
            case 'captcha':
                ?>
                <input type="hidden" name="captcha_session" value="<?= $element['session'] ?>" />
                <img id="captcha" src="/captcha.html?captcha_session=<?= $element['session'] ?>&amp;<?= SID ?>" alt="captcha" />
                <div class="form-group"><label for="nick"><?= $lang->getString("Bu erga rasimdagi raqamini yozin") ?></label></div>
                <input type="text" autocomplete="off" name="captcha" size="5" maxlength="5" />
                <?
                break;
			case 'son':
                ?>
                <input type="hidden" name="captcha_session" value="<?= $element['session'] ?>" />
                <input class="gradient_grey invert border padding radius" type="text" autocomplete="off" name="captcha" size="5" maxlength="5" />
                <?
                break;
            case 'input_text':
                echo '<input  style="width: 98%; margin-left: 1%; height: 32px; margin:3px;"  type="text"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="' . text::toValue($element['info']['value']) . '"' : '') .
                ($element['info']['maxlength'] ? ' maxlength="' . intval($element['info']['maxlength']) . '"' : '') .
                ($element['info']['size'] ? ' size="' . intval($element['info']['size']) . '"' : '') .
                ($element['info']['disabled'] ? ' disabled="disabled"' : '') .
                ' />';
                break;

            case 'hidden':
                echo '<input  style="width: 98%; margin-left: 1%; height: 32px; margin:3px;" class="otga"  type="hidden"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="' . text::toValue($element['info']['value']) . '"' : '') .
                ' />';
                break;
            case 'password':
                echo '<input style="width: 98%; margin-left: 1%; height: 32px; margin:3px;" class="otga" type="password"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="' . text::toValue($element['info']['value']) . '"' : '') .
                ($element['info']['maxlength'] ? ' maxlength="' . intval($element['info']['maxlength']) . '"' : '') .
                ($element['info']['size'] ? ' size="' . intval($element['info']['size']) . '"' : '') .
                ($element['info']['disabled'] ? ' disabled="disabled"' : '') .
                ' />';
                break;
            case 'textarea':
                echo '<textarea style="width:99%; height: 80px; color:wite; background-color: wite;"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['disabled'] ? ' disabled="disabled"' : '') .
                '>' .
                ($element['info']['value'] ? text::toValue($element['info']['value']) : '') .
                '</textarea>';
                break;
            case 'textmi':
                echo '	<span  style="width:99%; height: 80px; color:wite; background-color: wite;"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['disabled'] ? ' disabled="disabled"' : '') .
                '" class="block pull-right">' .
                ($element['info']['value'] ? text::toValue($element['info']['value']) : '') .
                '
										<small class="grey middle">Tanlang: &nbsp;</small>

										<span class="btn-toolbar inline middle no-margin">
											<span data-toggle="buttons" class="btn-group no-margin">
												<label class="btn btn-sm btn-yellow">
													1
													<input type="radio" value="1" />
												</label>

												<label class="btn btn-sm btn-yellow active">
													2
													<input type="radio" value="2" />
												</label>

												<label class="btn btn-sm btn-yellow">
													3
													<input type="radio" value="3" />
												</label>

												<label class="btn btn-sm btn-yellow">
													4
													<input type="radio" value="4" />
												</label>
											</span>
										</span>
									</span>';
                break;
            case 'kich_checkbox':
                echo '<div class="checkbox"><label style=" display: block!important; margin-bottom: -26px; border-radius: 2px; position: relative;" ><input ' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="' . text::toValue($element['info']['value']) . '"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' type="checkbox" class="ace input-lg" />
			    <span class="lbl bigger-120"> ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span>
				</label>';
                break;
			case 'checkbox':
                echo '<div class="checkbox"><label style=" display: block!important; margin-bottom: -26px; border-radius: 2px; position: relative;" ><input ' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="' . text::toValue($element['info']['value']) . '"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' type="checkbox" class="ace ace-checkbox-2" />
			    <span class="lbl bigger-120"> ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span>
				</label>';
                break;
			case 'on_of_katta':
                echo '<br /><div style=" display: block!important; margin-left: -6px;"  class="col-xs-12"><label>
				<input ' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="' . text::toValue($element['info']['value']) . '"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace ace-switch ace-switch-2" type="checkbox" />
				<span class="lbl" data-lbl="'.__('ON').'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.__('O`FF').'">&nbsp;&nbsp; ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span>
				</label></div><br />';
                break;
            case 'tashida_chek_tu_c':
                echo '<br /><div style="display: block!important; margin-top: -10px; margin-left: -6px;"  class="col-xs-12"><label>
				<input ' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="' . text::toValue($element['info']['value']) . '"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace ace-switch ace-switch-4" type="checkbox" />
				<span class="lbl" data-lbl="'.__('ON').'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.__('O`FF').'">&nbsp;&nbsp; ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span>
				</label></div><br /><div style="display: block!important; margin-top: -20px;"></div>';
                break;
			case 'tashida_chek_tu_c7':
                echo '<br /><div style="display: block!important; margin-top: -10px; margin-left: -6px;"  class="col-xs-12"><label>
				<input ' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="' . text::toValue($element['info']['value']) . '"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace ace-switch ace-switch-4 btn-flat" type="checkbox" />
				<span class="lbl" data-lbl="'.__('ON').'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.__('O`FF').'">&nbsp;&nbsp; ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span>
				</label></div><br />';
                break;
			case 'tashida_chek_tu_c6':
                echo '<br /><div style="display: block!important; margin-top: -10px; margin-left: -6px;"  class="col-xs-12"><label>
				<input ' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="' . text::toValue($element['info']['value']) . '"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace ace-switch ace-switch-4 btn-empty" type="checkbox" />
				<span class="lbl" data-lbl="'.__('ON').'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.__('O`FF').'">&nbsp;&nbsp; ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span>
				</label></div><br />';
                break;
			case 'tashida_chek_tu_c5':
                echo '<br /><div style="display: block!important; margin-top: -10px; margin-left: -6px;"  class="col-xs-12"><label>
				<input ' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="' . text::toValue($element['info']['value']) . '"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace ace-switch ace-switch-4 btn-rotate" type="checkbox" />
				<span class="lbl" data-lbl="'.__('ON').'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.__('O`FF').'">&nbsp;&nbsp; ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span>
				</label></div><br />';
                break;
			case 'tashida_chek_tu_c4':
                echo '<br /><div style="display: block!important; margin-top: -10px; margin-left: -6px;"  class="col-xs-12"><label>
				<input ' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="' . text::toValue($element['info']['value']) . '"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace ace-switch btn-rotate" type="checkbox" />
				<span class="lbl" data-lbl="'.__('ON').'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.__('O`FF').'">&nbsp;&nbsp; ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span>
				</label></div><br />';
                break;
			case 'tashida_chek_tu_c3':
                echo '<br /><div style="display: block!important; margin-top: -10px; margin-left: -6px;"  class="col-xs-12"><label>
				<input ' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="' . text::toValue($element['info']['value']) . '"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace ace-switch ace-switch-7" type="checkbox" />
				<span class="lbl" data-lbl="'.__('ON').'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.__('O`FF').'">&nbsp;&nbsp; ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span>
				</label></div><br />';
                break;
			case 'tashida_chek_tu_c2':
                echo '<br /><div style="display: block!important; margin-top: -10px; margin-left: -6px;"  class="col-xs-12"><label>
				<input ' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="' . text::toValue($element['info']['value']) . '"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace ace-switch ace-switch-6" type="checkbox" />
				<span class="lbl">&nbsp;&nbsp; ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span>
				</label></div><br />';
                break;
			case 'tashida_chek_tu_c1':
                echo '<br /><div style="display: block!important; margin-top: -10px; margin-left: -6px;"  class="col-xs-12"><label>
				<input ' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="' . text::toValue($element['info']['value']) . '"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace ace-switch ace-switch-5" type="checkbox" />
				<span class="lbl" data-lbl="'.__('ON').'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.__('O`FF').'">&nbsp;&nbsp; ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span>
				</label></div><br />';
                break;
			case 'tashida_chek_tu':
                echo '<br /><div style="display: block!important; margin-top: -10px; margin-left: -6px;"  class="col-xs-12"><label>
				<input ' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="' . text::toValue($element['info']['value']) . '"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace ace-switch" type="checkbox" />
				<span class="lbl" data-lbl="'.__('ON').'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.__('O`FF').'">&nbsp;&nbsp; ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span>
				</label></div><br />';
                break;
			case 'tashida_chek_rim_c':
                echo '<br /><div style="display: block!important; margin-top: -10px; margin-left: -6px;"  class="col-xs-12"><label>
				<input ' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="' . text::toValue($element['info']['value']) . '"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace ace-switch ace-switch-3" type="checkbox" />
				<span class="lbl" data-lbl="'.__('ON').'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.__('O`FF').'">&nbsp;&nbsp; ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span>
				</label></div><br />';
                break;
			case 'tashida_chek_rim_m':
                echo '<br /><div style="display: block!important; margin-top: -10px; margin-left: -6px;"  class="col-xs-12"><label>
				<input ' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="' . text::toValue($element['info']['value']) . '"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace ace-switch ace-switch-3" type="checkbox" />
				<span class="lbl" data-lbl="'.__('ON').'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.__('O`FF').'">&nbsp;&nbsp; ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span>
				</label></div><br />';
                break;
			case 'ki_radio10':
                echo '<div style="position: relative; display: block; margin-left: 10px; margin-top: 1px; margin-bottom: -23px;"><label><input type="radio"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="1"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace input-lg"/><span class="lbl bigger-120">  ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span></label></div>';
                break;
			case 'ki_radio1':
                echo '<div style="position: relative; display: block; margin-left: 10px; margin-top: 1px; margin-bottom: -23px;"><label><input type="radio"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="2"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace input-lg"/><span class="lbl bigger-120">  ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span></label></div>';
                break;
			case 'ki_radio2':
                echo '<div style="position: relative; display: block; margin-left: 10px; margin-top: 1px; margin-bottom: -23px;"><label><input type="radio"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="3"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace input-lg"/><span class="lbl bigger-120">  ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span></label></div>';
                break;
			case 'ki_radio3':
                echo '<div style="position: relative; display: block; margin-left: 10px; margin-top: 1px; margin-bottom: -23px;"><label><input type="radio"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="4"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace input-lg"/><span class="lbl bigger-120">  ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span></label></div>';
                break;
			case 'ki_radio4':
                echo '<div style="position: relative; display: block; margin-left: 10px; margin-top: 1px; margin-bottom: -23px;"><label><input type="radio"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="5"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace input-lg"/><span class="lbl bigger-120">  ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span></label></div>';
                break;
			case 'ki_radio5':
                echo '<div style="position: relative; display: block; margin-left: 10px; margin-top: 1px; margin-bottom: -23px;"><label><input type="radio"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="6"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace input-lg"/><span class="lbl bigger-120">  ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span></label></div>';
                break;
			case 'ki_radio6':
                echo '<div style="position: relative; display: block; margin-left: 10px; margin-top: 1px; margin-bottom: -23px;"><label><input type="radio"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="7"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace input-lg"/><span class="lbl bigger-120">  ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span></label></div>';
                break;
			case 'ki_radio7':
                echo '<div style="position: relative; display: block; margin-left: 10px; margin-top: 1px; margin-bottom: -23px;"><label><input type="radio"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="8"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace input-lg"/><span class="lbl bigger-120">  ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span></label></div>';
                break;
			case 'ki_radio8':
                echo '<div style="position: relative; display: block; margin-left: 10px; margin-top: 1px; margin-bottom: -23px;"><label><input type="radio"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="9"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace input-lg"/><span class="lbl bigger-120">  ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span></label></div>';
                break;
			case 'ki_radio9':
                echo '<div style="position: relative; display: block; margin-left: 10px; margin-top: 1px; margin-bottom: -23px;"><label><input type="radio"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="10"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace input-lg"/><span class="lbl bigger-120">  ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span></label></div>';
                break;
			case 'radio10':
                echo '<div style="position: relative; display: block; margin-left: 10px; margin-top: 1px; margin-bottom: -23px;"><label>
				<input type="radio"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="1"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace" /><span class="lbl">   ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span></label></div>';
                break;
			case 'radio1':
                echo '<div style="position: relative; display: block; margin-left: 10px; margin-top: 1px; margin-bottom: -23px;"><label>
				<input type="radio"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="2"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace" /><span class="lbl">   ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span></label></div>';
                break;
			case 'radio2':
                echo '<div style="position: relative; display: block; margin-left: 10px; margin-top: 1px; margin-bottom: -23px;"><label>
				<input type="radio"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="3"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace" /><span class="lbl">   ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span></label></div>';
                break;
			case 'radio3':
                echo '<div style="position: relative; display: block; margin-left: 10px; margin-top: 1px; margin-bottom: -23px;"><label>
				<input type="radio"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="4"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace" /><span class="lbl">   ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span></label></div>';
                break;
			case 'radio4':
                echo '<div style="position: relative; display: block; margin-left: 10px; margin-top: 1px; margin-bottom: -23px;"><label>
				<input type="radio"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="5"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace" /><span class="lbl">   ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span></label></div>';
                break;
			case 'radio5':
                echo '<div style="position: relative; display: block; margin-left: 10px; margin-top: 1px; margin-bottom: -23px;"><label>
				<input type="radio"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="6"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace" /><span class="lbl">   ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span></label></div>';
                break;
			case 'radio6':
                echo '<div style="position: relative; display: block; margin-left: 10px; margin-top: 1px; margin-bottom: -23px;"><label>
				<input type="radio"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="7"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace" /><span class="lbl">   ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span></label></div>';
                break;
			case 'radio7':
                echo '<div style="position: relative; display: block; margin-left: 10px; margin-top: 1px; margin-bottom: -23px;"><label>
				<input type="radio"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="8"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace" /><span class="lbl">   ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span></label></div>';
                break;
			case 'radio8':
                echo '<div style="position: relative; display: block; margin-left: 10px; margin-top: 1px; margin-bottom: -23px;"><label>
				<input type="radio"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="9"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace" /><span class="lbl">   ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span></label></div>';
                break;
			case 'radio9':
                echo '<div style="position: relative; display: block; margin-left: 10px; margin-top: 1px; margin-bottom: -23px;"><label>
				<input type="radio"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="10"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace" /><span class="lbl">   ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span></label></div>';
			case 'submit':
                echo '<input style="width: 98%; margin-left: 1%; height: 32px; margin:3px;" class="otga form-control" type="submit"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="' . text::toValue($element['info']['value']) . '"' : '') .
                ' />';
                break;
            case 'file':
                echo '<input type="file"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ' />';
                break;
            case 'select':
                echo '<select  style="width: 96%; margin-left: 1%;font-size:16px; padding: 4px; background: #FAFAFA; " name="' . $element['info']['name'] . '">';
                foreach ($element['info']['options'] AS $option) {
                    if ($option['groupstart'])
                        echo '<optgroup  label="' . $option[0] . '">';
                    elseif ($option['groupend'])
                        echo '</optgroup>';
                    else
                        echo '<option' .
                        ($option[2] ? ' selected="selected"' : '') .
                        ' value="' . $option[0] . '"' .
                        '>' .
                        $option[1] .
                        '</option>';
                }
                echo '</select>';
                break;
        }

        if ($element['br'])
            echo '<br />';
    }
    ?>

        <?
        echo '</form>';
        ?>    
</div>
<? if ($ajax_url) { ?>
    <script>
        form_ajax_submit(document.getElementById('<?= $id ?>'), '<?= $ajax_url ?>');
    </script>
    <?
}?>