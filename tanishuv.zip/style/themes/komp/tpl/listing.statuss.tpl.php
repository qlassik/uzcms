<style>
	.voouz{
	width: 100%;
	height: 50px;
    margin: 2px auto;
    background: #EBEBEB;
    padding: 5px;
    border: 0.5px solid #DFDFDF;
    border-radius: 3px;
    }
	.voouzga{
	width: 50%;
	margin: 2px auto;
    background: #EBEBEB;
    padding: 5px;
    border: 1px solid #DFDFDF;
    border-radius: 5px;
    }	
	.wwwvoouz{
	width: 400px;
	height: 305px;
	margin: 2px auto;
    padding: 5px;
    border: 1px solid #DFDFDF;
    border-radius: 5px;
    }	</style>
	<?
$iefix = ($url && $uzcms->ie_ver && $uzcms->ie_ver < 10) ? 'onclick="location.href = \'' . $url . '\'"' : '';
$post_time = $time ? '<span class="vaqt">' . $time . '</span>' : '';
$post_counter = $counter ? '<span class="counter gradient_grey invert border">' . $counter . '</span>' : '';
$post_actions = '<span class="actions">' . $this->section($actions, '<a href="{url}"><img src="{icon}" alt="" /></a>') . '</span>';
$post_actions_t = '<span class="actions">' . $this->section($actions_t, '<a href="{url}"><img src="{icon}" alt="" /></a>') . '</span>';

?>
<div class="ana">
<table width="100%" border="0"><tr><td  style="width: 400px;">
<small style="float:right; padding:5px; background:#f7f5f5;">
<?if ($actions || $hightlight){?>
<?= $post_actions ?>
<?= $hightlight ?>
		<?}?>
</small>
<?= $title ?>
</td>
</tr>
</table>
<hr />
<table width="90%" border="0"><tr><td  style="width: 85px;">
<?if ($image){?>

<img class="voouz" src="<?= $image ?>" style="width: 70px;"/>

<?}?>
</td><td>
<a href="?status=<?=$admine?>&ov1=ok" title="Juda zor"><div class="btn progress-bar progress-bar-danger" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width: <?= $ov1 ?>%">
    <span class="sr-only"><?= $ov1 ?>% </span>
</div></a><br />
<a href="?status=<?=$admine?>&ov2=ok" title="Yahshi"><div class="btn progress-bar progress-bar-danger" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width: <?= $ov2 ?>%">
     <span class="sr-only"><?= $ov2 ?>% </span>
</div></a><br />
<a href="?status=<?=$admine?>&ov3=ok" title="Juda yomon"><div class="btn progress-bar progress-bar-danger" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width: <?= $ov3 ?>%">
    <span class="sr-only"><?= $ov3 ?>% </span>
</div></a><br />
</td>
</tr>
</table>
</div>