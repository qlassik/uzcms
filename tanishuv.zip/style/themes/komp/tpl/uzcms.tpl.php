 <? 
 if ($user->fon){
  if ($user->fon == 'ra'){ 
 $fon = $user->fon_r; 
 }else{
 $fon = $user->fon; 	 
 }}else{
  $fon = $uzcms->fon_2500;  
 }
 $ank = (empty($_GET ['id'])) ? $user : new user((int)$_GET ['id']);
  if ($ank->foncc){
 $foncc = $ank->foncc; 	 
 }else{
  $foncc = $uzcms->foncc_2500;  
 } 
 
 ?>
 <style type="text/css">


.navbar{
	 background:#b7b7b7 url("<?=$fon?>");
}
.navbar-static-top {
  margin-bottom: 19px;
}

.navbar-wrapper {
  position: absolute;
  top: 0;
  right: 0;
  left: 0;
  z-index: 20;
}
.navbar-wrapper > .container {
  padding-right: 0;
  padding-left: 0;
}
.navbar-wrapper .navbar {
  padding-right: 15px;
  padding-left: 15px;
}
.navbar-wrapper .navbar .container {
  width: auto;
}

.carousel {
  height: 500px;
  margin-bottom: 60px;
}
.carousel-caption {
  z-index: 10;
}

.carousel .item {
  height: 500px;
  background-color: #777;
}
.carousel-inner > .item > img {
  position: absolute;
  top: 0;
  left: 0;
  min-width: 100%;
  height: 500px;
}


.marketing .col-lg-4 {
  margin-bottom: 20px;
  text-align: center;
}
.marketing h2 {
  font-weight: normal;
}
.marketing .col-lg-4 p {
  margin-right: 10px;
  margin-left: 10px;
}


.featurette-divider {
  margin: 80px 0; 
}

.featurette-heading {
  font-weight: 300;
  line-height: 1;
  letter-spacing: -1px;
}


@media (min-width: 768px) {
  .navbar-wrapper {
    margin-top: 20px;
  }
  .navbar-wrapper .container {
    padding-right: 15px;
    padding-left: 15px;
  }
  .navbar-wrapper .navbar {
    padding-right: 0;
    padding-left: 0;
  }

  .navbar-wrapper .navbar {
    border-radius: 4px;
  }

  .carousel-caption p {
    margin-bottom: 20px;
    font-size: 21px;
    line-height: 1.4;
  }

  .featurette-heading {
    font-size: 50px;
  }
}

@media (min-width: 992px) {
  .featurette-heading {
    margin-top: 120px;
  }
}

 </style>