<div class="kv1"><center>
    <?
    echo $page == 1 ? '<span class="pageee"> 1 </span>' : '<a class="pageeeol" href="' . $link . 'page=1"> <<<  </a>';
    for ($i = max(2, $page - 8); $i < min($k_page, $page + 10); $i++) {
        if ($i == $page)
            echo ' <span class="pageees">  ' . $i . ' </span> ';
        else
            echo ' <a class="pageeeo" href="' . $link . 'page=' . $i . '"> ' . $i . ' </a>';
    }
    echo $page == $k_page ? ' <span class="pageees"> ' . $k_page . ' </span> ' : ' <a class="pageeeol" href="' . $link . 'page=' . $k_page . '"> >>> </a> '
    ?>
</center></div>
