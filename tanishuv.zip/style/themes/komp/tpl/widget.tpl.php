<div class="widget"><!-- Виджет <?=$name?>  -->
<?=$content?>
</div>