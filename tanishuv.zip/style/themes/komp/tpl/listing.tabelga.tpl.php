<tr><td class="center">
<label class="pos-rel">
<?=$admine?>
<span class="lbl"></span>
</label>
</td>
<td class="center">
<div class="action-buttons">
<a href="#" class="green bigger-140 show-details-btn" title="Show Details">
<?=$tabela?>
<span class="sr-only"><?=$tabela?></span>
</a>
</div>
</td>
<td>
<?if ($url){?>
<a href="<?=$url?>"><?=$tabelb?></a>
<?}else{?>
<?=$tabelb?>
<?}?>
</td>
<td><?=$tabelc?></td>
<td>
<span class="label label-sm label-warning"><?=$tabeld?></span>
</td>
</tr>