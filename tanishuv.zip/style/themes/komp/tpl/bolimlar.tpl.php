 <nav class="navbar navbar-fixed-top navbar-default navbar-static-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="/"><?=$uzcms->sayt?></a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
        
             <li class="dropdown">
              <a href="<?=bolim_bolimga_s(''.$uzcms->bolim1.'')?>" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> <?=__(bolim_bolimga($uzcms->bolim1))?> <span class="caret"></span></a>
              <ul class="alert alert-warning dropdown-menu">
                <?
			  $q = mysql_query("SELECT * FROM `bolimlarga` WHERE `bolimlarga` = '".$uzcms->bolim1."' ORDER BY `id` DESC LIMIT 2");
while ($us = mysql_fetch_assoc($q)) {

echo '<li class="post"><a href="/'.$us['manzil'].'">'.__(''.$us['nomi'].'').'</a></li>';;
 }
			  
			  ?>
				
			
               </ul>
            </li>	
			
            <li class="dropdown">
              <a href="<?=bolim_bolimga_s(''.$uzcms->bolim2.'')?>" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> <?=__(bolim_bolimga($uzcms->bolim2))?> <span class="caret"></span></a>
              <ul class="alert alert-warning dropdown-menu">
                <?
			  $q = mysql_query("SELECT * FROM `bolimlarga` WHERE `bolimlarga` = '".$uzcms->bolim2."' ORDER BY `id` DESC LIMIT 2");
while ($us = mysql_fetch_assoc($q)) {

echo '<li class="post"><a href="/'.$us['manzil'].'">'.__(''.$us['nomi'].'').'</a></li>';;
 }
			  
			  ?>
				
			
               </ul>
            </li>			
           <li class="dropdown">
              <a href="<?=bolim_bolimga_s(''.$uzcms->bolim3.'')?>" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> <?=__(bolim_bolimga($uzcms->bolim3))?><span class="caret"></span></a>
              <ul class="alert alert-warning dropdown-menu">
                <?
			  $q = mysql_query("SELECT * FROM `bolimlarga` WHERE `bolimlarga` = '".$uzcms->bolim3."' ORDER BY `id` DESC LIMIT 2");
while ($us = mysql_fetch_assoc($q)) {

echo '<li class="post"><a href="/'.$us['manzil'].'">'.__(''.$us['nomi'].'').'</a></li>';;
 }
			  
			  ?>
				
			
               </ul>
            </li>
            <li class="dropdown">
              <a href="<?=bolim_bolimga_s(''.$uzcms->bolim4.'')?>" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> <?=__(bolim_bolimga($uzcms->bolim4))?><span class="caret"></span></a>
              <ul class="alert alert-warning dropdown-menu">
                <?
			  $q = mysql_query("SELECT * FROM `bolimlarga` WHERE `bolimlarga` = '".$uzcms->bolim4."' ORDER BY `id` DESC LIMIT 2");
while ($us = mysql_fetch_assoc($q)) {

echo '<li class="post"><a href="/'.$us['manzil'].'">'.__(''.$us['nomi'].'').'</a></li>';;
 }
			  
			  ?>
				
			
               </ul>
            </li>
			
			
			
			
			
			
			
			
			
			
			
          </ul>
          <ul class="nav navbar-nav navbar-right">
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> <?echo' '. $lang->name.' '; ?> <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><?
$languages = languages::getList();
$listing = new listing();
foreach ($languages as $key => $l) {
    $post = $listing->post();
    $post->url = '?set_lang=' . urlencode($key) . (!empty($_GET['return']) ? '&amp;return=' . urlencode($_GET['return']) : '');
    $post->title = $user_language_pack->code == $key ? $l['name'] : $l['enname'];
    $post->icon = empty($l['icon']) ? false : $l['icon'];
}
$listing->display(__('Til paket topilmadi'));
			?></li>
            </ul>
            </li>
			<? if ($user->id){
			 echo'<li class="active"><a href="/xona.html">'.__('Sozlamalar').'</a></li>';	
			 echo'<li><a href="/file.html">'.__('Sahifa ochish').'</a></li>';				
			}else{
			 echo'<li class="active"><a href="/kirish.html">'.__('Kirish').'</a></li>';	
			 echo'<li><a href="/support">'.__('Qabul xona').'</a></li>';				 
			}?>
           
			
            
          </ul>
        </div>
      </div>
    </nav>

