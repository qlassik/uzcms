<div class="kv1"><center>
    <?
    foreach($select AS $option){
        if (empty($option[2]))
            echo ' <a class="qani" href="'.$option[0].'"> '.$option[1].' </a> ';
        else
            echo ' <span class="qani"> '.$option[1].' </span> ';
    }
    ?>
</center></div>