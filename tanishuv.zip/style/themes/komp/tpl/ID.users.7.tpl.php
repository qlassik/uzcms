<?

$ank = (empty($_GET ['id'])) ? $user : new user((int)$_GET ['id']);
if ($ank->fone){
$fon = $ank->fone;	
}else{
if ($ank->fon){
$fon = '/style/shaxar/'.$ank->fon.'.jpg';
}else{
$fon = 'yoq';	
}
}
if($user->id)if ($user->id == $ank->id);else echo'<a href="/xabar?id='.$ank->id.'"><div class="user_ekran_xat_katta_img"></div></a>';
echo'<div class="gmenu"><div class="tepabg"><img  class="rasim_7" src="'.$fon.'"></div>';
echo'<div class="ID_7"><div class="dumaloq_7"><table width="100%"><tbody><tr><td width="50px">';
if ($path = $ank->getAva()) {

	echo'<img src="' . $path . '" width="50" height="50"  alt="' . __('Foto %s', $ank->title) . '"  style="border-radius:25px;">';
}
$qq = $ank->ank_g_r;
$ay = date("Y");
$ess = $ay - $qq;
echo'</a></td><td style="display: block !important; width:80%; margin-left: 5%;"><b><font color="#ccc">'.$ank->nick.'</b>  <br><span  style="font-size: 70%; text-transform: uppercase;">'.$ess .' '.__('yosh').' | <i>'.$ank->fon.'</i></span><br />';
echo '</td></tr></tbody></table></div>';
if ($ank->id == $user->id){
	echo '<div class="ID_7_t clr"></div>';
}else{






if ($user->id){

echo '<center  class="ID_7_t"><table width="100%" border="0"><tr>';
  if ($ank->is_friend($user)){
	   echo '<td width="25%"><center class="user_7_ekra_fon_ana_a"><a href="?id='.$ank->id.'&amp;friend=delete"> +'.__('O`chirish').' </a></center></td>';
      }else{
		     echo '<td width="25%"><center style="font-size: 84%;" class="user_7_ekra_fon_ana"><a href="?id='.$ank->id.'&amp;friend=add"> +'.__('Do`stlik').' </a></center></td>';
   }
   	if (!$user->is_enemies($ank)) {
	echo '<td width="25%"><center style="font-size: 84%;"  class="user_7_ekra_fon_ana"><a href="/ID'.$ank->id.'?id='.$ank->id.'&enemies"><span class="ff"> +'.__('To`siq qo`yish').' </span><span class="fff"> +'.__('To`siq').' </span></a></center></td>';
	}else{
			$pages = new pages ;
$pages->posts = mysql_result(mysql_query("SELECT COUNT(*) FROM `enemies` WHERE `id_user` = '$user->id'"), 0) ;
$pages->this_page() ;

		$q = mysql_query("SELECT * FROM `enemies` WHERE `id_user` = '$user->id' ORDER BY `time` DESC LIMIT ".$pages->limit);
        while($enemies = mysql_fetch_object($q)) 
	if ($enemies->id_who == $ank->id){
	echo '<td width="25%"><center style="font-size: 84%;"  class="user_7_ekra_fon_ana_a"><a href="/ID'.$ank->id.'?delete=' .$enemies->id. '"><span class="ff"> +'.__('To`siqni olish').' </span><span class="fff"> +'.__('T / O').' </span></a></center></td>';
	}




	}
	echo '<td width="25%" ><center style="font-size: 84%;" class="user_7_ekra_fon_ana"><a href="/user/sovga/ot.php?id='.$ank->id.'"> +'.__('Sovga').'</a></center></td>';
echo '<td width="25%"><center style="font-size: 84%;"  class="user_7_ekra_fon_ana"><a href="/user/group/ot.php?id='.$ank->id.'"> +'.__('Gurpaga').'</a></center></td>';
}
echo '</tr></table></center></div>';
}