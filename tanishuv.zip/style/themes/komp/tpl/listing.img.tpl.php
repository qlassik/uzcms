 <?
$iefix = ($url && $uzcms->ie_ver && $uzcms->ie_ver < 10) ? 'onclick="location.href = \'' . $url . '\'"' : '';
$post_time = $time ? '<span style="margin:5px; margin-left: -3px;"  class="vaqt">' . $time . '</span>' : '';
$post_counter = $counter ? '<span class="counter gradient_grey invert border">' . $counter . '</span>' : '';
$post_actions = '' . $this->section($actions, '<a href="{url}"><img src="{icon}" alt="" /></a>') . '';
$post_action_t = '' . $this->section($action_t, '<a href="{url}"><img src="{icon}" alt="" /></a>') . '';
?>

 <? if ($image) { ?> 

       
        


            <a href="<?=$url?>"> <img style="margin: 6px; width: 80px;   margin-left: 20px;  padding: 4px;  height: 80px;   
    background: #EBEBEB;
    border: 1px solid #DFDFDF;
    border-radius: 3px;" src="<?= $image ?>" title="voo.uz" alt="voo.uz"></a>


            
        <? } elseif ($icon) { ?>
           
        	   
                
        <? } else { ?>
            
                    <?= $title ?>
                    <?= $post_counter ?>
               
                    <?= $post_time ?>
                    <?= $post_actions ?>
               
        <? } ?>

        <? if ($content) { ?>
            
                    <?= $content ?>
               
        <? } ?>

        <? if ($bottom) { ?>
             <?= $bottom ?>
              
        <? } ?>
