<style>
@media (max-width:500px) and (min-width:100px) {
.zzzz{
	display: block !important; margin-top: 6px;
	margin-left: -30px;

}
    }
	@media (min-width:500px) and (max-width:2700px) {
    .zzzz{
			display: block !important; margin-top: 6px;

	}
    }
</style>
    <?
$iefix = ($url && $uzcms->ie_ver && $uzcms->ie_ver < 10) ? 'onclick="location.href = \'' . $url . '\'"' : '';
$post_time = $time ? '<span class="vaqt">' . $time . '</span>' : '';
$post_counter = $counter ? '<span class="counter gradient_grey invert border">' . $counter . '</span>' : '';
$post_actions = '<span class="actions">' . $this->section($actions, '<a href="{url}"><img src="{icon}" alt="" /></a>') . '</span>';
?>
<?= ($url ? '<a href="' . $url . '" class="' : '<div class="') . '' . ($hightlight ? ' hightlight' : '') . '" id="' . $id . '"    >' ?>
     <table <?= $iefix ?> cellspacing="0" callpadding="0" width="100%" >
        <? if ($image) { ?>
            <tr>
                <td class="image" rowspan="4">
                    <img  style="width:<?=$uzcms->k_img_razmer?>px" src="<?= $image ?>" alt="" />
                </td>
                <td class="men2">
                    <?= $title ?>
                    <?= $post_counter ?>
                </td>

                <td style ="text-align: right;" class="chap">
                    <?= $post_time ?>
                    <?= $post_actions ?>
                </td>
            </tr>
        <? } elseif ($icon) { ?>
            <tr>
                   
               
                <td class="men2">
                      <?= $title ?>
                    <?= $post_counter ?>
                </td>

                <td style ="text-align: right;" class="chap">
                   <div class="zzzz"><?= $post_time ?></div>
                    <?= $post_actions ?>
                </td>
            </tr>
        <? } else { ?>
            <tr>
                <td class="men2">
                    <?= $title ?>
                    <?= $post_counter ?>
                </td>

                <td style ="text-align: right;" class="chap">
                    <?= $post_time ?>
                    <?= $post_actions ?>
                </td>
            </tr>
        <? } ?>

        <? if ($content) { ?>
            <tr>
                <td class="men2" colspan="10">
                    <?= $content ?>
                </td>
            </tr>
        <? } ?>

        <? if ($bottom) { ?>
            <tr>
                <td class="bottom" colspan="10">
                    <?= $bottom ?>
                </td>
            </tr>
        <? } ?>
    </table>
<?=
$url ? '</a>' : '</div>'?>