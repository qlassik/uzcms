  <style>
  .gruppa{
    transition: background, 500ms;
    -moz-transition: background 500ms;
    -webkit-transition: background 500ms;
    -o-transition: background 500ms;
    background: #FAFAFA;
    border: 1px #DBDBDB solid;
    color: #686868 !important;
    padding: 6px;
    display: block !important;
    border-top-style: none !important;
    font-size: 100%;
    box-shadow: 0 0 0 1px #FCFCFC inset;
    overflow: hidden;
}
  
 .voouzga{
	width: 50%;
	margin: 2px auto;
    background: #EBEBEB;
    padding: 5px;
    border: 1px solid #DFDFDF;
    border-radius: 5px;
	margin-top:  10px;  
    }
.bax{
    display: inline-block;
    min-width: 8px;
	width: 18px;
    padding: 4px;
    font-size: 10px;
    font-weight: 700;
    line-height: 1;
    color: #fff;
    text-align: center;
    white-space: nowrap;
    vertical-align: middle;
    background-color: #777;
    border-radius: 25px;
	margin: 3px;
	}
.bax2{
    display: inline-block;
    min-width: 8px;
	width: 22px;
    padding: 4px;
    font-size: 10px;
    font-weight: 700;
    line-height: 1;
    color: #fff;
    text-align: center;
    white-space: nowrap;
    vertical-align: middle;
    background-color: #fff;
    border-radius: 25px;
	margin: 3px;
	}
.baxq{
    display: inline-block;
    min-width: 8px;
	padding: 4px;
    font-size: 10px;
    font-weight: 700;
    line-height: 1;
    color: #fff;
    text-align: center;
    white-space: nowrap;
    vertical-align: middle;
    background-color: #777;
    border-radius: 25px;
	margin: 3px;
	}		
.UZCMS_quote{
    border: 1px solid #E4E4E4;
    border-radius: 2px;
    background-color: white;
    box-shadow: 0 1px 6px -4px black inset;
    padding: 6px;
    color: #838383;
    margin-left: 24px;
}

.UZCMS_quote a{
    color: #838383;
}
.UZCMS_photoss{
	width: 95%;
    display: block;
    margin: 2px auto;
    background: #EBEBEB;
    padding: 5px;
    border: 1px solid #DFDFDF;
    border-radius: 5px;
}
.UZCMS_photo{
	width: 95%;
    display: block;
    margin: 2px auto;
    background: #EBEBEB;
    padding: 5px;
    border: 1px solid #DFDFDF;
    border-radius: 5px;

}
.UZCMS_photoi{
  border-radius: 2px;
   padding: 20px;
}
.UZCMS_nick_f{
	width: 40px;
    display: block;
    margin: 2px auto;
    background: #EBEBEB;
    padding: 5px;
    border: 1px solid #DFDFDF;
    border-radius: 5px;
}
.UZCMS_nick_ff{
	width: 150px;
    display: block;
    margin: 2px auto;
    background: #EBEBEB;
    padding: 5px;
    border: 1px solid #DFDFDF;
    border-radius: 15px;
}
.UZCMS_nick_on{
    text-shadow: 1px 1px 4px #00E900;
}

.UZCMS_nick_off{

}

.UZCMS_phpcode{
    max-height: 400px;
    max-width: 684px;
    overflow: auto;
    border: 1px solid #E2E2E2;
    padding: 5px;
    border-radius: 2px;
    background-color: #F7F7F7;
    box-shadow: 0 0 8px -5px black inset;
}

.UZCMS_spoiler{
    border: 1px #ccc solid;
    border-radius: 2px;
    padding: 3px;    
}

.UZCMS_spoiler > .UZCMS_spoiler_title{
    cursor: pointer;
}

.UZCMS_spoiler.expanded > .UZCMS_spoiler_title:before{
    content: '▼ ';
}

.UZCMS_spoiler.collapsed > .UZCMS_spoiler_title:before{
    content: '► ';
}

.UZCMS_spoiler > .UZCMS_spoiler_content{
    overflow-y: hidden;
}
#loading-layer { background: #000; padding: 20px; text-align: center; color: #fff; border-radius: 2px }
.a_demo_four {
	background-color:#3bb3e0;
	font-family: 'Open Sans', sans-serif;
	font-size:12px;
	text-decoration:none;
	color:#fff;
	position:relative;
	padding:10px 20px;
	padding-right:50px;
	background-image: linear-gradient(bottom, rgb(44,160,202) 0%, rgb(62,184,229) 100%);
	background-image: -o-linear-gradient(bottom, rgb(44,160,202) 0%, rgb(62,184,229) 100%);
	background-image: -moz-linear-gradient(bottom, rgb(44,160,202) 0%, rgb(62,184,229) 100%);
	background-image: -webkit-linear-gradient(bottom, rgb(44,160,202) 0%, rgb(62,184,229) 100%);
	background-image: -ms-linear-gradient(bottom, rgb(44,160,202) 0%, rgb(62,184,229) 100%);
	background-image: -webkit-gradient(
	linear,
	left bottom,
	left top,
	color-stop(0, rgb(44,160,202)),
	color-stop(1, rgb(62,184,229))
	);
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	-o-border-radius: 5px;
	border-radius: 5px;
	-webkit-box-shadow: inset 0px 1px 0px #2ab7ec, 0px 5px 0px 0px #156785, 0px 10px 5px #999;
	-moz-box-shadow: inset 0px 1px 0px #2ab7ec, 0px 5px 0px 0px #156785, 0px 10px 5px #999;
	-o-box-shadow: inset 0px 1px 0px #2ab7ec, 0px 5px 0px 0px #156785, 0px 10px 5px #999;
	box-shadow: inset 0px 1px 0px #2ab7ec, 0px 5px 0px 0px #156785, 0px 10px 5px #999;
}

.a_demo_four:active {
	top:3px;
	background-image: linear-gradient(bottom, rgb(62,184,229) 0%, rgb(44,160,202) 100%);
	background-image: -o-linear-gradient(bottom, rgb(62,184,229) 0%, rgb(44,160,202) 100%);
	background-image: -moz-linear-gradient(bottom, rgb(62,184,229) 0%, rgb(44,160,202) 100%);
	background-image: -webkit-linear-gradient(bottom, rgb(62,184,229) 0%, rgb(44,160,202) 100%);
	background-image: -ms-linear-gradient(bottom, rgb(62,184,229) 0%, rgb(44,160,202) 100%);
	background-image: -webkit-gradient(
	linear,
	left bottom,
	left top,
	color-stop(0, rgb(62,184,229)),
	color-stop(1, rgb(44,160,202))
	);
	-webkit-box-shadow: inset 0px 1px 0px #2ab7ec, 0px 2px 0px 0px #156785, 0px 5px 3px #999;
	-moz-box-shadow: inset 0px 1px 0px #2ab7ec, 0px 2px 0px 0px #156785, 0px 5px 3px #999;
	-o-box-shadow: inset 0px 1px 0px #2ab7ec, 0px 2px 0px 0px #156785, 0px 5px 3px #999;
	box-shadow: inset 0px 1px 0px #2ab7ec, 0px 2px 0px 0px #156785, 0px 5px 3px #999;
}

.a_demo_four::before {
	background-color:#2591b4;
	background-image:url(../images/right_arrow.png);
	background-repeat:no-repeat;
	background-position:center center;
	content:"";
	width:20px;
	height:20px;
	position:absolute;
	right:15px;
	top:50%;
	margin-top:-9px;
	-webkit-border-radius: 50%;
	-moz-border-radius: 50%;
	-o-border-radius: 50%;
	border-radius: 50%;
	-webkit-box-shadow: inset 0px 1px 0px #052756, 0px 1px 0px #60c9f0;
	-moz-box-shadow: inset 0px 1px 0px #052756, 0px 1px 0px #60c9f0;
	-o-box-shadow: inset 0px 1px 0px #052756, 0px 1px 0px #60c9f0;
	box-shadow: inset 0px 1px 0px #052756, 0px 1px 0px #60c9f0;
}

.a_demo_four:active::before {
	top:50%;
	margin-top:-12px;
	-webkit-box-shadow: inset 0px 1px 0px #60c9f0, 0px 3px 0px #0e3871, 0px 6px 3px #1a80a6;
	-moz-box-shadow: inset 0px 1px 0px #60c9f0, 0px 3px 0px #0e3871, 0px 6px 3px #1a80a6;
	-o-box-shadow: inset 0px 1px 0px #60c9f0, 0px 3px 0px #0e3871, 0px 6px 3px #1a80a6;
	box-shadow: inset 0px 1px 0px #60c9f0, 0px 3px 0px #0e3871, 0px 6px 3px #1a80a6;
}


.royhatdan_ot_ramkasini_ichi {
    color: #fff;
    background-color: #2C3E50;
    border-color: #f1f1f1;
}

.content .most-viewed .news-item .news-title {
    color: #3c4b62;
    font-size: 15px;
    margin-bottom: 10px;
    position: relative;
    z-index: 1;
}
* {
    -webkit-tap-highlight-color: transparent;
}
*, :after, :before {
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    box-sizing: border-box;
}
user agent stylesheet
div {
    display: block;
}
a, a:focus, a:hover {
    text-decoration: none;
    transition: all .3s;
    outline: none;
    -webkit-tap-highlight-color: rgba(255,255,255,0);
}
a, button {
    cursor: pointer;
}.royhatdan_ot_ramkasi {
    padding: 7px;
    margin-bottom: 2px;
	border: 1px solid transparent;
}.krish_title_ramkasini_ichi {
	font-size: 26px;
    color: #fff;
    background-color: #18a10c;
    border-color: #d6e9c6;
}.krish_title_ramkasi {
    padding: 1px;
    margin-bottom: 2px;
	border: 1px solid transparent;
}.tagii {
color: #fff;
background: #fd6a69;
padding: 6px;
}.fon_orqaga_polni
  {
	  padding:10px;
	  background:#fbfcfd;
	  border:1px solid #f1f1f1;
  }.royhatdan_ot_ramkasini_ichi a{
	color: #fff;
}.user_1_ekra_fon_ana_a { 
          color: #ccc;
          padding:10px;
	  background:#9bf2fd;
	  border:1px solid #f1f1f1;
}


.user_1_ekra_fon_ana { 
          color: #ccc;
          padding:10px;
	  background:#fbfcfd;
	  border:1px solid #f1f1f1;
}.user_2_ekra_fon_ana { 
          color: #ccc;
          padding:8px;
	  background:#fbfcfd;
	  border:1px solid #f1f1f1;
}.user_2_ekra_fon_ana_img { 
color: #ccc; 
padding:3px;
 background:#fbfcfd;
 border:1px solid #f1f1f1;
 }.user_ekran_xat_kichik_img { 
background-image: url("/img/answered-h.png");
background-position: 0% -1px;
height: 16px;
position: absolute;
margin-left: 80%;
margin-top: 10px;
width: 16px;
z-index: 1;
}.user_ekran_xat_kichik_img:hover { 
background-image: url("/img/answered-h.png");
background-position: 0% -1px;
}.user_ekran_xat_katta_img{ 
background-image: url("/img/send@2x.png");
background-position: 0% -1px;
height: 40px;
position: absolute;
margin-left: 80%;
margin-top: 10px;
width: 48px;
z-index: 1;
}.user_ekran_xat_katta_img:hover { 
background-image: url("/img/send@2x.png");
background-position: 0% -1px;
}.user_2_ekra_fon_ana_img_a { 
color: #ccc; 
padding:3px;
 background:#2af9fd;
 border:1px solid #f1f1f1;
 }.user_7_ekra_fon_ana_a { 
          color: #ccc;
          padding:10px;
	  background:#9bf2fd;
	  border:1px solid #f1f1f1;
}


.user_7_ekra_fon_ana { 
          color: #ccc;
          padding:10px;
	  background:#fbfcfd;
	  border:1px solid #f1f1f1;
}.tashqari{
  display: inline-block;
    padding: 6px 12px;
    margin-bottom: 0;
    font-size: 14px;
    width: 100%;
    font-width: 100%;
    line-height: 1.42857143;
    text-align: center;
    white-space: nowrap;
    vertical-align: middle;
    -ms-touch-action: manipulation;
    touch-action: manipulation;
    cursor: pointer;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    background-image: none;
    border: 1px solid transparent;
    border-radius: 4px;
}.dumaloq
{
	
	text-shadow: 1px 1px 4px #000;
	color:#fff;
	
	margin-left:20px;
	margin-top:-100px;	
	font-size:16px;
}.dumaloq_7
{
	text-shadow: 1px 1px 4px #000;
	color:#fff;
	margin-left:20px;
	font-size:16px;
       margin: 20px;
}.ID_7d{
display: block !important;
margin-top:-200px;	
}.tepabg
{
	z-index:0;
        max-height:300px;
	color:#fff;
	width:100%;
}

.tepabg img
{		z-index:1;
	width:100%;
	max-height:300px;	
}@media (max-width:300px) and (min-width:100px) {
   .kotarr_7{
display: block !important;
 font-size: 68%; 
 width:80%;
 margin-left: -3%;
 margin-top: -100px;
}
.ID_7{
display: block !important;
margin-top:-120px;	
}
.ID_7_t
{ 
display: block !important;
 margin-top: -5px;	
}
.rasim_7{
 height: 140px;	
}
.rasim_7_o{
width: 60px;
height: 60px;	
}
	}
	@media (max-width:400px) and (min-width:300px) {
   .kotarr_7{
display: block !important;
 font-size: 68%; 
 width:80%;
 margin-left: -3%;
 margin-top: -100px;
}
.ID_7{
display: block !important;
margin-top:-120px;	
}
.ID_7_t
{ 
display: block !important;
 margin-top: 35px;	
}
.rasim_7{
 height: 140px;	
}
.rasim_7_o{
width: 60px;
height: 60px;	
}
	}
	@media (max-width:500px) and (min-width:400px) {
   .kotarr_7{
display: block !important;
 font-size: 68%; 
width:80%;
 margin-left: -3%;
 margin-top: -140px;
}
.ID_7{
display: block !important;
margin-top:-110px;	
}
.ID_7_t
{ 
display: block !important;
 margin-top: 40px;	
}
.rasim_7{
 height: 180px;	
}
.rasim_7_o{
width: 80px;
height: 80px;	
}
 }
	@media (max-width:755px) and (min-width:500px) {
      .kotarr_7{
display: block !important;
 font-size: 68%; 
width:80%;
 margin-left: 2%;
 margin-top: -160px;
}
.ID_7{
display: block !important;
margin-top:-110px;	
}
.ID_7_t
{ 
display: block !important;
 margin-top: 40px;	
}
.rasim_7{
 height: 200px;	
}
.rasim_7_o{
width: 100px;
height: 	100px;	
}
	}
	
	
	@media (max-width:998px) and (min-width:755px) {
      .kotarr_7{
display: block !important;
 font-size: 68%; 
width:80%;
 margin-left: 2%;
 margin-top: -200px;
}
.ID_7{
display: block !important;
margin-top:-110px;	
}
.ID_7_t
{ 
display: block !important;
 margin-top: 40px;	
}
.rasim_7{
 height: 250px;	
}
.rasim_7_o{
width: 140px;
height: 140px;	
}
	}



	@media (max-width:1100px) and (min-width:998px) {
      .kotarr_7{
display: block !important;
 font-size: 68%; 
width:80%;
 margin-left: 2%;
 margin-top: -260px;
}
.ID_7{
display: block !important;
margin-top:-110px;	
}
.ID_7_t
{ 
display: block !important;
 margin-top: 40px;	
}
.rasim_7{
 height: 350px;	
}
.rasim_7_o{
width: 200px;
height: 200px;	
}
	}
	

	@media (max-width:2900px) and (min-width:1100px) {
      .kotarr_7{
display: block !important;
 font-size: 68%; 
width:80%;
 margin-left: 2%;
 margin-top: -260px;
}
.ID_7{
display: block !important;
margin-top:-110px;	
}
.ID_7_t
{ 
display: block !important;
 margin-top: 40px;	
}
.rasim_7{
 height: 450px;	
}
.rasim_7_o{
width: 220px;
height: 220px;	
}
	}.ID_8_t { 
display: block !important;
 margin-top: 12px;
	}.dumaloqa_10 { 
text-shadow: 1px 1px 4px #000;
 color:#fff; margin-left:20px; 
margin-top:-195px;
font-size:16px;
 }@media (max-width:400px) and (min-width:100px) {
   .kotarr_12{
display: block !important;
 font-size: 68%; 
width:80%;
 margin-left: -3%;
 margin-top: -130px;
}

.ID_12{
display: block !important;
margin-top:-120px;	
}
.rasim_12{
 height: 140px;	
}
.rasim_12_o{
width: 70px;
height: 70px;
text-shadow: 1px 1px 1px #000;
color:#fff;
margin-left:20px;
font-size:16px;
margin: 20px;
border-radius: 15px;	

}
	}
	@media (max-width:500px) and (min-width:400px) {
   .kotarr_12{
display: block !important;
 font-size: 68%; 
width:80%;
 margin-left: 1%;
 margin-top: -160px;
}

.ID_12{
display: block !important;
margin-top:-140px;	
}
.rasim_12{
 height: 180px;	
}
.rasim_12_o{
width: 80px;
height: 80px;
text-shadow: 1px 1px 1px #000;
color:#fff;
margin-left:20px;
font-size:16px;
margin: 20px;
border-radius: 15px;	
}
 }
	@media (max-width:755px) and (min-width:500px) {
      .kotarr_12{
display: block !important;
 font-size: 68%; 
width:80%;
 margin-left: 2%;
 margin-top: -150px;
}

.ID_12{
display: block !important;
margin-top:-180px;	
}
.rasim_12{
 height: 190px;	
}
.rasim_12_o{
width: 100px;
height: 	100px;
text-shadow: 1px 1px 1px #000;
color:#fff;
margin-left:20px;
font-size:16px;
margin: 20px;
border-radius: 20px;	
}
	}
	
	
	@media (max-width:998px) and (min-width:755px) {
      .kotarr_12{
display: block !important;
 font-size: 68%; 
width:80%;
 margin-left: 2%;
 margin-top: -210px;
}

.ID_12{
display: block !important;
margin-top:-220px;	
}
.rasim_12{
 height: 250px;	
}
.rasim_12_o{
width: 140px;
height: 140px;	
text-shadow: 1px 1px 1px #000;
color:#fff;
margin-left:20px;
font-size:16px;
margin: 20px;
border-radius: 20px;
}
	}



	@media (max-width:1100px) and (min-width:998px) {
      .kotarr_12{
display: block !important;
 font-size: 68%; 
width:80%;
 margin-left: 2%;
 margin-top: -260px;
}

.ID_12{
display: block !important;
margin-top:-280px;	
}
.rasim_12{
 height: 350px;	
}
.rasim_12_o{
width: 200px;
height: 200px;	
text-shadow: 1px 1px 1px #000;
color:#fff;
margin-left:20px;
font-size:16px;
margin: 20px;
border-radius: 20px;
}
	}
	

	@media (max-width:2900px) and (min-width:1100px) {
      .kotarr_12{
display: block !important;
 font-size: 68%; 
width:80%;
 margin-left: 2%;
 margin-top: -260px;
}

.ID_12{
display: block !important;
margin-top:-300px;	
}
.rasim_12{
 height: 550px;	
}
.rasim_12_o{
width: 220px;
height: 220px;
text-shadow: 1px 1px 1px #000;
color:#fff;
margin-left:20px;
font-size:16px;
margin: 20px;
border-radius: 20px;
}
	}@media (max-width:400px) and (min-width:100px) {
   .kotarr_13{
display: block !important;
 font-size: 68%; 
width:80%;
 margin-left: -3%;
 margin-top: -100px;
}

.ID_13{
display: block !important;
margin-top:-110px;	
}
.rasim_13{
 height: 140px;	
}
.rasim_13_o{
width: 70px;
height: 70px;	
}
	}
	@media (max-width:500px) and (min-width:400px) {
   .kotarr_13{
display: block !important;
 font-size: 68%; 
width:80%;
 margin-left: -3%;
 margin-top: -140px;
}

.ID_13{
display: block !important;
margin-top:-120px;	
}
.rasim_13{
 height: 180px;	
}
.rasim_13_o{
width: 80px;
height: 80px;	
}
 }
	@media (max-width:755px) and (min-width:500px) {
      .kotarr_13{
display: block !important;
 font-size: 68%; 
width:80%;
 margin-left: 2%;
 margin-top: -160px;
}

.ID_13{
display: block !important;
margin-top:-140px;	
}
.rasim_13{
 height: 200px;	
}
.rasim_13_o{
width: 100px;
height: 	100px;	
}
	}
	
	
	@media (max-width:998px) and (min-width:755px) {
      .kotarr_13{
display: block !important;
 font-size: 68%; 
width:80%;
 margin-left: 2%;
 margin-top: -200px;
}

.ID_13{
display: block !important;
margin-top:-180px;	
}
.rasim_13{
 height: 250px;	
}
.rasim_13_o{
width: 140px;
height: 140px;	
}
	}



	@media (max-width:1100px) and (min-width:998px) {
      .kotarr_13{
display: block !important;
 font-size: 68%; 
width:80%;
 margin-left: 2%;
 margin-top: -260px;
}

.ID_13{
display: block !important;
margin-top:-240px;	
}
.rasim_13{
 height: 350px;	
}
.rasim_13_o{
width: 200px;
height: 200px;	
}
	}
	

	@media (max-width:2900px) and (min-width:1100px) {
      .kotarr_13{
display: block !important;
 font-size: 68%; 
width:80%;
 margin-left: 2%;
 margin-top: -230px;
}

.ID_13{
display: block !important;
margin-top:-260px;	
}
.rasim_13{
 height: 550px;	
}
.rasim_13_o{
width: 220px;
height: 220px;	
}
	}.yashil_con {
    display: inline-block;
    min-width: 10px;
    padding: 1px 4px;
   font-size: 12px;
    font-weight: 700;
    line-height: 1;
    color: #fff;
    text-align: center;
    white-space: nowrap;
    vertical-align: middle;
    background-color: green;
    border-radius: 10px;
}.smail_k{
 display: inline-block;
 min-width: 10px;
 padding: 3px 7px;
 font-size: 12px;
 font-weight: 700;
 line-height: 1; color: #fff; 
text-align: center; white-space: nowrap;
 vertical-align: middle;
 background-color: green;
 border-radius: 10px;
 }.strike_k{
 display: inline-block; 
min-width: 10px; 
padding: 3px 7px;
 font-size: 12px; font-weight: 700;
 line-height: 1; color: #fff; 
text-align: center; 
white-space: nowrap; 
vertical-align: middle;
 background-color: #ccc; 
border-radius: 10px;
}.index_congif
{ 
float:right; padding: 2px; width: 18px; background:red; color: #fff; border-radius: 5px;
}.editable,
.secondEditable
 {
    outline: none;
    margin: 0 0 20px 0;
    background-color: #FFF;
    padding: 0px 5px 0px 5px;
    border: 1px solid #424141;
}@media (max-width:400px) and (min-width:100px) {
   .kotarr_11{
display: block !important;
 font-size: 68%; 
width:80%;
 margin-left: -3%;
 margin-top: -100px;
}
.ff{
	display: none;
}

.ID_11{
display: block !important;
margin-top:-110px;	
}
.rasim_11{
 height: 140px;	
}
.rasim_11_o{
width: 70px;
height: 70px;	
}
	}
	@media (max-width:500px) and (min-width:400px) {
   .kotarr_11{
display: block !important;
 font-size: 68%; 
width:80%;
 margin-left: -3%;
 margin-top: -140px;
}
.ff{
	display: none;
}
.ID_11{
display: block !important;
margin-top:-120px;	
}
.rasim_11{
 height: 180px;	
}
.rasim_11_o{
width: 80px;
height: 80px;	
}
 }
	@media (max-width:755px) and (min-width:500px) {
      .kotarr_11{
display: block !important;
 font-size: 68%; 
width:80%;
 margin-left: 2%;
 margin-top: -160px;
}
.fff{
	display: none;
}
.ID_11{
display: block !important;
margin-top:-140px;	
}
.rasim_11{
 height: 200px;	
}
.rasim_11_o{
width: 100px;
height: 	100px;	
}
	}
	
	
	@media (max-width:998px) and (min-width:755px) {
      .kotarr_11{
display: block !important;
 font-size: 68%; 
width:80%;
 margin-left: 2%;
 margin-top: -200px;
}
.fff{
	display: none;
}
.ID_11{
display: block !important;
margin-top:-180px;	
}
.rasim_11{
 height: 250px;	
}
.rasim_11_o{
width: 140px;
height: 140px;	
}
	}



	@media (max-width:1100px) and (min-width:998px) {
      .kotarr_11{
display: block !important;
 font-size: 68%; 
width:80%;
 margin-left: 2%;
 margin-top: -260px;
}
.fff{
	display: none;
}
.ID_11{
display: block !important;
margin-top:-240px;	
}
.rasim_11{
 height: 350px;	
}
.rasim_11_o{
width: 200px;
height: 200px;	
}
	}
	

	@media (max-width:2900px) and (min-width:1100px) {
      .kotarr_11{
display: block !important;
 font-size: 68%; 
width:80%;
 margin-left: 2%;
 margin-top: -260px;
}
.fff{
	display: none;
}
.ID_11{
display: block !important;
margin-top:-260px;	
}
.rasim_11{
 height: 550px;	
}
.rasim_11_o{
width: 220px;
height: 220px;	
}
	}@media (max-width:400px) and (min-width:100px) {
   .kotarr_8{
display: block !important;
 font-size: 68%; 
 width:80%;
 margin-left: -3%;
 margin-top: -100px;
}
.ff{
	display: none;
}

.ID_8{
display: block !important;
margin-top:-110px;	
}
.rasim_8{
 height: 140px;	
}
.rasim_8_o{
width: 60px;
height: 60px;	
}
	}
	@media (max-width:500px) and (min-width:400px) {
   .kotarr_8{
display: block !important;
 font-size: 68%; 
width:80%;
 margin-left: -3%;
 margin-top: -140px;
}
.ff{
	display: none;
}
.ID_8{
display: block !important;
margin-top:-120px;	
}
.rasim_8{
 height: 180px;	
}
.rasim_8_o{
width: 80px;
height: 80px;	
}
 }
	@media (max-width:755px) and (min-width:500px) {
      .kotarr_8{
display: block !important;
 font-size: 68%; 
width:80%;
 margin-left: 2%;
 margin-top: -160px;
}
.fff{
	display: none;
}
.ID_8{
display: block !important;
margin-top:-140px;	
}
.rasim_8{
 height: 200px;	
}
.rasim_8_o{
width: 100px;
height: 	100px;	
}
	}
	
	
	@media (max-width:998px) and (min-width:755px) {
      .kotarr_8{
display: block !important;
 font-size: 68%; 
width:80%;
 margin-left: 2%;
 margin-top: -200px;
}
.fff{
	display: none;
}
.ID_8{
display: block !important;
margin-top:-180px;	
}
.rasim_8{
 height: 250px;	
}
.rasim_8_o{
width: 140px;
height: 140px;	
}
	}



	@media (max-width:1100px) and (min-width:998px) {
      .kotarr_8{
display: block !important;
 font-size: 68%; 
width:80%;
 margin-left: 2%;
 margin-top: -260px;
}
.fff{
	display: none;
}
.ID_8{
display: block !important;
margin-top:-240px;	
}
.rasim_8{
 height: 350px;	
}
.rasim_8_o{
width: 200px;
height: 200px;	
}
	}
	

	@media (max-width:2900px) and (min-width:1100px) {
      .kotarr_8{
display: block !important;
 font-size: 68%; 
width:80%;
 margin-left: 2%;
 margin-top: -260px;
}
.fff{
	display: none;
}
.ID_8{
display: block !important;
margin-top:-260px;	
}
.rasim_8{
 height: 550px;	
}
.rasim_8_o{
width: 220px;
height: 220px;	
}
	}@media (max-width:400px) and (min-width:100px) {
.ID_9{
display: block !important;
margin-top:-110px;	
}
.rasim_9{
 height: 200px;	
}
.rasim_9_o{
width: 90px;
height: 90px;	
}
.ff{
	display: none;
}
.zxc{
	display: block !important;
margin-top: 60px;
}

	}
	@media (max-width:500px) and (min-width:400px) {
.ID_9{
display: block !important;
margin-top:-110px;	
}
.rasim_9{
 height: 200px;	
}
.rasim_9_o{
width: 100px;
height: 100px;	
}
.ff{
	display: none;
}
.zxc{
	display: block !important;
margin-top: 80px;
}
 }
	@media (max-width:755px) and (min-width:500px) {
.ID_9{
display: block !important;
margin-top:-110px;	
}
.rasim_9{
 height: 200px;	
}
.rasim_9_o{
width: 130px;
height: 130px;	
}
.fff{
	display: none;
}
.zxc{
	display: block !important;
margin-top: 50px;
}

	}
	
	
	@media (max-width:998px) and (min-width:755px) {
  .ID_9{
display: block !important;
margin-top:-110px;	
}
.rasim_9{
 height: 240px;	
}
.rasim_9_o{
width: 140px;
height: 140px;	
}
.fff{
	display: none;
}
.zxc{
	display: block !important;
margin-top: 40px;
}
	}



	@media (max-width:1100px) and (min-width:998px) {
.ID_9{
display: block !important;
margin-top:-110px;	
}
.rasim_9{
 height: 250px;	
}
.rasim_9_o{
width: 150px;
height: 150px;	
}
.fff{
	display: none;
}
.zxc{
	display: block !important;
margin-top: 30px;
}
	}
	

	@media (max-width:2900px) and (min-width:1100px) {
.ID_9{
display: block !important;
margin-top:-110px;	
}
.rasim_9{
 height: 300px;	
}
.rasim_9_o{
width: 160px;
height: 160px;	
}
.fff{
	display: none;
}
	}@media (max-width:300px) and (min-width:100px) {
   .kotarr_6{
display: block !important;
 font-size: 68%; 
 width:80%;
 margin-left: -3%;
 margin-top: -100px;
}
.ID_6{
display: block !important;
margin-top:-30px;	
}
.ID_6_t
{ 
display: block !important;
 margin-top: -5px;	
}
.rasim_6{
 height: 140px;	
}
.rasim_6_o{
width: 60px;
height: 60px;	
}
	}
	@media (max-width:400px) and (min-width:300px) {
   .kotarr_6{
display: block !important;
 font-size: 68%; 
 width:80%;
 margin-left: -3%;
 margin-top: -100px;
}
.ID_6{
display: block !important;
margin-top:-30px;	
}
.ID_6_t
{ 
display: block !important;
 margin-top: -5px;	
}
.rasim_6{
 height: 140px;	
}
.rasim_6_o{
width: 60px;
height: 60px;	
}
	}
	@media (max-width:500px) and (min-width:400px) {
   .kotarr_6{
display: block !important;
 font-size: 68%; 
width:80%;
 margin-left: -3%;
 margin-top: -140px;
}
.ID_6{
display: block !important;
margin-top:-5px;	
}
.ID_6_t
{ 
display: block !important;
 margin-top: 40px;	
}
.rasim_6{
 height: 180px;	
}
.rasim_6_o{
width: 80px;
height: 80px;	
}
 }
	@media (max-width:755px) and (min-width:500px) {
      .kotarr_6{
display: block !important;
 font-size: 68%; 
width:80%;
 margin-left: 2%;
 margin-top: -160px;
}
.ID_6{
display: block !important;
margin-top:-5px;	
}
.ID_6_t
{ 
display: block !important;
 margin-top: 40px;	
}
.rasim_6{
 height: 200px;	
}
.rasim_6_o{
width: 100px;
height: 	100px;	
}
	}
	
	
	@media (max-width:998px) and (min-width:755px) {
      .kotarr_6{
display: block !important;
 font-size: 68%; 
width:80%;
 margin-left: 2%;
 margin-top: -200px;
}
.ID_6{
display: block !important;
margin-top:-5px;	
}
.ID_6_t
{ 
display: block !important;
 margin-top: 40px;	
}
.rasim_6{
 height: 250px;	
}
.rasim_6_o{
width: 140px;
height: 140px;	
}
	}



	@media (max-width:1100px) and (min-width:998px) {
      .kotarr_6{
display: block !important;
 font-size: 68%; 
width:80%;
 margin-left: 2%;
 margin-top: -260px;
}
.ID_6{
display: block !important;
margin-top:-5px;	
}
.ID_6_t
{ 
display: block !important;
 margin-top: 40px;	
}
.rasim_6{
 height: 350px;	
}
.rasim_6_o{
width: 200px;
height: 200px;	
}
	}
	

	@media (max-width:2900px) and (min-width:1100px) {
      .kotarr_6{
display: block !important;
 font-size: 68%; 
width:80%;
 margin-left: 2%;
 margin-top: -260px;
}
.ID_6{
display: block !important;
margin-top:-5px;	
}
.ID_6_t
{ 
display: block !important;
 margin-top: 40px;	
}
.rasim_6{
 height: 450px;	
}
.rasim_6_o{
width: 220px;
height: 220px;	
}
	}.tush{
margin: 25px;	
}#iconka_qlassik_ru{
width: 18px;
height: 18px;
margin-top: 3px;
}
.postga_ddd {
    color: #333;
    background-color: #ccc;
    border-color: #f1f1f1;
}
.tel_qil {
    border-width: 0;
    position: fixed;
    right: 30px;
    z-index: 99;
    -webkit-transition-duration: .3s;
    transition-duration: .3s;
    opacity: 0;
    filter: alpha(opacity=0);
    bottom: -24px;
    visibility: hidden;
}
 .chiziq_t {
                    margin-top: -20px;
					}					
					.chiziqs {
                    background-color: #FFF;
                    position: relative;
                    margin: 0;
                    padding: 2px 2px 4px;
					}
					.chiz{
                    padding-bottom: 3px;
                    margin: 4px 0 4px;
					border-bottom: 3px solid #eee;
					}
  </style>


<?if ($korga){?>
  <div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
							
							<i class="ace-icon fa fa-home home-icon"></i>
								<a href="/"><?=__('Bosh sahifa')?></a>
							</li>

							<?echo' '.$this->section($korga, '<li  class="active"><a href="{1}"> {0} </a></li> ').''; ?>  
                           
						</ul>
						
						
						
						

						
						</div>
					</div>
					

			
  <?}?> 
  
  
  <?if ($grupaga){?>
  <div id="qani"> <?echo' '.$this->section($grupaga, '<div  class="gruppa" role="alert"><a href="{1}">  {0} </a></div>').''; ?>  </div>
  <?}?> 







<? echo' '.$this->section($returns, '<div class="royhatdan_ot_ramkasi royhatdan_ot_ramkasini_ichi" role="alert"><a  href="{1}"> » {0} </a></div>', true) .''; ?>
<?echo' '.$this->section($actions, '<div class="royhatdan_ot_ramkasi royhatdan_ot_ramkasini_ichi" role="alert"><a href="{1}"> » {0} </a></div> ').''; ?> 
<?
if ($user->group >= '2'){
echo '<div  class="royhatdan_ot_ramkasi royhatdan_ot_ramkasini_ichi" role="alert">
<a  href="/admin"> '.sm_icon(qlassik_ru('23')).'   '.__('Adminka').' </a> 
</div>';
}
$d = mysql_result(mysql_query("SELECT COUNT(*) FROM `users`"), 0);
$c = mysql_result(mysql_query("SELECT COUNT(*) FROM `users_online`"), 0);
$f = $d - $c;
echo'<div class="royhatdan_ot_ramkasi royhatdan_ot_ramkasini_ichi" role="alert">
<a  href="/">'.sm_icon(qlassik_ru('21')).' '.__('Bosh sahifa').'</a> 
</div>
<div class="royhatdan_ot_ramkasi royhatdan_ot_ramkasini_ichi" role="alert"><a href="/azolar.html">'.sm_icon(qlassik_ru('22')).' '.__('Azolar').'</a> '.$d.' (<a href="/mexmon.html">'.mysql_result(mysql_query("SELECT COUNT(*) FROM `users_online`"), 0).'/'.$f.'</a>)</div>
<div style="text-align:center"><div class="tagii"><small>'.$uzcms->sayt_p.'</small></div></div>';
?>
			
			
			
			<div style="width: 95%; margin: 8px; margin-left: 2%;"  class="chiz"></div> <a href="#" id="btn-scroll-up" class="btn-scroll-up btn btn-sm btn-inverse">
				<i class="ace-icon fa fa-angle-double-up icon-only bigger-110"></i>
			</a><div style="text-align: center; margin-top: 4px;">
				<div class="footer-content">
						<span class="bigger-120">
							<?=$copyright?>
						</span>

						&nbsp; &nbsp;
						<span class="action-buttons">
							<a href="/<?=$uzcms->telegram; ?>">
								<i class="ace-icon fa  fa-location-arrow light-blue bigger-150"></i>
							</a>

							<a href="/<?=$uzcms->mail; ?>">
								<i class="ace-icon fa fa-at text-primary bigger-150"></i>
							</a>

							<a href="/<?=$uzcms->yotub; ?>">
								<i class="ace-icon fa fa-video-camera orange bigger-150"></i>
							</a>
						</span>
					</div>
					</div>
					</div>
				
			

			