﻿    <?

	
$q = mysql_query("SELECT * FROM `slayt` WHERE  `sayti` = '".$uzcms->sayti."' AND `azo` = '".$uzcms->azo."' AND `id` = '".$uzcms->slayt."' ORDER BY `id` DESC LIMIT 1");
while ($us = mysql_fetch_assoc($q)) {
echo $us['cod'];
}


	
	
	?>	
	