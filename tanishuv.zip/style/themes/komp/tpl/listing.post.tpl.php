<style>
@media (max-width:500px) and (min-width:100px) {
.zzzz{
	display: block !important; margin-top: 6px;
	margin-left: -30px;

}
    }
	@media (min-width:500px) and (max-width:2700px) {
    .zzzz{
			display: block !important; margin-top: 6px;

	}
    }
	
#siyyyy{    
	margin: 4px;
    }
	</style>
<div id="siyyyy"><?
$iefix = ($url && $uzcms->ie_ver && $uzcms->ie_ver < 10) ? 'onclick="location.href = \'' . $url . '\'"' : '';
$post_time = $time ? '<span class="vaqt">' . $time . '</span>' : '';
$post_counter = $counter ? '<span class="counter gradient_grey invert border">' . $counter . '</span>' : '';
$post_actions = '<span class="actions">' . $this->section($actions, '<a href="{url}"><img src="{icon}" alt="" /></a>') . '</span>';
?>
<?= ($url ? '<a href="' . $url . '" class="' : '<div class="') . '' . ($hightlight ? ' hightlight' : '') . '" id="' . $id . '"    >' ?>
     <table <?= $iefix ?> cellspacing="0" callpadding="0" width="100%" >
        <? if ($image) { ?>
            <tr class="ana">
                <td width="15%"  rowspan="4">
                    <img src="<?= $image ?>" alt="" />
			 </td>
                <td width="80%"  class="qaniz" class="men2">
                    <?= $title ?>
                    <?= $post_counter ?>
                </td>

                <td width="5%"  class="qaniz" style ="text-align: right;" class="chap">
                    <?= $post_time ?>
                    <?= $post_actions ?>
                </td>
            </tr>
        <? } elseif ($icon) { ?>
            <tr>
                   
               
                <td width="100%" class="royhatdan_ot_ramkasi postga_ddd">
                   »       <?= $title ?>
				   <?if($counter){?>
                   <center  style="float:right; clear:left; min-width: 15px; padding: 4px; color: #fff;" class="smail_k">
				   <?= $post_counter ?><center>
		<?}?>
                </td>
                </td>

                <td style ="text-align: right;" class="chap">
                   
            </tr>
        <? } else { ?>
            <tr>
                <td class="men2">
                    <?= $title ?>
                    <?= $post_counter ?>
                </td>

                <td style ="text-align: right;" class="chap">
                    <?= $post_time ?>
                    <?= $post_actions ?>
                </td>
            </tr>
        <? } ?>

        <? if ($content) { ?>
            <tr>
                <td class="men2" colspan="10">
                    <?= $content ?>
                </td>
            </tr>
        <? } ?>

        <? if ($bottom) { ?>
            <tr>
                <td class="bottom" colspan="10">
                    <?= $bottom ?>
                </td>
            </tr>
        <? } ?>
    </table>
<?=
$url ? '</a>' : '</div>'?></div>