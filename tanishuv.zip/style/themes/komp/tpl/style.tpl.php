 <? 

 if ($user->input){
 $input = $user->input; 
 }else{
 $input = $uzcms->input;  
 }
 
 ?>
 <style type="text/css">
 
input[type="submit"] {
outline:none;
font-family: Arial;
background:  <?=$input?>;
color: #fff;
padding: 5px 8px;
margin:2px;
border: 0px;
cursor: pointer;
}
h1,h2,h3,h4,h5,.h1,.h2,.h3,.h4,.h5 {
	margin: 2em 0 .6em 0;
	letter-spacing: -0.01em;
	line-height: normal;
	font-weight: bold;
	text-rendering: optimizeLegibility;
}
h1, .h1 { font-size: 23px; }
h2, .h2 { font-size: 21px; }
h3, .h3 { font-size: 20px; }
h4, .h4 { font-size: 18px; }
h5, .h5 { font-size: 16px; }

.addcomment h3 { margin: .3em 0 .6em 0; }

.strike { text-decoration: line-through; }
.nobr { white-space: nowrap; }
.hide { display: none; }
.title_hide { left: -9999px; position: absolute; top: -9999px; overflow: hidden; width: 0; height: 0; }
.uline { text-decoration: underline; }
.strike { text-decoration: line-through; }
.justify { text-align: justify; }
.center { text-align: center; }
.left { float: left; }
.right { float: right; }
	fieldset { border: 1px solid rgba(0,0,0,0.1); padding: 20px; margin-bottom: 25px; }
	fieldset legend { font-weight: bold; }

.grey { color: #919191; }
.grey a { color: inherit; }
.grey a:hover { color: #353535; }
.blue { color: #9F9F9F; }
.orange { color: #e85319; }

sup { vertical-align: super; font-size: smaller; }
sub { vertical-align: sub; font-size: smaller; }
.over { display: inline-block; vertical-align: middle; max-width: 100%; white-space: nowrap; text-overflow: ellipsis; overflow: hidden; }
a .over { cursor: pointer; }

.cover { background-position: 50% 50%; background-repeat: no-repeat; -webkit-background-size: cover; background-size: cover; }

ul { padding-left: 25px; list-style: disc outside; }
ol { padding-left: 25px; list-style: decimal outside; }

	strong, b { font-weight: bold }
	em, cite, i { font-style: italic }
	caption { text-align: left }
	th, td { vertical-align: middle }
	small, .small { font-size: .9em; }
	hr { height: 0; border: 0; border-top: 2px solid #eeeeef; -moz-box-sizing: content-box; box-sizing: content-box; margin: 20px 0; }

	.clr { clear: both }
	.clrfix:after { clear: both; content: ""; display: table; }

@media only screen and (min-width: 601px) {
.grid_1_2, .grid_1_4 {
	float: left; margin-right: 4%;
	-moz-box-sizing: border-box; -webkit-box-sizing: border-box; box-sizing: border-box;
}
	.grid_1_2 { width: 48%; }
	.grid_1_4 { width: 22%; }
	.grid_last { margin-right: 0; }
}

.cccc { position: relative; }
	.cccc-menu, .cccc-form {
		min-width: 160px; padding: 12px 0; border-radius: 2px; margin-top: 5px !important; display: none; z-index: 99; position: absolute;
		box-shadow: 0 8px 40px -10px rgba(0,0,0,0.3); border: 1px solid #e6e6e6; border-color: rgba(0,0,0,0.1); background-clip: padding-box;
		background-color: #fff;
	}
	.cccc-menu { list-style: none; margin: 0; }
	.cccc-form { padding: 40px; }

	.cccc-menu.dot:before, .cccc-form.dot:before {
		content: "";
		position: absolute;
		top: 0; left: 50%;
		margin: -11px 0 0 -11px;
		width: 22px; height: 22px;
		border-radius: 50%;
		background-color: #fff;
	}

	/* DropMenu */
	.cccc-menu li a { height: 1%; padding: 5px 20px; border: 0 none; display: block; white-space: nowrap; text-decoration: none; color: inherit; }
	.cccc-menu li a:hover { background-color: #e05b37; color: #fff; }
	.open .cccc-menu, .open .cccc-form { display: block; }
.fade { opacity: 0; -webkit-transition: opacity 0.15s linear; transition: opacity 0.15s linear; }
	.fade.in { opacity: 1; }
	.collapse { overflow: hidden; height: 0; width: 0; display: inline-block; }
	.collapse.in { display: block; width: auto; height: auto; }
	.collapsing { position: relative; height: 0; overflow: hidden; -webkit-transition: height 0.35s ease; transition: height 0.35s ease; }

.tab-content > .tab-pane { display: none; }
	.tab-content > .active { display: block; }



/* --- Layout --- */
xxx { background: #ededed; }
.wrp { max-width: 1437px; }

/* --- Структура --- */
.conteiner:after, #tepa:after { clear: both; content: ""; display: table; }
.midside {
	float: left;
	padding: 0 350px 0 13%;
	width: 100%;
	-moz-box-sizing: border-box; -webkit-box-sizing: border-box; box-sizing: border-box;
}
.rightside {
	float: right;
	width: 300px;
	padding: 0 25px;
	margin-left: -350px;
	position: relative;
}
.chap{
	float: right;
	width: 300px;
	padding: 0 25px;
	margin-left: -350px;
	position: relative;
}
/* --- Шапка сайта --- */
#tepaga { margin-bottom: 25px; }
#tepaga, #tepaga_menu { height: 80px; }
.tepaga {
	width: 100%; height: 0; z-index: 22;
	position: fixed;
	left: 0; top: 0;
}
	.tepaga .midside { height: 0; }
	#tepaga_menu {
		position: relative; z-index: 15;
		padding: 0 25px; 
		background-color: #9F9F9F;
		border-radius: 0 0 2px 2px;
		box-shadow: 0 1px 3px 0 rgba(0,0,0,0.2); -webkit-box-shadow: 0 1px 3px 0 rgba(0,0,0,0.2);
		display: flex;
		align-items: center;
		justify-content: space-between;
	}

/* Кнопка включения меню */
#mobile_menu_btn {
	position: absolute;
	left: 0; top: 0;
	width: 40px; height: 80px;
	text-transform: lowercase;
	white-space: nowrap;
	border: 0 none;
	background-color: transparent;
	color: #fff;
	padding: 5px;
	text-align: center;
	border-right: 1px solid rgba(255,255,255,0.1)
}
	#mobile_menu_btn > *, #mobile_menu_btn { cursor: pointer; }
	.menu_toggle { display: inline-block; vertical-align: middle; width: 18px; height: 18px; margin: -2px 6px; position: relative; }
	.menu_toggle > i {
		height: 2px; width: 100%;
		background-color: #fff;
		position: absolute;
		left: 0; top: 0;
		-webkit-transition: all ease .2s; transition: all ease .2s;
	}
	.mt_1 { margin-top: 2px; }
	.mt_2 { margin-top: 8px; }
	.mt_3 { margin-top: 14px; }
	.menu_toggle__title { display: none; }
	.mobile-menu_open #mobile_menu_btn .mt_1 {
		-webkit-transform: rotate(-45deg); transform: rotate(-45deg);
	}
	.mobile-menu_open #mobile_menu_btn .mt_2 { opacity: 0; }
	.mobile-menu_open #mobile_menu_btn .mt_3 {
		-webkit-transform: rotate(45deg); transform: rotate(45deg);
	}

/* Логотип */
.logotype {
	white-space: nowrap;
	color: #fff;
	text-decoration: none !important;
	display: flex;
	align-items: center;
	justify-content: space-around;
	height: 80px;
}
	.logotype .logo_title {
		margin: 0 0 0 18px;
		font-size: 20px;
		line-height: 34px;
		font-weight: normal;
	}
	.logotype .icon-logo { fill: #fff; }

	/* Меню в Шапке */
	#top_menu { margin: 0 25px; flex: 1 auto; white-space: nowrap; text-align: center; cursor: default; }
	#top_menu > a {
		text-decoration: none !important;
		display: inline-block;
		color: #fff;
		position: relative;
		z-index: 2;
		padding: 10px 3%;
		opacity: .8;
	}
	#top_menu > a:after {
		content: "";
		position: absolute;
		left: 50%; top: 50%;
		margin: -5px 0 0 -5px;
		width: 10px; height: 10px;
		border-radius: 100%;
		background-color: #fff;
		overflow: hidden;
		opacity: 0;
	}
	@-webkit-keyframes sun {
		0% { margin: -5px 0 0 -5px; width: 10px; height: 10px; opacity: 0; }
		50% { margin: -50px 0 0 -50px; width: 100px; height: 100px; opacity: .15; } 
		100% { margin: -80px 0 0 -80px; width: 160px; height: 160px; opacity: 0; }
	}
	@keyframes sun {
		0% { margin: -5px 0 0 -5px; width: 10px; height: 10px; opacity: 0; }
		50% { margin: -50px 0 0 -50px; width: 100px; height: 100px; opacity: .15; } 
		100% { margin: -80px 0 0 -80px; width: 160px; height: 160px; opacity: 0; }
	}

	#top_menu > a:hover { z-index: 1; opacity: 1; }
	#top_menu > a:hover:after {
		-webkit-animation: sun .3s ease;
		animation: sun .3s ease;
	}

	#top_menu > a.active { cursor: default; opacity: 1; }
	#top_menu > a.active:before {
		content: "";
		position: absolute;
		left: 50%; top: 100%;
		width: 4px; height: 4px;
		margin: -2px 0 0 -2px;
		border-radius: 50%;
		background-color: #fff;
	}
	#top_menu > a.active:after { display: none; }

/* Авторизация */
#login_pane {
	list-style: none;
	padding: 0; margin: 0;
}
	#login_pane > li > .btn-border {
		border-color: rgba(255,255,255,0.2);
		color: #fff;
		white-space: nowrap;
	}
	#login_pane > li > .btn-border:hover {
		border-color: #fff;
		box-shadow: inset 0 0 0 2px rgba(255,255,255,0.2); -webkit-box-shadow: inset 0 0 0 2px rgba(255,255,255,0.2);
	}
	#login_pane > li > .btn-border .over { max-width: 120px; margin-top: -2px; }
	#login_pane > li > .btn-border > .pm_num { margin-top: -3px; vertical-align: middle; display: inline-block; }
	.pm_num {
		font-size: 11px;
		background-color: #fff;
		border-radius: 10px;
		min-width: 12px; height: 12px;
		line-height: 13px;
		margin: -2px -14px 0 12px;
		padding: 4px;
		color: #9F9F9F;
		text-align: center;
		vertical-align: middle;
	}

	/* Форма входа */
	#login_pane .cccc-form {
		text-align: center;
		left: 50%;
		padding: 39px; margin-left: -200px;
		width: 320px;
	}
	.cccc-form .soc_links { margin: 0; }
	.cccc-form .soc_links > a { margin-bottom: 20px; }
	.login_form {
		list-style: none;
		padding: 0; margin: 0;
		border-bottom: 1px solid #efefef;
	}
	.login_form > li {
		border-top: 1px solid #efefef;
		display: block;
		position: relative;
	}
	.login_form > li > label { display: none; }
	.login_form > li > input {
		border: 0 none;
		padding: 19px; padding-left: 23px;
		border-radius: 0;
		background-color: transparent;
		width: 100%; height: 60px;
	}
	.login_form > li > .icon {
		position: absolute;
		left: 0; top: 50%;
		margin: -7px 0 0 0;
		height: 14px; width: 1em;
	}
	.login_form > li.login_input-btn > input { padding-right: 65px; }
	.login_form > li.login_input-btn > .btn {
		position: absolute;
		right: 0; top: 50%;
		margin-top: -18px; padding: 0;
		width: 54px;
	}
	.login_form__foot { text-align: left; margin-top: 20px; }

	/* При успешной авторизации */
	.cccc-form.logged:after {
		content: "";
		position: absolute;
		left: 0; top: 0;
		width: 100%; height: 99px;
		z-index: -1;
	}
		.cccc-form.logged:before, .cccc-form.logged:after { background-color: #f7f7f7; }
		.login_pane__info .avatar { margin: 12px 0; }
		.login_pane__menu {
			list-style: none;
			padding: 0; margin: 25px 0;
			text-align: left;
			border-bottom: 1px solid #efefef;
		}
		.login_pane__menu li a {
			color: inherit;
			text-decoration: none !important;
			padding: 14px 0; display: block;
			border-top: 1px solid #efefef;
		}
		.login_pane__menu li a:hover { color: #9F9F9F; }
		
		.login_pane__foot { text-align: left; }
		.login_pane__foot .plus_icon { margin: -3px 5px 0 0; }


/* Меню Категорий */
@media only screen and (min-width: 601px) {
#cat_menu {
	float: left;
	width: 13%;
	position: relative;
	z-index: 10;
	margin-top: 105px;
}
	.cat_menu a, .cat_menu a:after { -webkit-transition: all ease .22s; transition: all ease .22s; }
	.cat_menu a {
		display: block;
		padding: 6% 10px;
		color: #5a5a5a;
		text-decoration: none !important;
		position: relative;
	}
	.cat_menu a:hover { color: #9F9F9F; }
	.cat_menu a:before, .cat_menu a:after {
		content: "";
		position: absolute;
		left: 0; top: 0; bottom: 0;
		background-color: #5a5a5a;
		width: 0; height: auto;
	}
	.cat_menu a:hover:after { width: 5px; background-color: #9F9F9F; }

	.cat_menu a.active { cursor: default; color: inherit; }
	.cat_menu a.active:after { display: none; }
	.cat_menu a.active:before { width: 5px; }
}

.cat_menu ul {
  display: block;
  margin: 0;
  padding: 0;
  list-style: none;
}

.cat_menu ul ul {
  padding-left: 10px;
}
/* Мы в Соц.сетях */

/* --- Контент --- */
#content, .content_top { position: relative; }

/* --- Сортировка и Хлебные крошки --- */
.pagetools {
	border: 1px solid #d6d6d6;
	border-radius: 2px;
	margin-bottom: 25px;
	position: relative;
	padding-left: 8%;
	width: 100%; height: 52px;
	overflow: hidden;
	font-size: .9em;
	-moz-box-sizing: border-box; -webkit-box-sizing: border-box; box-sizing: border-box;
}
	#combo-tools .pagetools_in { 
		height: 100px;
		-webkit-transition: all .3s ease .2s; transition: all .3s ease .2s;
	}
	.pagetools_in { color: #919191; }
	.sortbar_in, .speedbar { display: block; height: 22px; padding: 14px 25px; line-height: 22px; }
	.pagetools_back {
		position: absolute;
		left: 0; top: 0;
		width: 8%; height: 50px;
		border-right: 1px solid #d6d6d6;
		text-align: center;
	}
	.pagetools_back .icon {
		display: block;
		margin: 15px auto 0 auto;
		width: 30px; height: 20px;
	}
	#combo-tools.active > .pagetools_in { margin-top: -50px; }
	.breadcrumb .over { vertical-align: baseline; }

	.sortbar_in { white-space: nowrap; }
	.sortbar_in > form { display: inline; }

/* --- Новости --- */
.box, .comment {
	background-color: #fff;
	margin-bottom: 25px;
	border-radius: 2px;
	position: relative;
	box-shadow: 0 1px 3px 0 rgba(0,0,0,0.2); -webkit-box-shadow: 0 1px 3px 0 rgba(0,0,0,0.2);
}
	.box > .heading { padding: 4% 8%; margin: 0; text-transform: uppercase; }
	.box > .heading .hnum { font-size: .6em; display: inline-block; vertical-align: top; margin: 0 0 0 .4em; }
	.box_in { padding: 4% 7%; }

	.story .title { margin: -.1em 0 1em 0; font-size: 20px; }
	.story .title > a {
		color: inherit;
		text-decoration: none !important;
		-webkit-transition: all ease .2s; transition: all ease .2s;
	}
	.story .title > a:hover { color: #9F9F9F; }

	/* Иконки управления новостью слева */
	.story_icons {
		position: absolute;
		top: 0; left: 0;
		width: 8%;
		list-style: none;
		padding: 4% 0 0 0; margin: -.2em 0 0 0;
	}
	.fixed_story .story_icons { z-index: 1; }
	.story_icons > li { text-align: center; margin: 0 0 10px 0; }

	.story .box_in > .text { font-size: 1.08em; }
	.story .box_in > .text:after { content: ""; display: block; clear: both; }
	.story .box_in > .text > img[style*="left"], .story .box_in > .text > .highslide img[style*="left"] { margin: 2px 4% 4% 0; }
	.story .box_in > .text > img[style*="right"], .story .box_in > .text > .highslide img[style*="right"] { margin: 2px 0 4% 4%; }
	.story .box_in > .text img { max-width: 100%; }

	/* Редактировал... */
	.editdate {
		margin: 4% 0 0 0;
		font-family: Georgia, "Times New Roman", Times, serif;
		font-style: italic;
	}

	/* Кнопка "В закладки" */
	.fav_btn > a, .edit_btn > a {
		display: inline-block;
		padding: 4px;
		width: 16px; height: 16px;
	}
		.fav_btn .icon {
			width: 16px; height: 16px;
			vertical-align: top;
		}
		.fav_btn .icon-fav { fill: #919191; }
		.fav_btn:hover .icon-fav { fill: #9F9F9F; }
		@media only screen and (min-width: 601px) {
			.fixed_story .fav_btn .icon-fav { fill: #fff; }
			.fixed_story .fav_btn:hover .icon-fav { fill: #fff; }
		}
		
		.fav_btn .icon-star { fill: #fed762; }

	/* Кнопка "Редактировать" */
	.edit_btn > a {
		position: relative;
		-webkit-transition: transform ease .2s; transition: transform ease .2s;
	}
		.edit_btn > a > i, .edit_btn > a:after, .edit_btn > a:before { 
			padding-top: 2px;
			width: 16px; height: 0;
			background-color: #919191;
			overflow: hidden;
			display: block;
			margin: 3px 0;
		}
		.edit_btn > a:after, .edit_btn > a:before { content: ""; }
		.edit_btn > a:hover > i, .edit_btn > a:hover:after, .edit_btn > a:hover:before {
			background-color: #9F9F9F;
		}
		.edit_btn > a:hover { 
			-webkit-transform: rotate(90deg); transform: rotate(90deg);
		}

	/* Важная новость */
	.fixed_label {
		position: absolute;
		left: 0; top: 0;
		width: 8%; height: 30px;
		padding-top: 4%;
	}
		.fixed_label:before {
			content: "";
			position: absolute;
			left: 50%; top: 0; bottom: 0;
			margin: 0 0 0 -15px;
			background-color: #e85319;
			width: 30px;
		}
		.fixed_label:after {
			content: "";
			position: absolute;
			bottom: 0; left: 50%;
			margin: 0 0 0 -15px;
			border: solid transparent;
			border-bottom-color: #fff;
			border-width: 0 15px 5px 15px;
			z-index: 1;
		}
	
	/* Нижняя часть новости */
	.story_tools { margin-top: 4%; }
		.story_tools > .category { float: right; margin-top: .7em; font-size: .9em; }
		.story_tools > .category .icon { width: 12px; height: 15px; margin: -.2em .4em 0 0; }
		.story_tools > .btn { float: left; margin-right: 2em; }
		.story_tools > .rate { float: left; }
		.story_tools .rate_stars { margin-top: 6px; }

		.rate_like > a, .rate_like-dislike {
			float: left;
			height: 22px; line-height: 22px;
			padding: 6px 12px;
			border: 1px solid #eaeaea;
			border-radius: 18px;
			text-decoration: none !important;
			font-weight: bold;
			color: #919191;
			-webkit-transition: all ease .2s; transition: all ease .2s;
		}
		.rate_like > a:hover { border-color: #9F9F9F; color: #9F9F9F; }
		.rate_like .icon { width: 16px; height: 15px; margin: -.2em .3em 0 0; }

		.rate_like-dislike > a {
			display: inline-block;
			width: 22px; height: 22px;
			text-align: center;
		}
		.rate_like-dislike > a .icon {
			width: 14px; height: 15px;
			fill: #787878;
			vertical-align: middle;
			margin: -.3em 0 0 0;
		}
		.rate_like-dislike > a:hover .icon { fill: #9F9F9F; }
		.rate_like-dislike .ratingplus { color: #88c54d; }
		.rate_like-dislike .ratingminus { color: #e45757; }
		.rate_like-dislike > span { cursor: default; margin: 0 .3em; }

	.story > .meta { font-size: .9em; background-color: #f7f7f7; padding: 2% 7%; border-radius: 0 0 2px 2px; }
		.meta:after, .story_tools:after { clear: both; display: table; content: ""; }
		.meta > ul { list-style: none; padding: 0; margin: 0; }
		.meta > ul > li { display: inline; }
		.meta > ul.left > li { margin-right: 2em; }
		.meta > ul.right > li { margin-left: 2em; }
		.meta .icon { width: 16px; height: 16px; margin: -.2em .4em 0 0; }
		.meta .icon-views { height: 18px; }

	.signature {
		font-size: .9em;
		opacity: .5;
		margin-top: .9em;
	}

/* --- Постраничная навигация --- */
.navigation { margin: 25px 0; }
	.navigation:after { clear: both; display: block; content: ""; }

	.pages { text-align: left; }
	.pages span, .pages a:hover, .page_next-prev { 
		background-color: #fff;
		box-shadow: 0 1px 2px 0 rgba(0,0,0,0.2); -webkit-box-shadow: 0 1px 2px 0 rgba(0,0,0,0.2);
		border-radius: 18px;
	}
	.pages span, .pages a {
		color: inherit;
		display: inline-block;
		position: relative;
		padding: 7px 7px;
		min-width: 22px; height: 22px; line-height: 22px;
		text-align: center;
		text-decoration: none !important;
		font-weight: bold;
	}
	.pages span { color: #399; }
	.pages a:hover { color: #fff; background-color: #9F9F9F; }
	.pages span { color: #9F9F9F; }

	.page_next-prev { float: right; height: 36px; }
		.page_next-prev * { float: left; }
		.page_next-prev .icon { width: 32px; height: 20px; fill: #d7d7d7; }
		.page_next-prev > span >  a:hover .icon { fill: #9F9F9F; }
		.page_next-prev > span > * { float: left; padding: 8px 12px; }

	.page_next > span, .page_prev > span { opacity: 0.5; }

	/* Постраничная навигация в новости */
	.splitnewsnavigation { margin-top: 4%; padding-top: 4%; font-weight: bold; border-top: 1px solid #efefef; }
	.splitnewsnavigation > a, .splitnewsnavigation > span { padding: 6px 10px; }

@media only screen and (min-width: 600px) {
	/* Уменьшение отступов */
.hblockkk  {
		display: inline-block;
		position: absolute;
		top: -7px; left: -5px;
		width: 33px; height: 33px;
		background: url(/1.png) 0 0 no-repeat;
}
}
@media only screen and (max-width: 600px) {
.hblockkk{
	text-transform: uppercase;
	font-weight: bold;
	background-color: #f7f7f7;
	border-radius: 2px 2px 0 0;
	font-size: 1em;
	padding: 2.5% 8%;
	margin: 0;
}
}
/* --- Блок: Новости Партнеров --- */
.hblock > .title {
	text-transform: uppercase;
	font-weight: bold;
	background-color: #f7f7f7;
	border-radius: 2px 2px 0 0;
	font-size: 1em;
	padding: 2.5% 8%;
	margin: 0;
}
	.banner img { vertical-align: top; max-width: 100%; }
	.midside .banner {
		padding: 2.5% 8%;
		text-align: center;
		-moz-box-sizing: border-box; -webkit-box-sizing: border-box; box-sizing: border-box;
	}
	.hblock .banner { border-top: 1px solid #efefef; }

	.informer_list {
		list-style: none;
		margin: 0 25px 0 0;
		padding: 0;
	}
		.informer_list:after { clear: both; display: block; content: ""; }
		.informer_list li {
			float: left;
			width: 33%;
			padding-right: 12px;
			-moz-box-sizing: border-box; -webkit-box-sizing: border-box; box-sizing: border-box;
		}
		.informer_list li .title { font-weight: bold; margin-bottom: 1em; }
		.informer_list li .title a { display: block; color: inherit; text-decoration: none !important; }
		.informer_list li .title a:hover { color: #9F9F9F; }
		
		.more_icon {
			display: inline-block;
			background-color: #9F9F9F;
			border-radius: 9px;
			height: 4px;
			padding: 7px 8px;
			margin-top: 1em;
			}
		.more_icon:after { clear: both; display: block; content: ""; }
		.more_icon > i {
			margin-left: 2px;
			float: left;
			width: 4px; height: 4px;
			border-radius: 50%;
			background-color: #fff;
			-webkit-transition: all ease .2s; transition: all ease .2s;
		}
		.more_icon:hover > i { margin-left: 10px; }
		.more_icon > i:first-child { margin-left: 0 !important; }

/* --- Правая колонка --- */
.block, .rightside .banner { margin-bottom: 25px; }
	.rightside .banner { box-shadow: 0 1px 2px 0 rgba(0,0,0,0.2); -webkit-box-shadow: 0 1px 2px 0 rgba(0,0,0,0.2); }

	.block > .title {
		text-transform: uppercase;
		white-space: nowrap;
		overflow: hidden;
		margin: 0 0 20px 0;
	}
	.block > .title > b, .block > .title:after, .block > .title > h4 { font-size: 1em; margin: 0; display: inline-block; vertical-align: middle; }
	.block > .title:after {
		content: "";
		background: #dedede;
		height: 4px; width: 100%;
		margin: 0 0 0 15px;
		border-top: 1px solid #d1d1d1;
	}

	/* Смена баннера при уменьшении разрешения */
	@media only screen and (max-width: 1279px) { .banner_300 { display: none; } }
	@media only screen and (min-width: 1280px) { .banner_240 { display: none; } }

	/* Блок: Популярное */
	ol.topnews {
		margin: -20px 0 0 0; padding: 0;
		list-style: none;
		counter-reset: ol-counter;
	}
		ol.topnews > li > a:after { content: ""; display: block; clear: both; }
		ol.topnews > li > a {
			display: block;
			color: inherit;
			text-decoration: none !important;
			border-bottom: 1px solid #d5d5d5;
			padding: 25px 0 25px 70px;
		}
		ol.topnews > li:last-child > a { border-bottom-width: 0; }
		ol.topnews > li > a:before, ol.topnews > li > a > b { -webkit-transition: all ease .2s; transition: all ease .2s; }
		ol.topnews > li > a:before {
			content: counter(ol-counter);
			counter-increment: ol-counter;
			font-weight: bold;
			font-size: 1.5em;
			border-radius: 50%;
			border: 2px solid #3896e6;
			width: 48px; height: 48px;
			text-align: center;
			float: left;
			line-height: 30px;
			padding: 7px 0;
			margin-left: -70px;
			color: #9F9F9F;
			-moz-box-sizing: border-box; -webkit-box-sizing: border-box; box-sizing: border-box;
		}
		ol.topnews > li > a:hover:before {
			color: #fff;
			background-color: #9F9F9F;
			box-shadow: 0 9px 13px 0 rgba(0,0,0,0.22); -webkit-box-shadow: 0 9px 13px 0 rgba(0,0,0,0.22);
		}
		ol.topnews > li > a > * { cursor: pointer; display: block; }
		ol.topnews > li > a > b { display: block; }
		ol.topnews > li > a > span {
			font-size: .9em;
			opacity: .5;
			text-transform: lowercase;
			margin-top: .4em;
		}
		ol.topnews > li > a:hover > b { color: #9F9F9F; }

	/* Блок: Опросы */
	.block_grey {
		padding: 25px;
		margin-bottom: 25px;
		border-radius: 2px;
		background-color: #e5e5e5;
	}
		.block_grey > .title {
			margin: 0 0 1em 0;
			font-size: 1em;
			letter-spacing: 0;
		}
		.vote_more { font-size: .9em; margin: -.7em 0 1em 0; }

		.vote_list { margin: 8% 0; }
		.vote_list .vote, .vote_list .pollanswer { margin: .6em 0 .2em 0; }
		.vote_list .vote > input, .vote_list .pollanswer > input { display:none;  }
		.vote_list .vote > input + label:before, .vote_list .pollanswer > input + label:before {
			display:inline-block;
			width: 8px; height: 8px;
			border: 4px solid #3b3b3b;
			background-color: #fff;
			margin: -3px 4px 0 0;
			vertical-align:middle;
			cursor:pointer;
			content: "";
			border-radius: 2px;
		}
		.vote_list .vote > input[type="radio"] + label:before,
		.vote_list .pollanswer > input[type="radio"] + label:before { border-radius: 50%; }
		.vote_list .vote > input + label:hover:before, .vote_list .pollanswer > input + label:hover:before { border-color: #9F9F9F; }
		.vote_list .vote > input:checked + label:before, .vote_list .pollanswer > input:checked + label:before {
			background-color: #9F9F9F;
			border-color: #9F9F9F;
		}
		.vote_list .vote > input + label:before, .vote_list .vote > input:checked + label:before,
		.vote_list .pollanswer > input + label:before, .vote_list .pollanswer > input:checked + label:before
		{ -webkit-transition: border-color ease .2s; transition: border-color ease .2s; }

		.btn-border .icon-votes { width: 16px; height: 14px; margin: -3px 0 0 0; vertical-align: middle; }
		.vote_votes, .pollallvotes { font-size: .9em; }

		#dlevotespopupcontent { height: auto !important; overflow: visible !important; }

	/* Блок: Архив новостей */
	.title_tabs { margin: -10px 0 10px 0 !important; }
	.title_tabs ul { cursor: default; list-style: none; padding: 0; margin: 0 0 0 15px; }
		.title_tabs * { display: inline-block; vertical-align: middle; }
		.title_tabs ul li > a {
			display: block;
			width: 36px; height: 16px;
			padding: 10px 0;
			border-radius: 50%;
			margin-bottom: 2px;
			text-align: center;
			position: relative;
		}
		.title_tabs ul li.active > a {
			background-color: #fff;
			box-shadow: 0 1px 2px 0 rgba(0,0,0,0.2); -webkit-box-shadow: 0 1px 2px 0 rgba(0,0,0,0.2);
		}
		.title_tabs ul li > a > .icon { width: 16px; height: 16px; fill: #6a6a6a; vertical-align: top; }
		.title_tabs ul li.active > a > .icon { fill: #9F9F9F; }

	/* Блок: Изменить оформление */
	.block_bg {
		margin-bottom: 25px;
		background-color: #1b64a8;
		border-radius: 2px;
		box-shadow: 0 1px 2px 0 rgba(0,0,0,0.2); -webkit-box-shadow: 0 1px 2px 0 rgba(0,0,0,0.2);
		padding: 25px;
	}
		.block_bg > .title {
			font-size: 1em;
			color: #fff;
			margin: -.2em 0 .6em 0;
			text-transform: uppercase;
		}
		.change_skin {
			background: url(/style/img/change_skin.png) no-repeat 0 50%;
			-webkit-background-size: cover; background-size: cover;
		}

		.change_skin .styled_select {
			background: #fff;
			border-radius: 2px;
			width: 100%;
			box-shadow: 0 3px 7px 0 rgba(0,0,0,0.2); -webkit-box-shadow: 0 3px 7px 0 rgba(0,0,0,0.2);
			border-width: 0;
			overflow: hidden;
			position: relative;
		}
		.change_skin .styled_select > .icon {
			position: absolute;
			left: 100%; top: 50%;
			width: 16px; height: 10px;
			margin: -5px 0 0 -26px;
 			fill: #d7d7d7;
		}
		.change_skin .styled_select:hover > .icon { fill: #9F9F9F; }
		.change_skin .styled_select select {
			width: 112%; height: 36px;
			background-color: transparent;
			border-width: 0;
			padding: 7px;
			position: relative;
			z-index: 1;
			appearance: none; -webkit-appearance: none; -moz-appearance: none;
		}
	
	/* Блок: Теги */
	.tag_list > span { margin: 0 2px 2px 0; }
		.tag_list > span, .tag_list > span > a { display: inline-block; }
		.tag_list > span > a {
			border: 1px solid #d6d6d6;
			color: inherit;
			text-decoration: none !important;
			padding: 4px 8px;
			border-radius: 2px;
		}
		.tag_list > span > a:hover {
			background-color: #fff;
			color: #9F9F9F;
			border-color: #fff;
			box-shadow: 0 3px 7px 0 rgba(0,0,0,0.2); -webkit-box-shadow: 0 3px 7px 0 rgba(0,0,0,0.2);
		}
		.tags_more { margin-top: 1em; }

	/* Блок: Похожее */
	.relnews {
		margin: -20px 0 0 0; padding: 0;
		list-style: none;
	}
		.relnews > li > a:after { content: ""; display: block; clear: both; }
		.relnews > li > a {
			display: block;
			color: inherit;
			text-decoration: none !important;
			border-bottom: 1px solid #d5d5d5;
			padding: 25px 0 25px 33px;
		}
		.relnews > li:last-child > a { border-bottom-width: 0; }
		.relnews > li > a .icon, .relnews > li > a > b { -webkit-transition: all ease .2s; transition: all ease .2s; }
		.relnews > li > a .icon {
			width: 16px; height: 14px;
			float: left;
			margin: 4px 0 0 -33px;
		}
		.relnews > li > a > * { cursor: pointer; display: block; }
		.relnews > li > a > b { display: block; }
		.relnews > li > a > span {
			font-size: .9em;
			opacity: .5;
			text-transform: lowercase;
			margin-top: .4em;
		}
		.relnews > li > a:hover > b { color: #9F9F9F; }

	/* Блок: последние комментарии */
	.lastcomm {
		margin: -20px 0 0 0; padding: 0;
		list-style: none;
	}
		.lastcomm > li > a:after { content: ""; display: block; clear: both; }
		.lastcomm > li > a {
			display: block;
			color: inherit;
			text-decoration: none !important;
			border-bottom: 1px solid #d5d5d5;
			padding: 25px 0 25px 33px;
		}
		.lastcomm > li:last-child > a { border-bottom-width: 0; }
		.lastcomm > li > a .icon, .lastcomm > li > a > b { -webkit-transition: all ease .2s; transition: all ease .2s; }
		.lastcomm > li > a .icon {
			width: 16px; height: 14px;
			float: left;
			margin: 4px 0 0 -33px;
		}
		.lastcomm > li > a > * { cursor: pointer; display: block; }
		.lastcomm > li > a > b { display: block; margin-top: .4em;}
		.lastcomm > li > a > span {
			font-size: .9em;
			opacity: .5;
		}
		.lastcomm > li > a:hover > b { color: #9F9F9F; }

/* --- Футер --- */
.footer_menu { position: relative; padding: 0 0 25px 0; }
.foot_menu {
	list-style: none;
	padding: 0;
	margin: 0 -25px 0 0;
}
	.foot_menu > li {
		float: left;
		width: 33.33333%;
		padding-right: 25px;
		-moz-box-sizing: border-box; -webkit-box-sizing: border-box; box-sizing: border-box;
	}
	.foot_menu > li > b { display: block; margin-bottom: 1em; }
	.foot_menu > li > b > i { display: none; }
	.foot_menu > li nav > a {
		color: #838383;
		display: block;
		font-size: .9em;
		padding: .2em 0;
	}
	@media only screen and (min-width: 601px) {
		.foot_menu > li > div {
			display: block !important;
			height: auto !important; width: auto !important;
		}
	}

	/* Кнопка наверх */
	.upper {
		position: absolute;
		left: 0;
		width: 13%;
		text-align: center;
	}
		#upper {
			display: block;
			margin: 0 auto;
			border-radius: 50%;
			width: 64px; height: 64px;
			background-color: #d7d7d7;
			position: relative;
		}
		#upper .icon {
			width: 20px; height: 32px;
			fill: #ededed;
			position: absolute;
			left: 50%; top: 50%;
			margin: -16px 0 0 -10px;
		}
		#upper:hover { background-color: #9F9F9F; }
		#upper:hover .icon { fill: #fff; }

.footer { font-size: .9em; padding: 25px 0; border-top: 1px solid #d9d9d9; }
	.footer a, .footer { color: #838383; }
	.footer .midside { display: flex; }
	.footer .copyright { width: 100%; }
	.copyright a { font-weight: bold; }

	.ca { float: right; white-space: nowrap; margin-left: 20px; }
	.ca > .icon {
		margin: -.2em .8em 0 0;
		width: 30px; height: 17px;
		fill: #cbcbcb;
	}
	.ca:hover > .icon { fill: #838383; }

	.counter { float: right; margin-left: 10px; margin-top: 2px; opacity: .5; }
	.counter:hover { opacity: 1; }
	.counter > img { vertical-align: top; }

/* --- Просмотр новости --- */
.showfull .pagetools { position: absolute; }
	.showfull .story { float: left; width: 100%; margin-top: 77px; }
	.showfull .comments, .showfull #dle-content .box { float: left; width: 100%; }
	.showfull #dle-content .rightside { margin: 0 -350px 0 0; }

	.showfull #dle-content .rightside .banner { padding: 0; }

/* --- Статические страницы --- */
.page_static { margin-bottom: 60px; }
	.page_static:after { clear: both; display: block; content: ""; }
	.page_static > .text { font-size: 1.15em; }

/* --- Информация об ошибках --- */
.berrors {
	background: #ffe6dd;
	border: 1px solid #f0c4b5;
	color: #553c33;
	padding: 20px 25px;
	margin-bottom: 25px;
	height: 1%;
	border-radius: 2px;
	box-sizing: border-box;
}

/* --- Комментарии --- */
/* Форма добавления */
.addcomment { background-color: #f7f7f7; }
	.plus_icon { width: 16px; height: 16px; display: inline-block; vertical-align: middle; position: relative; }
	.addcomment .plus_icon { width: 8%; padding: 10px 0; float: left; margin-top: 4%; }
	.plus_icon > span, .plus_icon > span:before, .plus_icon > span:after {
		overflow: hidden;
		text-indent: -9999px;
		white-space: nowrap;
		position: absolute;
	}
	.plus_icon > span:before, .plus_icon > span:after {
		background-color: #b3b3b3;
		content: "";
	}
	.plus_icon > span {
		width: 16px; height: 16px;
		left: 50%; top: 50%;
		margin: -8px 0 0 -8px;
	}
	.plus_icon > span:after {
		left: 0; top: 50%;
		width: 100%; height: 2px;
		margin-top: -1px;
	}
	.plus_icon > span:before {
		left: 50%; top: 0; 
		width: 2px; height: 100%;
		margin-left: -1px;
	}

	.plus_icon.circle {
		width: 12px; height: 12px;
		padding: 4px;
		border-radius: 50%;
		border: 2px solid #9F9F9F;
	}
	.plus_icon.circle > span { width: 12px; height: 12px; margin: -6px 0 0 -6px; }
	.plus_icon.circle > span:before, .plus_icon.circle > span:after { background-color: #9F9F9F; }

	/* Формы на UL */
	ul.ui-form { list-style: none; padding: 0; margin: 0; }
		ul.ui-form > li { margin-bottom: 20px; }
		ul.ui-form > li:last-child { margin-bottom: 0; }
		.form-group { margin-bottom: 20px; }
		.form-group > label { display: block; margin-bottom: .4em; }
		.imp:after { content: "*"; margin: 0 0 0 10px; color: #e85319; }

		@media only screen and (min-width: 601px) {
			.form-group.combo:after { clear: both; display: table; content: ""; }
			.form-group.combo > .combo_field { width: 50%; float: left;
				-moz-box-sizing: border-box; -webkit-box-sizing: border-box; box-sizing: border-box;
			}
			.form-group.combo > .combo_field:last-child { padding-left: 10px; }
			.form-group.combo > .combo_field:first-child { padding-right: 10px; }
		}
		.form_submit { margin-top: 20px; }
		.form-sep { border-top: 1px solid #efefef; }

	/* Модификация BB редактора для комментариев */
	#comment-editor .bb-editor textarea { padding: 7px; padding-bottom: 45px; height: 200px; }
	.addpm #comment-editor .bb-editor textarea { height: 340px; }

	.wseditor table, .bb-editor table { margin: 0px; }

/* Комментарии */
.com_list { }
	.comment {
		padding: 4% 8%;
		position: relative;
		-webkit-transition: box-shadow ease .4s; transition: box-shadow ease .4s;
	}
	.com_list .comment {
		border-top: 1px solid #efefef;
		background-color: transparent;
		margin: 0;
		border-radius: 0;
		box-shadow: none; -webkit-box-shadow: none;
	}
	.comment:hover {
		position: relative;
		box-shadow: 0 2px 12px 0 rgba(0,0,0,0.2); -webkit-box-shadow: 0 2px 12px 0 rgba(0,0,0,0.2);
	}
	.avatar { display: inline-block; }
	.avatar .cover {
		width: 100px; height: 100px;
		border-radius: 50%;
		white-space: nowrap;
		text-indent: -9999px;
		display: inline-block;
	}
	.comment .avatar { float: left; margin-right: 15px; position: relative; }
	.comment .avatar .cover { width: 36px; height: 36px; }
	.com_online {
		position: absolute;
		left: 100%; top: 50%;
		margin: -4px 0 0 -4px;
		overflow: hidden;
		text-indent: -9999px;
		background-color: #70bb39;
		border: 2px solid #fff;
		width: 4px; height: 4px;
		border-radius: 50%;
	}

	.com_info { font-size: .9em; margin-bottom: 2%; margin-top: -5px; }
	.com_info:after { clear: both; display: block; content: ""; }

	.com_user { float: left; margin: 9px 15px 0 0; }
	.comment .meta { display: inline; }
	.comment .meta .left { margin: 9px 0 0 0; }
	.comment .meta .left .mass input { margin: -2px 0 0 0; vertical-align: middle; }
		.comment .meta > ul.left > li { margin-right: 10px; }

		.comment .reply { text-transform: lowercase; }
		.comment .meta .left a {
			display: inline-block;
			width: 20px; height: 20px;
			vertical-align: middle;
			padding: 2px;
			margin-top: -2px;
			-moz-box-sizing: border-box; -webkit-box-sizing: border-box; box-sizing: border-box;
		}
		.comment .meta .left .reply a { padding: 2px; width: auto; vertical-align: baseline; }
		.comment .meta .left .del a { padding: 4px; }
		.comment .meta .left .icon { margin: 0; fill: #919191; vertical-align: top; }
		.comment .meta .left a:hover .icon { fill: #9F9F9F; }
		.comment .meta .left a .icon-reply {
			width: 15px; height: 16px;
			fill: #9F9F9F !important;
			margin-right: .4em;
			vertical-align: middle;
		}
		.comment .meta .left a .icon-coms {
			width: 15px; height: 16px;
			fill: #9F9F9F !important;
			margin-right: .4em;
			vertical-align: middle;
		}
		.comment .meta .left .edit_btn > a { padding: 2px; margin-top: -4px; } 
		.comment .icon-bad { width: 16px; height: 16px; }
		.comment .icon-cross { width: 12px; height: 12px; }

	.comment .meta .rate { float: right; }

	/* Древовидные комментарии */
	#dle-comments-list { width: 100%; overflow: hidden; }
	#dle-comments-list .comments-tree-list { list-style: none; padding: 0; margin: 0; }
	#dle-comments-list > .comments-tree-list > li > .comments-tree-list { padding: 0 8%; border-top: 1px solid #efefef; }
	#dle-comments-list > .comments-tree-list > li .comments-tree-list > li { padding-left: 20px; }
	#blind-animation .comments-tree-list { list-style: none; padding: 0; margin: 0; }

	.comments-tree-list > li > ol > li .comment {
		padding: 30px 0;
		position: relative;
		box-shadow: none; -webkit-box-shadow: none;
		border-width: 0;
	}
	.comments-tree-list li ol li .comment {

		position: relative;
		box-shadow: none; -webkit-box-shadow: none;
		border-width: 0;
	}
	.comments-tree-list > li > ol > li .comment:after {
		content: "";
		position: absolute;
		width: 2000px; height: 1px;
		margin-left: -500px;
		left: 0; top: 0;
		background-color: #efefef;
	}

	.comments-tree-list > li > ol > li .comment:before {
		content: "";
		position: absolute;
		left: 0; top: 12px;
		margin: 30px 0 0 -20px;
		background-color: #e6e6e6;
		width: 10px; height: 2px;
	}	

	/* Управление комментариями */
	.mass_comments_action { text-align: right; border-top: 1px solid #efefef; padding: 2% 8%; }
	.mass_comments_action > select { height: 36px; padding: 5px; width: 200px; margin-left: 1em; }

	.com_content > .title { margin-top: 4%; }
	.com_content > .text { font-size: 1.08em; }

/* --- Контакты --- */
#map { width: 100%; height: 400px; }
	.map_resp {
		width: 100%; padding-top: 60%; height: 0;
		position: relative;
	}
	.map_resp > #map {
		position: absolute;
		left: 0; top: 0; bottom: 0;
		height: auto;
	}
	.dark_top {
		border-radius: 2px 2px 0 0;
		color: #fff;
		background: #2c2c2c;
	}
	.contacts { font-size: 1.3em; }
	.contacts > .grid_1_2 { padding-left: 42px; }
	.contacts > .grid_1_2 .icon {
		float: left;
		margin: 5px 0 0 -42px;
		width: 24px;
	}

/* --- Регистрация, Восстановление пароля, Добавление новости---*/
.page_form_style xxx { background-color: #f7f7f7; }
	.page_form { max-width: 1100px; padding-left: 7%; }
	.page_form__back {
		background-color: #9F9F9F;
		position: fixed;
		left: 0; top: 0;
		height: 100%; width: 3%;
		padding: 0 2%;
	}
	.page_form__back:after {
		content: "";
		position: absolute;
		top: 0; right: 0;
		width: 5px; height: 100%;
		background-repeat: repeat-y;
		background-image: -webkit-linear-gradient(left, rgba(0,0,0,0) 0%, rgba(0,0,0,0.1) 100%);
		background-image: -moz-linear-gradient(left, rgba(0,0,0,0) 0%, rgba(0,0,0,0.1) 100%);
		background-image: -o-linear-gradient(left, rgba(0,0,0,0) 0%, rgba(0,0,0,0.1) 100%);
		background-image: linear-gradient(left, rgba(0,0,0,0) 0%, rgba(0,0,0,0.1) 100%);
	}
	.page_form__back > .icon {
		position: absolute;
		left: 50%; top: 8%;
		margin: 0 0 0 -15px;
		width: 30px; height: 20px;
		fill: #fff;
		opacity: .6;
	}
	.page_form__back:hover > .icon { opacity: 1; }
	.page_form__xxx { padding: 0 10%; }
	.page_form__logo { padding: 8% 0 0 0; margin-bottom: 8%; }
	.page_form__logo .icon { margin-top: -10px; width: 60px; height: 60px; }

	.page_form__inner > .title { font-weight: normal; font-size: 30px; margin: 4% 0; }
	.page_form__form .form_submit { border-top: 1px solid #e0e0e0; padding: 20px 0 0 0; margin-top: 20px; }
		.footer { background: <?=$uzcms->pas_colorr?>; padding: 15px; }
	.footer .midside { display: block; padding: 0; }
	.footer .copyright, .footer .copyright a { color: #d5d5d5; }
		.footer .copyright { padding: 0 0 15px 0; border-bottom: 1px solid #2c2c2c; }
		.footer .ca { display: block; float: none; margin: 0; padding: 15px 0; color: #4e4e4e !important; }
		.footer .ca .icon { fill: #323232; }
	}
	@media only screen and (min-width: 701px) {
		.page_form__form { font-size: 1.25em; }
		.page_form__form .form-group label { color: #999; }
		.page_form__form .form-group input, .page_form__form .form-group textarea,
		.page_form__form .form-group select, .page_form__form .c-captcha input {
			font-size: 1em;
			height: 60px;
			line-height: 26px;
			padding: 15px;
		}
		.page_form__form .form-group textarea { height: auto; }
		.page_form__form .c-captcha img { width: 160px; height: 60px; }
		.page_form__form .c-captcha input { width: 160px; }

		.page_form__form .form_submit { padding-top: 3%; margin-top: 3%; }
		.page_form__form ul.ui-form > li { margin-bottom: 3%; }
		.page_form__form .form_submit > .btn {
			font-size: 1em;
			font-weight: normal !important;
			height: 60px;
			border-radius: 30px;
			line-height: 26px;
			padding: 17px 28px;
		}
	}

	.page_form__form .login_check { position: relative; }
	.page_form__form .login_check > input { padding-right: 150px; }
	.page_form__form .login_check > .btn {
		width: 120px;
		position: absolute;
		right: 0; top: 0;
		font-weight: bold;
		margin: 12px;
	}
	#result-registration { margin-top: 10px; font-size: .8em; }
	.regtext { margin-bottom: 5%; }

	.page_form__foot { margin-top: 8%; padding-bottom: 8%; }
	.page_form__foot > * { display: block; float: none; }
	.page_form__foot .ca { display: block; margin-top: 2%; margin-left: 0; }

/* --- PM --- */
@media only screen and (min-width: 601px) {
#pm-menu:after { content: ""; clear: both; display: block; }
	#pm-menu { margin-bottom: 25px; }
	#pm-menu a { color: inherit; padding: 10px 16px; border-radius: 2px; border: 2px solid transparent; float: left; text-decoration: none !important; }
	#pm-menu a:hover { border-color: #9F9F9F; color: #9F9F9F; }
}

	.pm-box { margin-bottom: 25px; }
		.pm_status { padding: 25px; background-color: #f7f7f7; border-radius: 2px; }
		.pm_progress_bar { background-color: #e5dbcc; margin-bottom: 10px; border-radius: 2px; }
		.pm_progress_bar span { background: #e85319; font-size: 0; height: 20px; border-radius: 2px; display: block; overflow: hidden }

/* --- Страница пользователя --- */
.userinfo_top { position: relative; padding-bottom: 50px; margin-bottom: 50px; }
.userinfo_top .avatar { position: absolute; }
.user_tab { list-style: none; padding: 0; margin: 0; }
	.user_tab > li { display: inline; margin-right: 1.2em; }
	.user_tab > li > a {
		text-decoration: none !important;
		font-size: .6em;
		-webkit-transition: all ease .3s; transition: all ease .3s;
	}
	.user_tab > li > a { color: #fff; opacity: .5; }
	.user_tab > li > a:hover { color: inherit; }
	.user_tab > li.active > a { cursor: default; font-size: 1em; opacity: 1; }

	.usinf { list-style: none; padding: 0; margin: 0 0 25px 0; } 
	.usinf li { padding: 12px 0; border-top: 1px solid #e6e6e6; }
	.usinf li:first-child { border-top-width: 0; }

	.ui-c1, .ui-c2 { display: inline-block; vertical-align: top; }
	.ui-c1 { width: 30%; margin-right: 5%; }
	.ui-c2 { width: 60%; }

	/* Окно пользователя */
	.userinfo { padding-left: 90px; }
	.userinfo .avatar { position: absolute; float: left; margin: 0 0 0 -90px; }
	.userinfo .avatar .cover { width: 60px; height: 60px; }
	.userinfo > ul { list-style: none; padding: 0; margin: 0; }

/* --- Статистика --- */
.stats_head > ul {
	list-style: none;
	padding: 0; margin: 0;
	font-size: 1.25em;
}
	.stats_head > ul > li { margin-top: 15px; padding-left: 30px; }
	.stats_head > ul > li:before {
		content: "";
		float: left;
		margin: 2px 0 0 -30px;
		width: 16px; height: 16px;
		border-radius: 50%;
		background-color:  #9F9F9F;
	}
	.stats_head > ul > li > b {
		display: block;
		font-size: .8em;
		opacity: .5;
		font-weight: normal;
	}
	.stats_head > ul > li.stats_d:before { background-color: #f6a71a; }
	.stats_head > ul > li.stats_w:before { background-color: #ce3f28; }
	
	.stat_group { margin-bottom: 25px; }
	.stat_group > h5 { margin-top: 0; margin-bottom: 1em; }
	.stat_group > ul { list-style: none; padding: 0; margin: 0; }
	.stat_group > ul > li { padding: .6em 0; border-top: 1px dotted #d5d5d5; }

/* --- Страница поиска --- */
.search_result_num { font-size: .9em; margin: 25px 0 0; }
.search table { width: 100%; border-spacing: 5px; border-collapse: separate; }
#searchtable td, #searchtable td div, #searchtable table { margin: 0 !important; padding: 0 !important; }
	#searchtable td.search br { display: none; }
	td.search .bbcodes { margin: 0 !important; }
	td.search { vertical-align: top; }

/* --- === Разрешение ниже 1280 === ---*/
@media only screen and (max-width: 1279px) {
	.midside { padding-right: 290px; }
	.rightside { width: 240px; margin-left: -290px; }
	.showfull #dle-content .rightside { width: 240px; margin-right: -290px; }
	#searchsuggestions { width: 240px; }

	/* Шапка сайта */
	.logotype .logo_title { font-size: 18px; }

	/* Популярные новости */
	ol.topnews > li > a { padding-left: 45px; }
	ol.topnews > li > a:before {
		font-size: 1.2em;
		width: 28px; height: 28px;
		line-height: 20px;
		padding: 2px 0; margin-left: -45px;
	}

	/* Опросы */
	#votes .btn-border { padding-left: 10px; padding-right: 10px; } 
}
@media only screen and (max-width: 1235px) {
	.midside { padding-left: 25px; }
	#top_menu { display: none; }
	#tepagaga_menu { padding-left: 65px; }
	xxx, .page { width: 100%; height: 100%; }
	#cat_menu, .page, .tepagaga { -webkit-transition: all ease .3s; transition: all ease .3s; }
	#cat_menu {
		position: fixed;
		z-index: 1111;
		top: 0; left: 0; top: 0; bottom: 0;
		margin: 0;
		overflow-y: auto;
		overflow-x: hidden;
		width: 200px;
		background-color: #ededed;
		border-right: 1px solid #d9d9d9;
		margin-left: -200px;
		visibility: hidden;
		opacity: 0;
		-webkit-overflow-scrolling: touch;
	}
	#cat_menu .soc_links { padding-bottom: 20px; }
	.mobile-menu_open #cat_menu { margin-left: 0; visibility: visible; opacity: 1; }
	.mobile-menu_open .page { margin-left: 200px; overflow: hidden; }
	.mobile-menu_open xxx { overflow: hidden; }
	.mobile-menu_open .tepagaga { left: 200px; }
	
}
@media (min-width: 1236px) {
	.cat_menu__tm, #mobile_menu_btn { display: none; }
}

/* --- === Разрешение ниже 980 === ---*/
@media (min-width: 981px) { #search_btn { display: none; } }
@media (max-width: 980px) {

	.midside { padding-right: 25px; }

	/* Шапка и модификация поиска */
	#tepagaga_menu {
		display: block;
		padding-right: 86px;
	}
	.logotype { float: left; }

	#login_pane { float: right; margin-top: 22px; }
	#search_btn {
		position: absolute;
		right: 0; top: 0; bottom: 0;
		width: 86px; height: 80px;
		padding: 0 25px;
		border: 0 none;
		cursor: pointer;
		background-color: transparent;
	}
	#search_btn > span {
		display: block;
		width: 32px; height: 32px;
		border: 2px solid #fff;
		border-radius: 50%;
		overflow: hidden;
		position: relative;
	}
	#search_btn > span > .icon {
		position: absolute;
		left: 50%; top: 50%;
		margin: -8px 0 0 -8px;
		width: 16px; height: 16px;
		fill: #fff;
		-webkit-transition: all ease .3s; transition: all ease .3s;
	}
	.search_open #search_btn > span > .icon-search,
	#search_btn > span > .icon-cross {
		opacity: 0; visibility: hidden;
		-webkit-transform: scale(0.3,0.3);
    	transform: scale(0.3,0.3);
	}
	.search_open #search_btn > span > .icon-cross,
	#search_btn > span > .icon-search {
		opacity: 1; visibility: visible;
		-webkit-transform: scale(1,1);
    	transform: scale(1,1);
	}
	#q_search {
		display: block;
		position: fixed;
		z-index: 23;
		left: 25px; right: 86px; top: 0;
		margin:0;
		width: auto; height: 80px;
		margin-top: -80px;
	}
	.q_search > input { background-color: #fff; }
	.logotype, #mobile_menu_btn, #login_pane, #q_search { -webkit-transition: all ease .3s; transition: all ease .3s; }
	.search_open .logotype, .search_open #mobile_menu_btn, .search_open #login_pane, #q_search { opacity: 0; visibility: hidden; }
	.search_open #q_search { margin-top: 0; opacity: 1; visibility: visible; }
	.q_search_adv { display: none; }

	/* Новости */
	.showfull .story { margin-top: 0; }
	.showfull .pagetools { position: relative; }
	.rightside, .tags_block,
	.showfull #dle-content .rightside .banner_240,
	.midside .banner { display: none; }
	.showfull #dle-content .rightside {
		float: none;
		width: auto;
		margin: 0; padding: 0;
		display: block;
	}
	.showfull .comments, .showfull #dle-content .box { float: none; }

	/* Блоки */
	.block { 
		background-color: #fff;
		margin-bottom: 25px;
		border-radius: 2px;
		position: relative;
		box-shadow: 0 1px 3px 0 rgba(0,0,0,0.2); -webkit-box-shadow: 0 1px 3px 0 rgba(0,0,0,0.2);
	}
	.block > .title { padding: 4% 8%; margin-bottom: 0; }
	.block > .title:after { display: none; } 

	/* Блок: Похожее; */
	.relnews { margin: 0; border-top: 1px solid #efefef; }
	.relnews > li > a {
		border-bottom: 1px solid #efefef;
		padding: 4% 8%
	}
	.relnews > li > a .icon { margin: 3px 0 0 0; }
	.relnews > li > a > b, .relnews > li > a > span { margin-left: 27px; }

	/* Опросы */
	.block_grey { padding: 4% 8%; margin-bottom: 25px; }
	.block_grey > .title { font-size: 1.2em; } 
	.vote_list { margin: 4% 0; }
}
@media only screen and (max-width: 700px) {
	.page_form__form .login_check > .btn {
		margin: 5px; font-weight: normal;
	}
	
	
	
}
@media only screen and (max-width: 750px) {
	/* Новости партнеров */
	.informer_list { margin-right: 0; }
	.informer_list li { float: none; width: auto; padding: 0; margin-bottom: 25px; }
	.informer_list li:last-child { margin-bottom: 0; }

	/* Длинные таблицы */
	.table_top_users, .pmlist { overflow-x: auto; overflow-y: hidden; -webkit-overflow-scrolling: touch; }
	table.userstop, table.pm { width: 900px; }
	
	
	
	
	
}
@media only screen and (max-device-width: 480px) {
	xxx { -webkit-text-size-adjust: 100%; }  



	
}

/* --- === Разрешение ниже 600 === ---*/
@media only screen and (max-width: 600px) {
	/* Уменьшение отступов */
	xxx, select, input, textarea, button { font-size: 13px/1.5; }
	.hblock, .mass_comments_action, #dofullsearch, .vote_more, .bb-pane { display: none; }
	.midside { padding: 0; }
	#content { 
	margin-left: 3%;
	display: inline-block;
    width: 94%;
	}
	.navigation { margin: 15px 0; }
	.box, .comment, .berrors { margin-bottom: 15px; }
	.box > .heading { padding: 20px; }
	.quote, blockquote { font-size: 1.1em; }

	.mejs-container { max-width: 100%; }
	.story video { max-width: 100%; }
	.story iframe { max-width: 100%; }

	/* Всплывающие окна */
	.ui-dialog { width: 100% !important; left: 0 !important; } 
	.ui-dialog-buttonset > .ui-button { margin: 2px; }

	/* Оптимизация шапки */
	#tepagaga, .tepagaga { margin: 0; height: 50px; }
	.tepagaga {
		background-color: #9F9F9F;
		box-shadow: 0 1px 3px 0 rgba(0,0,0,0.2); -webkit-box-shadow: 0 1px 3px 0 rgba(0,0,0,0.2);
	}
	#tepagaga_menu {
		position: relative;
		height: auto;
		border-radius: 0;
		box-shadow: none; -webkit-box-shadow: none;
		padding: 0 50px;
		z-index: 1;
		height: 50px;
	}
	#tepagaga_menu:after {
		content: "";
		position: absolute;
		top: 100%; left: 0;
		height: 1px; width: 100%;
		background: rgba(255,255,255,0.1);
	}
	.logotype {
		float: none;
		width: 100%; height: 50px;
		text-align: center;
		justify-content: center;
	} 
	.logo_title { display: none; }
	.logotype .icon-logo { width: 32px; height: 32px; }

	/* Оптимизация меню */
	#mobile_menu_btn, #search_btn {
		width: 50px; height: 50px;
		padding: 0;
		border-right-width: 0;
	}
	.mobile-menu_open .mt_1 { margin-top: 8px; }
	.mobile-menu_open .mt_2 { margin-top: 8px; }
	.mobile-menu_open .mt_3 { margin-top: 8px; }
	#cat_menu {
		position: fixed;
		z-index: 0;
		margin: -60% 0 0 0;
		width: 100%;
		background: #9F9F9F;
		left: auto; right: auto;
	}
	#cat_menu:after {
		content: "";
		position: fixed;
		width: 100%; height: 70px; margin-top: 50px;
		left: 0; right: 0; top: 0;
		z-index: 1;
		background-repeat: repeat-y;
		background-image: -webkit-linear-gradient(top, #9F9F9F 30%, rgba(51,148,230,0) 100%);
		background-image: -moz-linear-gradient(top, #9F9F9F 30%, rgba(51,148,230,0) 100%);
		background-image: -o-linear-gradient(top, #9F9F9F 30%, rgba(51,148,230,0) 100%);
		background-image: linear-gradient(top, #9F9F9F 30%, rgba(51,148,230,0) 100%);
	}
	.cat_menu { padding: 10%; margin-top: 50px; }
	.cat_menu a:first-child { border-top-width: 0; }
	.cat_menu a {
		text-decoration: none !important;
		font-size: 1.1em;
		padding: 3% 0;
		display: block;
		color: #fff;
		border-top-color: #3d99e7;
		border-top: 1px solid rgba(255,255,255,0.06);
	}
	#cat_menu .soc_links { display: none; }

		.mobile-menu_open .tepagaga { left: auto; }
		.mobile-menu_open .page { margin-left: 0; }
		.mobile-menu_open #cat_menu { margin-top: 50px; }
		.mobile-menu_open #login_pane { opacity: 1; visibility: visible; }

		/* Оптимизация авторизации */
		#login_pane {
			float: none;
			margin-top: 16px;
			text-align: center;
			visibility: hidden;
			opacity: 0;
			-webkit-transition: all ease .3s; transition: all ease .3s;
		}
		#login_pane .cccc-form {
			position: fixed;
			top: 105px; left: 10px; right: 10px; bottom: 10px;
			overflow-x: hidden;
			overflow-y: auto;
			margin: 0; padding-bottom: 0;
			width: auto; min-width: 0;
			-moz-box-sizing: border-box; -webkit-box-sizing: border-box; box-sizing: border-box;
		}
		.login_pane__foot, .login_form__foot { padding-bottom: 39px; }

	/* Оптимизация поиска */
	#search_btn { padding: 7px; }
	#search_btn > span {
		border-width: 0;
		width: 36px; height: 36px;
	}
	#q_search {
		left: 15px; right: 50px;
		height: 50px;
		padding: 0;
	}
	.q_search { margin-top: 7px; }

	/* Оптимизация карусели */
	.sorovga { margin-bottom: 0; border-radius: 0; }
	.sorovga-caption {
		position: absolute;
		left: 0; top: 0;
		width: 100%; height: 100%;
		margin: 0;
		display: table;
	}
	.sorovga-caption_in {
		display: table-cell;
		vertical-align: middle;
		text-align: center;
		padding: 15px;
	}
	.sorovga-caption .title { font-size: 1.2em; font-weight: bold; }
	.sorovga-caption .text { font-size: 1em; }

	.sorovga-control { position: static; }
	.sorovga-control_in { background: none; box-shadow: none; -webkit-box-shadow: none; }
	.sorovga-indicators { display: none; }
	.sorovga-control .up, .sorovga-control .down { position: absolute; z-index: 12; left: 50%; margin-left: -21px; }
	.sorovga-control .up { top: 0; }
	.sorovga-control .down { bottom: 0; }
	.sorovga-control .up .icon, .sorovga-control .down .icon { fill: #fff !important; }

	/* Блоки */
	.block, .block_grey { margin-bottom: 15px; }
	.block > .title, .block_grey, .relnews > li > a { padding: 20px; }

	/* Оптимизация новостей */
	.box_in { padding: 2px; }
	.story_icons {
		float: right;
		position: relative;
		padding: 0; margin: -4px 0 10px 10px;
	}
	.story > .meta { padding: 10px 20px; }
	.meta > ul.left > li { margin-right: 12px; }
	.meta > ul.right > li { margin-left: 12px; }

	.story .title { font-size: 1.15em; }
	.story .box_in > .text { font-size: 1em; }

	.story_date > * { display: none; }
	.story_date > time { display: inline; }
	.category { display: none; }

	.story_tools, .editdate { margin-top: 20px; }
	.shortstory .story_tools > .rate { float: right; }
	.story_tools > .btn { padding: 0; height: 36px; width: 36px; text-align: center; }
	.story_tools > .btn:after, .story_tools > .btn:before { content: ""; }
	.story_tools > .btn > b, .story_tools > .btn:after, .story_tools > .btn:before {
		display: inline-block;
		overflow: hidden;
		text-indent: -9999px;
		background-color: #fff;
		width: 4px; height: 4px;
		border-radius: 50%;
		margin: 11px 0 0 0;
		vertical-align: middle;
	}
	.story_tools > .btn > b { margin-left: 2px; margin-right: 2px; }

	/* Важная новость */
	.fixed_label {
		width: 10px; height: 18px;
		padding: 0;
		margin-top: 20px;
		background-color: #e85319;
	}
		.fixed_label:before { display: none; }
		.fixed_label:after {
			bottom: auto; left: 100%; top: 0;
			margin: 0 0 0 -3px;
			border: solid transparent;
			border-right-color: #fff;
			border-width: 9px 3px 9px 0;
		}

	/* Хлебные крошки и сортировка */
	.pagetools {
		margin-bottom: 0;
		border-radius: 0;
		border-width: 0 0 1px 0;
		height: 51px;
		padding-left: 50px;
	}
		.pagetools_back { width: 50px; height: 50px; }
		.sortbar, .breadcrumb_in {
			width: 100%;
			overflow-x: auto; overflow-y: hidden;
			-webkit-overflow-scrolling: touch;
		}
		.breadcrumb_in .over { display: block; overflow: visible; }
		.sortbar_in:after, .breadcrumb_in .over:after { content: ""; width: 25px; display: inline-block; }
	
	/* Постраничная навигация */
	.page_next-prev { height: auto; float: none; background: none; box-shadow: none; -webkit-box-shadow: none; }
		.page_prev { float: left; }
		.page_next { float: right; }
		.page_prev, .page_next {
			position: relative;
			z-index: 1;
			border-radius: 18px;
			background-color: #fff;
			box-shadow: 0 1px 2px 0 rgba(0,0,0,0.2); -webkit-box-shadow: 0 1px 2px 0 rgba(0,0,0,0.2);
		}
		.pages { text-align: center; }
		.navigation .pages > * {
			display: none;
			border-radius: 18px;
			background: #9c9c9c;
			color: #fff;
			box-shadow: 0 1px 2px 0 rgba(0,0,0,0.2); -webkit-box-shadow: 0 1px 2px 0 rgba(0,0,0,0.2);
		}
		.navigation .pages > span { background: #9F9F9F; }
		.navigation .pages > span,
		.navigation .pages > *:first-child,
		.navigation .pages > *:last-child { display: inline-block; }
		.navigation .pages > span.nav_ext { display: none; }

	/* Комментарии */
	.addcomment .plus_icon { display: none; }
	.addcomment h3 { display: none; } 

	.comment { padding: 20px; padding-bottom: 60px; }
		.com_content > .title { font-size: 1.15em; }
		.comment .meta {
			position: absolute;
			bottom: 14px; left: 20px; right: 20px;
		}
		.com_info { margin: 0 0 20px 0; padding-left: 46px; }
		.com_user { display: block; }
		.comment .avatar { margin-left: -46px; margin-right: 0; }
		.comment .rate_like > a, .comment  .rate_like-dislike { border-color: transparent; }
		.comment .meta .mass, .reply a span { display: none; }

	/* Древовидные комментарии */
	#dle-comments-list > .comments-tree-list > li > .comments-tree-list { padding: 0 20px; }
	.comments-tree-list li ol li .comment {
		padding: 20px 0;
		padding-bottom: 60px;
	}
	.comments-tree-list .comments-tree-list .comment .meta { left: 0; right: 0; }
	.comments-tree-list > li > ol > li .comment:before { margin: 25px 0 0 -20px; }

	/* Контакты */
	.contacts { font-size: 1em; }
		.contacts > .grid_1_2 { margin-top: 15px; padding-left: 30px; }
		.contacts > .grid_1_2 .icon { width: 16px; height: 18px; margin-left: -30px; }

	/* Формы */
	.form_submit > .btn-big { width: 100%; margin-top: 5px; }
		.form_submit .c-captcha { float: none; margin-bottom: 20px; }
		.c-captcha img, .c-captcha > input { width: 122px; }
		.combo_field { margin-bottom: 20px; }

	/* Оптимизация регистрации и восстановления пароля */
	.page_form { padding-left: 0; padding-top: 50px; }
		.page_form__xxx { padding: 0 8%; }
		.page_form__logo .icon { margin-top: 0; }
		.page_form__back {
			left: 0;
			z-index: 999;
			width: 100%; height: 50px;
			padding: 0;
		}
		.page_form__back > .icon { top: 50%; left: 0; margin: -10px 0 0 8%; }
		.page_form__back:after { display: none; }

		.page_form__inner > .title { font-size: 24px; }

	/* Статистика */
	.stats_head > ul { font-size: 1em; }

	/* Персональные сообщения */
	#pm-menu { margin-bottom: 20px; }
		#pm-menu a {
			padding: 10px 0;
			color: inherit;
			display: block;
			border-top: 1px solid #efefef;
			text-decoration: none !important;
		}
		#pm-menu a:hover { color: #9F9F9F; }

	/* Страница пользователя */
	.userinfo_top { padding-bottom: 50px; }
	.user_tab > li { display: block; margin-right: 0; }
		.user_tab > li > a { font-size: 11px; letter-spacing: 0; }

	.ui-c1, .ui-c2 { width: 100%; margin: 0; display: block; vertical-align: top; }
	.ui-c1 { font-size: .9em; }

	/* Меню снизу */
	.footer_menu { padding: 15px; }
		.foot_menu { margin: 0; }
		.foot_menu > li { float: none; width: auto; padding: 0; }
		.foot_menu > li:first-child > b { border-top-width: 0; }
		.foot_menu > li > b {
			cursor: pointer;
			margin: 0; padding: 10px 0;
			font-weight: normal;
			border-top: 1px solid #d5d5d5;
		}

		.foot_menu > li > b i {
			display: block;
			float: right;
			width: 12px; height: 2px;
			position: relative;
			margin: 10px 0;
			background-color: #353535;
		}
		.foot_menu > li > b.collapsed i, .foot_menu > li > b.collapsed i:after { background-color: #9F9F9F; }
		.foot_menu > li > b.collapsed i:after {
			content: "";
			display: block;
			margin: -5px auto 0 auto;
			height: 12px; width: 2px;
		}
		.foot_menu > li .collapse { display: none; }
		.foot_menu > li .collapse.in { display: block; }
		.foot_menu > li nav { padding: 10px; padding-top: 0; }

	.footer { background: <?=$uzcms->pas_color?>; padding: 15px; }
	.footer .midside { display: block; padding: 0; }
	.footer .copyright, .footer .copyright a { color: #d5d5d5; }
		.footer .copyright { padding: 0 0 15px 0; border-bottom: 1px solid #2c2c2c; }
		.footer .ca { display: block; float: none; margin: 0; padding: 15px 0; color: #4e4e4e !important; }
		.footer .ca .icon { fill: #323232; }
	}

	.g-hidden { display: none; }
.g-line { zoom: 1; }
.g-line:after { content: "."; display: block; height: 0; clear: both; visibility: hidden; }
.l-container { width: 100%; padding: 0 40px; margin: 0 auto; }

.c-hiddenn { display: none; }
.c-linen { zoom: 1; }
.c-linen:after { content: "."; display: block; height: 0; clear: both; visibility: hiddenn; }
.kv3{
    color: red !important;
    padding: 13px;
    display: block !important;
    border-top-style: none !important;
    font-size: 14px;
	font-family: cursive;
    font-style: italic;
}
.kv4{
	background: #90fa9a;
    color: red !important;
    padding: 13px;
    border-top-style: none !important;
	border-radius: 5px;
    font-size: 14px;
	font-family: cursive;
    font-style: italic;
}
.kv5{
	background: #90fa9a;
    color: red !important;
    padding: 13px;
    border-top-style: none !important;
	font-size: 14px;
	font-family: cursive;
    font-style: italic;
}
.kv1{
    display: inline-block;
    color: #686868 !important;
    padding: 13px;
    display: block !important;
    border-top-style: none !important;
    font-size: 14px;
	font-family: cursive;
    font-style: italic;
}
.bolimlar{
	background: #fff;
	margin-top: -35px;
	padding: 6px;
	}
.uff{
    padding-top: 30px;
    padding-bottom: 30px;
    margin-bottom: 30px;
    color: inherit;
   
}
.kv2{
	background: #fff; 
	cursor: pointer; 
	border: 1px solid #ccc;
    color: #686868 !important;
    padding: 13px;
    display: block !important;
    font-size: 14px;
	font-style: italic;
	margin: 5px;
}
.kv2:first-child{
    border-top-style: solid !important;
    border-top-left-radius: 2px;
    border-top-right-radius: 2px;
}

.kv2:last-child{
    border-bottom-left-radius: 2px;
    border-bottom-right-radius: 2px;
}

.kv2 td{
    padding: 2px;
}

.kv2 td.icons{
    width: 16px;
    height: 16px;
}

.kv2 td.image{
    width: 48px;
}

.kv2 td.title{
}

.kv2.hightlight td.title{
    font-weight: bold;
}

a.kv2:hover{
    text-decoration: none !important;
    background-color: white;
}

.kv2 td.chap{
    width: 1px;
    white-space: nowrap;
    font-size: 100%;
    color: #979797;
}

.kv2 td.content{   
}

.kv2 td.bottom{
    text-align: right;
    font-size: 80%;
    color: #979797;
}

.kv2 .actions a{
    padding: 2px;
    opacity: 0.1;
    transition:all 300ms;
    -moz-transition:all 300ms; /* Firefox 4 */
    -webkit-transition:all 300ms; /* Safari и Chrome */
    -o-transition:all 300ms; /* Opera */
}

.kv2:hover .actions a{    
    opacity: 0.5;
}

.kv2 .actions a:hover{
    opacity: 1;
}

.kv2 .vaqt{
	width: 1px;
    white-space: nowrap;
    font-size: 80%;
    color: #979797;
}

.kv2 .counter{
    white-space: nowrap;
    border-radius: 10000px;
    padding: 0px 4px;
    float: right;
    font-weight: bold;
    color: #3F7EFD;
    box-shadow: 0 0 0 1px white, 0px 0px 2px -1px black inset;
}
.kv2 img{
    white-space: nowrap;
    border-radius: 10000px;
    padding: 0px 4px;
    float: right;
    font-weight: bold;
    color: #3F7EFD;
    box-shadow: 0 0 0 1px white, 0px 0px 2px -1px black inset;
}
.passss{
display: inline-block;
margin-top: auto;
}

.fonn:first-child{
    border-top-style: solid !important;
    border-top-left-radius: 2px;
    border-top-right-radius: 2px;
}

.fonn:last-child{
    border-bottom-left-radius: 2px;
    border-bottom-right-radius: 2px;
}

.fonn td{
    padding: 2px;
}

.fonn td.icons{
    width: 16px;
    height: 16px;
}

.fonn td.image{
    width: 48px;
}

.fonn td.title{
}

.fonn.hightlight td.title{
    font-weight: bold;
}

a.fonn:hover{
    text-decoration: none !important;
    background-color: white;
}

.fonn td.chap{
    width: 1px;
    white-space: nowrap;
    font-size: 100%;
    color: #979797;
}

.fonn td.content{   
}

.fonn td.bottom{
    text-align: right;
    font-size: 80%;
    color: #979797;
}

.fonn .actions a{
    padding: 2px;
    opacity: 0.1;
    transition:all 300ms;
    -moz-transition:all 300ms; /* Firefox 4 */
    -webkit-transition:all 300ms; /* Safari и Chrome */
    -o-transition:all 300ms; /* Opera */
}

.fonn:hover .actions a{    
    opacity: 0.5;
}

.fonn .actions a:hover{
    opacity: 1;
}

.fonn .vaqt{
	width: 1px;
    white-space: nowrap;
    font-size: 80%;
    color: #979797;
}

.fonn .counter{
    white-space: nowrap;
    border-radius: 10000px;
    padding: 0px 4px;
    float: right;
    font-weight: bold;
    color: #3F7EFD;
    box-shadow: 0 0 0 1px white, 0px 0px 2px -1px black inset;
}
.fonn img{
    white-space: nowrap;
    border-radius: 10000px;
    padding: 0px 4px;
    float: right;
    font-weight: bold;
    color: #3F7EFD;
    box-shadow: 0 0 0 1px white, 0px 0px 2px -1px black inset;
}
.www{
	cursor: pointer; 
	border: 0px solid #ccc;
    color: #686868 !important;
    padding: 13px;
    display: block !important;
    font-size: 14px;
	font-style: italic;
	margin: -3px;
}


.btn1 {
  color : rgb(49, 46, 46);
  background-color: rgba(255, 222, 121, 0.96);
  border-radius: 10px 0 0 10px;
  font-size: 16px;
}

.btn1:not([disabled]):hover {
  background-color: rgba(107, 103, 91, 0.96);
  color: white;
}

.btn1[disabled] {
  color : rgb(187, 187, 187);
  background-color: rgba(230, 230, 229, 0.96);
}
</style>