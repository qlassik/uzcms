<center class="fe">
    <?
    echo $page == 1 ? '<span class=""> 1 </span>' : '<a class="korma" href="' . $link . 'page=1"> 1 </a>';
    for ($i = max(2, $page - 8); $i < min($k_page, $page + 10); $i++) {
        if ($i == $page)
            echo '<span class="korma">  ' . $i . ' </span> ';
        else
            echo ' <a class="korma" href="' . $link . 'page=' . $i . '"> ' . $i . ' </a>';
    }
    echo $page == $k_page ? ' <span class="korma"> ' . $k_page . ' </span> ' : ' <a class="korma" href="' . $link . 'page=' . $k_page . '"> ' . $k_page . ' </a> '
    ?>
</center>
