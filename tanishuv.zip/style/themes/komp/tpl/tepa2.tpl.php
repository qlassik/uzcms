<?
 $e = ''.$lang->name.'nomi';
$_SESSION['sava'] = $_SERVER['REQUEST_URI'];
$return =  $_SESSION['sava'];
 $ank = (empty($_GET ['id'])) ? $user : new user((int)$_GET ['id']);
 if ($user->id){  
 if ($_SESSION['vozz'] == $_SERVER['REQUEST_URI']){
   
   
   
 }else{
$as = mysql_result(mysql_query("SELECT COUNT(*) FROM `mt`"), 0);
$im = mt_rand(1, $as);


 
 
 
 
 
 
 
 
 
 
 
 if ($user->xtet){
 if ($user->xtet == '12345'){
$ss = mysql_query("SELECT * FROM `mt` WHERE `id`='".$im."' ");
while ($csw= mysql_fetch_assoc($ss)) {
echo  $csw['cod'];
}
 }else{
$ss = mysql_query("SELECT * FROM `mt` WHERE `id`='".$user->xtet."' ");
while ($csw= mysql_fetch_assoc($ss)) {
echo  $csw['cod'];
}
}
}elseif ($uzcms->xtet == '12345'){	
$ss = mysql_query("SELECT * FROM `mt` WHERE `id`='".$im."' ");
while ($csw= mysql_fetch_assoc($ss)) {
echo  $csw['cod'];
}
}else{
$ss = mysql_query("SELECT * FROM `mt` WHERE `id`='".$uzcms->xtet."' ");
while ($csw= mysql_fetch_assoc($ss)) {
echo  $csw['cod'];	
}
}
 
  echo'<div class="logo"><table cellpadding="0" cellspacing="0" width="100%">';
  echo'<tbody><tr>';
  echo'<td class="r_bar" width="5%" style="border-right: 1px solid #fe8483">';
  echo'<ul id="nav"><li>'; 
  echo'<a href="/ID" style="text-decoration: none;">';
  echo'<font color="white"><img src="/img/cab_man.png"> </font>';
  echo'</a>';
  echo'</li></ul></td>';
  
  
  
  
  
  

  
  
  
  
  
  
  

$sql_where = array("`mail`.`id_user` = '{$user->id}'");
$sql_where[] = "`mail`.`is_read` = '0'";
$q = mysql_query("SELECT `users`.`id`,
        `mail`.`id_sender`,
        MAX(`mail`.`time`) AS `time`,
        MIN(`mail`.`is_read`) AS `is_read`,
        COUNT(`mail`.`id`) AS `count`
FROM `mail`
LEFT JOIN `users` ON `mail`.`id_sender` = `users`.`id`
WHERE " . implode(' AND ', $sql_where) . "
GROUP BY `mail`.`id_sender`
ORDER BY `time` DESC
LIMIT 1");
while ($ma = mysql_fetch_assoc($q)) {
	$ank = new user((int)$ma['id_sender']);
	if ($ma['count'] == $user->mail_new_count){
	$ke = $ma['id'];
	}else{
	$ke = $user->login;	
	}
	 	
}
  if(!isset($ke))$ke = $user->login;
  if ($ke == $user->login){
  if ($user->mail_new_count){
  echo'<td class="r_bar" width="5%" style="border-right: 1px solid #fe8483">';
  echo'<ul id="nav"><li>'; 
  echo'<a href="/xabar?xabar_keldi" style="text-decoration: none;">';
  echo'<font color="white"><img src="/img/send.png"> '.$user->mail_new_count.'</font>';
  echo'</a>';
  echo'</li></ul></td>'; 
  }else{

  if ($user->mail_k_new_count){
  echo'<td class="r_bar" width="5%" style="border-right: 1px solid #fe8483">';
  echo'<ul id="nav"><li>'; 
  echo'<a href="/komfrensa?men" style="text-decoration: none;">';
  echo'<font color="white"><img src="/img/send.png"> '.$user->mail_k_new_count.'</font>';
  echo'</a>';
  echo'</li></ul></td>'; 
  }
  
	  
	  
  }
  }else{
  echo'<td class="r_bar" width="5%" style="border-right: 1px solid #fe8483">';
  echo'<ul id="nav"><li>'; 
  echo'<a href="/xabar?id='.$ke.'" style="text-decoration: none;">';
  echo'<font color="white"><img src="/img/send.png"> '.$user->mail_new_count.'</font>';
  echo'</a>';
  echo'</li></ul></td>';   
  }
  

  if ($user->friend_new_count){
  echo'<td class="r_bar" width="5%" style="border-right: 1px solid #fe8483">';
  echo'<ul id="nav"><li>'; 
  echo'<a href="mening_dostlarim.html?friend" style="text-decoration: none;">';
  echo'<font color="white"><img src="/img/notification-on-w.png"> '.$user->friend_new_count.'</font>';
  echo'</a>';
  echo'</li></ul></td>'; 
  }elseif ($user->mexmon){
  echo'<td class="r_bar" width="5%" style="border-right: 1px solid #fe8483">';
  echo'<ul id="nav"><li>'; 
  echo'<a href="/mexmonlar.html" style="text-decoration: none;">';
  echo'<font color="white"><img src="/img/kor.png"> '.$user->mexmon.'</font>';
  echo'</a>';
  echo'</li></ul></td>'; 
  }elseif ($user->kon_qosh){
  echo'<td class="r_bar" width="5%" style="border-right: 1px solid #fe8483">';
  echo'<ul id="nav"><li>'; 
  echo'<a href="/komfrensa_xabar.html?id='.$user->id.'" style="text-decoration: none;">';
  echo'<font color="white"><img src="/img/notification-on-w.png"> '.$user->kon_qosh.'</font>';
  echo'</a>';
  echo'</li></ul></td>'; 
  }elseif ($user->gruppa){
  echo'<td class="r_bar" width="5%" style="border-right: 1px solid #fe8483">';
  echo'<ul id="nav"><li>'; 
  echo'<a href="/grup.html" style="text-decoration: none;">';
  echo'<font color="white"><img src="/img/notification-on-w.png"> '.$user->gruppa.'</font>';
  echo'</a>';
  echo'</li></ul></td>'; 
  } 

  if ($user->baxo){ 
  echo'<td class="r_bar" width="5%" style="border-right: 1px solid #fe8483">';
  echo'<ul id="nav"><li>'; 
  echo'<a href="/baxo.html" style="text-decoration: none;">';
  echo'<font color="white"><img src="/img/baxo.png"> '.$user->baxo.'</font>';
  echo'</a>';
  echo'</li></ul></td>'; 
  }else{
  echo'<td class="r_bar" width="5%" style="border-right: 1px solid #fe8483"><ul id="nav"><li> ';
  echo'<a href="/hozir_saytda.html" style="text-decoration: none;">';
  echo'<font color="white"><img src="/img/us.png"> '.mysql_result(mysql_query("SELECT COUNT(*) FROM `users_online`"), 0).'</font>';
  echo'</a>';
  echo'</li></ul></td>';  
  }
  
if ($user->chatga){
  echo'<td class="r_bar" width="5%" style="border-right: 1px solid #fe8483"><ul id="nav"><li>';
  echo'<a href="/chat/" style="text-decoration: none;">';
  echo'<font color="white">';
  echo'<img src="/img/jaa.png" /> <img src="/img/obs.png" />  '.mysql_result(mysql_query("SELECT COUNT(*) FROM `chat_mini` WHERE `u` = '".$user->id."'"), 0).'';
  echo' </font>';
  echo'</a>';
  echo'</li></ul></td>';		
}else{
  echo'<td class="r_bar" width="5%" style="border-right: 1px solid #fe8483"><ul id="nav"><li>';
  echo'<a href="/chat/" style="text-decoration: none;">';
  echo'<font color="white">';
  echo'<img src="/img/obs.png">  '.mysql_result(mysql_query("SELECT COUNT(*) FROM `chat_on`"), 0).'';
  echo' </font>';
  echo'</a>';
  echo'</li></ul></td>';	
}

  
  
  echo'<td class="r_bar" width="5%" style="border-right: 1px solid #fe8483"><ul id="nav">';
  echo'<li>';
  echo'<a href="/lenta.html" style="text-decoration: none;">';
  echo'<font color="white"><img src="/img/lenta.png"> '.$user->sharh.'</font>';
  echo'</a>';
  echo'</li></ul></td>';
  
  
  echo'<td class="r_bar" width="5%" style="border-right: 1px solid #fe8483">';
  echo'<ul id="nav"><li>';
  echo'<a href="/muhokama.html" style="text-decoration: none;">';
  echo'<font color="white"><img src="/img/chat.png"> '.$user->bildirgi.'</font>';
  echo'</a>';
  echo'</li></ul></td></tr></tbody></table>';
  echo'</div>';
 }
}



        if ($err || $msg){
		?>			
		<div class="list1">
				  <?= $this->section($err, '<div style="color:red" class="">{text}</div>'); ?>
                  <?= $this->section($msg, '<div style="color:green" class="">{text}</div>'); ?>
        </div>		
			<?
			
			
}else{ 
if ($_SESSION['qayt'] == $_SERVER['REQUEST_URI']);else{   
 if ($user->ak == '2'){
	 echo'<div class="list1">'.__('Sizning profilingiz aktivlashtirilmagan, saytdan to`liq foydalanish uchun iltimos profilingizni <a href="/ak.html"><b>faollashtring</b></a>.').'</div>';
  }
  if ($user->ak == '3'){
	 echo'<div class="list1">'.__('Sizni profilingizni admin rad qildi aktivlashni.').'</div>'; 
  }
  if ($user->id && !$user->username || $user->id && !$user->userfam || $user->id && !$user->ank_d_r || $user->id && !$user->ank_m_r || $user->id && !$user->ank_g_r) {
	 echo'<div class="list1" style="color: red;">'.__('Malumotlaringzni to`ldiring <a href="/sozlash"><b> sozlash</b></a>.').'</div>';
  	  
  }

// echo'<div class="list1">» <a href="/sms/"><span style="font-weight: bold;">Bepul sms yuborish</span></a></div>'; 	
} 
}
$kir = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `ak` = '2' AND `bol` = '2'"), 0);
if ($_SESSION['qayt'] == $_SERVER['REQUEST_URI']){
	
	
}else{
	
if ($user->group >= '4' && $kir){ 
 echo '<div class="news"><b>'.$title.'</b> <a href="/ak.html"><b style="color: red;">'.__('Aktivlang').' ('.$kir.')</b></a></div>';
}else{
 echo '<div class="news"><b>'.$title.'</b></div>';	 
 }	
}
$user->mail_new_count = mysql_result(mysql_query("SELECT COUNT(*) FROM `mail` WHERE `id_user` = '$user->id' AND `is_read` = '0'"), 0);


  ?>  
  
  
  
  
  
  <style>
  #qani{
	  margin-top: 10px;
	  margin: 12px; 
	  background: #fbfcfd;
    border: 1px solid #f1f1f1;
  }
  .qani {
	display: inline-block;
    padding: 4px 9px;
    margin: 3px;
    font-size: 85%;
    font-weight: 400;
    line-height: 1.42857143;
    text-align: center;
    white-space: nowrap;
    vertical-align: middle;
    -ms-touch-action: manipulation;
    touch-action: manipulation;
    cursor: pointer;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    border-radius: 1px;
    background: #fbfcfd;
    border: 1px solid #f1f1f1;
}
  .qaniz {
	display: inline-block;
    padding: 4px 9px;
    margin: 3px;
    font-size: 85%;
    font-weight: 400;
    line-height: 1.42857143;
    text-align: center;
    white-space: nowrap;
    vertical-align: middle;
    -ms-touch-action: manipulation;
    touch-action: manipulation;
    cursor: pointer;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    border-radius: 1px;
    background: #fbfcfd;
}
  </style>
  <?if ($dostga){?>
  <div id="qani"> <?echo' '.$this->section($dostga, '<span  class="qani" role="alert"><a href="{1}"> {0} </a></span> / ').''; ?>  </div>
  <?}?>
 
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  