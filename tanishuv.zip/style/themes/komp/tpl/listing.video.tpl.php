<style>
		@media (max-width:500px) and (min-width:100px) {
div.gallery {
    margin: 3px;
    border: 1px solid #ccc;
    float: left;
    width: 72px;
	height: 72px;
}

div.gallery:hover {
    border: 1px solid #777;
}

div.gallery img {
    width: 100%;
    height: auto;
	height: 45px;
}

div.desc {
    padding: 5px;
    text-align: center;
}
.ayy{
    display: inline-block;
    min-width: 8px;
    padding: 1px 4px;
    font-size: 10px;
    font-weight: 700;
    line-height: 1;
    color: #fff;
    text-align: center;
    white-space: nowrap;
    vertical-align: middle;
    background-color: #777;
    border-radius: 7px;
	}
    }
	@media (min-width:500px) and (max-width:2700px) {
    div.gallery {
    margin: 3px;
    border: 1px solid #ccc;
    float: left;
    width: 100px;
	height: 100px;
}

div.gallery:hover {
    border: 1px solid #777;
}

div.gallery img {
    width: 100%;
    height: auto;
	height: 70px;
}

div.desc {
    padding: 5px;
    text-align: center;
}
.ayy{
    display: inline-block;
    min-width: 8px;
    padding: 1px 4px;
    font-size: 10px;
    font-weight: 700;
    line-height: 1;
    color: #fff;
    text-align: center;
    white-space: nowrap;
    vertical-align: middle;
    background-color: #777;
    border-radius: 7px;
	}
    }
	
	
	

</style>
<?
$im = mt_rand(1, 20);
$iefix = ($url && $uzcms->ie_ver && $uzcms->ie_ver < 10) ? 'onclick="location.href = \'' . $url . '\'"' : '';
$kv_time = $time ? '<span class="time">' . $time . '</span>' : '';
$kv_counter = $counter ? '<span class="counter gradient_grey invert border">' . $counter . '</span>' : '';
$actions = '<span class="actions">' . $this->section($actions, '<a href="{url}"><img src="{icon}" alt="" /></a>') . '</span>';
$kv_mehmon = $mehmon ? '<span class="time">' . $mehmon . '</span>' : '';
?>


	   <li>
											<a href="<?=$url?>" data-rel="colorbox">
												<img width="80" height="80" alt="voo.ux" src="<?=$image?>" />
											</a>

											<div class="tools tools-top in">
												<a href="<?=$url?>">
													<i style="font-size: 55%; color: #fff;"><?=stripcslashes(htmlspecialchars(@iconv_substr($title, 0, 18, 'utf-8')))?></i>
												</a>
                                            </div>
										</li>
									
