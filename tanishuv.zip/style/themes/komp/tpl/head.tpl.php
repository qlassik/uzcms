<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?= $lang->xml_lang ?>">
    <head>
    <title><?= $title ?></title>
    <? if ($description) { ?>
        <meta name="description" content="<?= $description ?>" />
    <? } ?>
    <? if ($keywords) { ?>
        <meta name="keywords" content="<?= $keywords ?>" />
    <? } ?>
	<meta http-equiv="Сontent-Type" content="application/xhtml+xml; charset=utf-8"/>
    <meta name="generator" content="UZCMS <?= $uzcms->version ?>" />
	<meta name="keywords" content="<?= $title ?>" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="UZCMS <?= $uzcms->xabar ?>">
    <meta name="author" content="UZCMS <?= $uzcms->korik ?>">
	<link rel="stylesheet" href="/ajax/css/voouz.css" />
	<link rel="stylesheet" href="/ajax/assets/css/bootstrap.min.css" />
	<link rel="stylesheet" href="/ajax/assets/font-awesome/4.5.0/css/font-awesome.min.css" />
    <link rel="stylesheet" href="/ajax/assets/css/fonts.googleapis.com.css" />
        <link rel="stylesheet" href="/ajax/assets/css/ace.min.css" class="ace-main-stylesheet" id="main-ace-style" />
        <link rel="stylesheet" href="/ajax/assets/css/ace-rtl.min.css" />
        <script src="/ajax/assets/js/ace-extra.min.js"></script>
	    <script src="/ajax/assets/js/jquery-2.1.4.min.js"></script>
        <script src="/ajax/assets/js/bootstrap.min.js"></script>
		<?=$this->display('uzcms.tpl');?>	
	<?=$this->display('style.tpl');?>
	<link rel="stylesheet" href="<?= $path ?>/css/style.css">
	
    <? if ($_SESSION['vozz']  == $_SERVER['REQUEST_URI']){?>   
	<?}else{?>
	<?if ($user->id){?>
	<link href="<?= $path ?>/uzcms.css" type="text/css" rel="stylesheet" />
	<?}?>
	<link href="<?= $path ?>/icons.css" type="text/css" rel="stylesheet" />
	 <?}?>
<?
echo"<style type='text/css'>";
$sonidgtsgytrht = mysql_result(mysql_query("SELECT COUNT(*) FROM `css`"), 0);
$sdsdsd = mysql_query("SELECT * FROM `css` WHERE  `id` ORDER BY `id` DESC LIMIT ".$sonidgtsgytrht."");
while ($css= mysql_fetch_assoc($sdsdsd)) {
$css3 = $css['cod'];
}




?>


a.button15 {
  display: inline-block;
  font-family: arial,sans-serif;
  font-size: 11px;
  font-weight: bold;
  color: rgb(68,68,68);
  text-decoration: none;
  user-select: none;
  padding: .2em 1.2em;
  outline: none;
  border: 1px solid rgba(0,0,0,.1);
  border-radius: 2px;
  background: rgb(245,245,245) linear-gradient(#f4f4f4, #f1f1f1);
  transition: all .218s ease 0s;
}
a.button15:hover {
  color: rgb(24,24,24);
  border: 1px solid rgb(198,198,198);
  background: #f7f7f7 linear-gradient(#f7f7f7, #f1f1f1);
  box-shadow: 0 1px 2px rgba(0,0,0,.1);
}
a.button15:active {
  color: rgb(51,51,51);
  border: 1px solid rgb(204,204,204);
  background: rgb(238,238,238) linear-gradient(rgb(238,238,238), rgb(224,224,224));
  box-shadow: 0 1px 2px rgba(0,0,0,.1) inset;
}
.kaz{
	background: <?=$user->fon_color?>;
	text-align: center;
    white-space: nowrap;
    vertical-align: middle;
    border-radius: 2px;
	font-size: 34px;
	margin: 3px;
	padding: 8px;
	color: #fff;
	}
	.kazx{
	background: yelow;
	text-align: center;
    white-space: nowrap;
    vertical-align: middle;
    border-radius: 2px;
	margin: 3px;
	padding: 4px;
	color: #fff;
	}
	.fonu13{
	background: <?=$user->fon_color?>;
	text-align: center;
	font-size: 76%;
    white-space: nowrap;
    vertical-align: middle;
    border-radius: 10px 0px 10px 10px;
	margin: 1px;
	padding: 4px;
	}	
	.fonu12{
	background: <?=$user->fon_color?>;
	text-align: center;
	font-size: 76%;
    white-space: nowrap;
    vertical-align: middle;
    border-radius: 10px 0px 20px 0px;
	margin: 1px;
	padding: 4px;
	}	
	.fonu11{
	background: <?=$user->fon_color?>;
	text-align: center;
	font-size: 76%;
    white-space: nowrap;
    vertical-align: middle;
    border-radius: 10px 20px 10px 10px;
	margin: 1px;
	padding: 4px;
	}	
	.fonu9{
	background: <?=$user->fon_color?>;
	text-align: center;
    white-space: nowrap;
	font-size: 76%;
    vertical-align: middle;
    border-radius: 10px 0px 0px 0px;
	margin: 1px;
	padding: 4px;
	}	
	.fonu8{
	background: <?=$user->fon_color?>;
	text-align: center;
    white-space: nowrap;
	font-size: 76%;
    vertical-align: middle;
    border-radius: 10px 10px 10px 0px;
	margin: 1px;
	padding: 4px;
	}		
	.fonu7{
	background: <?=$user->fon_color?>;
	text-align: center;
    white-space: nowrap;
    vertical-align: middle;
	font-size: 76%;
    border-radius: 0px 10px 10px 0px;
	margin: 1px;
	padding: 4px;
	}		
	.fonu6{
	background: <?=$user->fon_color?>;
	text-align: center;
    white-space: nowrap;
    vertical-align: middle;
	font-size: 76%;
    border-radius: 10px 0px 0px;
	margin: 1px;
	padding: 4px;
	}		
	.fonu10{
	background: <?=$user->fon_color?>;
	text-align: center;
    white-space: nowrap;
	font-size: 76%;
    vertical-align: middle;
    border-radius: 10px 0px 27px;
	margin: 1px;
	padding: 4px;
	}		
	.fonu5{
	background: <?=$user->fon_color?>;
	text-align: center;
    white-space: nowrap;
	font-size: 76%;
    vertical-align: middle;
    border-radius: 0px 0px 27px;
	margin: 1px;
	padding: 4px;
	}	
	.fonu4{
	background: <?=$user->fon_color?>;
	text-align: center;
    white-space: nowrap;
	font-size: 76%;
    vertical-align: middle;
    border-radius: 10px 27px;
	margin: 1px;
	padding: 4px;
	}
	.fonu3{
	background: <?=$user->fon_color?>;
	text-align: center;
    white-space: nowrap;
    vertical-align: middle;
    border-radius: 0px 27px;
	font-size: 76%;
	margin: 1px;
	padding: 4px;
	}	
	.fonu2{
	background: <?=$user->fon_color?>;
	text-align: center;
    white-space: nowrap;
    vertical-align: middle;
	font-size: 76%;
    border-radius: 27px;
	margin: 1px;
	padding: 3px;
	}
	.fonu1{
	background: <?=$user->fon_color?>;
	text-align: center;
    white-space: nowrap;
    vertical-align: middle;
    border-radius: 7px;
	font-size: 76%;
	margin: 1px;
	padding: 5px;
	}
	

	@media (max-width:6478px) and (min-width:990px) {
    
    }
#qanii{
	padding: 10px;
	margin: -1px;
}
			@media (max-width:478px) and (min-width:100px) {
    .tusheee {
       margin-top: 50px;
    }
    }
		@media (max-width:11878px) and (min-width:478px) {
    .tusheee {
       display: none;
    }
    }	
		@media (max-width:478px) and (min-width:100px) {
    .tepaa {
       margin-top: -120px;
    }
    }
		@media (max-width:11878px) and (min-width:478px) {
    .tepaa {
       margin-top: -20px;
    }
    }
	
	
		@media (max-width:500px) and (min-width:100px) {
    .foo {
        display:none;
    }
    }
		@media (max-width:4479px) and (min-width:479px) {
    .yon_479 {
        display:none;
    }
    }	
		@media (max-width:479px) and (min-width:10px) {
    .och_479 {
        display:none;
    }
	.yon_479 {
        float:right; clear:left;
    }
    }	
			@media (max-width:988px) and (min-width:100px) {
    .foos {
        display:none;
    }
    }
			@media (max-width:5988px) and (min-width:988px) {
    .foosjk {
        display:none;
    }
    }
	
	
	@media (min-width:500px) and (max-width:2700px) {
    .fooy{
        display:none;
    }
    }
    @media (max-width:768px) and (min-width:100px) {
    .bolim {
        display:none;
    }
    }
    @media (min-width:768px) and (max-width:2700px) {
    .bolimm {
        display:none;
    }
    }
	</style>
</head>
<?


$as = mysql_result(mysql_query("SELECT COUNT(*) FROM `mt`"), 0);
$im = mt_rand(1, $as);
if ($uzcms->titga == '12345'){	
$ss = mysql_query("SELECT * FROM `mt` WHERE `id`='".$im."' ");
while ($csw= mysql_fetch_assoc($ss)) {
$tepas = $csw['cod'];
}
}else{
$ss = mysql_query("SELECT * FROM `mt` WHERE `id`='".$uzcms->titga."' ");
while ($csw= mysql_fetch_assoc($ss)) {
$tepas = $csw['cod'];
}
}

	if (isset($_SESSION['skin']) || isset($_COOKIE['skin'])){
	if (isset($_COOKIE['skin'])){
	echo'<body class="'.$_COOKIE['skin'].'">';
	}elseif(isset($_SESSION['skin'])){
	echo'<body class="'.$_SESSION['skin'].'">';
	}
	}else{
	echo'<body class="no-skin">';
	}
	
	echo '<div id="fonu">';
 
if ($user->id){
if($_SESSION['tepaga'] == $_SERVER['REQUEST_URI']){
$this->display('mail.tepa1.tpl');
}else{
$this->display('tepa1.tpl');	
}
}else{
echo $tepas ;


}




?>

		<div class="main-container ace-save-state" id="main-container">
			<?if ($user->id){ echo'<div class="tepaa"></div>'; } ?>
			<script type="text/javascript">
				try{ace.settings.loadState('main-container')}catch(e){}
			</script>
<?if($user->id){?><div class="tusheee"></div>
			<?
				if (isset($_SESSION['sur']) || isset($_COOKIE['sur'])){
				if (isset($_SESSION['sur']) && $_SESSION['sur'] == 'ok'){	
			    echo'<div id="sidebar" class="sidebar                  responsive                    ace-save-state sidebar-scroll push_away">';
				}elseif (isset($_COOKIE['sur']) && $_COOKIE['sur'] == 'ok'){	
			    echo'<div id="sidebar" class="sidebar                  responsive                    ace-save-state sidebar-scroll push_away">';
				}
				}else{
			echo'<div id="sidebar" class="sidebar                  responsive                    ace-save-state ">';
			}
			?>
			<script type="text/javascript">
					try{ace.settings.loadState('sidebar')}catch(e){}
				</script>

				<div class="sidebar-shortcuts" id="sidebar-shortcuts">
					<div class="sidebar-shortcuts-large" id="sidebar-shortcuts-large">
						<?
						if (MANZIL_S == '/user/profile/index.php' || MANZIL_S == '/index.php'){
                         $ide = (int)$_GET ['id'];
                         $oziniki = (empty($ide)) ? $user : new user((int)$ide);
                        }else{
						 $oziniki = (empty($user)) ? $user : new user((int)$user);
                        }
						 
						 
						 
					 
						 
						 
if($_SESSION['tepaga'] == $_SERVER['REQUEST_URI']){
if (MANZIL_S == '/user/xizmatlar/mail.php'){
	?></div><center style="margin-top: 11px; font-size: 18px;" class="fa fa-desktop"></center></div>
				<ul class="nav nav-list">
				<?
$user->mail_new_count = mysql_result(mysql_query("SELECT COUNT(*) FROM `mail` WHERE `id_user` = '$user->id' AND `is_read` = '0'"), 0);

$sql_where = array("`mail`.`id_user` = '{$user->id}'");
if ($user->mail_new_count) {
    $sql_where[] = "`mail`.`is_read` = '0'";
}

$pages = new pages ();
$pages->posts = mysql_result(mysql_query("SELECT COUNT(DISTINCT(`mail`.`id_sender`)) FROM `mail` WHERE " . implode(' AND ', $sql_where)), 0); 
$pages->this_page(); 

$q = mysql_query("SELECT `users`.`id`,
        `mail`.`id_sender`,
        MAX(`mail`.`time`) AS `time`,
        MIN(`mail`.`is_read`) AS `is_read`,
        COUNT(`mail`.`id`) AS `count`
FROM `mail`
LEFT JOIN `users` ON `mail`.`id_sender` = `users`.`id`
WHERE " . implode(' AND ', $sql_where) . "
GROUP BY `mail`.`id_sender`
ORDER BY `time` DESC
LIMIT $pages->limit");

$listing = new listing();
while ($mail = mysql_fetch_assoc($q)) {
	$ozinikis = new user((int)$mail['id_sender']);
    $rey = $listing->rey();
    $rey->image = $ozinikis->getAva();
    $rey->url = 'xabar?id=' . $ozinikis->id;
    $rey->title = sm_nick(text::toOutput($ozinikis->username));
	if (!$mail['is_read']){
    $rey->hightlight = $user->mail_new_count ? '+' . $mail['count'] : $mail['count'];
    }else{
	$rey->hightlight = $user->mail_new_count ? '+' . $mail['count'] : $mail['count'];
    }
	if ($ozinikis->id == $_GET['id']){
	$rey->admine = $ozinikis->id;
	}
}
    



$listing->display(__('Yozishmalar yo`q'));

$pages->display('?');
}elseif (MANZIL_S == '/user/xizmatlar/mail_k.php'){
	?></div><center style="margin-top: 11px; font-size: 18px;" class="fa fa-desktop"></center></div>
				<ul class="nav nav-list">
				<?	

$listing = new listing();
$q = mysql_query("SELECT * FROM `komfrensa` WHERE `id_user` = '$user->id'  ORDER BY `id` DESC LIMIT 18");
while ($p_user = mysql_fetch_assoc($q)) {
$rey = $listing->rey();
$qaa = mysql_query("SELECT * FROM `komfrensa_nom` WHERE `id` = '".$p_user['admin']."' ORDER BY `id` DESC LIMIT 1");
while ($pa_a = mysql_fetch_assoc($qaa)) {
$rasim = $pa_a['rasim'];
$p = $pa_a['ne'];
}
$rey->image = $rasim;	
$rey->url = '?id='.$p_user['id'].'&ida='.$p_user['user'].'';
$rey->title = $p_user['nomi'];	
if (isset($p)){
$rey->hightlight = $p;
}
if ($p_user['id'] == $_GET['id']){
	$rey->admine = $p_user['id'];
}	
}
$listing->display(__('Ro`yhat bo`sh'));
	
}
}else{
?><img class="nav-user-photo" style="border-radius: 20px; margin: 8px; width: 80%;" src="<?= $oziniki->getAva(); ?>" alt="VOO.UZ" />
						
						
						
						<? if($user->id == $oziniki->id){ ?>	
						<button class="btn btn-success">
							<a href="/files/mening_fayllarim.php?id=<?=$oziniki->id;?>" style="text-decoration: none;"><?= sm_icon(qlassik_ru('58'));?></a>
						</button>

						<button class="btn btn-info">
							<a href="/qongiroq.html" style="text-decoration: none;"><?= sm_icon(qlassik_ru('59'));?></a>
						</button>

						<button class="btn btn-warning">
							<a href="/s_sozlash" style="text-decoration: none;"><?= sm_icon(qlassik_ru('60'));?></a>
						</button>

						<button class="btn btn-danger">
							<a href="/sozlash" style="text-decoration: none;"><?= sm_icon(qlassik_ru('61'));?></a>
						</button>
					</div>
					<?}else{?>
						<button class="btn btn-success">
							<a href="/xabar?id=<?=$oziniki->id;?>" style="text-decoration: none;"><?= sm_icon(qlassik_ru('77'));?></a>
						</button>

						<button class="btn btn-info">
							<a href="/tell_qill.html?qongiroq=<?=$oziniki->id;?>" style="text-decoration: none;"><?= sm_icon(qlassik_ru('78'));?></a>
						</button>

						<button class="btn btn-warning">
							<a href="/pul_otkazish.html?id=<?=$oziniki->id;?>" style="text-decoration: none;"><?= sm_icon(qlassik_ru('79'));?></a>
						</button>

						<button class="btn btn-danger">
							<a href="/bani.html?id=<?=$oziniki->id;?>" style="text-decoration: none;"><?= sm_icon(qlassik_ru('80'));?></a>
						</button>
					</div>					
					
					
					<?}?>
	
                        
					<div class="sidebar-shortcuts-mini" id="sidebar-shortcuts-mini">
						<span class="btn btn-success"></span>

						<span class="btn btn-info"></span>

						<span class="btn btn-warning"></span>

						<span class="btn btn-danger"></span>
					</div>
				</div>
				<ul class="nav nav-list">
				
				
				<?
if (isset($_SESSION['highlight']) && $dhighlight = $_SESSION['highlight'] == 'highlight' || isset($_COOKIE['highlight'])  && $dhighlight = $_COOKIE['highlight'] == 'highlight'){
				$dighlight = ' highlight  hover';	
				}else{
				$dighlight = '';
				}

if (MANZIL_S == '/user/xizmatlar/mail.php'){
$active = 'active'.$dighlight.'';	
}
if (MANZIL_S == '/user/xizmatlar/mail_k.php'){
$active1 = 'active'.$dighlight.'';	
}
if (MANZIL_S == '/foto/albums.php' || MANZIL_S == '/foto/index.php' || MANZIL_S == '/foto/photos.php' || MANZIL_S == '/foto/photo.php'){
$active4 = 'active'.$dighlight.'';	
}
if (MANZIL_S == '/gruppa/index.php' || MANZIL_S == '/gruppa/za.php' || MANZIL_S == '/gruppa/bil.php' ){
$active6 = 'active'.$dighlight.'';	
}	
if (MANZIL_S == '/forum/my.themes.php' || MANZIL_S == '/forum/index.php' || MANZIL_S == '/forum/vote.new.php' || MANZIL_S == '/forum/vote.edit.php' || MANZIL_S == '/forum/topic.themes.delete.php' || MANZIL_S == '/forum/topic.new.php' || MANZIL_S == '/forum/topic.edit.php' || MANZIL_S == '/forum/topic.delete.php' || MANZIL_S == '/forum/topic.php' || MANZIL_S == '/forum/theme.status.php' || MANZIL_S == '/forum/theme.security.php' || MANZIL_S == '/forum/theme.rename.php' || MANZIL_S == '/forum/theme.posts.delete.php' || MANZIL_S == '/forum/theme.new.php' || MANZIL_S == '/forum/theme.move.php' || MANZIL_S == '/forum/theme.delete.php' || MANZIL_S == '/forum/theme.actions.php' || MANZIL_S == '/forum/theme.php' || MANZIL_S == '/forum/search.php' || MANZIL_S == '/forum/message.new.php' || MANZIL_S == '/forum/message.history.php' || MANZIL_S == '/forum/message.files.php' || MANZIL_S == '/forum/message.edit.php' || MANZIL_S == '/forum/message.php' || MANZIL_S == '/forum/last.themes.php' || MANZIL_S == '/forum/last.posts.php' || MANZIL_S == '/forum/category.new.php' || MANZIL_S == '/forum/category.edit.php' || MANZIL_S == '/forum/category.delete.php' || MANZIL_S == '/forum/category.clear.php' || MANZIL_S == '/forum/categories.sort.php' || MANZIL_S == '/forum/category.php'){
$active7 = 'active'.$dighlight.'';	
}
if (MANZIL_S == '/kundalik/my.themes.php' || MANZIL_S == '/kundalik/index.php' || MANZIL_S == '/kundalik/vote.new.php' || MANZIL_S == '/kundalik/vote.edit.php' || MANZIL_S == '/kundalik/topic.themes.delete.php' || MANZIL_S == '/kundalik/topic.new.php' || MANZIL_S == '/kundalik/topic.edit.php' || MANZIL_S == '/kundalik/topic.delete.php' || MANZIL_S == '/kundalik/topic.php' || MANZIL_S == '/kundalik/theme.status.php' || MANZIL_S == '/kundalik/theme.security.php' || MANZIL_S == '/kundalik/theme.rename.php' || MANZIL_S == '/kundalik/theme.posts.delete.php' || MANZIL_S == '/kundalik/theme.new.php' || MANZIL_S == '/kundalik/theme.move.php' || MANZIL_S == '/kundalik/theme.delete.php' || MANZIL_S == '/kundalik/theme.actions.php' || MANZIL_S == '/kundalik/theme.php' || MANZIL_S == '/kundalik/search.php' || MANZIL_S == '/kundalik/message.new.php' || MANZIL_S == '/kundalik/message.history.php' || MANZIL_S == '/kundalik/message.files.php' || MANZIL_S == '/kundalik/message.edit.php' || MANZIL_S == '/kundalik/message.php' || MANZIL_S == '/kundalik/last.themes.php' || MANZIL_S == '/kundalik/last.posts.php' || MANZIL_S == '/kundalik/category.new.php' || MANZIL_S == '/kundalik/category.edit.php' || MANZIL_S == '/kundalik/category.delete.php' || MANZIL_S == '/kundalik/category.clear.php' || MANZIL_S == '/kundalik/categories.sort.php' || MANZIL_S == '/kundalik/category.php'){
$active8 = 'active'.$dighlight.'';	
}
if (MANZIL_S == '/chat/index.php' || MANZIL_S == '/chat/korsatkich.php' || MANZIL_S == '/chat/xabarni_ochirish.php' || MANZIL_S == '/chat/xabarlarni_ochirish.php'){
$active5 = 'active'.$dighlight.'';	
}
if (MANZIL_S == '/user/aktiv/chiqish.php'){
$active12 = 'active'.$dighlight.'';	
}
if (MANZIL_S == '/files/mening_fayllarim.php' || MANZIL_S == '/files/mening_fayllarim.php' ){
$active13 = 'active'.$dighlight.'';	
}
if (MANZIL_S == '/user/status/index.php' || MANZIL_S == '/user/status/all.php' || MANZIL_S == '/user/status/kom.php'){
$active14 = 'active'.$dighlight.'';	
}
//echo MANZIL_S;

if($user->id == $oziniki->id){

 $sql_where = array("`mail`.`id_user` = '{$user->id}'");
$sql_where[] = "`mail`.`is_read` = '0'";
$q = mysql_query("SELECT `users`.`id`,
        `mail`.`id_sender`,
        MAX(`mail`.`time`) AS `time`,
        MIN(`mail`.`is_read`) AS `is_read`,
        COUNT(`mail`.`id`) AS `count`
FROM `mail`
LEFT JOIN `users` ON `mail`.`id_sender` = `users`.`id`
WHERE " . implode(' AND ', $sql_where) . "
GROUP BY `mail`.`id_sender`
ORDER BY `time` DESC
LIMIT 1");
while ($ma = mysql_fetch_assoc($q)) {
	$oziniki = new user((int)$ma['id_sender']);
	if ($ma['count'] == $user->mail_new_count){
	$ke = $ma['id'];
	}else{
	$ke = $user->login;	
	}
	 	
}
  if(!isset($ke))$ke = $user->login;
  if ($ke == $user->login){
  if ($user->mail_new_count){
  echo'<li class="'.$active.'"><a href="/xabar?xabar_keldi"><i class="menu-icon">'.sm_icon(qlassik_ru('27')).'  </i><span class="menu-text"> '.__('Habar keldi').' </span><span style="margin: 0 7px 7px 13px;" class="badge badge-primary">'.$user->mail_new_count.'</span></a><b class="arrow"></b></li>';
  }else{
   echo'<li class="'.$active.'"><a href="/xabar?"><i class="menu-icon">'.sm_icon(qlassik_ru('26')).'  </i> <span class="menu-text"> '.__('Habarlar').' </span></a><b class="arrow"></b></li>';
  }
  }else{
	echo'<li class="'.$active.'"><a href="/xabar?id='.$ke.'"><i class="menu-icon">'.sm_icon(qlassik_ru('27')).'  </i><span class="menu-text"> '.__('Habar keldi').' </span><span style="margin: 0 7px 7px 13px;" class="badge badge-primary">'.$user->mail_new_count.'</span></a><b class="arrow"></b></li>';
  }
  
  
 
  	if ($user->mail_k_new_count){
  echo'<li class="'.$active1.'"><a href="/komfrensa?men"><i class="menu-icon">'.sm_icon(qlassik_ru('38')).'  </i> <span class="menu-text"> '.__('Konfrensya').' </span><span style="margin: 0 7px 7px 13px;" class="badge badge-primary">'.$user->mail_k_new_count.'</span></a><b class="arrow"></b></li>';
  }else{
	 echo'<li class="'.$active1.'"><a href="/komfrensa?men"><i class="menu-icon">'.sm_icon(qlassik_ru('39')).'  </i> <span class="menu-text"> '.__('Konfrensya').' </span></a><b class="arrow"></b></li>';
 }
  if ($user->friend_new_count){
  echo'<li class="active'.$dighlight.'"><a href="/mening_dostlarim.html?friend"><i class="menu-icon">'.sm_icon(qlassik_ru('49')).'  </i> <span class="menu-text"> '.__('Do`rtar').' </span><span style="margin: 0 7px 7px 13px;" class="badge badge-primary">'.$friend_new_count.'</span></a><b class="arrow"></b></li>';  
  }elseif ($user->mexmon){
  echo'<li class="active'.$dighlight.'"><a href="/mexmonlar.html"><i class="menu-icon">'.sm_icon(qlassik_ru('50')).'  </i> <span class="menu-text"> '.__('Mexmonlar').' </span><span style="margin: 0 7px 7px 13px;" class="badge badge-primary">'.$user->mexmon.'</span></a><b class="arrow"></b></li>';  
  }elseif ($user->kon_qosh){
   echo'<li class="active'.$dighlight.'"><a href="/komfrensa?men"><i class="menu-icon">'.sm_icon(qlassik_ru('51')).'  </i> <span class="menu-text"> '.__('Konfrensaga').' </span><span style="margin: 0 7px 7px 13px;" class="badge badge-primary">'.$user->kon_qosh.'</span></a><b class="arrow"></b></li>';  
  }elseif ($gurpaga_chaqiryapti){
  echo'<li class="active'.$dighlight.'"><a href="/grup.html"><i class="menu-icon">'.sm_icon(qlassik_ru('52')).'  </i> <span class="menu-text"> '.__('Gurpaga taklif').' </span><span style="margin: 0 7px 7px 13px;" class="badge badge-primary">'.$gurpaga_chaqiryapti.'</span></a><b class="arrow"></b></li>';  
  }elseif ($gurpamga_keldi){
  echo'<li class="active'.$dighlight.'"><a href="/grup_keldi.html"><i class="menu-icon">'.sm_icon(qlassik_ru('53')).'  </i> <span class="menu-text"> '.__('Gurpaga keldi').' </span><span style="margin: 0 7px 7px 13px;" class="badge badge-primary">'.$gurpamga_keldi.'</span></a><b class="arrow"></b></li>';  
  }elseif ($xza = mysql_result(mysql_query("SELECT COUNT(*) FROM `tell_b` WHERE `id_user` = '".$user->id."' AND `ko` = '3'"), 0)){
  echo'<li class="active'.$dighlight.'"><a href="/grup_keldi.html"><i class="menu-icon">'.sm_icon(qlassik_ru('64')).'  </i> <span class="menu-text"> '.__('Qo`ngiroq qildi').' </span><span style="margin: 0 7px 7px 13px;" class="badge badge-primary">'.$xza.'</span></a><b class="arrow"></b></li>';  
  } 


  	if ($user->sharh){
  echo'<li class="'.$active2.'"><a href="/sharh.html"><i class="menu-icon">'.sm_icon(qlassik_ru('40')).'  </i> <span class="menu-text"> '.__('Sharhlar').' </span><span style="margin: 0 7px 7px 13px;" class="badge badge-primary">'.$user->sharh.'</span></a><b class="arrow"></b></li>';
  }else{
	 echo'<li class="'.$active2.'"><a href="/sharh.html"><i class="menu-icon">'.sm_icon(qlassik_ru('41')).'  </i> <span class="menu-text"> '.__('Sharhlar').' </span></a><b class="arrow"></b></li>';
 }

 
  	if ($user->bildirgi){
  echo'<li class="'.$active3.'"><a href="/bildirgi.html"><i class="menu-icon">'.sm_icon(qlassik_ru('42')).'  </i> <span class="menu-text"> '.__('Bildirgi').' </span><span style="margin: 0 7px 7px 13px;" class="badge badge-primary">'.$user->bildirgi.'</span></a><b class="arrow"></b></li>';
  }else{
	 echo'<li class="'.$active3.'"><a href="/bildirgi.html"><i class="menu-icon">'.sm_icon(qlassik_ru('43')).'  </i> <span class="menu-text"> '.__('Bildirgilar').' </span></a><b class="arrow"></b></li>';
 }
}
    echo'<li class="'.$active4.'"><a href="/foto/albums.php?id='.$oziniki->id.'"><i class="menu-icon">'.sm_icon(qlassik_ru('44')).'  </i> <span class="menu-text"> '.__('Foto albom').' </span>';
	if ($sa = mysql_result(mysql_query("SELECT COUNT(*) FROM `fo` WHERE `id` = '".$user->id."'"), 0)){
	echo' <span style="margin: 0 7px 7px 13px;" class="badge badge-primary"> '.$sa.'</span>';
	}
	echo'</a><b class="arrow"></b></li>';
 if ($user->chatga){
    echo'<li class="'.$active5.'"><a href="/chat/"><i class="menu-icon">'.sm_icon(qlassik_ru('45')).'  </i> <span class="menu-text"> '.__($uzcms->chat_tepa).' </span> <img src="/img/ch_e.png" /> <span style="margin: 0 7px 7px 13px;" class="badge badge-primary"> '.mysql_result(mysql_query("SELECT COUNT(*) FROM `chat_mini` WHERE `u` = '".$user->id."'"), 0).'</span></a><b class="arrow"></b></li>';
 }else{
    echo'<li class="'.$active5.'"><a href="/chat/"><i class="menu-icon">'.sm_icon(qlassik_ru('45')).'  </i> <span class="menu-text"> '.__($uzcms->chat_tepa).' </span><span style="margin: 0 7px 7px 13px;" class="badge badge-primary">'.mysql_result(mysql_query("SELECT COUNT(*) FROM `chat_on`"), 0).'</span></a><b class="arrow"></b></li>';
 	 
 }
 echo'<li class="'.$active6.'"><a href="/gruppa/?mening='.$oziniki->id.'"><i class="menu-icon">'.sm_icon(qlassik_ru('76')).'  </i> <span class="menu-text"> '.__('Gruppa').' </span>';
 
 if (mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa` WHERE `admin` = '".$oziniki->id."'"), 0)){
  echo'<span style="margin: 0 7px 7px 13px;" class="badge badge-primary">'.mysql_result(mysql_query("SELECT COUNT(*) FROM `gruppa` WHERE `admin` = '".$oziniki->id."'"), 0).'</span>';
 
 }
  echo'</a><b class="arrow"></b></li>';
  
 echo'<li class="'.$active14.'"><a href="/user/status/index.php?='.$oziniki->id.'"><i class="menu-icon">'.sm_icon(qlassik_ru('81')).'  </i> <span class="menu-text"> '.__('Statuslar').' </span>';
 
 if ($saaaa = mysql_result(mysql_query("SELECT COUNT(*) FROM `status` WHERE `id_user` = '".$oziniki->id."'"), 0)){
  echo'<span style="margin: 0 7px 7px 13px;" class="badge badge-primary">'.$saaaa.'</span>';
 
 }
  echo'</a><b class="arrow"></b></li>';  
  
  
 echo'<li class="'.$active13.'"><a href="/files/mening_fayllarim.php?id='.$oziniki->id.'"><i class="menu-icon">'.sm_icon(qlassik_ru('82')).'  </i> <span class="menu-text"> '.__('Fayllar').' </span>';
 
 if ($mano1 = mysql_result(mysql_query("SELECT COUNT(*) FROM `files_cache` WHERE `id_user` = '".$oziniki->id."'  AND `berk` = 'img'"), 0) || $mano2 = mysql_result(mysql_query("SELECT COUNT(*) FROM `files_cache` WHERE `id_user` = '".$oziniki->id."' AND `berk` = 'mp3'"), 0) || $mano3 = mysql_result(mysql_query("SELECT COUNT(*) FROM `files_cache` WHERE `id_user` = '".$oziniki->id."'  AND `berk` = 'video'"), 0) || $mano4 = mysql_result(mysql_query("SELECT COUNT(*) FROM `files_cache` WHERE `id_user` = '".$oziniki->id."'  AND `berk` = 'Fayillar'"), 0)){
  $saaaax = $mano1 + $mano2 + $mano3 + $mano4;
  echo'<span style="margin: 0 7px 7px 13px;" class="badge badge-primary">'.$saaaax.'</span>';
 
 }
  echo'</a><b class="arrow"></b></li>';  
    
  
  
  
  
  
 	 
 
     echo'<li class="'.$active7.'"><a href="/forum/my.themes.php?id='.$oziniki->id.'"><i class="menu-icon">'.sm_icon(qlassik_ru('46')).'  </i> <span class="menu-text"> '.__('Forum').' </span>';
	 if ($forum = mysql_result(mysql_query("SELECT `th`.* ,
        `tp`.`name` AS `topic_name`,
        `cat`.`name` AS `category_name`,
        `tp`.`group_write` AS `topic_group_write`,
        COUNT(`msg`.`id`) AS `count`,
        (SELECT COUNT(`fv`.`id_user`) FROM `forum_views` AS `fv` WHERE `fv`.`id_theme` = `msg`.`id_theme`)  AS `views`
FROM `forum_messages` AS `msg`
LEFT JOIN `forum_themes` AS `th` ON `th`.`id` = `msg`.`id_theme`
LEFT JOIN `forum_topics` AS `tp` ON `tp`.`id` = `th`.`id_topic`
LEFT JOIN `forum_categories` AS `cat` ON `cat`.`id` = `th`.`id_category`
WHERE `th`.`id_autor` = '{$oziniki->id}'
AND `th`.`group_show` <= '{$user->group}'
AND `tp`.`group_show` <= '{$user->group}'
AND `cat`.`group_show` <= '{$user->group}'
AND `msg`.`group_show` <= '{$user->group}'
GROUP BY `msg`.`id_theme`
ORDER BY MAX(`msg`.`time`)"), 0)){
	 echo'<span style="margin: 0 7px 7px 13px;" class="badge badge-primary">'.$forum.'</span>';
	 }
	 echo'</a><b class="arrow"></b></li>';
 
         echo'<li class="'.$active8.'"><a href="/kundalik/my.themes.php?id='.$oziniki->id.'"><i class="menu-icon">'.sm_icon(qlassik_ru('47')).'  </i> <span class="menu-text"> '.__('Kundalik').' </span>';
	 if ($kundalik = mysql_result(mysql_query("SELECT `th`.* ,
        `tp`.`name` AS `topic_name`,
        `cat`.`name` AS `category_name`,
        `tp`.`group_write` AS `topic_group_write`,
        COUNT(`msg`.`id`) AS `count`,
        (SELECT COUNT(`fv`.`id_user`) FROM `kundalik_views` AS `fv` WHERE `fv`.`id_theme` = `msg`.`id_theme`)  AS `views`
FROM `kundalik_messages` AS `msg`
LEFT JOIN `kundalik_themes` AS `th` ON `th`.`id` = `msg`.`id_theme`
LEFT JOIN `kundalik_topics` AS `tp` ON `tp`.`id` = `th`.`id_topic`
LEFT JOIN `kundalik_categories` AS `cat` ON `cat`.`id` = `th`.`id_category`
WHERE `th`.`id_autor` = '{$oziniki->id}'
AND `th`.`group_show` <= '{$user->group}'
AND `tp`.`group_show` <= '{$user->group}'
AND `cat`.`group_show` <= '{$user->group}'
AND `msg`.`group_show` <= '{$user->group}'
GROUP BY `msg`.`id_theme`
ORDER BY MAX(`msg`.`time`)"), 0)){
	 echo'<span style="margin: 0 7px 7px 13px;" class="badge badge-primary">'.$kundalik.'</span>';
	 }
	 echo'</a><b class="arrow"></b></li>';
 
     echo'<li class="'.$active9.'"><a href="/oyinlar"><i class="menu-icon">'.sm_icon(qlassik_ru('54')).'  </i> <span class="menu-text"> '.__('O`yinlar').' </span><span style="margin: 0 7px 7px 13px;" class="badge badge-primary">'.$uzcms->oyin.'</span></a><b class="arrow"></b></li>';
 
   	
	echo'<li class="'.$active10.'"><a href="/pullik_xizmatlar.html"><i class="menu-icon">'.sm_icon(qlassik_ru('55')).'  </i> <span class="menu-text"> '.__('Pullik xizmatlar').' </span></a><b class="arrow"></b></li>';
 
   	echo'<li class="'.$active11.'"><a href="/boshqa_bolimlar.html"><i class="menu-icon">'.sm_icon(qlassik_ru('56')).'  </i> <span class="menu-text"> '.__('Boshqa bo`limlar').' </span></a><b class="arrow"></b></li>';
 
  	echo'<li class="'.$active12.'"><a href="/chiqish.html"><i class="menu-icon">'.sm_icon(qlassik_ru('57')).'  </i> <span class="menu-text"> '.__('Saytdan chiqish').' </span></a><b class="arrow"></b></li>';
 			
}				
?>
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				</ul>
				<div class="sidebar-toggle sidebar-collapse" id="sidebar-collapse">
					<i id="sidebar-toggle-icon" class="ace-icon fa fa-angle-double-left ace-save-state" data-icon1="ace-icon fa fa-angle-double-left" data-icon2="ace-icon fa fa-angle-double-right"></i>
				</div>
			</div>
			
			<?}?>
			
			
			<div class="main-content">
				
<?if($user->id)if($_SESSION['tepaga'] == $_SERVER['REQUEST_URI']);else{?>
			<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<?
							
							
							if (MANZIL_S == '/admin/editon.php'){
							echo'<li>
							<i class="ace-icon fa fa-home home-icon"></i>
								<a onclick="javascript:history.back(); return false;"> '.__('Qaytish').'</a>
							</li>';
							}else{
							echo'<li>
							
							<i class="ace-icon fa fa-home home-icon"></i>
								<a href="/">'.__('Bosh sahifa').'</a>
							</li>';								
							}
						   
						   
						   if ($user->ak == '2'){
						   echo'<li class="active">
								<a href="/ak.html" style="color: red;">'.__('Pro`filni aktivlang').'</a>
							</li>';
					   }elseif ($user->ak == '3'){
						   echo'<li class="active">
								<a href="/admin"  style="color: red;">'.__('Rad etilgan profil').'</a>
							</li>';								   
							   
						   }
						   if ($user->id && !$user->username || $user->id && !$user->userfam || $user->id && !$user->ank_d_r || $user->id && !$user->ank_m_r || $user->id && !$user->ank_g_r) {
						   echo'<li class="active">
								<a href="/sozlash"  style="color: green;">'.__('Profilingizni sozlang').'</a>
							</li>';								   
						   }
						   
							
							if ($dostga){?>
                            <?echo' '.$this->section($dostga, '<li  class="active"><a href="{1}"> {0} </a></li> ').''; ?>  
                            <?}?>
							
                            
						</ul>
						
						
						
						

						<div class="nav-search" id="nav-search">
							<form class="form-search">
								<span class="input-icon">
									<input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
									<i class="ace-icon fa fa-search nav-search-icon"></i>
								</span>
							</form>
						</div>
					</div>
					<?}?>

					<style>
					.chiziq_t {
                    margin-top: -20px;
					}					
					.chiziqs {
                    background-color: #FFF;
                    position: relative;
                    margin: 0;
                    padding: 2px 2px 4px;
					}
					.chiz{
                    padding-bottom: 3px;
                    margin: 4px 0 4px;
                    border-bottom: 1px solid #eee;
					}					
					</style>
				
			
					
			<div class="chiziq">
						

						<div class="row2">
							<div class="col-xs-13">
								
								
								
					<?
					if($msg){
						?><style>
                    .alert-fkk {
                    background-color: <?=$uzcms->erorga?>;
                    color: #fff;
                    }
                    </style><?
		
					}
					if($err){
						?><style>
                    .alert-fkk {
                    background-color: <?=$uzcms->msgga?>;
                    color: #31708f;
                    }
                    </style><?	
					}
					
					if ($err || $msg){?>
					<div class="alert alert-fkk hidden-sm hidden-xs">
									<button type="button" class="close" data-dismiss="alert">
										<i class="ace-icon fa fa-times"></i>
									</button>
					<?= $this->section($err, '{text}'); ?>
                    <?= $this->section($msg, '{text}'); ?>
					</div>
								
								
								
					<div class="alert alert-fkk hidden-md hidden-lg">
									<button type="button" class="close" data-dismiss="alert">
										<i class="ace-icon fa fa-times"></i>
									</button>
					<?= $this->section($err, '{text}'); ?>
                    <?= $this->section($msg, '{text}'); ?>
					</div>
                   <?}?>		
								
								<?= $content ?>
								
								
																		<?
if ($user->id){

	
	
	
 if ($_SESSION['vozz']  == $_SERVER['REQUEST_URI']){

$this->display('eng_tagi_mail.tpl');	 

 }else{
$this->display('eng_tagi.tpl');	 
}
}
?>	
								

							</div>
						</div>
					</div>
				</div>
			</div>

			
		</div><? if (!MANZIL_S == '/user/profile/azo_bol.php'){?>
		 <script src="/ajax/js/jquery.min.js"></script>
		<?}?>
	
		</div>
		
		
		
		<script type="text/javascript">
			if('ontouchstart' in document.documentElement) document.write("<script src='/ajax/assets/js/jquery.mobile.custom.min.js'>"+"<"+"/script>");
		</script>
		<script src="/ajax/assets/js/ace-elements.min.js"></script>
		<script src="/ajax/assets/js/ace.min.js"></script> 
		<?

	echo '<div style="position:fixed; left: 5%; bottom:15px;" id="frends"></div>';




?>
	</body>
</html>   
        
				
