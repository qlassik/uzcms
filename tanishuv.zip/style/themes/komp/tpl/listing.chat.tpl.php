<?
$iefix = ($url && $uzcms->ie_ver && $uzcms->ie_ver < 10) ? 'onclick="location.href = \'' . $url . '\'"' : '';
$post_time = $time ? '<span margin-top: -20px;  float:right; font-size: 80%; class="vaqt">' . $time . '</span>' : '';
$post_counter = $counter ? '<span class="counter gradient_grey invert border">' . $counter . '</span>' : '';
$post_actions = '<span class="actions">' . $this->section($actions, '<a href="{url}"><img src="{icon}" alt="" /></a>') . '</span>';
$post_actions_t = '<span class="actions">' . $this->section($actions_t, '<a href="{url}"><img src="{icon}" alt="" /></a>') . '</span>';

?>
        <? if ($image) { ?>

                    
<div style="margin:5px;padding:5px;border-bottom:1px solid #f2f2f2;">
<div class="row" ><div class="col-lg-12" >
<div class="media">
<table width="100%"><tr><td><a href="<?=$url?>" class="pull-left" >
<img style="width: 50px; height: 50px; border-radius:32px;" src="<?= $image ?>">
</a>
<div class="media-body" >
<div class="clock">
<small style="float:right; padding:5px; background:#f7f5f5;">
<?if ($time || $hightlight){?>
<?= $post_time ?>
<?= $hightlight ?>
		<?}?>
</small>
</div>
<p class="media-heading" style="margin-left:5px;">&nbsp;
<strong>
<?= $title ?><br /><? if ($admine){?>
    <?=$admine?>
		<?}?>
 </strong>&nbsp; 
 </p></div></td></tr>
 
 <tr><td></td></tr><tr><td style="   display: block !important; margin-top: 5px;" class="ana"><? if ($mehmon){?>
    <?=$mehmon?>
		<?}?><span style="float:right;><?= $post_actions ?></span>&nbsp;</td></tr></table>
 </div>
 </div> 
 </div>
 </div> 
 
               
        <? } elseif ($icon) { ?>
          
                    <img style="width:<?=$uzcms->k_icon_razmer?>px" src="<?= $icon ?>" alt="" />   <?= $title ?>
                    <?= $post_counter ?>
  
                    <?= $post_time ?>
                    <?= $post_actions ?>
                
        <? } else { ?>
                    <?= $title ?>
                    <?= $post_counter ?>
                
				    <?= $post_time ?>
                    <?= $post_actions ?>

        <? } ?>

        <? if ($content) { ?>
             <?= $content ?>
                
        <? } ?>

        <? if ($bottom) { ?>
             <?= $bottom ?>
          
        <? } ?>