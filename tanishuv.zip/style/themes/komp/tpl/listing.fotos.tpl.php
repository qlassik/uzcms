<style>
	#gallery {
    margin: 12px;
    background: #fbfcfd;
    border: 1px solid #f1f1f1;
}

#gallery:hover {
    border: 1px solid #777;
}
  

</style>
<?
$iefix = ($url && $uzcms->ie_ver && $uzcms->ie_ver < 10) ? 'onclick="location.href = \'' . $url . '\'"' : '';
$kv_mehmon = $mehmon ? '<span class="time">' . $mehmon . '</span>' : '';
?>
<a href="<?=$url?>">
<img  id="gallery" src="<?=$image?>" width="72" height="72" title="voo.uz ofissalni modul sayt" alt="voo.uz"></a>
<?if ($actions){?>
<?$actions = '<span class="actions">' . $this->section($actions, '<a href="{url}"><img src="{icon}" alt="" /></a>') . '</span>';?>
<span class="strike_k" style="top: 20px; margin-left: -78px;"><?=$actions?></span>
<?}?>


