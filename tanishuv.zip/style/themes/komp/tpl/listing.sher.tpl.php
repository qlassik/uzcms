<style>
 span.korildi {
  position: relative;
  z-index: 1;
  color: black;
  font-size: 50%;
  text-decoration: none;
}
span.korildi:after {
   content: "<?=$hightlight?>";  /* здесь 6 букв */
  position: absolute;
  z-index: -1;
  top: -5px;
  bottom: -5px;
  left: -5px;
  width: calc(100% + 6*(1em*90/110) - 2px*2*2);  /* где 6*(1em*90/235), где 6 - это 6 букв, 90 - это font-size after, а 235 - это font-size родителя */
  text-align: right;
  color: #fff;
  font-size: 120%;
  padding: .25em .5em;
  border-radius: 5px;
  border: 2px solid #c61e40;
  -webkit-transform: skewX(-10deg);
  transform: skewX(-10deg);
  background: linear-gradient(#d4536d, #c61e40) no-repeat 100% 0;
  background-size: calc(6*(1em*90/210) + .5em) 100%;
  box-shadow: inset calc(-6*(1em*90/10) - .5em) 0 rgba(255,255,255,0);
}
span.korildi1:hover:after {
  box-shadow: inset calc(-6*(1em*90/95) - .5em) 0 rgba(255,255,255,.2);
}
span.korildi:active:after {
  background-image: linear-gradient(#c61e40, #d4536d);
}
html { min-height:100vh;}
.mediPlayer { float:left; margin:2px;}
</style>
<? 
$iefix = ($url && $uzcms->ie_ver && $uzcms->ie_ver < 10) ? 'onclick="location.href = \'' . $url . '\'"' : '';
$post_time = $time ? '<span class="vaqt">' . $time . '</span>' : '';
$post_counter = $counter ? '<span class="counter gradient_grey invert border">' . $counter . '</span>' : '';
$post_actions = '<span class="actions">' . $this->section($actions, '<a href="{url}"><img src="{icon}" alt="" /></a>') . '</span>';
$post_actions_t = '<span class="actions">' . $this->section($actions_t, '<a href="{url}"><img src="{icon}" alt="" /></a>') . '</span>';

if($matn){
	$a = mt_rand(1, 10);
echo'<a href="'.$url.'"><div style="margin: 5px; min-height: 60px;" class="ana">';
echo '<img style="margin-top: -5px; width: 45px; height: 45px;" src="/img/kayfiyat/'.$a.'.png" /><div style="float:right; clear:left; margin-right: -8px; margin-top: -8px;" class="">'.$post_actions.'</div>';
echo '<a href="'.$url.'"><div style="margin-left: 50px; margin-top: -50px; font-size: 90%;">';
echo $matn;

echo '</div></a>';
echo '</div>';
echo'<div style="margin: 5px; min-height: 20px;" class="ana">';
echo '<div style="" ><span style="float:right; clear:left; margin-right: 22px; margin-top: 9px;" class="korildi">'.$bottom.'</span>';
echo '<div style="margin-top: -8px;" ><a href="'.$tabela_url.'"><span style="margin: 1px;">'.$tabela.' </span><img src="/img/klass_g.png" /></a>    <a href="'.$tabelb_url.'"><img src="/img/klass-b.png" /><span style="margin: 1px;"> '.$tabelb.' </span></a></div>';
echo'</div></div></a>';		
}elseif($rasim){
echo'<a href="'.$url.'"><div style="margin: 5px; min-height: 60px;" class="ana">';
echo '<img style="margin-top: -5px; width: 45px; height: 45px;" src="/files/.sts/'.$rasim.'" /><div style="float:right; clear:left; margin-right: -8px; margin-top: -8px;" class="">'.$post_actions.'</div>';
echo '<a href="'.$url.'"><div style="margin-left: 50px; margin-top: -50px; font-size: 90%;">';
echo $title;

echo '</div></a>';
echo '</div>';
echo'<div style="margin: 5px; min-height: 20px;" class="ana">';
echo '<div style="" ><span style="float:right; clear:left; margin-right: 22px; margin-top: 9px;" class="korildi">'.$bottom.'</span>';
echo '<div style="margin-top: -8px;" ><a href="'.$tabela_url.'"><span style="margin: 1px;">'.$tabela.' </span><img src="/img/klass_g.png" /></a>    <a href="'.$tabelb_url.'"><img src="/img/klass-b.png" /><span style="margin: 1px;"> '.$tabelb.' </span></a></div>';
echo'</div></div></a>';	
}elseif ($mp3){
?><link rel="stylesheet" href="/style/css/progres-bar.css">
<script src="/style/js/jquery-1.12.4.min.js"></script>
<script src="/style/js/player.js"></script>	
<div  style="margin: 10px; height: 25px;" class="mediPlayer">
<audio class="listen" preload="none" data-size="45" src="/files/yuklanmalar/.sts/<?=$mp3?>"></audio>
</div>

<script>
    $(document).ready(function () {
        $('.mediPlayer').mediaPlayer();
    });
</script>
<? echo'<a href="'.$url.'"><div style="margin: 5px; min-height: 55px;" class="ana">';
echo '<div style="float:right; clear:left; margin-right: -8px; margin-top: -38px;" class="">'.$post_actions.'</div>';
echo '<a href="'.$url.'"><div style="margin-right: -8px; margin-top: -10px; font-size: 90%;">';
echo $title;

echo '</div></a>';
echo '</div>';
echo'<div style="margin: 5px; min-height: 20px;" class="ana">';
echo '<div style="" ><span style="float:right; clear:left; margin-right: 22px; margin-top: 9px;" class="korildi">'.$bottom.'</span>';
echo '<div style="margin-top: -8px;" ><a href="'.$tabela_url.'"><span style="margin: 1px;">'.$tabela.' </span><img src="/img/klass_g.png" /></a>    <a href="'.$tabelb_url.'"><img src="/img/klass-b.png" /><span style="margin: 1px;"> '.$tabelb.' </span></a></div>';
echo'</div></div></a>';
}elseif($video){
echo'<a href="'.$url.'"><div style="margin: 5px; min-height: 60px;" class="ana">';
echo '<img style="margin-top: -5px; width: 45px; height: 45px;" src="/img/videoo.png" /><div style="float:right; clear:left; margin-right: -8px; margin-top: -8px;" class="">'.$post_actions.'</div>';
echo '<a href="'.$url.'"><div style="margin-left: 50px; margin-top: -50px; font-size: 90%;">';
echo $title;

echo '</div></a>';
echo '</div>';
echo'<div style="margin: 5px; min-height: 20px;" class="ana">';
echo '<div style="" ><span style="float:right; clear:left; margin-right: 22px; margin-top: 9px;" class="korildi">'.$bottom.'</span>';
echo '<div style="margin-top: -8px;" ><a href="'.$tabela_url.'"><span style="margin: 1px;">'.$tabela.' </span><img src="/img/klass_g.png" /></a>    <a href="'.$tabelb_url.'"><img src="/img/klass-b.png" /><span style="margin: 1px;"> '.$tabelb.' </span></a></div>';
echo'</div></div></a>';		
}?>


