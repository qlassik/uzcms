<style>
@media (max-width:300px) and (min-width:100px) {
.zzz{
	display: block !important; margin-top: -25px;

}
    }
	@media (min-width:300px) and (max-width:2700px) {
    .zzz{
		display: block !important; margin-top: -5px;

	}
    }
</style>
<?
$iefix = ($url && $uzcms->ie_ver && $uzcms->ie_ver < 10) ? 'onclick="location.href = \'' . $url . '\'"' : '';
$post_time = $time ? '<span class="vaqt">' . $time . '</span>' : '';
$post_counter = $counter ? '<span class="counter gradient_grey invert border">' . $counter . '</span>' : '';
$post_actions = '<span class="actions">' . $this->section($actions, '<a href="{url}"><img src="{icon}" alt="" /></a>') . '</span>';
$post_actions_t = '<span class="actions">' . $this->section($actions_t, '<a href="{url}"><img src="{icon}" alt="" /></a>') . '</span>';

?>
        <? if ($image) { ?>
	
                    
<div style="margin:5px;padding:5px;border-bottom:1px solid #f2f2f2;">
<div class="row" ><div class="col-lg-12" >
<div class="media">
<table width="100%"><tr><td><a href="<?=$url?>" class="pull-left" >
<img style="width: 40px; height: 40px; border-radius:22px;" src="<?= $image ?>" title="voo.uz">
</a>
<div class="media-body">
<div class="clock" style="font-size: 85%;">
<?if ($actions || $hightlight){?>
<small style="float:right; padding:5px; background:#f7f5f5;">
<?= $post_actions?>
<?= $hightlight ?>
</small>		
		<?}?>

</div>
<p class="media-heading" style="margin-left:5px;">&nbsp;
<strong>
<a href="<?=$url?>" class="pull-left" style="font-size: 85%;"><?= $title ?></a><br /><? if ($mehmon){?>
    <?=$mehmon?>
		<?}?>
 </strong>&nbsp; 
 </p></div> 
 </div>
		</td></tr>
 
 <tr><td></td></tr><tr><td style="font-size: 80%;   display: block !important; margin-top: 5px;" class="ana"><?= $admine ?>&nbsp;<small style="float:right; clear:left; padding:5px;"><?if ($time){?>
<div class="zzz"><?= $post_time ?></div>
		<?}?></small><br /> <? if ($content) { ?>
             <hr /><?= $content ?>
                
        <? } ?></td></tr></table>
 </div>
 </div> 
 </div>
 </div> 


 
		
		
		
		
		
		
		
		
		
		
           
               
        <? } elseif ($icon) { ?>
          
                    <img style="width:<?=$uzcms->k_icon_razmer?>px" src="<?= $icon ?>" alt="" />   <?= $title ?>
                    <?= $post_counter ?>
  
                    <?= $post_time ?>
                    <?= $post_actions ?>
                
        <? } else { ?>
                    <a href="<?=$url?>" ><div id="qani" class="gruppa">
					<?= $title ?>
                    <?= $post_counter ?>
                
				    <?= $post_time ?>
                    <div style="float:right; padding:1px; background:#f7f5f5;"><?= $post_actions ?></div>
					</div></a>

        <? } ?>

       

        <? if ($bottom) { ?>
             <?= $bottom ?>
          
        <? } ?>