<?
$iefix = ($url && $uzcms->ie_ver && $uzcms->ie_ver < 10) ? 'onclick="location.href = \'' . $url . '\'"' : '';
$kv_time = $time ? '<span class="time">' . $time . '</span>' : '';
$kv_counter = $counter ? '<span class="counter gradient_grey invert border">' . $counter . '</span>' : '';
$actions = '<span class="actions">' . $this->section($actions, '<a href="{url}"><img src="{icon}" alt="" /></a>') . '</span>';
$kv_mehmon = $mehmon ? '<span class="time">' . $mehmon . '</span>' : '';
?>
<?= ($url ? '<a href="' . $url . '" class="' : '<div class="') . 'kv' . ($hightlight ? ' hightlight' : '') . '" id="' . $id . '">' ?>
    
        <? if ($image) { ?>
            
              <article class="box story shortstory">
	<aside class="box hblock">
		<h2 class="title"><?= $title ?></h2></aside>
		
	
		<div align="center"><a href="#img"><img src="<?= $image ?>" alt="VOO.UZ" width="98%"></a></div>
		<div class="box_in">
			<div class="text">
			<?= $content ?>
		</div>
		<div class="story_tools">
			<div class="category">
				<svg class="icon icon-cat"><use href="#icon-cat"></use></svg>
			 <?=$toplam?></div>
			<i class="btn"><b><a href="<?=$url?>" style="color:#fff"><?=__('Batafsil')?></a></b></i>
			
				<div class="rate">
					<div class="rate_stars"><div id="ratig-layer-1"><div class="rating">
		<ul class="unit-rating">
		<li class="current-rating" style="width:0%;">0</li>
		<li><a href="/#" title="<?=__('Juda yomon')?>" class="r1-unit" onclick="doRate(&#39;1&#39;, &#39;1&#39;); return false;">1</a></li>
		<li><a href="/#" title="<?=__('Chidasa boladi')?>" class="r2-unit" onclick="doRate(&#39;2&#39;, &#39;1&#39;); return false;">2</a></li>
		<li><a href="/#" title="<?=__('Qoniqarli')?>" class="r3-unit" onclick="doRate(&#39;3&#39;, &#39;1&#39;); return false;">3</a></li>
		<li><a href="/#" title="<?=__('Yahshi')?>" class="r4-unit" onclick="doRate(&#39;4&#39;, &#39;1&#39;); return false;">4</a></li>
		<li><a href="/#" title="<?=__('Zo`r')?>" class="r5-unit" onclick="doRate(&#39;5&#39;, &#39;1&#39;); return false;">5</a></li>
		</ul>
</div></div></div>
					
					
				</div>
			
		</div>
		
	</div> 
	<div class="meta">
		<ul class="right">
			<li class="grey" title="<?=__('Korildi')?>: 0"><svg class="icon icon-views"><use href="#icon-views"></use></svg>  <?=$kv_mehmon?></li>
			<li title="<?=__('Sharhlar')?>: <?=$sharh?>"><a href="#comment"><svg class="icon icon-coms"><use href="#icon-coms"></use></svg> <?=$sharh?> </a></li>
		</ul>
		<ul class="left">
			<li class="story_date"><svg class="icon icon-info"><use href="#icon-info"></use></svg> <span class="grey"> <?=$admine?> </span><time datetime="" class="grey"><a href="<?= $kv_time_url ?>"> <?= $kv_time ?></a></time></li>
		</ul>
	</div>
</article>
            
        <? } elseif ($icon) { ?>
            
			
			
			
			<article class="box story shortstory">
	<aside class="box hblock">
		<h2 class="title"><?= $title ?></h2></aside>
		
	
		<div align="center"><a href="#img"><img src="<?= $icon ?>" alt="VOO.UZ" width="98%"></a></div>
		<div class="box_in">
			<div class="text">
			<?= $content ?>
		</div>
		<div class="story_tools">
			<div class="category">
				<svg class="icon icon-cat"><use href="#icon-cat"></use></svg>
			 <?=$toplam?></div>
			<i class="btn"><b><a href="<?=$url?>" style="color:#fff"><?=__('Batafsil')?></a></b></i>
			
				<div class="rate">
					<div class="rate_stars"><div id="ratig-layer-1"><div class="rating">
		<ul class="unit-rating">
		<li class="current-rating" style="width:0%;">0</li>
		<li><a href="/#" title="<?=__('Juda yomon')?>" class="r1-unit" onclick="doRate(&#39;1&#39;, &#39;1&#39;); return false;">1</a></li>
		<li><a href="/#" title="<?=__('Chidasa boladi')?>" class="r2-unit" onclick="doRate(&#39;2&#39;, &#39;1&#39;); return false;">2</a></li>
		<li><a href="/#" title="<?=__('Qoniqarli')?>" class="r3-unit" onclick="doRate(&#39;3&#39;, &#39;1&#39;); return false;">3</a></li>
		<li><a href="/#" title="<?=__('Yahshi')?>" class="r4-unit" onclick="doRate(&#39;4&#39;, &#39;1&#39;); return false;">4</a></li>
		<li><a href="/#" title="<?=__('Zo`r')?>" class="r5-unit" onclick="doRate(&#39;5&#39;, &#39;1&#39;); return false;">5</a></li>
		</ul>
</div></div></div>
					
					
				</div>
			
		</div>
		
	</div> 
	<div class="meta">
		<ul class="right">
			<li class="grey" title="<?=__('Korildi')?>: 0"><svg class="icon icon-views"><use href="#icon-views"></use></svg>  <?=$kv_mehmon?></li>
			<li title="<?=__('Sharhlar')?>: <?=$sharh?>"><a href="#comment"><svg class="icon icon-coms"><use href="#icon-coms"></use></svg> <?=$sharh?> </a></li>
		</ul>
		<ul class="left">
			<li class="story_date"><svg class="icon icon-info"><use href="#icon-info"></use></svg> <span class="grey"> <?=$admine?> </span><time datetime="" class="grey"><a href="<?= $kv_time_url ?>"> <?= $kv_time ?></a></time></li>
		</ul>
	</div>
</article>
			
			
			
			
			
			
			
			
        
        <? } else { ?>
   <?//sozla
?>   
                <span class="title">
                    <?= $title ?>
                    <?= $kv_counter ?>
                </span>

                <span class="vaqt">
                    <?= $kv_time ?>
                    <?= $kv_actions ?>
                </span>
          
        <? } ?>

        

        <? if ($bottom) { ?>
           
                    <?= $bottom ?>
             
        <? } ?>
 
<?=
$url ? '</a>' : '</div>'?>