   <select  style="width: 20%; float:right; clear:left; margin-top: -45px; margin-right: 30%; font-size: 100%; padding: 2px;" onchange="location = this.options[this.selectedIndex].value;">
        <?
        foreach ($order AS $option) {
            echo '<option style="font-size: 100%; padding: 2px;"  value="' . $option[0] . '"' . (!empty($option[2]) ? ' selected="selected"' : '') . '>' . $option[1] . '</option>';
        }
        ?>
    </select>

   
