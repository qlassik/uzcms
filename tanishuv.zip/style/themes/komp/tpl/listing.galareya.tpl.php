 <?
$iefix = ($url && $uzcms->ie_ver && $uzcms->ie_ver < 10) ? 'onclick="location.href = \'' . $url . '\'"' : '';
$post_time = $time ? '<span style="margin:5px; margin-left: -3px;"  class="vaqt">' . $time . '</span>' : '';
$post_counter = $counter ? '<span class="counter gradient_grey invert border">' . $counter . '</span>' : '';
$post_actions = '' . $this->section($actions, '<a href="{url}"><img src="{icon}" alt="" /></a>') . '';
$post_action_t = '' . $this->section($action_t, '<a href="{url}"><img src="{icon}" alt="" /></a>') . '';
?>

 <? if ($image) { ?> 

       
        



            <div class="gallery_product col-lg-2 col-md-4 col-sm-4 col-xs-6 filter hdpe">
                <div class="kv1" role="alert"> <center> <img style="width: 100%; max-width: 180px;  margin-left: -10px; margin-top: -10px; padding: 4px;  height: 180px;    display: block;
    background: #EBEBEB;
    border: 1px solid #DFDFDF;
    border-radius: 5px;" src="<?= $image ?>" alt="voo.uz"></center> <?= $post_time ?><div style="margin:5px; margin-left: -3px;"> <?= $post_actions ?>  <span style="float:right; clear:left; margin-right: -10px;"><?= $post_action_t  ?></span> </div>
				</div><div style="width: 100%; height: 50px; margin-top: -30px;"  class="alert alert-success" role="alert"><?= $title ?></div>
            </div>


            
        <? } elseif ($icon) { ?>
           
                   <div class="kv1" role="alert"> <center> <img style="width: 100%; max-width: 180px;  margin-left: -10px; margin-top: -10px; padding: 4px;  height: 180px;    display: block;
    background: #EBEBEB;
    border: 1px solid #DFDFDF;
    border-radius: 5px;" src="<?= $icon ?>" alt="voo.uz"></center> <?= $post_time ?><div style="margin:5px; margin-left: -3px;"> <?= $post_actions ?>  <span style="float:right; clear:left; margin-right: -10px;"><?= $post_action_t  ?></span> </div>
				</div><div style="width: 100%; height: 50px; margin-top: -30px;"  class="alert alert-success" role="alert"><?= $title ?></div>
          
				   
                
        <? } else { ?>
            
                    <?= $title ?>
                    <?= $post_counter ?>
               
                    <?= $post_time ?>
                    <?= $post_actions ?>
               
        <? } ?>

        <? if ($content) { ?>
            
                    <?= $content ?>
               
        <? } ?>

        <? if ($bottom) { ?>
             <?= $bottom ?>
              
        <? } ?>
