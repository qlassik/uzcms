<?
 $ank = (empty($_GET ['id'])) ? $user : new user((int)$_GET ['id']);
  

echo'<div class="fonniki"><a href="/user/fon/"><div class="tema"></div></a>';


  echo'<div class="js"><div id="chap">
   <div class="rasimga"><img src="' . $ank->getAva() . '" alt="' . __('voo.uz uzcms sqachat Foto %s', $ank->title) . '" /></div></div>
   <div id="ong">
    
	
   <div class="manzil"><span class="isimvafamilya"> '.$ank->nick.'  </span></div> <span class="vatan">'.$ank->dav.'.  '.$ank->vil.'.</span><hr align="center" width="90%" size="2" color="#fff" /><div class="p-passs">
   
   

   
   
   
    <center>
	<a href="/user/sozlash"><div class="p-men"></div></a>
	<a href="/user/dost"><div class="p-dos"></div></a>
    <a href="/user/foto"><div class="p-fo"></div></a>
	<a href="/user/gurip"><div class="p-gurpa"></div></a>	
    <a href="/user/oyin"><div class="p-oyin"></div></a> 
	<a href="/user/sovga"><div class="p-bo"></div></a></center>		
	</div></div></div>';
   
   

  echo'<div class="jss"><div id="chap">
   <div class="manzil"><span class="isimvafamilya"> '.$ank->nick.'  </span> <span class="vatan">'.$ank->dav.'.  '.$ank->vil.'.</span></div><div class="rasimga"><img src="' . $ank->getAva() . '" alt="' . __('voo.uz uzcms sqachat Foto %s', $ank->title) . '" /></div></div>
   
   <center><table width="98%" border="0">
   <tr id="tr">
   <th id="th"><a href="/user/dost"  style="color: #fff;"> '.__('Do`stlar').' </a></th> 
   <th id="th"><a href="/user/gurip"  style="color: #fff;"> '.__('Grupa').' </a></th>    
   <th id="th"><a href="/user/foto"  style="color: #fff;"> '.__('Fo`to`').' </a></th>   
   <th id="th"><a href="/user/oyin"  style="color: #fff;"> '.__('O`yin').' </a></th>    
   </tr>
   </table></center>
   
   
   
 </div>';   
   
   

   

    echo '</div>';
?>

 






