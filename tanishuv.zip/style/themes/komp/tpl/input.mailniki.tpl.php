<style>
.korma {
	background: red;
	opacity: 0.5;
	margin: 2px;
	padding: 4px;
	font-size: 8px;
	color: #fff;
	}
	.tesa{
		margin-top: -36px;	
        margin-left: 13px;		
    
	}
.foss{
    display: inline-block;
    min-width: 10px;
    padding: 3px 7px;
    font-size: 12px;
    font-weight: bold;
    line-height: 1;
    color: #fff;
    text-align: center;
    white-space: nowrap;
    vertical-align: baseline;
    background-color: green;
    border-radius: 10px;
}
table.fixedga {
    position: fixed;
    bottom: 0;
    right: 0;
    width: 100%;
    border: none;
}
.tess {
      width: 95%;
      height: 16px;
      border: none; 
      background: #FAF9FA;
      }
.tessx {
      width: 15px;
      height: 16px;
      border: none; 
      background: #FAF9FA;
      }	  
   @media (max-width:400px) and (min-width:100px) {
	   .fe{
		   margin-bottom: 30px; 
		   margin-top: 5px; 
	   }
	   .yoqote {
       width: 100%;
       height: 40px;
       border: none; 
       background: #FAF9FA;
      }
      .yoz {
      width: 95%;
      height: 40px;
      border: none; 
      background: #FAF9FA;
      }
	  	   .jonat{
       border: none; 
       background: #FAF9FA;
      }
	.tep{
	margin-top: -24px; 
   }
   .jooo{
	 background-image: url('/img/okey.png');
	 border:none; 
	 background-repeat:no-repeat; 
	 width: 24px; 
	 float:right;
	 clear:left;
	 height: 24px;
     background-size:100% 100%;
   }
   .stikkers{
	 width: 24px; 
	 float:right;
	 clear:left;
	 height: 24px; 
     margin-top: -20px;	 
   }
   .ikki{
	   display: none;
   }
   .uch{
	   display: none;
   }   
   .tor{
	   display: none;
   }   
   .besh{
	   display: none;
   }   
   
	}	
	   @media (max-width:750px) and (min-width:400px) {
		   .fe{
		   margin-bottom: 30px; 
		   margin-top: 5px; 
	   }
	   .yoqote {
       width: 100%;
       height: 45px;
       border: none; 
       background: #FAF9FA;
      }
      .yoz {
      width: 100%;
      height: 45px;
      border: none; 
      background: #FAF9FA;
      }

	   .jonat{
       border: none; 
       background: #FAF9FA;
      }
	.tep{
	margin-top: -24px; 
   }
   .jooo{
	 background-image: url('/img/okey.png');
	 border:none; 
	 background-repeat:no-repeat; 
	 width: 26px; 
	 float:right;
	 clear:left;
	 height: 26px;
     background-size:100% 100%; 
   }
   .stikkers{
	 margin-top: -20px;	
	 width: 30px; 
	 float:right;
	 clear:left;
	 height: 30px;  
	 margin-top: -20px;	 
   }
   .bir{
	   display: none;
   }
   .uch{
	   display: none;
   }   
   .tor{
	   display: none;
   }   
   .besh{
	   display: none;
   }   
   
	}	
	   @media (max-width:968px) and (min-width:750px) {
		   .fe{
		   margin-bottom: 30px; 
		   margin-top: 8px; 
	   }
	   .yoqote {
       width: 100%;
       height: 45px;
       border: none; 
       background: #FAF9FA;
      }
      .yoz {
      width: 100%;
      height: 45px;
      border: none; 
      background: #FAF9FA;
      }

	   .jonat{
       border: none; 
       background: #FAF9FA;
      }
	.tep{
	margin-top: -24px; 
   }
   .jooo{
	 background-image: url('/img/okey.png');
	 border:none; 
	 background-repeat:no-repeat; 
	 width: 26px; 
	 float:right;
	 clear:left;
	 height: 26px;
     background-size:100% 100%; 
   }
   .stikkers{
	 margin-top: -20px;	
	 width: 30px; 
	 float:right;
	 clear:left;
	 height: 30px; 
     margin-top: -17px;	  	 
   }
   .ikki{
	   display: none;
   }
   .bir{
	   display: none;
   }   
   .tor{
	   display: none;
   }   
   .besh{
	   display: none;
   }   
   
	}	
	   @media (max-width:1400px) and (min-width:968px) {
		.fe{
		   margin-bottom: 42px; 
		   margin-top: 6px; 
	   }
	   .yoqote {
       width: 100%;
       height: 50px;
       border: none; 
       background: #FAF9FA;
      }
      .yoz {
      width: 100%;
      height: 50px;
      border: none; 
      background: #FAF9FA;
      }

	   .jonat{
       border: none; 
       background: #FAF9FA;
      }
	.tep{
	margin-top: -24px; 
   }
   .jooo{
	 background-image: url('/img/okey.png');
	 border:none; 
	 background-repeat:no-repeat; 
	 width: 30px; 
	 float:right;
	 clear:left;
	 height: 30px;
     background-size:100% 100%; 
   }
   .stikkers{
	 width: 32px; 
	 float:right;
	 clear:left;
	 height: 32px;  
	 margin-top: -17px;	 	 
   }   
   .ikki{
	   display: none;
   }
   .uch{
	   display: none;
   }   
   .bir{
	   display: none;
   }   
   .besh{
	   display: none;
   }   
   
	}	
	   @media (max-width:3000px) and (min-width:1400px) {
		  .fe{
		   margin-bottom: 42px; 
		   margin-top: 6px;  
	   }
	   .yoqote {
       width: 100%;
       height: 55px;
       border: none; 
       background: #FAF9FA;
      }
      .yoz {
      width: 100%;
      height: 55px;
      border: none; 
      background: #FAF9FA;
      }

	   .jonat{
       border: none; 
       background: #FAF9FA;
      }
	.tep{
	margin-top: -24px; 
   }
   .jooo{
	 background-image: url('/img/okey.png');
	 border:none; 
	 background-repeat:no-repeat; 
	 width: 36px; 
	 float:right;
	 clear:left;
	 height: 36px;
     background-size:100% 100%; 
   }
   .stikkers{
	 width: 40px; 
	 float:right;
	 clear:left;
	 height: 40px;  
	 margin-top: -17px;	 
   }
   .ikki{
	   display: none;
   }
   .uch{
	   display: none;
   }   
   .tor{
	   display: none;
   }   
   .bir{
	   display: none;
   }  
   
	}	
.yozuv{
    padding: 3px;
    margin: 2px;
    font-weight: normal;
    color: #000000;
    border: 4px #97DE69 solid;
    background-color: #7DDA40;
}
.file-upload {
	     display: block !important;
     width: 33px; 
     height: 27px;
	 margin-top: 100px;
	 margin-right: -3px;
	 background: url("/img/album-sm.png");
     background-size:100% 100%;
}
.file-upload:hover {
     background:7aad55#;
}
.file-upload input[type="file"]{
    display: none; 
}
.file-upload label {
     display: block;
     position: absolute;
     top: 55px;
     left: 0;
     width: 30px;
     height: 40px;
     cursor: pointer;
}
.file-upload span {
     line-height: 46px;
}
</style>
<div class="form">
<? $name = 'message'; ?>
    <?=
    '<form id="' . $id . '"' .
    ($method ? ' method="' . $method . '"' : '') .
    ($name ? ' name="' . $name . '"' : '') .	
    ($action ? ' action="' . $action . '"' : '') .
    ($files ? ' enctype="multipart/form-data"' : '')
    . '>'
    ?>

    <?
    foreach ($el AS $element) {
        if ($element['title'])
            echo '<div class="form-group"><label for="nick">'.$element['title'] . '</label></div>';
        switch ($element['type']) {
            case 'text': echo '<div class="form-group"><label for="nick">'.$element['value']. '</label></div>';
                break;
            case 'captcha':
                ?>
                <input type="hidden" name="captcha_session" value="<?= $element['session'] ?>" />
                <img id="captcha" src="/captcha.html?captcha_session=<?= $element['session'] ?>&amp;<?= SID ?>" alt="captcha" />
                <div class="form-group"><label for="nick"><?= $lang->getString("Bu erga rasimdagi raqamini yozin") ?></label></div>
                <input type="text" autocomplete="off" name="captcha" size="5" maxlength="5" />
                <?
                break;
			case 'son':
                ?>
                <input type="hidden" name="captcha_session" value="<?= $element['session'] ?>" />
                <input class="gradient_grey invert border padding radius" type="text" autocomplete="off" name="captcha" size="5" maxlength="5" />
                <?
                break;
            case 'input_text':
                echo '<input class="otga"  type="text"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="' . text::toValue($element['info']['value']) . '"' : '') .
                ($element['info']['maxlength'] ? ' maxlength="' . intval($element['info']['maxlength']) . '"' : '') .
                ($element['info']['size'] ? ' size="' . intval($element['info']['size']) . '"' : '') .
                ($element['info']['disabled'] ? ' disabled="disabled"' : '') .
                ' />';
                break;

            case 'hidden':
                echo '<input class="otga"  type="hidden"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="' . text::toValue($element['info']['value']) . '"' : '') .
                ' />';
                break;
            case 'password':
                echo '<input class="otga" type="password"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="' . text::toValue($element['info']['value']) . '"' : '') .
                ($element['info']['maxlength'] ? ' maxlength="' . intval($element['info']['maxlength']) . '"' : '') .
                ($element['info']['size'] ? ' size="' . intval($element['info']['size']) . '"' : '') .
                ($element['info']['disabled'] ? ' disabled="disabled"' : '') .
                ' />';
                break;
            case 'textarea':
                echo '<table  width="100%" border="0">';  
echo '<tr><td width="10px" class="tessx">
<div style="margin-top: -15px;" class="file-upload">
     <label><input type="file" name="file"></label>
</div>
</td><td class="yoz"><textarea class="yoqote"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['disabled'] ? ' disabled="disabled"' : '') .
                '>' .
                ($element['info']['value'] ? text::toValue($element['info']['value']) : '') .
                '</textarea></td>
<td class="jonat">
&nbsp;&nbsp;&nbsp;<a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion4" href="smailes.html?#collapseOne11" aria-expanded="false" title="'.__('Strike').'"><img class="stikkers" src="/img/a.png" title="'.__('Strike').'" /></a>
</td>
<td class="jonat">
<div class="bir">&nbsp;&nbsp;</div>
<div class="ikki">&nbsp;&nbsp;&nbsp;</div>
<div class="uch">&nbsp;&nbsp;&nbsp;&nbsp;</div>
<div class="tor">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>
<div class="besh">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>
</td>
<td class="jonat">
<div class="bir"><input type="image"  class="jooo" name="post" value="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"></div>
<div class="ikki"><input type="image"  class="jooo" name="post" value="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"></div>
<div class="uch"><input type="image"  class="jooo" name="post" value="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"></div>
<div class="tor"><input type="image"  class="jooo" name="post" value="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"></div>
<div class="besh"><input type="image"  class="jooo" name="post" value="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"></div>
</td>
<td class="jonat">
<div class="bir">&nbsp;&nbsp;</div>
<div class="ikki">&nbsp;&nbsp;&nbsp;</div>
<div class="uch">&nbsp;&nbsp;&nbsp;&nbsp;</div>
<div class="tor">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>
<div class="besh">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>
</td>
</tr>
</table>';
                break;
            case 'textmi':
                echo '	<span  style="width:99%; height: 80px; color:wite; background-color: wite;"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['disabled'] ? ' disabled="disabled"' : '') .
                '" class="block pull-right">' .
                ($element['info']['value'] ? text::toValue($element['info']['value']) : '') .
                '
										<small class="grey middle">Tanlang: &nbsp;</small>

										<span class="btn-toolbar inline middle no-margin">
											<span data-toggle="buttons" class="btn-group no-margin">
												<label class="btn btn-sm btn-yellow">
													1
													<input type="radio" value="1" />
												</label>

												<label class="btn btn-sm btn-yellow active">
													2
													<input type="radio" value="2" />
												</label>

												<label class="btn btn-sm btn-yellow">
													3
													<input type="radio" value="3" />
												</label>

												<label class="btn btn-sm btn-yellow">
													4
													<input type="radio" value="4" />
												</label>
											</span>
										</span>
									</span>';
                break;
            case 'kich_checkbox':
                echo '<div class="checkbox"><label style=" display: block!important; margin-bottom: -26px; border-radius: 2px; position: relative;" ><input ' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="' . text::toValue($element['info']['value']) . '"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' type="checkbox" class="ace input-lg" />
			    <span class="lbl bigger-120"> ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span>
				</label>';
                break;
			case 'checkbox':
                echo '<div class="checkbox"><label style=" display: block!important; margin-bottom: -26px; border-radius: 2px; position: relative;" ><input ' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="' . text::toValue($element['info']['value']) . '"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' type="checkbox" class="ace ace-checkbox-2" />
			    <span class="lbl bigger-120"> ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span>
				</label>';
                break;
			case 'on_of_katta':
                echo '<br /><div style=" display: block!important; margin-left: -6px;"  class="col-xs-12"><label>
				<input ' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="' . text::toValue($element['info']['value']) . '"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace ace-switch ace-switch-2" type="checkbox" />
				<span class="lbl" data-lbl="'.__('ON').'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.__('O`FF').'">&nbsp;&nbsp; ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span>
				</label></div><br />';
                break;
            case 'tashida_chek_tu_c':
                echo '<br /><div style="display: block!important; margin-top: -10px; margin-left: -6px;"  class="col-xs-12"><label>
				<input ' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="' . text::toValue($element['info']['value']) . '"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace ace-switch ace-switch-4" type="checkbox" />
				<span class="lbl" data-lbl="'.__('ON').'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.__('O`FF').'">&nbsp;&nbsp; ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span>
				</label></div><br /><div style="display: block!important; margin-top: -20px;"></div>';
                break;
			case 'tashida_chek_tu_c7':
                echo '<br /><div style="display: block!important; margin-top: -10px; margin-left: -6px;"  class="col-xs-12"><label>
				<input ' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="' . text::toValue($element['info']['value']) . '"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace ace-switch ace-switch-4 btn-flat" type="checkbox" />
				<span class="lbl" data-lbl="'.__('ON').'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.__('O`FF').'">&nbsp;&nbsp; ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span>
				</label></div><br />';
                break;
			case 'tashida_chek_tu_c6':
                echo '<br /><div style="display: block!important; margin-top: -10px; margin-left: -6px;"  class="col-xs-12"><label>
				<input ' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="' . text::toValue($element['info']['value']) . '"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace ace-switch ace-switch-4 btn-empty" type="checkbox" />
				<span class="lbl" data-lbl="'.__('ON').'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.__('O`FF').'">&nbsp;&nbsp; ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span>
				</label></div><br />';
                break;
			case 'tashida_chek_tu_c5':
                echo '<br /><div style="display: block!important; margin-top: -10px; margin-left: -6px;"  class="col-xs-12"><label>
				<input ' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="' . text::toValue($element['info']['value']) . '"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace ace-switch ace-switch-4 btn-rotate" type="checkbox" />
				<span class="lbl" data-lbl="'.__('ON').'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.__('O`FF').'">&nbsp;&nbsp; ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span>
				</label></div><br />';
                break;
			case 'tashida_chek_tu_c4':
                echo '<br /><div style="display: block!important; margin-top: -10px; margin-left: -6px;"  class="col-xs-12"><label>
				<input ' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="' . text::toValue($element['info']['value']) . '"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace ace-switch btn-rotate" type="checkbox" />
				<span class="lbl" data-lbl="'.__('ON').'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.__('O`FF').'">&nbsp;&nbsp; ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span>
				</label></div><br />';
                break;
			case 'tashida_chek_tu_c3':
                echo '<br /><div style="display: block!important; margin-top: -10px; margin-left: -6px;"  class="col-xs-12"><label>
				<input ' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="' . text::toValue($element['info']['value']) . '"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace ace-switch ace-switch-7" type="checkbox" />
				<span class="lbl" data-lbl="'.__('ON').'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.__('O`FF').'">&nbsp;&nbsp; ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span>
				</label></div><br />';
                break;
			case 'tashida_chek_tu_c2':
                echo '<br /><div style="display: block!important; margin-top: -10px; margin-left: -6px;"  class="col-xs-12"><label>
				<input ' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="' . text::toValue($element['info']['value']) . '"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace ace-switch ace-switch-6" type="checkbox" />
				<span class="lbl">&nbsp;&nbsp; ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span>
				</label></div><br />';
                break;
			case 'tashida_chek_tu_c1':
                echo '<br /><div style="display: block!important; margin-top: -10px; margin-left: -6px;"  class="col-xs-12"><label>
				<input ' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="' . text::toValue($element['info']['value']) . '"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace ace-switch ace-switch-5" type="checkbox" />
				<span class="lbl" data-lbl="'.__('ON').'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.__('O`FF').'">&nbsp;&nbsp; ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span>
				</label></div><br />';
                break;
			case 'tashida_chek_tu':
                echo '<br /><div style="display: block!important; margin-top: -10px; margin-left: -6px;"  class="col-xs-12"><label>
				<input ' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="' . text::toValue($element['info']['value']) . '"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace ace-switch" type="checkbox" />
				<span class="lbl" data-lbl="'.__('ON').'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.__('O`FF').'">&nbsp;&nbsp; ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span>
				</label></div><br />';
                break;
			case 'tashida_chek_rim_c':
                echo '<br /><div style="display: block!important; margin-top: -10px; margin-left: -6px;"  class="col-xs-12"><label>
				<input ' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="' . text::toValue($element['info']['value']) . '"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace ace-switch ace-switch-3" type="checkbox" />
				<span class="lbl" data-lbl="'.__('ON').'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.__('O`FF').'">&nbsp;&nbsp; ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span>
				</label></div><br />';
                break;
			case 'tashida_chek_rim_m':
                echo '<br /><div style="display: block!important; margin-top: -10px; margin-left: -6px;"  class="col-xs-12"><label>
				<input ' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="' . text::toValue($element['info']['value']) . '"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace ace-switch ace-switch-3" type="checkbox" />
				<span class="lbl" data-lbl="'.__('ON').'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.__('O`FF').'">&nbsp;&nbsp; ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span>
				</label></div><br />';
                break;
			case 'ki_radio10':
                echo '<div style="position: relative; display: block; margin-left: 10px; margin-top: 1px; margin-bottom: -23px;"><label><input type="radio"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="1"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace input-lg"/><span class="lbl bigger-120">  ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span></label></div>';
                break;
			case 'ki_radio1':
                echo '<div style="position: relative; display: block; margin-left: 10px; margin-top: 1px; margin-bottom: -23px;"><label><input type="radio"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="2"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace input-lg"/><span class="lbl bigger-120">  ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span></label></div>';
                break;
			case 'ki_radio2':
                echo '<div style="position: relative; display: block; margin-left: 10px; margin-top: 1px; margin-bottom: -23px;"><label><input type="radio"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="3"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace input-lg"/><span class="lbl bigger-120">  ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span></label></div>';
                break;
			case 'ki_radio3':
                echo '<div style="position: relative; display: block; margin-left: 10px; margin-top: 1px; margin-bottom: -23px;"><label><input type="radio"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="4"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace input-lg"/><span class="lbl bigger-120">  ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span></label></div>';
                break;
			case 'ki_radio4':
                echo '<div style="position: relative; display: block; margin-left: 10px; margin-top: 1px; margin-bottom: -23px;"><label><input type="radio"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="5"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace input-lg"/><span class="lbl bigger-120">  ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span></label></div>';
                break;
			case 'ki_radio5':
                echo '<div style="position: relative; display: block; margin-left: 10px; margin-top: 1px; margin-bottom: -23px;"><label><input type="radio"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="6"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace input-lg"/><span class="lbl bigger-120">  ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span></label></div>';
                break;
			case 'ki_radio6':
                echo '<div style="position: relative; display: block; margin-left: 10px; margin-top: 1px; margin-bottom: -23px;"><label><input type="radio"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="7"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace input-lg"/><span class="lbl bigger-120">  ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span></label></div>';
                break;
			case 'ki_radio7':
                echo '<div style="position: relative; display: block; margin-left: 10px; margin-top: 1px; margin-bottom: -23px;"><label><input type="radio"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="8"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace input-lg"/><span class="lbl bigger-120">  ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span></label></div>';
                break;
			case 'ki_radio8':
                echo '<div style="position: relative; display: block; margin-left: 10px; margin-top: 1px; margin-bottom: -23px;"><label><input type="radio"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="9"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace input-lg"/><span class="lbl bigger-120">  ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span></label></div>';
                break;
			case 'ki_radio9':
                echo '<div style="position: relative; display: block; margin-left: 10px; margin-top: 1px; margin-bottom: -23px;"><label><input type="radio"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="10"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace input-lg"/><span class="lbl bigger-120">  ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span></label></div>';
                break;
			case 'radio10':
                echo '<div style="position: relative; display: block; margin-left: 10px; margin-top: 1px; margin-bottom: -23px;"><label>
				<input type="radio"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="1"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace" /><span class="lbl">   ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span></label></div>';
                break;
			case 'radio1':
                echo '<div style="position: relative; display: block; margin-left: 10px; margin-top: 1px; margin-bottom: -23px;"><label>
				<input type="radio"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="2"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace" /><span class="lbl">   ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span></label></div>';
                break;
			case 'radio2':
                echo '<div style="position: relative; display: block; margin-left: 10px; margin-top: 1px; margin-bottom: -23px;"><label>
				<input type="radio"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="3"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace" /><span class="lbl">   ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span></label></div>';
                break;
			case 'radio3':
                echo '<div style="position: relative; display: block; margin-left: 10px; margin-top: 1px; margin-bottom: -23px;"><label>
				<input type="radio"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="4"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace" /><span class="lbl">   ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span></label></div>';
                break;
			case 'radio4':
                echo '<div style="position: relative; display: block; margin-left: 10px; margin-top: 1px; margin-bottom: -23px;"><label>
				<input type="radio"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="5"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace" /><span class="lbl">   ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span></label></div>';
                break;
			case 'radio5':
                echo '<div style="position: relative; display: block; margin-left: 10px; margin-top: 1px; margin-bottom: -23px;"><label>
				<input type="radio"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="6"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace" /><span class="lbl">   ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span></label></div>';
                break;
			case 'radio6':
                echo '<div style="position: relative; display: block; margin-left: 10px; margin-top: 1px; margin-bottom: -23px;"><label>
				<input type="radio"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="7"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace" /><span class="lbl">   ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span></label></div>';
                break;
			case 'radio7':
                echo '<div style="position: relative; display: block; margin-left: 10px; margin-top: 1px; margin-bottom: -23px;"><label>
				<input type="radio"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="8"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace" /><span class="lbl">   ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span></label></div>';
                break;
			case 'radio8':
                echo '<div style="position: relative; display: block; margin-left: 10px; margin-top: 1px; margin-bottom: -23px;"><label>
				<input type="radio"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="9"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace" /><span class="lbl">   ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span></label></div>';
                break;
			case 'radio9':
                echo '<div style="position: relative; display: block; margin-left: 10px; margin-top: 1px; margin-bottom: -23px;"><label>
				<input type="radio"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="10"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' class="ace" /><span class="lbl">   ' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</span></label></div>';
        }

        
    }
    ?>
	
