<style>
@media (max-width:300px) and (min-width:100px) {
.zzz{
	display: block !important; margin-top: -25px;

}
    }
	@media (min-width:300px) and (max-width:2700px) {
    .zzz{
		display: block !important; margin-top: -5px;

	}
    }
</style>
<?
$iefix = ($url && $uzcms->ie_ver && $uzcms->ie_ver < 10) ? 'onclick="location.href = \'' . $url . '\'"' : '';
$post_time = $time ? '<span class="vaqt">' . $time . '</span>' : '';
$post_counter = $counter ? '<span class="counter gradient_grey invert border">' . $counter . '</span>' : '';
$post_actions = '<span class="actions">' . $this->section($actions, '<a href="{url}"><img src="{icon}" alt="" /></a>') . '</span>';
$post_actions_t = '<span class="actions">' . $this->section($actions_t, '<a href="{url}"><img src="{icon}" alt="" /></a>') . '</span>';
if ($image) { 
if ($admine){
echo'<li class="active"><a href="'.$url.'">';
}else{
echo'<li class=""><a href="'.$url.'">';	
}
echo'<img  style="margin-top: -5px; margin-left: 3px; width: 26px; height: 26px; border-radius:13px;" src="'.$image.'" title="voo.uz">
<span style="width: 250px; margin-left: 4px;" class="menu-text"> '.$title.' ...</span>
<span style="margin: 0 7px 7px 13px;" class="badge badge-primary">';
if ($actions || $hightlight){
echo '<small>'.$post_actions;
echo ' '.$hightlight.'</small>';
		
		}
echo '</small></span></a>';
echo '<b class="arrow"></b>
</li>';
 
}