<?

$ank = (empty($_GET ['id'])) ? $user : new user((int)$_GET ['id']);
if ($ank->fone){
$fon = $ank->fone;	
}else{
if ($ank->fon){
$fon = '/style/shaxar/'.$ank->fon.'.jpg';
}else{
$fon = 'yoq';	
}
}
if($user->id)if ($user->id == $ank->id);else echo'<a href="/xabar?id='.$ank->id.'"><div class="user_ekran_xat_kichik_img"></div></a>';
echo'<div class="gmenu user_2_ekra_fon_ana"><div class="tepabg"></div>';
echo'<table width="100%"><tbody><tr><td width="80px">';
if ($path = $ank->getAva()) {

	echo'<img src="' . $path . '" width="50" height="50"  alt="' . __('Foto %s', $ank->title) . '"  style="border-radius:5px;">';
}
$qq = $ank->ank_g_r;
$ay = date("Y");
$ess = $ay - $qq;
echo'</a></td><td><b><font color="#ccc">'.$ank->nick.'</b>  <br>'.$ess .' '.__('yosh').' | <i style="text-transform: uppercase;">'.$ank->fon.'</i><br />';

if ($ank->id == $user->id){
echo '</td></tr></tbody></table></div>';	
}else{
	echo '</td></tr></tbody></table></div>';	
if ($user->id){

echo '<table width="100%" border="0"><tr>';
  if ($ank->is_friend($user)){
	   echo '<td width="25%"><center class="user_2_ekra_fon_ana_img_a"><a href="?id='.$ank->id.'&amp;friend=delete"><img  style="width:40px; height: 35px; border-radius:25px;" src="/img/dos.png" title="+'.__('O`chirish').'" alt="+'.__('O`chirish').'" />  </a></center></td>';
      }else{
		     echo '<td width="25%"><center style="font-size: 84%;" class="user_2_ekra_fon_ana_img"><a href="?id='.$ank->id.'&amp;friend=add"><img  style="width:35px; height: 35px; border-radius:25px;" src="/img/dos.png" title="+'.__('Do`stlik').' " alt="+'.__('Do`stlik').'" /> </a></center></td>';
   }
   	if (!$user->is_enemies($ank)) {
	echo '<td width="25%"><center style="font-size: 84%;"  class="user_2_ekra_fon_ana_img"><a href="/ID'.$ank->id.'?id='.$ank->id.'&enemies"><img  style="width:35px; height: 35px; border-radius:25px;" src="/img/kontak.png" title="+'.__('To`siq qo`yish').' " alt="+'.__('To`siq qo`yish').' " /> </a></center></td>';
	}else{
			$pages = new pages ;
$pages->posts = mysql_result(mysql_query("SELECT COUNT(*) FROM `enemies` WHERE `id_user` = '$user->id'"), 0) ;
$pages->this_page() ;

		$q = mysql_query("SELECT * FROM `enemies` WHERE `id_user` = '$user->id' ORDER BY `time` DESC LIMIT ".$pages->limit);
        while($enemies = mysql_fetch_object($q)) 
	if ($enemies->id_who == $ank->id){
	echo '<td width="25%"><center style="font-size: 84%;"  class="user_2_ekra_fon_ana_img_a"><a href="/ID'.$ank->id.'?delete=' .$enemies->id. '"><img  style="width:35px; height: 35px; border-radius:25px;" src="/img/kontak.png" title="+'.__('To`siqni olish').'" alt="+'.__('To`siqni olish').'" />  </a></center></td>';
	}




	}
	echo '<td width="25%"><center style="font-size: 84%;" class="user_2_ekra_fon_ana_img"><a href="/user/sovga/ot.php?id='.$ank->id.'"><img  style="width:35px; height: 35px; border-radius:25px;" src="/img/ig.png" title="+'.__('Sovga').'" alt="+'.__('Sovga').'" /> </a></center></td>';
echo '<td width="25%"><center style="font-size: 84%;"  class="user_2_ekra_fon_ana_img"><a href="/user/group/ot.php?id='.$ank->id.'"><img  style="width:35px; height: 35px; border-radius:25px;" src="/img/gurpa.png" title="+'.__('Gurpaga').'" alt="+'.__('Gurpaga').'" /> </a></center></td>';
echo '</tr></table></center>';
}else{
echo '</td></tr></tbody></table></div>';	
}

}
echo '<div class="clr"></div>';