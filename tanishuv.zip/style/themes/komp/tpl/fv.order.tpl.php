<center style="margin: 6px; margin-left: -5px;"><aside  class="kal">

    <select   style="width:96%; height: 40px; color:wite; background-color: wite;" class="btn" onchange="location = this.options[this.selectedIndex].value;">
        <?
        foreach ($order AS $option) {
            echo '<option  value="' . $option[0] . '"' . (!empty($option[2]) ? ' selected="selected"' : '') . '>' . $option[1] . '</option>';
        }
        ?>
    </select>
</aside>
</center>
   
