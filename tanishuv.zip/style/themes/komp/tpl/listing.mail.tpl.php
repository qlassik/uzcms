<?
$iefix = ($url && $uzcms->ie_ver && $uzcms->ie_ver < 10) ? 'onclick="location.href = \'' . $url . '\'"' : '';
$post_time = $time ? '<span class="vaqt">' . $time . '</span>' : '';
$post_counter = $counter ? '<span class="counter gradient_grey invert border">' . $counter . '</span>' : '';
$post_actions = '<span class="actions">' . $this->section($actions, '<a href="{url}"><img src="{icon}" alt="" /></a>') . '</span>';
?>
<?= ($url ? '<a href="' . $url . '" class="' : '<div class="') . '' . ($hightlight ? ' hightlight' : '') . '" id="' . $id . '"    >' ?>
     <table <?= $iefix ?> cellspacing="0" callpadding="0" width="100%" >
        <? if ($image) { ?>
            <tr>
                <td class="image" rowspan="4">
                    <img  style="width:<?=$uzcms->k_img_razmer?>px" src="<?= $image ?>" alt="" />
                </td>
                <td class="">
                    <?= $title ?>
                    <?= $post_counter ?>
                </td>

                <td style ="text-align: right;" class="chap">
                    <?= $post_time ?>
                    <?= $post_actions ?>
                </td>
            </tr>
        <? } elseif ($icon) { ?>
            <tr>
                   
               
                <td class="">
                    <img style="width:<?=$uzcms->k_icon_razmer?>px" src="<?= $icon ?>" alt="" />   <?= $title ?>
                    <?= $post_counter ?>
                </td>

                <td style ="text-align: right;" class="chap">
                    <?= $post_time ?>
                    <?= $post_actions ?>
                </td>
            </tr>
        <? } else { ?>
            <tr>
                <td class="">
                    <?= $title ?>
                    <?= $post_counter ?>
                </td>

                <td style ="text-align: right;" class="chap">
                    <?= $post_time ?>
                    <?= $post_actions ?>
                </td>
            </tr>
        <? } ?>

        <? if ($content) { ?>
            <tr>
                <td class="" colspan="10">
                    <?= $content ?>
                </td>
            </tr>
        <? } ?>

        <? if ($bottom) { ?>
            <tr>
                <td class="bottom" colspan="10">
                    <?= $bottom ?>
                </td>
            </tr>
        <? } ?>
    </table>
<?=
$url ? '</a>' : '</div>'?>