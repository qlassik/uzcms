<style>
@media (max-width:500px) and (min-width:100px) {
.zzz{
	display: block !important; margin-top: -25px;

}
    }
	@media (min-width:500px) and (max-width:2700px) {
    .zzz{
		display: block !important; margin-top: -5px;

	}
    }
	.der{
	margin: 8px;
	padding: 6px;
    background: #fbfcfd;
    border: 1px solid #f1f1f1;
	}
	.daa{
		transition: background, 500ms;
    -moz-transition: background 500ms;
    -webkit-transition: background 500ms;
    -o-transition: background 500ms;
    background: #FAFAFA;
    border: 1px #DBDBDB solid;
    padding: 8px;
    display: block !important;
    border-top-style: none !important;
    font-size: 100%;
    box-shadow: 0 0 0 1px #FCFCFC inset;
    overflow: hidden;
	}
	.daa a{
	color: #686868 !important;	
	}
</style>
<?
$iefix = ($url && $uzcms->ie_ver && $uzcms->ie_ver < 10) ? 'onclick="location.href = \'' . $url . '\'"' : '';
$post_time = $time ? '<span class="vaqt">' . $time . '</span>' : '';
$post_counter = $counter ? '<span class="counter gradient_grey invert border">' . $counter . '</span>' : '';
$post_actions = '<span class="actions">' . $this->section($actions, '<a href="{url}"><img src="{icon}" alt="" /></a>') . '</span>';
$post_actions_t = '<span class="actions">' . $this->section($actions_t, '<a href="{url}"><img src="{icon}" alt="" /></a>') . '</span>';

?><?if ($image){?>
<div class="der">
 <center>
<a href="<?=$url?>" title="voo.uz"> <img style="margin: 5px; width: 50%;  border-radius: 5px;" src="<?= $image ?>" /> </a>
<hr />
</center>
<div style="margin:10px;">
<?= $title ?>

</div>
</div>
<?} else {?>
<div class="daa"> » <a href="<?=$url?>" title="voo.uz" ><?= $title ?> <? if ($hightlight){ ?> <span style="float:right; clear:left;"><div class="strike_k"><?=$hightlight?>   <?if ($counter){?><span style="color:red;">  /  <?=$counter?></span><?}?></div></span><?}?></a> </div>


<?}?>


