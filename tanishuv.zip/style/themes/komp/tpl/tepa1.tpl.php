<?
 $ide = (int)$_GET ['id'];
 $ank = (empty($ide)) ? $user : new user((int)$ide);

if ($user->title_fonga){?>
<style> 
	#navbar {
    margin: 0;
    padding-left: 0;
    padding-right: 0;
    border-width: 0;
    border-radius: 0;
    -webkit-box-shadow: none;
    box-shadow: none;
    min-height: 45px;
    background: <?=$user->title_fonga?>;
}
</style> 
<?}else{?>
<style> 
	#navbar {
    margin: 0;
    padding-left: 0;
    padding-right: 0;
    border-width: 0;
    border-radius: 0;
    -webkit-box-shadow: none;
    box-shadow: none;
    min-height: 45px;
    background: <?=$uzcms->title_fonga?>;
}
</style> 	
<?}?>
<style> 
  .tent{
    padding: 3px;
    background: #fbfcfd;
    border: 1px solid #f1f1f1;
	
  }
  .chii{
    padding: 13px;
    margin: 18px 0;
	border: 0px solid #eee;
    border-left-width: 5px;
	
   }
</style>
<?
 $e = ''.$lang->name.'nomi';
$_SESSION['sava'] = $_SERVER['REQUEST_URI'];
$return =  $_SESSION['sava'];
 $ank = (empty($_GET ['id'])) ? $user : new user((int)$_GET ['id']);
 /*if ($user->id){  
 if ($_SESSION['vozz'] == $_SERVER['REQUEST_URI']){
   
   
   
 }else{
$as = mysql_result(mysql_query("SELECT COUNT(*) FROM `mt`"), 0);
$im = mt_rand(1, $as);


 
 
 
 
 
 
 
 
 
 
 
 if ($user->xtet){
 if ($user->xtet == '12345'){
$ss = mysql_query("SELECT * FROM `mt` WHERE `id`='".$im."' ");
while ($csw= mysql_fetch_assoc($ss)) {
echo  $csw['cod'];
}
 }else{
$ss = mysql_query("SELECT * FROM `mt` WHERE `id`='".$user->xtet."' ");
while ($csw= mysql_fetch_assoc($ss)) {
echo  $csw['cod'];
}
}
}elseif ($uzcms->xtet == '12345'){	
$ss = mysql_query("SELECT * FROM `mt` WHERE `id`='".$im."' ");
while ($csw= mysql_fetch_assoc($ss)) {
echo  $csw['cod'];
}
}else{
$ss = mysql_query("SELECT * FROM `mt` WHERE `id`='".$uzcms->xtet."' ");
while ($csw= mysql_fetch_assoc($ss)) {
echo  $csw['cod'];	
}
}
 }
 }
 */?>


<div id="navbar" class="navbar navbar-default  ace-save-state">
			<div class="navbar-container ace-save-state" id="navbar-container">	<div class="yon_479">
							<ul  style="background: none;" class="nav ace-nav">
		<?				
		 if ($user->chatga){   
        echo'<li style="background: none;" class="green dropdown-modal">
							<a  style="background: none; border-left: none;" class="dropdown-toggle" href="/chat">
								<i class="ace-icon icon-animated-vertical">'.sm_icon(qlassik_ru('62')).'</i>
								<span style="margin-left: -8px;" class="badge badge-success">  '.mysql_result(mysql_query("SELECT COUNT(*) FROM `chat_mini` WHERE `u` = '".$user->id."'"), 0).' </span>
							</a>
                        </li>';
		}else{
        if ($user->tasma){    
			
			echo'<li style="background: none;" class="green dropdown-modal">
							<a  style="background: none; border-left: none;" class="dropdown-toggle" href="/tasma">
								<i class="ace-icon icon-animated-vertical">'.sm_icon(qlassik_ru('66')).'</i>
								<span style="margin-left: -8px;" class="badge badge-success">  '.mysql_result(mysql_query("SELECT COUNT(*) FROM `tasma` WHERE `u` = '".$user->id."'"), 0).' </span>
							</a>
                        </li>';
		}else{
			echo'<li style="background: none;" class="green dropdown-modal">
							<a  style="background: none; border-left: none;" class="dropdown-toggle" href="/chat">
								<i class="ace-icon icon-animated-vertical">'.sm_icon(qlassik_ru('67')).'</i>
								<span style="margin-left: -8px;" class="badge badge-success">  '.mysql_result(mysql_query("SELECT COUNT(*) FROM `chat_on`"), 0).' </span>
							</a>
                        </li>';			
			
		}
		}
		
		
		if ($user->friend_new_count){
			echo'<li style="background: none;" class="green dropdown-modal">
							<a  style="background: none; border-left: none;" class="dropdown-toggle" href="/mening_dostlarim.html?friend">
								<i class="ace-icon icon-animated-bell">'.sm_icon(qlassik_ru('68')).'</i>
								<span style="margin-left: -8px;" class="badge badge-success">  '.$friend_new_count.' </span>
							</a>
                        </li>';				
		}elseif ($user->mexmon){
			echo'<li style="background: none;" class="green dropdown-modal">
							<a  style="background: none; border-left: none;" class="dropdown-toggle" href="/mexmonlar.html">
								<i class="ace-icon icon-animated-bell">'.sm_icon(qlassik_ru('69')).'</i>
								<span style="margin-left: -8px;" class="badge badge-success">  '.$user->mexmon.' </span>
							</a>
                        </li>';			
	}elseif ($user->kon_qosh){
			echo'<li style="background: none;" class="green dropdown-modal">
							<a  style="background: none; border-left: none;" class="dropdown-toggle" href="/komfrensa?men">
								<i class="ace-icon icon-animated-bell">'.sm_icon(qlassik_ru('70')).'</i>
								<span style="margin-left: -8px;" class="badge badge-success">  '.$user->kon_qoshn.' </span>
							</a>
                        </li>';	
  }elseif ($gurpaga_chaqiryapti){
			echo'<li style="background: none;" class="green dropdown-modal">
							<a  style="background: none; border-left: none;" class="dropdown-toggle" href="/grup.html">
								<i class="ace-icon icon-animated-bell">'.sm_icon(qlassik_ru('71')).'</i>
								<span style="margin-left: -8px;" class="badge badge-success">  '.$gurpaga_chaqiryapti.' </span>
							</a>
                        </li>';	  
  }elseif ($gurpamga_keldi){
			echo'<li style="background: none;" class="green dropdown-modal">
							<a  style="background: none; border-left: none;" class="dropdown-toggle" href="/grup.html">
								<i class="ace-icon icon-animated-bell">'.sm_icon(qlassik_ru('72')).'</i>
								<span style="margin-left: -8px;" class="badge badge-success">  '.$gurpamga_keldi.' </span>
							</a>
                        </li>';	  
}elseif ($xza = mysql_result(mysql_query("SELECT COUNT(*) FROM `tell_b` WHERE `id_user` = '".$user->id."' AND `ko` = '3'"), 0)){
			echo'<li style="background: none;" class="green dropdown-modal">
							<a  style="background: none; border-left: none;" class="dropdown-toggle" href="/grup.html">
								<i class="ace-icon icon-animated-bell">'.sm_icon(qlassik_ru('63')).'</i>
								<span style="margin-left: -8px;" class="badge badge-success">  '.$xza.' </span>
							</a>
                        </li>';	  
} 
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	 $sql_where = array("`mail`.`id_user` = '{$user->id}'");
$sql_where[] = "`mail`.`is_read` = '0'";
$q = mysql_query("SELECT `users`.`id`,
        `mail`.`id_sender`,
        MAX(`mail`.`time`) AS `time`,
        MIN(`mail`.`is_read`) AS `is_read`,
        COUNT(`mail`.`id`) AS `count`
FROM `mail`
LEFT JOIN `users` ON `mail`.`id_sender` = `users`.`id`
WHERE " . implode(' AND ', $sql_where) . "
GROUP BY `mail`.`id_sender`
ORDER BY `time` DESC
LIMIT 1");
while ($ma = mysql_fetch_assoc($q)) {
	$ank = new user((int)$ma['id_sender']);
	if ($ma['count'] == $user->mail_new_count){
	$ke = $ma['id'];
	}else{
	$ke = $user->login;	
	}
	 	
}
  if(!isset($ke))$ke = $user->login;
  if ($ke == $user->login){
  if ($user->mail_new_count){
  echo'<li style="background: none;" class="green dropdown-modal">
							<a  style="background: none; border-left: none;" class="dropdown-toggle" href="/xabar?xabar_keldi">
								<i class="ace-icon icon-animated-vertical">'.sm_icon(qlassik_ru('73')).'</i>
								<span style="margin-left: -8px;" class="badge badge-success">  '.$user->mail_new_count.' </span>
							</a>
                        </li>';	
  }
  }else{
	  
	  
	  	if ($user->mail_k_new_count){
echo'<li style="background: none;" class="green dropdown-modal">
							<a  style="background: none; border-left: none;" class="dropdown-toggle" href="/komfrensa?men">
								<i class="ace-icon icon-animated-vertical">'.sm_icon(qlassik_ru('74')).'</i>
								<span style="margin-left: -8px;" class="badge badge-success">  '.$user->mail_k_new_count.' </span>
							</a>
                        </li>';				
}else{  
                        echo'<li style="background: none;" class="green dropdown-modal">
							<a  style="background: none; border-left: none;" class="dropdown-toggle" href="/xabar?id='.$ke.'">
								<i class="ace-icon icon-animated-vertical">'.sm_icon(qlassik_ru('75')).'</i>
								<span style="margin-left: -8px;" class="badge badge-success">  '.$user->mail_new_count.' </span>
							</a>
                        </li>';	
  
  
  }
  }
  
  
							
		
		
		?></ul>
					</div>
				
						
				<button type="button" class="navbar-toggle menu-toggler pull-left" id="menu-toggler" data-target="#sidebar">
					<span class="sr-only">Toggle sidebar</span>

					<span class="icon-bar"></span>

					<span class="icon-bar"></span>

					<span class="icon-bar"></span>
				</button>

				<div class="navbar-header pull-left">
					<div class="och_479"><a href="/" class="navbar-brand">
						<small>
							<?= __($uzcms->sitename) ?>
						</small>
						</a>
						</div>
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
					
				</div>

				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				<div class="navbar-buttons navbar-header pull-right" role="navigation">
					<div class="och_479">
					<ul class="nav ace-nav">
		<?				
		 if ($user->chatga){   
        echo'<li style="background: none;" class="green dropdown-modal">
							<a  style="background: none; border-left: none;" class="dropdown-toggle" href="/chat">
								<i class="ace-icon icon-animated-vertical">'.sm_icon(qlassik_ru('62')).'</i>
								<span style="margin-left: -8px;" class="badge badge-success">  '.mysql_result(mysql_query("SELECT COUNT(*) FROM `chat_mini` WHERE `u` = '".$user->id."'"), 0).' </span>
							</a>
                        </li>';
		}else{
        if ($user->tasma){    
			
			echo'<li style="background: none;" class="green dropdown-modal">
							<a  style="background: none; border-left: none;" class="dropdown-toggle" href="/tasma">
								<i class="ace-icon icon-animated-vertical">'.sm_icon(qlassik_ru('66')).'</i>
								<span style="margin-left: -8px;" class="badge badge-success">  '.mysql_result(mysql_query("SELECT COUNT(*) FROM `tasma` WHERE `u` = '".$user->id."'"), 0).' </span>
							</a>
                        </li>';
		}else{
			echo'<li style="background: none;" class="green dropdown-modal">
							<a  style="background: none; border-left: none;" class="dropdown-toggle" href="/chat">
								<i class="ace-icon icon-animated-vertical">'.sm_icon(qlassik_ru('67')).'</i>
								<span style="margin-left: -8px;" class="badge badge-success">  '.mysql_result(mysql_query("SELECT COUNT(*) FROM `chat_on`"), 0).' </span>
							</a>
                        </li>';			
			
		}
		}
		
		
		if ($user->friend_new_count){
			echo'<li style="background: none;" class="green dropdown-modal">
							<a  style="background: none; border-left: none;" class="dropdown-toggle" href="/mening_dostlarim.html?friend">
								<i class="ace-icon icon-animated-bell">'.sm_icon(qlassik_ru('68')).'</i>
								<span style="margin-left: -8px;" class="badge badge-success">  '.$friend_new_count.' </span>
							</a>
                        </li>';				
		}elseif ($user->mexmon){
			echo'<li style="background: none;" class="green dropdown-modal">
							<a  style="background: none; border-left: none;" class="dropdown-toggle" href="/mexmonlar.html">
								<i class="ace-icon icon-animated-bell">'.sm_icon(qlassik_ru('69')).'</i>
								<span style="margin-left: -8px;" class="badge badge-success">  '.$user->mexmon.' </span>
							</a>
                        </li>';			
	}elseif ($user->kon_qosh){
			echo'<li style="background: none;" class="green dropdown-modal">
							<a  style="background: none; border-left: none;" class="dropdown-toggle" href="/komfrensa?men">
								<i class="ace-icon icon-animated-bell">'.sm_icon(qlassik_ru('70')).'</i>
								<span style="margin-left: -8px;" class="badge badge-success">  '.$user->kon_qoshn.' </span>
							</a>
                        </li>';	
  }elseif ($gurpaga_chaqiryapti){
			echo'<li style="background: none;" class="green dropdown-modal">
							<a  style="background: none; border-left: none;" class="dropdown-toggle" href="/grup.html">
								<i class="ace-icon icon-animated-bell">'.sm_icon(qlassik_ru('71')).'</i>
								<span style="margin-left: -8px;" class="badge badge-success">  '.$gurpaga_chaqiryapti.' </span>
							</a>
                        </li>';	  
  }elseif ($gurpamga_keldi){
			echo'<li style="background: none;" class="green dropdown-modal">
							<a  style="background: none; border-left: none;" class="dropdown-toggle" href="/grup.html">
								<i class="ace-icon icon-animated-bell">'.sm_icon(qlassik_ru('72')).'</i>
								<span style="margin-left: -8px;" class="badge badge-success">  '.$gurpamga_keldi.' </span>
							</a>
                        </li>';	  
} 
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	 $sql_where = array("`mail`.`id_user` = '{$user->id}'");
$sql_where[] = "`mail`.`is_read` = '0'";
$q = mysql_query("SELECT `users`.`id`,
        `mail`.`id_sender`,
        MAX(`mail`.`time`) AS `time`,
        MIN(`mail`.`is_read`) AS `is_read`,
        COUNT(`mail`.`id`) AS `count`
FROM `mail`
LEFT JOIN `users` ON `mail`.`id_sender` = `users`.`id`
WHERE " . implode(' AND ', $sql_where) . "
GROUP BY `mail`.`id_sender`
ORDER BY `time` DESC
LIMIT 1");
while ($ma = mysql_fetch_assoc($q)) {
	$ank = new user((int)$ma['id_sender']);
	if ($ma['count'] == $user->mail_new_count){
	$ke = $ma['id'];
	}else{
	$ke = $user->login;	
	}
	 	
}
  if(!isset($ke))$ke = $user->login;
  if ($ke == $user->login){
  if ($user->mail_new_count){
  echo'<li style="background: none;" class="green dropdown-modal">
							<a  style="background: none; border-left: none;" class="dropdown-toggle" href="/xabar?xabar_keldi">
								<i class="ace-icon icon-animated-vertical">'.sm_icon(qlassik_ru('73')).'</i>
								<span style="margin-left: -8px;" class="badge badge-success">  '.$user->mail_new_count.' </span>
							</a>
                        </li>';	
  }
  }else{
	  
	  
	  	if ($user->mail_k_new_count){
echo'<li style="background: none;" class="green dropdown-modal">
							<a  style="background: none; border-left: none;" class="dropdown-toggle" href="/komfrensa?men">
								<i class="ace-icon icon-animated-vertical">'.sm_icon(qlassik_ru('74')).'</i>
								<span style="margin-left: -8px;" class="badge badge-success">  '.$user->mail_k_new_count.' </span>
							</a>
                        </li>';				
}else{  
                        echo'<li style="background: none;" class="green dropdown-modal">
							<a  style="background: none; border-left: none;" class="dropdown-toggle" href="/xabar?id='.$ke.'">
								<i class="ace-icon icon-animated-vertical">'.sm_icon(qlassik_ru('75')).'</i>
								<span style="margin-left: -8px;" class="badge badge-success">  '.$user->mail_new_count.' </span>
							</a>
                        </li>';	
  
  
  }
  }
  
  
							
		
		
		?>
						
						
						
						
						
						


						
						
						
						<li class="light-blue dropdown-modal">
							<a style="background: none;" data-toggle="dropdown"  class="dropdown-toggle">
								<img class="nav-user-photo" src="<?= $ank->getAva(); ?>" alt="VOO.UZ" />
								<span class="foos"><span class="user-info">
									<small><?= sm_nick($ank->userfam); ?></small>
									<?= sm_nick($ank->username); ?>
								</span></span>
								
								

								<i class="ace-icon fa fa-caret-down"></i>
							</a>

							<ul style="margin-top: 10px; margin-left: 20px;" class="user-menu dropdown-menu-right dropdown-menu dropdown-yellow dropdown-caret dropdown-close">
								<?
								
								if($user->id == $ank->id){
								echo'<li><a href="#">'.sm_icon(qlassik_ru('28')).'  '.__('Hisob to`ldirish').'</a></li>';
								echo'<li><a href="#">'.sm_icon(qlassik_ru('29')).'  '.__('Pullik hizmatlar').'</a></li>';
								echo'<li><a href="#">'.sm_icon(qlassik_ru('30')).'  '.__('Sozlamalar').'</a></li>';
								echo'<li><a href="#">'.sm_icon(qlassik_ru('31')).'  '.__('Sayt sozlamasi').'</a></li>';
                                }else{
								echo'<li><a href="#">'.sm_icon(qlassik_ru('32')).'  '.__('Pul o`tkazish').'</a></li>';
								echo'<li><a href="#">'.sm_icon(qlassik_ru('33')).'  '.__('Taqiqlash').'</a></li>';
								echo'<li><a href="#">'.sm_icon(qlassik_ru('34')).'  '.__('Qo`ngiroq qilish').'</a></li>';
								}
                               
								echo'<li class="divider"></li>';
                                echo'<li><a href="/chiqish.html">'.sm_icon(qlassik_ru('35')).'  '.__('Saytdan chiqish').'</a></li>';
								
								
								
								?>
							</ul>
						</li>
					</ul>
					</div>
				</div>
			</div>
		</div>
		