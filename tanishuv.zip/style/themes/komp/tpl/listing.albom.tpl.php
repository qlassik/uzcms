<style>
div.gallery {
    margin: 3px;
    border: 1px solid #ccc;
    float: left;
    width: 100px;
	height: 100px;
}

div.gallery:hover {
    border: 1px solid #777;
}

div.gallery img {
    width: 100%;
    height: auto;
	height: 70px;
}

div.desc {
    padding: 5px;
    text-align: center;
}
</style>
<?
$im = mt_rand(1, 20);
$iefix = ($url && $uzcms->ie_ver && $uzcms->ie_ver < 10) ? 'onclick="location.href = \'' . $url . '\'"' : '';
$kv_time = $time ? '<span class="time">' . $time . '</span>' : '';
$kv_counter = $counter ? '<span class="counter gradient_grey invert border">' . $counter . '</span>' : '';
$actions = '<span class="actions">' . $this->section($actions, '<a href="{url}"><img src="{icon}" alt="" /></a>') . '</span>';
$kv_mehmon = $mehmon ? '<span class="time">' . $mehmon . '</span>' : '';
?>

<span  >
<a href="<?=$url?>"> <img style="margin: 6px; background: #EBEBEB; border: 1px solid #DFDFDF; border-radius: 3px;"  src="/img/li/<?=$im?>.png" width="85px" height="85px" title="voo.uz" alt="voo.uz"></a>
<span style="margin-left: -55px; margin-top: 23px;" class="badge"><small><?=$hightlight?>  <?=__('Soni')?></small></span>
</span>



