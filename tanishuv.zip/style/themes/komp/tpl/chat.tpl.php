<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?= $lang->xml_lang ?>">
    <head>
    <title><?= $title ?></title>
    <? if ($description) { ?>
        <meta name="description" content="<?= $description ?>" />
    <? } ?>
    <? if ($keywords) { ?>
        <meta name="keywords" content="<?= $keywords ?>" />
    <? } ?>
	<meta http-equiv="Сontent-Type" content="application/xhtml+xml; charset=utf-8"/>
    <meta name="generator" content="UZCMS <?= $uzcms->version ?>" />
	<meta name="keywords" content="<?= $title ?>" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="UZCMS <?= $uzcms->xabar ?>">
    <meta name="author" content="UZCMS <?= $uzcms->korik ?>">
	<link rel="stylesheet" href="/ajax/css/voouz.css" />
	<link rel="stylesheet" href="/ajax/assets/css/bootstrap.min.css" />
	<link rel="stylesheet" href="/ajax/assets/font-awesome/4.5.0/css/font-awesome.min.css" />
    <link rel="stylesheet" href="/ajax/assets/css/fonts.googleapis.com.css" />
        <link rel="stylesheet" href="/ajax/css/ace.min.css" class="ace-main-stylesheet" id="main-ace-style" />
        <link rel="stylesheet" href="/ajax/assets/css/ace-rtl.min.css" />
        <script src="/ajax/assets/js/ace-extra.min.js"></script>
	<script src="/style/assets/js/ace-extra.min.js"></script>
    
    	<script src="/style/assets/js/jquery-2.1.4.min.js"></script>
        <script src="/style/assets/js/bootstrap.min.js"></script>
	<link href="/ajax/chat/assets/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="/ajax/chat/assets/css/style-light.css"  id="maintheme" rel="stylesheet">
<style>
#main-container {
    content: "";
    position: absolute;
    z-index: -2;
    width: 100%;
    max-width: inherit;
    bottom: 0;
    top: 0;
    background-image:url("/img/1.jpg");
}                                   
#main-container {
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    z-index: -1;
    background-repeat: no-repeat;
    background-position: 50%;
    background-size: cover;
}
.main-container-b {
    white-space: nowrap;
    text-align: center;
    font-size: 13px;
    line-height: 18px;
    height: 100%;
}
#footer {
   position:fixed;
   left:0px;
   bottom:0px;
   height:40px;
   width:100%;
   background: #fff;
}
#tur{
  
}
#rasmi {
   position:fixed;
   left:0px;
   top:0px;
   height:55px;
   width:100%;
   background: #2b2b2b9e;
}
#javoblar {
   
   left:0px;
   bottom:40px;
   height:50px;
   width:80%;
   background: #2b2b2b9e;
}
#xatolar {
   left:0px;
   font-size: 18px;
   color: #fff;
   margin-top: 30px;
   bottom:50px;
   height:45px;
   width:80%;
   background: #2b2b2b9e;
}


.yubor {
   height:25px;
   width:25px;
   border-radius: 13px;
   margin-top: 10px;
}
/* IE 6 */
* html #footer #rasmi {
   position:absolute;
   top:expression((0-(footer.offsetHeight)+(document.documentElement.clientHeight ? document.documentElement.clientHeight : document.body.clientHeight)+(ignoreMe = document.documentElement.scrollTop ? document.documentElement.scrollTop : document.body.scrollTop))+'px');
}
.ov{
     position: relative; 
     overflow: hidden; 
     width: 18px; 
     height: 18px;
	 margin-right: 100px;
	 margin-top: -73px;
	 float:right;
     background: url("/img/stats.png");
	 background-size: 18px;
     border-radius: 3px;
     padding: 1px;
     color: #fff;
     text-align: center;
	}
.yozuv{
    padding: 3px;
    margin: 2px;
    font-weight: normal;
    color: #000000;
    border: 4px #97DE69 solid;
    background-color: #7DDA40;
}
.bolimgaa{
    padding: 3px;
    margin: 2px;
    font-weight: normal;
    color: #f7fafc;
    border: 1px #2b2b2b solid;
    background-color: #999999a8;
}
.xa {
     position: relative; 
     overflow: hidden; 
     width: 20px; 
     height: 20px;
	 margin-top: 10px;
	 margin-right: 70px;
	 float:right;
     background-size: 20px;
     border-radius: 3px;
     padding: 1px;
     color: #fff;
     text-align: center;
}
.file-upload {
     position: relative; 
     overflow: hidden; 
     width: 20px; 
     height: 20px;
	 margin-top: 10px;
	 margin-right: 70px;
	 float:right;
     background: url("/img/staple.png");
	 background-size: 20px;
     border-radius: 3px;
     padding: 1px;
     color: #fff;
     text-align: center;
}
.file-upload:hover {
     background:7aad55#;
}
.file-upload input[type="file"]{
    display: none; 
}
.file-upload label {
     display: block;
     position: absolute;
     top: 0;
     left: 0;
     width: 100%;
     height: 100%;
     cursor: pointer;
}
.file-upload span {
     line-height: 36px;
}
</style></head><div id="rasmi">
<div class="form-material">
<? $this->display('chat_t.tpl');	?>
</div>
</div>
<body id="main-container">




<?
					if($msg){
						?><style>
                    .alert-fkk {
                    background-color: <?=$uzcms->erorga?>;
                    color: #fff;
                    }
                    </style><?
		
					}
					if($err){
						?><style>
                    .alert-fkk {
                    background-color: <?=$uzcms->msgga?>;
                    color: #31708f;
                    }
                    </style><?	
					}
					
					if ($err || $msg){?>
					<center><div id="xatolar" class="alert hidden-sm hidden-xs">
									<button type="button" class="close" data-dismiss="alert">
										<i class="ace-icon fa fa-times"></i>
									</button>
					<div style="margin-top: -7px;">				
					<?= $this->section($err, '{text}'); ?>
                    <?= $this->section($msg, '{text}'); ?>
					</div></div>
                     			
					<div id="xatolar" class="alert hidden-md hidden-lg">
									<button type="button" class="close" data-dismiss="alert">
										<i class="ace-icon fa fa-times"></i>
									</button>
					<div style="margin-top: -7px;">				
					<?= $this->section($err, '{text}'); ?>
                    <?= $this->section($msg, '{text}'); ?>
					</div></div></center>
                   <?}?>
</div>
<div style="margin: 40px;"></div>
<div id="tur"><?= $content ?></div>




<?
echo'<div style="margin: 15px; margin-top: -25px" id="collapseOne5" class="panel-collapse collapse" aria-expanded="false">';
echo '<div id="javoblar" style="margin-left: 10%" class="bolimgaa">';
echo '<table width="100%" border="0" > <tr> <td>';
echo '<td><center> <a href=""> <img class="yubor" src="/img/uzoq_o.png" title="voo.uz" /> </a> </center></td><td><center> <a href=""> <img class="yubor" src="/img/sma.png" title="voo.uz" /> </a> </center></td><td><center> <a href=""> <img class="yubor" src="/img/sub_d.png" title="voo.uz" /> </a> </center></td>';	
echo '</tr></table>';
echo '</div>';		
echo '</div>';
?>



<div id="footer">
<div class="form-material">
<form method="post" enctype="multipart/form-data">
<input style="width: 76%;"  class="form-control p-20 live-search-box" name="message" type="text" placeholder="<?=__('Yozish joyi')?>">
<input class="xa" style="width: 50px; height: 20px; margin: 10px; font-size: 60%; margin-top: -30px; cplor: #777;"  type="submit" value="<?=__('Yuborish')?>" />
<span  style="width:60px; float:right; clear:left;"></span>			
<div style="margin-top: -28px;" class="file-upload"> <div>
   <label for="file"></label>
   <input type="file" id="file" name="file" multiple>
 </div>
</div>
<div style="float:right; clear:left; margin-top: -29px; margin-right: 100px;" ><a  class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion4" href="?simmol#collapseOne5" ><img src="/img/extreme.png" style="width: 16px; height: 16px;" /></a></div>

</form>
</div>

</div>  

 
</body>
</html>