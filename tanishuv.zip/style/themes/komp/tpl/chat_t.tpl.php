<?
 $ide = (int)$_GET ['id'];
 $ank = (empty($ide)) ? $user : new user((int)$ide);

if ($user->title_fonga){?>
<style> 
	#navbar {
    margin: 0;
    padding-left: 0;
    padding-right: 0;
    border-width: 0;
    border-radius: 0;
    -webkit-box-shadow: none;
    box-shadow: none;
    min-height: 45px;
    background: <?=$user->title_fonga?>;
}
</style> 
<?}else{?>
<style> 
	#navbar {
    margin: 0;
    padding-left: 0;
    padding-right: 0;
    border-width: 0;
    border-radius: 0;
    -webkit-box-shadow: none;
    box-shadow: none;
    min-height: 45px;
    background: <?=$uzcms->title_fonga?>;
}
</style> 	
<?}?>
<style> 
  .tent{
    padding: 3px;
    background: #fbfcfd;
    border: 1px solid #f1f1f1;
	
  }
  .chii{
    padding: 13px;
    margin: 18px 0;
	border: 0px solid #eee;
    border-left-width: 5px;
	
   }
</style>
<?
 $e = ''.$lang->name.'nomi';
$_SESSION['sava'] = $_SERVER['REQUEST_URI'];
$return =  $_SESSION['sava'];
 $ank = (empty($_GET ['id'])) ? $user : new user((int)$_GET ['id']);
?>


	
				<a href="/"><img style="width: 32px; padding: 2px; margin-left: 15px; border-radius: 25px; margin-top: 7px;" src="/img/we.png" />
				
				</a>
				<div style="font-size: 100%; color: #fff; margin-left: 50px;  margin-top: -35px;"> <?=__($uzcms->chat_tepa)?> </div>
				<a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion4" href="?online#collapseOne4" ><div style="font-size: 70%; color: #fff; margin-left: 50px;  margin-top: 2px;"> <?=__('Online')?> : ( <?= mysql_result(mysql_query("SELECT COUNT(*) FROM `chat_on`"), 0)?> ) </div></a>
				
				<div style="margin-top: -45px" class="navbar-buttons pull-right" role="navigation">
					<ul class="nav ace-nav">
		<?				
		 if ($user->chatga){   
        echo'<li style="background: none;" class="green dropdown-modal">
							<a  style="background: none; border-left: none;" class="dropdown-toggle" href="/chat">
								<i class="ace-icon icon-animated-vertical">'.sm_icon(qlassik_ru('62')).'</i>
								<span style="margin-left: -8px;" class="badge badge-success">  '.mysql_result(mysql_query("SELECT COUNT(*) FROM `chat_mini` WHERE `u` = '".$user->id."'"), 0).' </span>
							</a>
                        </li>';
		}else{
        if ($user->tasma){    
			
			echo'<li style="background: none;" class="green dropdown-modal">
							<a  style="background: none; border-left: none;" class="dropdown-toggle" href="/tasma">
								<i class="ace-icon icon-animated-vertical">'.sm_icon(qlassik_ru('66')).'</i>
								<span style="margin-left: -8px;" class="badge badge-success">  '.mysql_result(mysql_query("SELECT COUNT(*) FROM `tasma` WHERE `u` = '".$user->id."'"), 0).' </span>
							</a>
                        </li>';
		}else{
			echo'<li style="background: none;" class="green dropdown-modal">
							<a  style="background: none; border-left: none;" class="dropdown-toggle" href="/chat">
								<i class="ace-icon icon-animated-vertical">'.sm_icon(qlassik_ru('67')).'</i>
								<span style="margin-left: -8px;" class="badge badge-success">  '.mysql_result(mysql_query("SELECT COUNT(*) FROM `chat_on`"), 0).' </span>
							</a>
                        </li>';			
			
		}
		}
		
		
		if ($user->friend_new_count){
			echo'<li style="background: none;" class="green dropdown-modal">
							<a  style="background: none; border-left: none;" class="dropdown-toggle" href="/mening_dostlarim.html?friend">
								<i class="ace-icon icon-animated-bell">'.sm_icon(qlassik_ru('68')).'</i>
								<span style="margin-left: -8px;" class="badge badge-success">  '.$friend_new_count.' </span>
							</a>
                        </li>';				
		}elseif ($user->mexmon){
			echo'<li style="background: none;" class="green dropdown-modal">
							<a  style="background: none; border-left: none;" class="dropdown-toggle" href="/mexmonlar.html">
								<i class="ace-icon icon-animated-bell">'.sm_icon(qlassik_ru('69')).'</i>
								<span style="margin-left: -8px;" class="badge badge-success">  '.$user->mexmon.' </span>
							</a>
                        </li>';			
	}elseif ($user->kon_qosh){
			echo'<li style="background: none;" class="green dropdown-modal">
							<a  style="background: none; border-left: none;" class="dropdown-toggle" href="/komfrensa?men">
								<i class="ace-icon icon-animated-bell">'.sm_icon(qlassik_ru('70')).'</i>
								<span style="margin-left: -8px;" class="badge badge-success">  '.$user->kon_qoshn.' </span>
							</a>
                        </li>';	
  }elseif ($gurpaga_chaqiryapti){
			echo'<li style="background: none;" class="green dropdown-modal">
							<a  style="background: none; border-left: none;" class="dropdown-toggle" href="/grup.html">
								<i class="ace-icon icon-animated-bell">'.sm_icon(qlassik_ru('71')).'</i>
								<span style="margin-left: -8px;" class="badge badge-success">  '.$gurpaga_chaqiryapti.' </span>
							</a>
                        </li>';	  
  }elseif ($gurpamga_keldi){
			echo'<li style="background: none;" class="green dropdown-modal">
							<a  style="background: none; border-left: none;" class="dropdown-toggle" href="/grup.html">
								<i class="ace-icon icon-animated-bell">'.sm_icon(qlassik_ru('72')).'</i>
								<span style="margin-left: -8px;" class="badge badge-success">  '.$gurpamga_keldi.' </span>
							</a>
                        </li>';	  
} 
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	 $sql_where = array("`mail`.`id_user` = '{$user->id}'");
$sql_where[] = "`mail`.`is_read` = '0'";
$q = mysql_query("SELECT `users`.`id`,
        `mail`.`id_sender`,
        MAX(`mail`.`time`) AS `time`,
        MIN(`mail`.`is_read`) AS `is_read`,
        COUNT(`mail`.`id`) AS `count`
FROM `mail`
LEFT JOIN `users` ON `mail`.`id_sender` = `users`.`id`
WHERE " . implode(' AND ', $sql_where) . "
GROUP BY `mail`.`id_sender`
ORDER BY `time` DESC
LIMIT 1");
while ($ma = mysql_fetch_assoc($q)) {
	$ank = new user((int)$ma['id_sender']);
	if ($ma['count'] == $user->mail_new_count){
	$ke = $ma['id'];
	}else{
	$ke = $user->login;	
	}
	 	
}
  if(!isset($ke))$ke = $user->login;
  if ($ke == $user->login){
  if ($user->mail_new_count){
  echo'<li style="background: none;" class="green dropdown-modal">
							<a  style="background: none; border-left: none;" class="dropdown-toggle" href="/xabar?xabar_keldi">
								<i class="ace-icon icon-animated-vertical">'.sm_icon(qlassik_ru('73')).'</i>
								<span style="margin-left: -8px;" class="badge badge-success">  '.$user->mail_new_count.' </span>
							</a>
                        </li>';	
  }
  }else{
	  
	  
	  	if ($user->mail_k_new_count){
echo'<li style="background: none;" class="green dropdown-modal">
							<a  style="background: none; border-left: none;" class="dropdown-toggle" href="/komfrensa?men">
								<i class="ace-icon icon-animated-vertical">'.sm_icon(qlassik_ru('74')).'</i>
								<span style="margin-left: -8px;" class="badge badge-success">  '.$user->mail_k_new_count.' </span>
							</a>
                        </li>';				
}else{  
                        echo'<li style="background: none;" class="green dropdown-modal">
							<a  style="background: none; border-left: none;" class="dropdown-toggle" href="/xabar?id='.$ke.'">
								<i class="ace-icon icon-animated-vertical">'.sm_icon(qlassik_ru('75')).'</i>
								<span style="margin-left: -8px;" class="badge badge-success">  '.$user->mail_new_count.' </span>
							</a>
                        </li>';	
  
  
  }
  }
  
  
							
		
		
		?><li class="light-blue dropdown-modal">
							<a style="background: none; margin-top: -3px;" data-toggle="dropdown"  class="dropdown-toggle">
								<img  class="nav-user-photo" src="<?= $ank->getAva(); ?>" alt="VOO.UZ" />
								</span>
								</a>

							
						</li>
					</ul>
					</div>
				
		<?
		
		
		
        echo'<div  style="margin: 15px" id="collapseOne4" class="panel-collapse collapse" aria-expanded="false">';
		$qs = mysql_query("SELECT * FROM `chat_on`");
        while ($p_user = mysql_fetch_assoc($qs)) {
        $ank = new user($p_user['id']);
		echo '<div style="margin: 5px" class="bolimgaa">';
		echo '<img style="float:right; clear:left; margin-right: 20px; margin-top: -6px;" src="/img/inline_video_small_play.png" title="VOO.UZ"/>';
		echo '<img style="margin: 2px; height: 30px; width: 30px; border-radius: 15px;" src="'.$ank->getAva().'" title="VOO.UZ"/>   '.sm_nick($ank->title);
		echo"</div>";
		}
		
		
		?>	
		
		