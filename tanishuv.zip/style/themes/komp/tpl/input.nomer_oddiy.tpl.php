    <link href="/style/css/jquerysctipttop.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="/style/css/intlInputPhone.min.css">
    <?=
    '<div class="ana"><form>'
    ?>

    <?
    foreach ($el AS $element) {
        if ($element['title'])
            echo ' <div style="margin-left: 22%;"> '.$element['title'] . ' </div>';
        switch ($element['type']) {
            case 'text': echo ' <div style="margin-left: 22%;"> '.$element['value']. ' </div>';
                break;
            case 'captcha':
                ?>
                <input type="hidden" name="captcha_session" value="<?= $element['session'] ?>" />
                <img id="captcha" src="/captcha.html?captcha_session=<?= $element['session'] ?>&amp;<?= SID ?>" alt="captcha" />
                <div class="form-group"><label for="nick"><?= $lang->getString("Bu erga rasimdagi raqamini yozin") ?></label></div>
                <input type="text" autocomplete="off" name="captcha" size="5" maxlength="5" />
                <?
                break;
			case 'son':
                ?>
                <input type="hidden" name="captcha_session" value="<?= $element['session'] ?>" />
                <input class="gradient_grey invert border padding radius" type="text" autocomplete="off" name="captcha" size="5" maxlength="5" />
                <?
                break;
            case 'input_text':
                echo '<center><div style="width: 60%;" class="input-phone"></div></center>';
                break;

            case 'hidden':
                echo '<input  style="width: 60%; margin-left: 1%; height: 32px; margin:3px;" class="otga"  type="hidden"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="' . text::toValue($element['info']['value']) . '"' : '') .
                ' />';
                break;
            case 'password':
                echo '<input style="width: 60%; margin-left: 1%; height: 32px; margin:3px;" class="otga" type="password"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="' . text::toValue($element['info']['value']) . '"' : '') .
                ($element['info']['maxlength'] ? ' maxlength="' . intval($element['info']['maxlength']) . '"' : '') .
                ($element['info']['size'] ? ' size="' . intval($element['info']['size']) . '"' : '') .
                ($element['info']['disabled'] ? ' disabled="disabled"' : '') .
                ' />';
                break;
            case 'textarea':
                echo '<textarea style="width:60%; height: 80px; color:wite; background-color: wite;"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['disabled'] ? ' disabled="disabled"' : '') .
                '>' .
                ($element['info']['value'] ? text::toValue($element['info']['value']) : '') .
                '</textarea>';
                break;
            case 'checkbox':
                echo '<label><input type="checkbox"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="' . text::toValue($element['info']['value']) . '"' : '') .
                ($element['info']['checked'] ? ' checked="checked"' : '') .
                ' />' .
                ($element['info']['text'] ? ' ' . $element['info']['text'] : '') .
                '</label>';
                break;
            case 'submit':
                echo '<center><input style="width: 60%;  height: 32px; margin:3px;" class="otga form-control" type="submit"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ($element['info']['value'] ? ' value="' . text::toValue($element['info']['value']) . '"' : '') .
                ' /></center>';
                break;
            case 'file':
                echo '<input type="file"' .
                ($element['info']['name'] ? ' name="' . $element['info']['name'] . '"' : '') .
                ' />';
                break;
            case 'select':
                echo '<select  style="width: 96%; margin-left: 1%;font-size:16px; padding: 4px; background: #FAFAFA; " name="' . $element['info']['name'] . '">';
                foreach ($element['info']['options'] AS $option) {
                    if ($option['groupstart'])
                        echo '<optgroup  label="' . $option[0] . '">';
                    elseif ($option['groupend'])
                        echo '</optgroup>';
                    else
                        echo '<option' .
                        ($option[2] ? ' selected="selected"' : '') .
                        ' value="' . $option[0] . '"' .
                        '>' .
                        $option[1] .
                        '</option>';
                }
                echo '</select>';
                break;
        }

        if ($element['br'])
            echo '<br />';
    }
    ?>

        <?
        echo '</form>';
        ?>    
</div>
<? if ($ajax_url) { ?>
    <script>
        form_ajax_submit(document.getElementById('<?= $id ?>'), '<?= $ajax_url ?>');
    </script>
    <?
}?>
<div class="royhatdan_ot_ramkasi royhatdan_ot_ramkasini_ichi" role="alert"><a href="/til.html" title="<?=__('Tilni o`zgartirish')?>"><?=__('Tilni o`zgartirish')?></a></div>
<div class="royhatdan_ot_ramkasi royhatdan_ot_ramkasini_ichi" role="alert"><a href="/kirish.html" title="<?=__('Saytga kirish')?>"><?=__('Saytga kirish')?></a></div>
<div class="royhatdan_ot_ramkasi royhatdan_ot_ramkasini_ichi" role="alert"><a href="/parolni_tiklash.html" title="<?=__('Parolni tikalash')?>"><?=__('Parolni tikalash')?></a></div>
<div style="text-align:center"><div class="tagii"><small><?=$uzcms->sayt_p?></small></div></div>
        <script>
        $(document).ready(function() {
            $('.input-phone').intlInputPhone();
        })
    </script>
	<script src="/style/js/jquery-1.12.4.min.js"></script>
    <script src="/style/js/intlInputPhone.min.js"></script>