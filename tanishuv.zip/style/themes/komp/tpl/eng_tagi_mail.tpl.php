<?
if (MANZIL_S == '/user/xizmatlar/mail_k.php'){
?><div class="royhatdan_ot_ramkasi royhatdan_ot_ramkasini_ichi" role="alert"><a href="/fonikonfrensa.html" title="<?=__('Fon qo`yish')?>"><?=__('Fon qo`yish')?></a></div><?
}else{
?><div class="royhatdan_ot_ramkasi royhatdan_ot_ramkasini_ichi" role="alert"><a href="/fon.html" title="<?=__('Fon qo`yish')?>"><?=__('Fon qo`yish')?></a></div><?}?>
<div class="royhatdan_ot_ramkasi royhatdan_ot_ramkasini_ichi" role="alert"><a href="/komfrensa?" title="<?=__('Kanfrensa')?>"><?=__('Kanfrensa')?></a></div>
<div class="royhatdan_ot_ramkasi royhatdan_ot_ramkasini_ichi" role="alert"><a href="/xabar?" title="<?=__('Xamma xabarlar')?>"><?=__('Xamma xabarlar')?></a></div>
<div class="royhatdan_ot_ramkasi royhatdan_ot_ramkasini_ichi" role="alert"><a href="/ID" title="<?=__('Bosh sahifa')?>"><?=__('Bosh sahifa')?></a></div>
<div style="text-align:center"><div class="tagii"><small><?=$uzcms->sayt_p?></small></div></div>
  <div style="margin: 15px 0px 0px 4px;" class="col-xs-12"> <center class="" role="alert">
				<div class="footer-inner">
					<div class="footer-content">
					
						<span class="bigger-120">
							<span class="blue bolder"><a href="http://voo.uz/info.php" /> DIZAYNER </span>
							<?=$copyright?>
						</span>

						&nbsp; &nbsp;
						<span class="action-buttons">
							<a href="/<?=$uzcms->telegram; ?>">
								<i class="ace-icon fa  fa-location-arrow light-blue bigger-150"></i>
							</a>

							<a href="/<?=$uzcms->mail; ?>">
								<i class="ace-icon fa fa-at text-primary bigger-150"></i>
							</a>

							<a href="/<?=$uzcms->yotub; ?>">
								<i class="ace-icon fa fa-video-camera orange bigger-150"></i>
							</a>
						</span>
					</div>
				</div>
			</center>
			
			
<a href="#" id="btn-scroll-up" class="btn-scroll-up btn btn-sm btn-inverse">
				<i class="ace-icon fa fa-angle-double-up icon-only bigger-110"></i>
			</a>
			</div>