<?
 $ide = (int)$_GET ['id'];
 $ank = (empty($ide)) ? $user : new user((int)$ide);
$id_kont = (int)$_GET ['id'];
	    	$qaa = mysql_query("SELECT * FROM `komfrensa_nom` WHERE `id` = '".$_GET['id']."' ORDER BY `id` DESC LIMIT 1");
while ($pa_userc = mysql_fetch_assoc($qaa)) {
	$iia = $pa_userc['nomi'];
	$ida = $pa_userc['id'];	
	$admin = $pa_userc['user'];	
	$rasim = $pa_userc['rasim'];	
	
}
if ($user->title_fonga){?>
<style> 
	#navbar {
    margin: 0;
    padding-left: 0;
    padding-right: 0;
    border-width: 0;
    border-radius: 0;
    -webkit-box-shadow: none;
    box-shadow: none;
    min-height: 45px;
    background: <?=$uzcms->title_fonga?>;
}
</style> 
<?}else{?>
<style> 
	#navbar {
    margin: 0;
    padding-left: 0;
    padding-right: 0;
    border-width: 0;
    border-radius: 0;
    -webkit-box-shadow: none;
    box-shadow: none;
    min-height: 45px;
    background: <?=$uzcms->title_fonga?>;
}
</style> 	
<?}?>
<style> 
  .tent{
    padding: 3px;
    background: #fbfcfd;
    border: 1px solid #f1f1f1;
	
  }
  .chii{
    padding: 13px;
    margin: 18px 0;
	border: 0px solid #eee;
    border-left-width: 5px;
	
   }
</style>
<?
if (MANZIL_S == '/user/xizmatlar/mail.php'){
echo '<div style="height: 50px; padding: 10px; background: #fbfcfd; border: 1px solid #f1f1f1;">
		<table style="margin-top: -8px;" width="100%" border="0">
		<tr>';
		
		
		if ($user->mail_new_count){
		echo '<td width="40"><a href="/xabar?"><img style="width: 32px; padding: 2px;  width: 32px border-radius: 25px; margin-top: -10px;" src="/img/arrow-down_h@2x.png" /></a><div class="tesa"><div class="foss">'.$user->mail_new_count.' </div></div>';
		}else{
		echo '<td width="20"><a href="/xabar?"><img style="width: 32px; padding: 2px;  width: 32px border-radius: 25px; margin-top: 5px;" src="/img/arrow-down_h@2x.png" /></a>';
			
		}
		
		
		
		
		echo '</td><td><div style="float:left;"> '.$ank->nick().'';
		
		if (isset($_SESSION['errr'])){
		echo '<span style="font-size: 70%; color:red" class="">: '.$_SESSION['errr'].'</span>';
		unset($_SESSION['errr']);
		}else{
			if (isset($_SESSION['msgr'])){
		echo '<span style="font-size: 70%; color:green" class="">: '.$_SESSION['msgr'].'</span>';	
		unset($_SESSION['msgr']);
			}
		}
		
		echo '<div style="font-size: 75%; color: #c2c0c0;">'.__('Ohirgi kirilgan vaqti').': '.misc::when($ank->last_visit).'</div></div></td></tr>
		
		</table><div  style="float:right; clear:left; margin-top: -34px;"><a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion4" href="/xabar?id='.$ank->id.'#collapseOne4" aria-expanded="false"><img src="/img/menu_active.png" /><img style="padding: 2px; height: 40px; width: 40px; border-radius: 25px; " src="'.$ank->getAva().'" title="voo.uz" /></a></div></div>';
	   
}elseif (MANZIL_S == '/user/xizmatlar/mail_k.php'){
	
	echo '<div style="height: 50px; padding: 10px; background: #fbfcfd; border: 1px solid #f1f1f1;">
		<table style="margin-top: -8px;" width="100%" border="0">
		<tr>';
		
		
		if ($user->mail_k_new_count){
		echo '<td width="40"><a href="/komfrensa?"><img style="width: 32px; padding: 2px;  width: 32px border-radius: 25px; margin-top: -10px;" src="/img/arrow-down_h@2x.png" /></a><div class="tesa"><div class="foss">'.$user->mail_k_new_count.' </div></div>';
		}else{
		echo '<td width="20"><a href="/komfrensa?"><img style="width: 32px; padding: 2px;  width: 32px border-radius: 25px; margin-top: 5px;" src="/img/arrow-down_h@2x.png" /></a>';
			
		}
		

		
		$onee = mysql_result(mysql_query("SELECT COUNT(*) FROM `kamfrensaa_on`  WHERE  `id` = '$id_kont'  AND `time` + '120' > '". TIME ."' "), 0);
		echo '</td><td><div style="font-size: 100%; float:left;"> '.$iia.'';
		if (isset($_SESSION['errr'])){
		echo '<span style="font-size: 70%; color:red" class="">: '.$_SESSION['errr'].'</span>';
		unset($_SESSION['errr']);
		}else{
			if (isset($_SESSION['msgr'])){
		echo '<span style="font-size: 70%; color:green" class="">: '.$_SESSION['msgr'].'</span>';	
		unset($_SESSION['msgr']);
			}
		}
		echo '<div style="font-size: 75%; color: #c2c0c0;">'.__('Do`stlar').': <b style="color: green;">'.$onee.' </b> / <span style="color: red;">'.mysql_result(mysql_query("SELECT COUNT(*) FROM `komfrensa` WHERE  `admin` = '".$id_kont."' "), 0).'</span></div></div></td></tr>
		
		</table><div  style="float:right; clear:left; margin-top: -34px;"><a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion4" href="?id='.$ank->id.'#collapseOne4" aria-expanded="false"><img src="/img/menu_active.png" /><img style="padding: 2px; height: 40px; width: 40px; border-radius: 25px; " src="'.$rasim.'" title="voo.uz" /></a></div></div>';
		
		
	
	
}