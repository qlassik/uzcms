<?

$ank = (empty($_GET ['id'])) ? $user : new user((int)$_GET ['id']);
if ($ank->fone){
$fon = $ank->fone;	
}else{
if ($ank->fon){
$fon = '/style/shaxar/'.$ank->fon.'.jpg';
}else{
$fon = 'yoq';	
}
}
if($user->id)if ($user->id == $ank->id);else echo'<a href="/xabar?id='.$ank->id.'"><div class="user_ekran_xat_katta_img"></div></a>';
echo'<div class="gmenu"><div class="tepabg"><img  class="rasim_6" src="'.$fon.'"></div>';
echo'<div class="dumaloq"><table width="100%"><tbody><tr class="ID_6"><td width="80px">';
if ($path = $ank->getAva()) {

	echo'<img src="' . $path . '" width="50" height="50"  alt="' . __('Foto %s', $ank->title) . '"  style="border-radius:25px;">';
}
$qq = $ank->ank_g_r;
$ay = date("Y");
$ess = $ay - $qq;
echo'</a></td><td><b><font color="#ccc">'.$ank->nick.'</b>  <br><span  style="font-size: 70%; text-transform: uppercase;">'.$ess .' '.__('yosh').' | <i>'.$ank->fon.'</i></span><br />';

if ($ank->id == $user->id){
echo '</td></tr></tbody></table></div>';	
echo '<br /><br /><br />';	
}else{
if ($user->id){

   if ($ank->is_friend($user)){
	echo '<div style="font-size: 11px;" class="dost"><a href="?id='.$ank->id.'&amp;friend=delete"> +'.__('O`chirish').' </a></div>';
      }else{
	echo '<div style="font-size: 11px;" class="dost"><a href="?id='.$ank->id.'&amp;friend=add"> +'.__('Do`stlik').' </a></div>';
   }

   	if (!$user->is_enemies($ank)) {
		echo '<div style="font-size: 11px;" class="dost"><a href="/ID'.$ank->id.'?id='.$ank->id.'&enemies"> +'.__('To`siq qo`yish').' </a></div>';
	}else{
			$pages = new pages ;
$pages->posts = mysql_result(mysql_query("SELECT COUNT(*) FROM `enemies` WHERE `id_user` = '$user->id'"), 0) ;
$pages->this_page() ;

		$q = mysql_query("SELECT * FROM `enemies` WHERE `id_user` = '$user->id' ORDER BY `time` DESC LIMIT ".$pages->limit);
        while($enemies = mysql_fetch_object($q)) 
	if ($enemies->id_who == $ank->id){
		echo '<div style="font-size: 11px;" class="dost"><a href="/ID'.$ank->id.'?delete=' .$enemies->id. '"> +'.__('To`siqni olish').' </a></div>';
	}
	}
echo '<div style="font-size: 11px;" class="dost"><a href="/user/sovga/ot.php?id='.$ank->id.'"> +'.__('Sovga').'</a></div><div style="font-size: 11px;" class="dost"><a href="/user/group/ot.php?id='.$ank->id.'"> +'.__('Gurpaga').'</a></div></td></tr></tbody></table></div>';
}else{
echo '</td></tr></tbody></table></div>';

}
}
