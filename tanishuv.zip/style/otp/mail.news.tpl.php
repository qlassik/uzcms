<html lang="ru" xml:lang="ru" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title><?= $title ?> - <?= $site ?></title>
    <style type="text/css">
            /* <![CDATA[ */
        body {
            font-family: tahoma, arial, verdana, sans-serif, Lucida Sans;
            font-size: 14px;
        }
        #unsubscribe{
            font-size: small;
        }

            /* ]]> */
    </style>
</head>
<body>
<div>Yangiliklar:</div>
<p><?= $content ?></p>
<div id="unsubscribe"> Sizga yangilik keldi <?= $email ?>, Sisilkani bosin <a href="<?= $unsubscribe ?>">Shuni</a>.</div>
</body>
</html>