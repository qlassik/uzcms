<html lang="ru" xml:lang="ru" xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title><?= $title ?></title>
        <style type="text/css">
            /* <![CDATA[ */
            body{
                font-family: tahoma, arial, verdana, sans-serif, Lucida Sans;
                font-size: 14px;
            }
            /* ]]> */
        </style>
    </head>
    <body>
        <b><?= $login ?></b>, <?=__('Siz ro`yhatdan o`tdingiz')?> <b><?= $site ?></b>.<br />
        <?=__('Parol')?>: <b><?= $password ?></b><br />
        <?=__('Aktivlang')?>: <b><a href="<?= $url ?>"><?= $url ?></a></b><br />
    </body>
</html>