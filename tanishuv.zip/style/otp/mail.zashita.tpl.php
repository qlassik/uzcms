<html lang="ru" xml:lang="ru" xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title><?=$title?></title>
        <style type="text/css">
            /* <![CDATA[ */
            body{
                font-family: tahoma, arial, verdana, sans-serif, Lucida Sans;
                font-size: 14px;
            }
            /* ]]> */
        </style>
    </head>
    <body>
        <b><?=$site?></b>
		<br />
        <b><a href="<?=$url?>"><?=$url?></a></b><br />
        <br />
        <?=__('Bravzeriz')?>: <?=$uzcms->browser?><br />
        IP: <?=long2ip($uzcms->ip_long)?><br />
    </body> 
</html>