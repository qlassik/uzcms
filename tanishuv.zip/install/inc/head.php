<!DOCTYPE html PUBLIC "-//mobilniFORUM//DTD XHTML Mobile 1.0//EN" "http://www.mobilniforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru">
<head>
<title><?php echo __($ini[$step]['title']);?></title>
<link rel="shortcut icon" href="/favicon.ico" />
<link rel="stylesheet" href="/install/style.css" type="text/css" />
<meta http-equiv="content-Type" content="application/xhtml+xml; charset=utf-8" />
</head>
<body>
