<div class="page_foot">
<a href="http://as-site.uz">as-site.uz</a>
</div>
</body>
</html>