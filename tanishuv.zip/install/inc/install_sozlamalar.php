<?php
class install_sozlamalar {
    var $conf = array();
    var $return = false;
    function __construct()
    {
        $this->settings = &$_SESSION['settings'];

        if ($this->conf = @parse_ini_file(H . '/sys/dat/yadro.ini', false)) {
            $this->return = true;
        }
    }

    function actions()
    {
        $return = false;
        if (!empty($this->conf['shif'])) {
            $this->settings['salt'] = $this->conf['shif'];
            $return = true;
        }

        if (!empty($this->conf['mcrypt_iv']))
            $this->settings['iv'] = $this->conf['mcrypt_iv'];

        return $return;
    }

    function form()
    {
        if (!$this->return) {
            echo "Sizda baza bor<br />";
            echo " sys/dat/yadro.ini shu faylni udalit qilin";
        }else {
            echo "Yuklanib bo`lgan";
        }

        return $this->return;
    }
}

?>
