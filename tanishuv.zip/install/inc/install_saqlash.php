<?php

class install_saqlash {

    var $is_writed = false;

    function __construct() {
        $this->settings = &$_SESSION['settings'];
        $this->settings['language'] = $_SESSION['language'];
    }

    function actions() {
        $return = false;
        if ($this->is_writed = ini::save(H . '/sys/dat/yadro.ini', $this->settings)) {
            $return = true;

            unset($_SESSION);
            session_destroy();

            foreach ($_COOKIE as $key => $value) {
                setcookie($key);
            }

            header("Location: /?" . passgen() . '&' . SID);
            exit;
        }

        return $return;
    }

    function form() {
        echo __('OKEYYYYYYYYYYYY');

        return true;
    }

    function __destruct() {
        if (!$this->is_writed)
            @unlink(H . '/sys/dat/yadro.ini');
    }

}

?>
