<?php

class install_load_sql {

    var $tables;

    function __construct() {
        db_connect();
        $this->tables = new tables();

        if (empty($_SESSION['rename_prefix']))
            $_SESSION['rename_prefix'] = '~' . TIME . '~';

        foreach ($this->tables->tables as $table) {
            if ($table {
                    0} == '~')
                continue;
            mysql_query("ALTER TABLE `" . my_esc($table) . "` RENAME `" . $_SESSION['rename_prefix'] . my_esc($table) . "`");
        }
    }

    function actions() {
        $return = true;
        global $options;

        $files_ini = array();
        $files_sql = array();

        if (!empty($_POST['load_data']) && !empty($options['new_base']))
            $files_sql = (array) glob(H . '/sys/db_tables/base.data.*.sql');

        $files_ini = (array) glob(H . '/sys/db_tables/base.create.*.ini');

        foreach ($files_ini as $file) {
            $tab = new table_structure($file);
            $sql = $tab->getSQLQueryCreate();
            if (!@mysql_query($sql))
                $return = false;
        }
        foreach ($files_sql as $file) {
            $sqls = sql_parser::getQueriesFromFile($file);
            foreach ($sqls as $sql) {
                if (!@mysql_query($sql))
                    $return = false;
            }
        }

        $_SESSION['install_load_sql_false'] = !$return;

        return $return;
    }

    function form() {
        echo __('Tablitsa yuklanib boldi endi siz o`z admitsator huquqizi kiritasiz');
        echo __('/sys/db_tables/ bu tablitsa turadigon joy');

        global $options;
        if (!empty($options['new_base'])) {
            $files = glob(H . '/sys/db_tables/base.data.*.sql');

            if ($files)
                echo '<br /><label><input type="checkbox" checked="checked" value="1" name="load_data" />' . __('Загрузить содержимое таблиц') . '</label>';
        }
        if (!empty($_SESSION['install_load_sql_false']))
            echo "<br />".__("SQL informatorda xatolik bor") ;

        return true;
    }

}

?>
