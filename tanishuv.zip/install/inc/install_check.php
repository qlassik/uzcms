<?php

class install_check {

    function check() {
        $check = new check_sys();

        foreach ($check->oks as $ok) {
            echo "$ok<br />";
        }

        foreach ($check->errors as $err) {
            echo "<span style='font-weight:bold'>" . __('xatolik') . ": $err</span><br />";
        }

        foreach ($check->notices as $note) {
            echo "<span style='font-weight:bold'>" . __('Masalan') . ":</span> $note<br />";
        }

        return empty($check->errors);
    }

    function actions() {
        return $this->check();
    }

    function form() {
        $ok = $this->check();
        if ($ok)
            echo "<span style='font-weight:bold'>" . __('Hamma fayl holatida') . "</span>";
        return $ok;
    }

}

?>
