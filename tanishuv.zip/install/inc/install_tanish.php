<?php
class install_tanish {
    function actions()
    {
        return true;
    }

    function form()
    {
        echo __("Salom UZCMS sikribdan foydalanganiz uchun rahmat");
        echo'<hr />';
        echo __("Azizlar bu skrib muallifi yani men Qodirov Elyorbek");
        echo __(" Bo`laman bu skrib DCMS SEVEN, DCMSSOTSANAL,");		
        echo __(" WORPRESS, DATALIFE, JOMBOOlA skriblarini umumlashtirib");
        echo __(" Yasaganman. BU skribdan TANISHUV, MAGAZIN, YUKLAMA, MP3, VIDEO,");		
        echo __(" TOP REYTIN, HOSTIN UPRAVLENYA ham modullarlik saytlar yasasa bo`ladi ");
        echo __(" AGAR savollaringiz bo`lsa +998 (91) 169-37-66 ga ");
        echo __(" qo`ng`iroq qiling");
        echo __(" VOO.uz");		
        echo __(" AS-site.uz");
        echo __(" 2016 yil 11 sentyabir");		
		
		
		
		return true;
    }
}

?>
