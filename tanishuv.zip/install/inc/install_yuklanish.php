<?php
class install_yuklanish {
    var $is_loaded = false;
    function __construct()
    {
        $settings = &$_SESSION['settings'];

        if (empty($settings)) {
            if ($settings = ini::read(H . '/sys/db_tables/yadro.ini', false)) {
                $this->is_loaded = true;
                $settings['mysql_pass'] = ''; 
            }
        }else {
            $this->is_loaded = true;
        }
    }

    function actions()
    {
        return $this->is_loaded;
    }

    function form()
    {
        if ($this->is_loaded)
            echo "<span style='font-weight:bold'>".__('Siz hozir baza malumotlarini kiritasiz')."</span>";
            echo "<span style='font-weight:bold'>".__('Doim yodda tutin bu skrib sifravoy tizimdan iborat')."</span>";
           echo "<span style='font-weight:bold'>".__('Siz baza dalniylaringiz /sys/dat/yadro.php ga tushadi')."</span>";
        
		return $this->is_loaded;
    }
}