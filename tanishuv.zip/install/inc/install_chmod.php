<?php

class install_chmod {

    function check() {
        $return = true;

        $nw = ini::read(H . '/sys/dat/chmod.ini');

        $err = array();
        foreach ($nw as $path) {
            $e = check_sys::getChmodErr($path, true);

            echo $path . ' ' . ($e ? '<span style="font-weight:bold">[' . __('Prablema') . ']</span>' : '[OK]') . '<br />';

            $err = array_merge($err, $e);
        }

        if ($err) {
            echo '<textarea>';
            foreach ($err as $error) {
                echo $error . "\r\n";
            }

            echo '</textarea><br />';
            echo '* ' . __('Chmod holatini tekshirin 644 yoki 666 bo`lsin');
        }else
            echo '<span style="font-weight:bold">' . __('okey') . '</span>';

        return empty($err);
    }

    function actions() {
        return $this->check();
    }

    function form() {
        return $this->check();
    }

}

?>
