<?php
require_once dirname(__FILE__) . '/../sys/inc/initialization.php';


 if ($_SESSION['language'] && languages::exists($_SESSION['language'])){
    $user_language_pack = new language_pack($_SESSION['language']);
}else {
    $user_language_pack = new language_pack('Uzbekcha');
}


function db_connect() {
    $settings = &$_SESSION['settings'];
    mysql_connect($settings['mysql_host'], $settings['mysql_user'], $settings['mysql_pass']) or die(__('Server bazaviymas'));
    mysql_select_db($settings['mysql_base']) or die(__('Baza yo`q'));
    mysql_query('SET NAMES "utf8"');
}

if (is_file(H . '/sys/dat/yadro.ini')) {
    header("Location: /?" . passgen() . '&' . SID);
    exit;
}

$install = &$_SESSION['install'];
$options = &$_SESSION['options'];
$ini = @parse_ini_file('inc/steps.ini', true);

foreach ($ini as $key => $value) {
    if (empty($value['if_option']) || isset($options[$value['if_option']])) {
        if (empty($install[$key]['status'])) {
            $step = $key;
            break;
        }
    }
}

header('Content-Type: application/xhtml+xml; charset=utf-8');
ob_start();
include 'inc/head.php';

echo "<h1>" . __($ini[$step]['title']) . "</h1>";

if (isset($_POST['to_start'])) {
    header("Location: ./?" . passgen() . '&' . SID);

    unset($_SESSION);
    session_destroy();

    session_name(SESSION_NAME) or die(__('Aparatizda ayib bor'));
    @session_start() or die(__('Aparatizda ayib bor'));
    exit;
}

echo '<center><table width="95%" border="1"><tr><td width="30%">';



if ($ini[$step]['test'] == 1){
	echo '<div class="form_header"> <img src="ok.png" /><s><b> '.__('Tilni tallash').'</b></s></div><hr />';
}else{
echo '<div class="form_header"> <img src="wait.png" /> '.__('Tilni tallash').'</div><hr />';
}

if ($ini[$step]['test1'] == 1){
	echo '<div class="form_header"> <img src="ok.png" /><s><b> '.__('Skrib xaqida').'</b></s></div><hr />';
}else{
echo '<div class="form_header"> <img src="wait.png" /> '.__('Skrib xaqida').'</div><hr />';
}

if ($ini[$step]['test2'] == 1){
	echo '<div class="form_header"> <img src="ok.png" /><s><b> '.__('Skrib patenti').'</b></s></div><hr />';
}else{
echo '<div class="form_header"> <img src="wait.png" /> '.__('Skrib patenti').'</div><hr />';
}

if ($ini[$step]['test3'] == 1){
	echo '<div class="form_header"> <img src="ok.png" /><s><b> '.__('Serwer malumotlari').'</b></s></div><hr />';
}else{
echo '<div class="form_header"> <img src="wait.png" /> '.__('Serwer malumotlari').'</div><hr />';
}

if ($ini[$step]['test4'] == 1){
	echo '<div class="form_header"> <img src="ok.png" /><s><b> '.__('Chmod tekshiruv').'</b></s></div><hr />';
}else{
echo '<div class="form_header"> <img src="wait.png" /> '.__('Chmod tekshiruv').'</div><hr />';
}

if ($ini[$step]['test5'] == 1){
	echo '<div class="form_header"> <img src="ok.png" /><s><b> '.__('Baza malumotlari xaqida').'</b></s></div><hr />';
}else{
echo '<div class="form_header"> <img src="wait.png" /> '.__('Baza malumotlari xaqida').'</div><hr />';
}

if ($ini[$step]['test6'] == 1){
	echo '<div class="form_header"> <img src="ok.png" /><s><b> '.__('Mysql baza bilan bog`lash').'</b></s></div><hr />';
}else{
echo '<div class="form_header"> <img src="wait.png" /> '.__('Mysql baza bilan bog`lash').'</div><hr />';
}

if ($ini[$step]['test7'] == 1){
	echo '<div class="form_header"> <img src="ok.png" /><s><b> '.__('Tablitsa yuklash').'</b></s></div><hr />';
}else{
echo '<div class="form_header"> <img src="wait.png" /> '.__('Tablitsa yuklash').'</div><hr />';
}

if ($ini[$step]['test8'] == 1){
	echo '<div class="form_header"> <img src="ok.png" /><s><b> '.__('SQLni yuklash').'</b></s></div><hr />';
}else{
echo '<div class="form_header"> <img src="wait.png" /> '.__('SQLni bazada mavjud shekilik').'</div><hr />';
}

if ($ini[$step]['test9'] == 1){
	echo '<div class="form_header"> <img src="ok.png" /><s><b> '.__('Wersiya holatini qabul qilish').'</b></s></div><hr />';
}else{
echo '<div class="form_header"> <img src="wait.png" /> '.__('Wersiya holatini qabul qilish').'</div><hr />';
}

if ($ini[$step]['test10'] == 1){
	echo '<div class="form_header"> <img src="ok.png" /><s><b> '.__('Wersiya manzildan olish').'</b></s></div><hr />';
}else{
echo '<div class="form_header"> <img src="wait.png" /> '.__('Wersiya manzildan olish').'</div><hr />';
}

if ($ini[$step]['test11'] == 1){
	echo '<div class="form_header"> <img src="ok.png" /><s><b> '.__('Ro`yhatdan o`tish').'</b></s></div><hr />';
}else{
echo '<div class="form_header"> <img src="wait.png" /> '.__('Ro`yhatdan o`tish').'</div><hr />';
}

if ($ini[$step]['test12'] == 1){
	echo '<div class="form_header"> <img src="ok.png" /><s><b> '.__('Saqlash').'</b></s></div><hr />';
}else{
echo '<div class="form_header"> <img src="wait.png" /> '.__('Saqlash').'</div><hr />';
}



echo '</td><th>';
echo "<form class='form_header' method='post' action='?" . passgen() . "'>";
echo "<input type='submit' name='to_start' value='" . __('Boshlash') . "' />";
echo "<input type='submit' name='refresh' value='" . __('Yangilash') . "' />";
echo "</form>";

if (!@include_once ('inc/' . $step . '.php'))
    die(__('xatolik bor inistalda %s', 'inc/' . $step . '.php'));
$inst_obj = new $step;

if (isset($_POST['next_step'])) {
    $install[$step]['status'] = $inst_obj->actions();

    header("Location: ./?" . passgen() . '&' . SID);
    exit;
}

echo "<form class='form_content' method='post' action='?" . passgen() . "'><div class='form_content'>";

$returned = $inst_obj->form();

echo "</div>";

if ($returned)
    echo "<input type='submit' name='next_step' value='" . __('Keyingisiga o`tish') . "' />";
else
    echo "<input type='submit' name='refresh' value='" . __('Yangilash') . "' />";
echo "</form></th></tr></table></center>";

include 'inc/foot.php';
?>
