<?php
include_once '../sys/inc/yadro.php';
$doc = new document_chat ();
$doc->title = __($uzcms->chat_tepa);
if ($user->id && !mysql_result(mysql_query("SELECT COUNT(*) FROM `chat_on` WHERE `id` = '" . my_esc($user->id) . "'"), 0)){
		 mysql_query("INSERT INTO `chat_on` (`id`, `time`) VALUES ('$user->id', '" . TIME . "')");
		 }else{
         mysql_query("UPDATE `chat_on` SET `time` = '" . TIME . "' WHERE `id` = '$user->id' LIMIT 1");
}
mysql_query("DELETE FROM `chat_on` WHERE `time` < '".(time()-300)."'");
	        if (!isset($_SESSION['message_time'])){
			$_SESSION['message_time'] = TIME;
			}
			$message = (string) $_POST['message'];
            $users_in_message = text::nickSearch($message);
            $message = text::input_text($message);
        
         if($user->ak == '3'){
		 $doc->err(__('Siz bloqlangansiz'));		  
	  }elseif($user->ak == '2'){
		 $doc->err(__('Sizning profilingiz aktivmas'));		  
	  }elseif (TIME <= $_SESSION['message_time']){
		 $doc->err(__('Haskerlik qilmang men elyorbek nickm qlassik_ru hammayoqni oldini olganman'));
	}elseif (mysql_result(mysql_query("SELECT COUNT(`id`) FROM `chat_mini` WHERE `id_user` = '".$user->id."' AND `time` > '".(time()-5)."' LIMIT 1"),0)!=0){
		 $doc->err(__('Haskerlik qilmang men elyorbek nickm qlassik_ru hammayoqni oldini olganman'));
	}elseif ($uzcms->censure && $mat = is_valid::mat($message)) {
            $doc->err(__('ZIT: %s', $mat));
        } elseif ($message) {
			
			
            
if (isset($_FILES ['file'] ['name'])){		
$chatniki_file_name = text::for_filename($_FILES ['file'] ['name']);
$chatnikis_path = FILES . '/.chat'; 
$chatnikis_dir = new files($chatnikis_path);
if (preg_match('/\\.(jpg|png|gif|jepg|JPG|PNG|GIF|JEPG)$/i', text::for_filename($_FILES ['file'] ['name']))) {
    if (!$img = @imagecreatefromjpeg($_FILES ['file'] ['tmp_name']) || !$img = @imagecreatefromgif($_FILES ['file'] ['tmp_name']) || !$img = @imagecreatefrompng($_FILES ['file'] ['tmp_name'])) {
        $doc->err(__('Rasim farmatda emas'));
    }elseif (!empty($_FILES ['file'])) {
    if ($_FILES ['file'] ['error']) {
        $doc->err(__('Yuklashda xatolik bor'));
    } elseif (!$_FILES ['file'] ['size']) {
        $doc->err(__('faylа yo`q'));
    } else {
        if ($chatnikis_dir->is_file($chatniki_file_name)) {
            $chatniki = new files_file($chatnikis_path, $chatniki_file_name);
            $chatniki->delete(); 
        }

        if ($files_ok = $chatnikis_dir->filesAdd(array($_FILES ['file'] ['tmp_name'] => $chatniki_file_name))) {
            $chatnikis_dir->group_show = 0;
            $files_ok [$_FILES ['file'] ['tmp_name']]->group_show = 0;
            $files_ok [$_FILES ['file'] ['tmp_name']]->id_user = $user->id;
            $files_ok [$_FILES ['file'] ['tmp_name']]->group_edit = max($user->group, 2);

            unset($files_ok);
        } else {
            $doc->err(__('Iloji yoq fayl saqlashga'));
        }
    }
}
}
}
 if (!$_FILES ['file'] ['error']) {
	$files = $chatniki_file_name;
}else{
	$files = '';	
}




            mysql_query("INSERT INTO `chat_mini` (`id_user`, `message`, `id_stt`, `file`, `time`) VALUES ('$user->id', '" . my_esc($message) . "', '".$id_stt. "', '" . my_esc($files) . "', '" . TIME . "')");
			 $user->chatga = '';			
             $user->balls++;
            if (isset($_POST['message'])){
			$_SESSION['message_time'] = TIME + 5;
			}
		}


?>
<style>
.ui-notify { width:400px; position:fixed; top:10px; right:10px; z-index: 999; }
.ui-notify-message { padding:10px; margin-bottom:15px; -moz-border-radius:8px; -webkit-border-radius:8px; border-radius:8px }
.ui-notify-message h1 { font-size:14px; margin:0; padding:0 }
.ui-notify-message p { margin:3px 0; padding:0; line-height:18px }
.ui-notify-message a { color:#87CEFF; }
.ui-notify-message:last-child { margin-bottom:0 }
.ui-notify-message-style { background:#000; background:rgba(0,0,0,0.8); -moz-box-shadow: 0 0 6px #000; -webkit-box-shadow: 0 0 6px #000; box-shadow: 0 0 6px #000; }
.ui-notify-message-style h1 { color:#EEE9E9; font-weight:bold }
.ui-notify-message-style p { color:#EEE9E9 }
.ui-notify-close { color:#fff; text-decoration:underline }
.ui-notify-click { cursor:pointer }
.ui-notify-cross { margin-top:-4px; float:right; cursor:pointer; text-decoration:none; font-size:12px; font-weight:bold; text-shadow:0 1px 1px #fff; padding:2px }
.ui-notify-cross:hover { color:#ffffab }
.ui-notify-cross:active { position:relative; top:1px }
.ui-notify_close { width:18px; height:18px; background: url(../front_end/close.png) no-repeat;}
.ui-notify_close:hover {background-position:0px -18px;}
@font-face {
	font-family: bloggersans;
	src: url(/img/bloggersans.ttf);
}
.emoji_tt_wrap:after {
    border-width: 5px;
    margin: 0 -5px;
    border-top-color: #ebeef2;
    -webkit-transform: translate3d(0, -0.5px, 0);
    transform: translate3d(0, -0.5px, 0);
}
.fc_msgs_unread {
    background-color: #e6ecf2;
}
.chat_onl_wrap {
	font-family: bloggersans;
	display: block;
	position: fixed;
	bottom: 0;
	right: 10px;
    width:50px
	text-align: center;
	z-index: 1500;
}
.chat_onl_inner {
	position: relative;
	background-color: #dae1e8;
	border-radius: 3px 3px 0 0;
	overflow: hidden;
}
.chat_cont_scrolling {
	position: relative;
}
.chat_tab_wrap {
	display: block;
	position: relative;
	overflow: hidden;
	cursor: pointer;
	width: 40px;
	padding: 6px;
}
.chat_tab_imgcont {
	position: relative;
	height: 40px;
	width: 40px;
	-o-transition: height 100ms ease-in-out, opacity 100ms ease-in-out;
	transition: height 100ms ease-in-out, opacity 100ms ease-in-out;
}
.chat_tab_close {
	position: absolute;
	top: 0;
	right: 0;
	width: 14px;
	height: 14px;
	border-radius: 50%;
	background-color: rgba(0,0,0,.65);
	opacity: 0;
	filter: alpha(opacity=0);
}
.chat_tab_img {
	width: 40px;
	height: 40px;
	border-radius: 50%;
	vertical-align: middle;
}
.chat_tab_close:after {
	display: block;
	content: ' ';
	width: 14px;
	height: 14px;
	background: url(/img/chats.png) no-repeat 3px -43px;
	opacity: 0.7;
	filter: alpha(opacity=70);
}
.chat_tab_imgcont.onlinedeas:after {
	border-color: #dae1e8;
	background-color: #62b245;
}
.chat_tab_imgcont.onlinedeas:after {
	bottom: 0;
	right: 0;
	border: 2px solid #fff;
	height: 7px;
	width: 7px;
}
.chat_tab_counter {
	position: absolute;
	top: 6px;
	left: 6px;
	height: 13px;
	min-width: 9px;
	border-radius: 8px;
	padding: 2px 4px;
	background-color: #e63917;
	color: #fff;
	font-weight: 600;
	-webkit-font-smoothing: subpixel-antialiased;
	-moz-osx-font-smoothing: auto;
	font-size: 11px;
}
.chat_tab_wrap {
	display: block;
	position: relative;
	overflow: hidden;
	cursor: pointer;
	width: 45px;
	padding: 6px;
    text-decoration: none;
	text-align: center;
}
.chat_onl_height
{
    width:50px;
}
.chat_tab_wrap:hover
{
	text-decoration: none;
}
.chat_onl_cont {
	padding: 6px 0;
}
.chat_onl {
	color: #7993ad;
	font-size: 11px;
	font-weight: 700;
	-webkit-font-smoothing: antialiased;
	-moz-osx-font-smoothing: grayscale;
	height: 14px;
	line-height: 14px;
}
.chat_onl:after {
    display: inline-block;
    content: ' ';
    width: 9px;
    height: 11px;
    background: url(/img/chats.png) no-repeat 0 -116px;
    margin-bottom: -1px;
    margin-left: 4px;
}
.ui-wrapper
{
	padding-bottom:0!important;
	width:auto!important;
}
/* -------------------------------------------------------------------------------------------------------------------------------------- */
/* Окно поиска */
.fc_tab_wrap {
	font-family: bloggersans;
	box-shadow: 0 1px 3px 0 rgba(0,0,0,.1);
	border-radius: 3px;
	font-size: 12px;
	width: 270px;
	position: fixed;
	height: 355px;
	min-width:270px;
	bottom: 25px;
	left: 10px;
	text-align: center;
	z-index: 1500;
}
.fc_tab_wraps {
	font-family: bloggersans;
	box-shadow: 0 1px 3px 0 rgba(0,0,0,.1);
	border-radius: 3px;
	font-size: 12px;
	width: 270px;
	position: fixed;
	height: 355px;
	min-width:270px;
	bottom: 25px;
	right: 80px;
	text-align: center;
	z-index: 1500;
}
.fc_tab_head {
	cursor: move;
	background-color: #6287ae;
	border: 1px solid #597da3;
	border-radius: 3px 3px 0 0;
	padding: 0 7px 0 8px;
}
.fc_tab_close_wrap, .fc_tab_max_wrap, .fc_tab_pin_wrap {
	display: block;
	float: right;
	padding: 4px;
	margin-top: 5px;
	visibility: visible;
	cursor: pointer;
	width: 15px;
}
.fc_tab_wrap .fc_tab_close {
	background-position: 2px -31px;
	height : 15px;
    width: 15px;
}
.fc_tab_wraps .fc_tab_close {
	background-position: 2px -31px;
	height : 15px;
    width: 15px;
}
.chats_sp {
	background: url(/img/chats.png) no-repeat;
}
.fc_tab_title {
	padding: 0 3px;
	text-align: left;
	font-size: 12px;
	font-weight: 700;
	-webkit-font-smoothing: antialiased;
	-moz-osx-font-smoothing: grayscale;
	color: #fff;
	height: 30px;
	line-height: 30px;
	overflow: hidden;
	white-space: nowrap;
	text-overflow: ellipsis;
}
.noselect {
	-webkit-user-select: none;
	-moz-user-select: none;
	-ms-user-select: none;
	user-select: none;
}
#fc_ctabs_cont {
	border: 1px solid #c5d0db;
	border-top: none;
	border-radius: 0 0 3px 3px;
}
.fc_tobottom #fc_ctabs_cont {
	border-bottom: none;
	border-radius: 0;
}
#fc_contacts, .fc_content {
	overflow: auto;
	overflow-x: hidden;
	overflow-y: auto;
	background: #fff;
}
.fc_contact {
	display: block;
	padding: 8px;
	white-space: nowrap;
	overflow: hidden;
}
span.fc_contact_photo {
	float: left;
	display: block;
	position: relative;
	height: 34px;
	width: 34px;
}
img.fc_contact_photo {
	width: 34px;
	height: 34px;
	border-radius: 50%;
}
span.fc_contact_photo.onlinedeas:after {
	bottom: 0;
	right: 0;
	border: 2px solid #fff;
	height: 6px;
	width: 6px;
}
.fc_contact_name {
	line-height: 34px;
	padding-left: 9px;
	white-space: nowrap;
	display: block;
	text-overflow: ellipsis;
	overflow: hidden;
	text-align: left;
	font-weight: 700;
	-webkit-font-smoothing: antialiased;
	-moz-osx-font-smoothing: grayscale;
	color: #42648b;
}
.clear_fix:after {
	content: '.';
	display: block;
	height: 0;
	font-size: 0;
	line-height: 0;
	clear: both;
	visibility: hidden;
}
div.fc_clist_filter_wrap {
	cursor: text;
	padding: 0px 8px 0px;
	border-top: 1px solid #dbe4ec;
	background: #fff;
	border-radius: 0 0 3px 3px;
}
.chats_sp.fc_clist_search_icon {
	float: left;
	background-position: 0 -100px;
	height: 12px;
	width: 12px;
	margin: 10px 0 0 5px;
}
div.fc_clist_filter {
	overflow: hidden;
	font-size: 12px;
}
#fc_clist_filter {
	width: 100%;
	outline: none;
}
#fc_clist_filter, #fc_clist_filter~.placeholder .ph_input {
	border: 0;
	padding: 0px 7px 0px;
	font-size: 12px;
}

/* Окно чата */
.fc_msgs_date {
	color: #939699;
	font-size: 11px;
	padding: 4px 0 6px;
	opacity: 0.8;
	filter: alpha(opacity=80);
	text-align: center;
}
.fc_msgs_wrap {
	padding: 4px 12px 4px 8px;
	position: relative;
}
div.fc_msgs_author {
	display: table-cell;
	vertical-align: bottom;
}
a.fc_msgs_img {
	display: block;
	width: 35px;
	height: 35px;
	border-radius: 50%;
	background-size: cover;
	margin-right: 5px;
}
.fc_msgs {
	display: table-cell;
	vertical-align: bottom;
	background-color: #fff;
	border: 1px solid #e1e4e8;
	padding: 4px 4px 3px;
	border-radius: 6px;
	box-sizing: border-box;
	max-width: 320px;
	overflow: hidden;
}
.fc_msg:first-child {
	padding-top: 0;
}
.fc_msg {
	padding: 4px 4px 2px;
	line-height: 17px;
}
.fc_msgs_out_inner {
	float: right;
}
.fc_tab_typing {
	color: #939699;
	opacity: 0;
	filter: alpha(opacity=0);
	min-height: 1.2em;
	max-height: 2.4em;
	line-height: 120%;
	padding: 3px 4px 7px 39px;
	vertical-align: middle;
}
.fc_tab_typing_icon {
	display: block;
	float: left;
	width: 4px;
	height: 4px;
	border-radius: 50%;
	top: 50%;
	margin: 5px 0 0 -27px;
	background: hsla(210,2%,67%,.5);
	-webkit-animation: 1.1s linear 0s infinite fc-typer;
	-o-animation: 1.1s linear 0s infinite fc-typer;
	animation: 1.1s linear 0s infinite fc-typer;
}
.clear {
	float: none;
	clear: both;
}
.fc_tab {
    border: 1px solid #c5d0db;
    border-top: none;
    border-radius: 0 0 3px 3px;
    background-color: #f3f5f7;
}
.fc_fixed .fc_tab, .fc_tobottom .fc_tab {
    border-bottom: none;
    border-radius: 0;
}
.fc_tab_log
{
	position:relative;
}
.fc_tab_log_wrap {
    overflow: hidden;
}
div.fc_editable, div.fc_editable~.placeholder .ph_input {
    padding-right: 22px;
    border: 0;
}
div.fc_tab_txt {
    background: #fff;
    padding: 6px 3px 0 0px;
    border-top: 1px solid #dbe4ec;
}
div.fc_editable, div.fc_editable~.placeholder .ph_input {
    padding-right: 22px;
    border: 0;
}
div.fc_editable {
    min-height: 28px;
    overflow-x: hidden;
    font-size: 12px;
    line-height: 140%;
    word-wrap: break-word;
}
.placeholder {
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    position: absolute;
	top:0;
    z-index: 999999999;
    cursor: text;
    pointer-events: none;
}
.ph_input
{
	border:none!important;
}
.fakeinput.dark, .fakeinput.dark~.placeholder .ph_input, div[contenteditable=true], div[contenteditable=true]~.placeholder .ph_input, input.dark, input.dark~.placeholder .ph_input, textarea.dark, textarea.dark~.placeholder .ph_input {
    padding: 5px 9px 7px;
    border-radius: 1px;
    box-sizing: border-box;
}
.fakeinput~.placeholder .ph_content, div[contenteditable=true]~.placeholder .ph_content, input.big_text~.placeholder .ph_content, input.dark~.placeholder .ph_content, input.search~.placeholder .ph_content, input.text~.placeholder .ph_content, textarea~.placeholder .ph_content {
    color: #7c7f82;
    -o-transition: color 0.2s ease;
    transition: color 0.2s ease;
    padding: 1px;
    opacity: 1;
    -webkit-filter: none;
    filter: none;
}
.fakeinput, .fakeinput~.placeholder .ph_input, div[contenteditable=true], div[contenteditable=true]~.placeholder .ph_input, input.big_text, input.big_text~.placeholder .ph_input, input.dark, input.dark~.placeholder .ph_input, input.search, input.search~.placeholder .ph_input, input.text, input.text~.placeholder .ph_input, textarea, textarea~.placeholder .ph_input {
    color: #000;
    padding: 3px 5px;
    margin: 0;
    border: 1px solid #d3d9de;
}
.fakeinput, div[contenteditable=true], input.big_text, input.dark, input.search, input.text, textarea {
    background: #fff;
    -webkit-appearance: none;
    border-radius: 0;
	text-align: left;
    border: none;
    overflow-y: auto;
    max-height: 60px;
    padding: 5px 30px 5px 5px;
    outline: none;
}
.emoji_cont {
    position: relative;
}
.fc_tab_txt .emoji_smile_wrap {
    margin: 0 2px 0 0;
}
.emoji_smile {
    position: absolute;
    cursor: pointer;
    top: 0;
    right: 0;
    z-index: 1;
}
.emoji_smile_wrap {
    position: absolute;
    top: 0;
    right: 0;
}
textarea.messinput
{
	width: 98%; 
	padding: 5px 30px 5px 5px; 
	max-width:98%; 
	min-width:98%; 
	box-sizing: border-box; 
	max-height:50px; 
	min-height:36px; 
	border: none; 
}
div[class*=scroller_] {outline:none;height:100%;}

/* OTHER */
.fc_tab_notify {
    background-color: #fff;
    left: 1px;
    right: 1px;
    padding: 6px;
    text-align: center;
    border-bottom: 1px solid #dbe4ec;
    z-index:1;
}
.emoji, .emoji_css {
    width: 16px;
    height: 16px;
    border: none;
    vertical-align: -3px;
    margin: 0 1px;
}
.emoji_smile_icon {
    width: 25px;
    height: 25px;
	position: absolute;
    float: right;
    z-index: 999999999999;
    right: 15px;
    background: url(/img/smile_icon.png) no-repeat 4px 4px;
}
.emoji_tt_wrap {
    width: 290px;
    opacity: 0;
    filter: alpha(opacity=0);
    z-index: 119;
    right: -4px;
	height:125px;
	overflow:hidden;
    bottom: 0px;
    box-shadow: 0 1px 3px rgba(0,0,0,.1);
    background-color: #fff;
    border: 1px solid #c5d0db;
    position: absolute;
}
.emoji_block_cont {
    overflow: hidden;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
}
.emoji_block_rel {
    position: relative;
}
.emoji_list_cont {
    padding: 2px 4px;
}
.emoji_list {
    overflow: hidden;
    height: 242px;
    position: relative;
    width: 275px;
}
.emoji_scroll {
    padding: 2px 0px;
    cursor: pointer;
}
.emoji_smile_cont {
    display: inline-block;
    position: relative;
    padding: 5px 4px;
    margin-right: 1px;
    cursor: pointer;
    z-index: 10;
}

.emoji_tt_wrap.tt_down:after, .emoji_tt_wrap.tt_down:before {
    right: 16px;
}
.noneshow
{
	display : none;
}
.onlinedeas:after {
    content: '';
    position: absolute;
    background-color: #8ac176;
    border-radius: 50%;
}
.chat_tab_imgcont.onlinedeas:after {
    bottom: 0;
    right: 0;
    border: 2px solid #fff;
    height: 7px;
    width: 7px;
}
.chat_tab_imgcont.onlinedeas:after {
    border-color: #dae1e8;
    background-color: #62b245;
}
.chat_tab_wrap:hover .chat_tab_imgcont.onlinedeas:after {
    border-color: #ccd5de;
}

</style>















<?

echo'<br />';
$q = mysql_query("SELECT * FROM `chat_mini`");
while ($md = mysql_fetch_assoc($q)) {
$ank = new user($md['id_user']);
$stt = new user($md['id_stt']);
if($user->id == $ank->id){
echo'<div class="fc_msgs_wrap fc_msgs_out messageeasybox">
		<div class="fc_msgs_out_inner">
			<div class="fc_msgs">
				<div class="fc_msg wrapped fc_msg_last">';
				
				if($md['file']){
					echo'<img  class="fc_msgs_img" style="margin: 4px; width: 100%; border-radius: 18px;" src="/files/.chat/'.$md['file'].'" title="voo.uz" /><hr />';
				}
			 echo''.$md['message'].' </div>
			</div>
		</div>
		<br class="clear">
	</div>';	
}else{
echo'	<div class="fc_msgs_wrap messageeasybox ">
		<div class="fc_msgs_author">
			<img  class="fc_msgs_img" style="margin: 4px; width: 35px; height: 35px; border-radius: 18px;" src="'.$ank->getAva().'" title="voo.uz" />
		</div>
		<div class="fc_msgs">
			<div class="fc_msg wrapped">';
			if($md['file']){
					echo'<img  class="fc_msgs_img" style="margin: 4px; width: 100%; border-radius: 18px;" src="/files/.chat/'.$md['file'].'" title="voo.uz" /><hr />';
				}
			echo''.$md['message'].' </div>
		</div>
	</div>';	
}

}

?>