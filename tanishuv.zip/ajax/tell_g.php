<?
include '../sys/inc/yadro.php';
$ank = (empty($_SESSION ['qongiroq'])) ? $user : new user((int)$_SESSION ['qongiroq']);
?>
<style>
.arr img {
	vertical-align: top;
}
.arr a {
	color:#fff;
}
</style>

<div class="alert alert-fkk hidden-sm hidden-xs">
									<button type="button" class="close" data-dismiss="alert">
										<i class="ace-icon fa fa-times"></i>
									</button>
								<?=__('Hozir ovozli habar jo`natish tamirlanyapti keyinroq urunib ko`ring')?>.
								</div>

								<div class="alert alert-fkk hidden-md hidden-lg">
									<button type="button" class="close" data-dismiss="alert">
										<i class="ace-icon fa fa-times"></i>
									</button>
								<?=__('Hozir ovozli habar jo`natish  tamirlanyapti keyinroq urunib ko`ring')?>.
								
								</div><div class="chiziq_t"></div>
<script type="text/javascript">
    window.onload = function() {
        new Audio('/files/yuklanmalar/.tell/xato.ogg').play();
    };
  </script><audio autoplay="autoplay">
  <source src="/files/yuklanmalar/.tell/xato.mp3" type="audio/mpeg">
  <source src="/files/yuklanmalar/.tell/xato.ogg" type="audio/ogg; codecs=vorbis">
  <source src="/files/yuklanmalar/.tell/xato.wav" type="audio/wav; codecs=vorbis">
	</audio>
	<?

exit;
?>