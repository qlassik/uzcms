<?
include '../sys/inc/yadro.php';
$ank = (empty($_SESSION ['qongiroq'])) ? $user : new user((int)$_SESSION ['qongiroq']);
?>
<style>
.arr img {
	vertical-align: top;
}
.arr a {
	color:#fff;
}
</style>

<div class="alert alert-fkk hidden-sm hidden-xs">
									<button type="button" class="close" data-dismiss="alert">
										<i class="ace-icon fa fa-times"></i>
									</button>
								<?
								if (mysql_result(mysql_query("SELECT COUNT(*) FROM `tell_b` WHERE `id_user` = '".$user->id."' AND `ank` = '".$_GET['bloq']."'"), 0)){
                                  echo __('Bu abanet bloq holatida'); 
								   }else{
                                  echo __('Abanet bloqlanmagan'); 

								   }?></div>

								<div class="alert alert-fkk hidden-md hidden-lg">
									<button type="button" class="close" data-dismiss="alert">
										<i class="ace-icon fa fa-times"></i>
									</button>
<?
								if (mysql_result(mysql_query("SELECT COUNT(*) FROM `tell_b` WHERE `id_user` = '".$user->id."' AND `ank` = '".$_GET['bloq']."'"), 0)){
                                  echo __('Bu abanet bloq holatida'); 
								   }else{
                                  echo __('Abanet bloqlanmagan'); 
								   }?>
								</div><div class="chiziq_t"></div>
  <?if ($ank->golos_zaynt()){?>
  <script type="text/javascript">
    window.onload = function() {
        new Audio('<?=$ank->golos_zaynt()?>').play();
    };
  </script><audio autoplay="autoplay">
  <source src="<?=$ank->golos_zaynt()?>" type="audio/mpeg">
  <source src="<?=$ank->golos_zaynt()?>" type="audio/ogg; codecs=vorbis">
  <source src="<?=$ank->golos_zaynt()?>" type="audio/wav; codecs=vorbis">
	</audio>	  
<?}else{?>
  <script type="text/javascript">
    window.onload = function() {
        new Audio('/files/yuklanmalar/.tell/zaynt.mp3').play();
    };
  </script><audio autoplay="autoplay">
  <source src="/files/yuklanmalar/.tell/zaynt.mp3" type="audio/mpeg">
  <source src="/files/yuklanmalar/.tell/zaynt.ogg" type="audio/ogg; codecs=vorbis">
  <source src="/files/yuklanmalar/.tell/zaynt.wav" type="audio/wav; codecs=vorbis">
	</audio><?
}
exit;
?>