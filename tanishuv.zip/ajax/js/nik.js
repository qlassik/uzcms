var Kisni="abcdefghijklmnopqrstuvwxyz?.<>"
var lucky="αв¢đєƒgнιĵкĻмησρqяѕтυνωχуz?.«» "


function change(_in, _out)
{
  var kisnisite="";
  var kisnilover=_in.value.toLowerCase();

 
  for(i=0; i<kisnilover.length; i++)
  {
    var banjarwap=kisnilover.charAt(i);
    for(j=0; (j<Kisni.length)&&(banjarwap!=Kisni.charAt(j)); j++);
    if (j<Kisni.length) { 
      kisnisite+=lucky.charAt(j);} else {
      kisnisite+=banjarwap;
    }
  }

  _out.value=kisnisite;

}

function focusFirst() {

  if (els = oTD.getElementsByTagName("input")) {
    els[0].focus();
  }
}

function highlight(field) {
field.focus();
  field.select();
}

document.write("<form name=\".\"><textarea class=\"ana\" name=\"textin\" rows=\"4\" cols=\"12\">VOO uz</textarea><br><input name=\"button\" type=\"button\" onclick=\"change(textin, message);\" value=\"O`zgartirish\"><br><br><textarea name=\"message\" rows=\"4\" cols=\"12\"></textarea>");
