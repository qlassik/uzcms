function ready(f){
    UZCMS.Event.on('ready', f);
}

if ( document.addEventListener ) {
   
    document.addEventListener( "DOMContentLoaded", function(){
        document.removeEventListener( "DOMContentLoaded", arguments.callee, false );
        UZCMS.Event.trigger('ready');
    }, false );


} else if ( document.attachEvent ) {

    document.attachEvent("onreadystatechange", function(){
        if ( document.readyState === "complete" ) {
            document.detachEvent( "onreadystatechange", arguments.callee );
            UZCMS.Event.trigger('ready');
        }
    });
}else{
    window.onload = function(){
        UZCMS.Event.trigger('ready');
    } 
}

UZCMS.listing_update = function(url, ids, callback, callback_err){
    UZCMS.Ajax({
        url: url,
        post:'skip_ids='+ids.join(','),
        callback: callback,
        error: callback_err
    });
};