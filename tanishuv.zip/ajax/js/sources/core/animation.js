
UZCMS.Animation = {
   
    };

    UZCMS.Animation._AnimatingNodes = [];
    UZCMS.Animation._AnimatingProperties = [];
    UZCMS.Animation._AnimatingAnimates = [];

    UZCMS.Animation.addToList = function(dom, property, animate){
        UZCMS.Animation._AnimatingNodes.push(dom);
        UZCMS.Animation._AnimatingProperties.push(property);
        UZCMS.Animation._AnimatingAnimates.push(animate);
    };
    
    UZCMS.Animation.deleteFromlist = function(index){
        UZCMS.Animation._AnimatingNodes.splice(index, 1);
        UZCMS.Animation._AnimatingProperties.splice(index, 1);
        UZCMS.Animation._AnimatingAnimates.splice(index, 1);
    };
    
    UZCMS.Animation.getIndexByProp = function(dom, property){
        for (var i = 0 ; i < UZCMS.Animation._AnimatingNodes.length; i++){            
            if (UZCMS.Animation._AnimatingNodes[i] == dom && UZCMS.Animation._AnimatingProperties[i] == property)
                return i;
        }
        return -1;
    };

    UZCMS.Animation.stop = function(dom, property, to_end_step){    
        var index = UZCMS.Animation.getIndexByProp(dom, property);    
        if (~index){
            // console.log('stop', dom, property);
            UZCMS.Animation._AnimatingAnimates[index].End(!!to_end_step);
            UZCMS.Animation.deleteFromlist(index);
        }    
    };

    UZCMS.Animation.colorStep = function(color1, color2, step){    
        if (!(color1 instanceof RGBColor))
            color1 = new RGBColor(color1);
        
        if (!(color2 instanceof RGBColor))
            color2 = new RGBColor(color2);
        
        var r =  parseInt(color1.r + (color2.r - color1.r) * step);
        var g =  parseInt(color1.g + (color2.g - color1.g) * step);
        var b =  parseInt(color1.b + (color2.b - color1.b) * step);
        
        if (color1.a == 0){
            r =  color2.r;
            g =  color2.g;
            b =  color2.b;
        }
        
        if (color2.a == 0){
            r =  color1.r;
            g =  color1.g;
            b =  color1.b;
        }
        
        var a =  parseFloat(color1.a + (color2.a - color1.a) * step);
        
        return new RGBColor('rgba(' + r + ', ' + g + ',' + b +',' + a +')');
    };

    
    UZCMS.Animation.style = function(dom, property, value, duration, callbackEnd){
        if (!dom || !dom.style)
            return false;
       
        UZCMS.Animation.stop(dom, property);
    
        if (!UZCMS.isNumber(duration))
            duration = UZCMS.StyleAnimationDuration;
        if (duration > 0 && duration < 30) // считаем, что задано в секундах
            duration *= 1000;
        
        property = property.toCamel();
    
        var styleStart, styleEnd;
        if (UZCMS.isArray(value) && value.length == 2){
            styleStart = UZCMS.Dom.parseStyle(value[0] === '' ? UZCMS.Dom.getComputedValue(dom, property) : value[0]);
            styleEnd = UZCMS.Dom.parseStyle(value[1] === '' ? UZCMS.Dom.getDefaultValue(dom, property): value[1]); 
            value = value[1];
        }else{
            styleStart = UZCMS.Dom.parseStyle(UZCMS.Dom.getComputedValue(dom, property));
            styleEnd = UZCMS.Dom.parseStyle(value === '' ? UZCMS.Dom.getDefaultValue(dom, property): value);            
        }
    
        if (styleEnd.units == '%')
            styleEnd = UZCMS.Dom.parseStyle(UZCMS.Dom.getProbeValue(dom, property, styleEnd.value + styleEnd.units));
    
        if (styleStart.value && styleStart.units && styleEnd.units && styleStart.units != styleEnd.units)
            return false;
    
        var units =  styleEnd.units || styleStart.units;    
        
        var colorEnd = new RGBColor(styleEnd.value);
        var colorStart = new RGBColor(styleStart.value);            
    
        var callback = function(step){
           
            if (colorEnd.ok){
                dom.style[property] = UZCMS.Animation.colorStep(colorStart, colorEnd, step);
            
			}else if (UZCMS.isNumber(styleEnd.value)){
                dom.style[property] = parseFloat(styleStart.value + (styleEnd.value - styleStart.value) * step).toFixed(2) + units; 
            } else{
                step = 1;
            }
                        
            if (step == 1){
                dom.style[property] = value;
                
                UZCMS.Animation.stop(dom, property);
                if (UZCMS.isFunction(callbackEnd))
                    callbackEnd.call(dom);
            }                            
        }
    
        if (UZCMS.StyleAnimation && duration)
            UZCMS.Animation.addToList(dom, property, new UZCMS.Animate(duration, callback));
        else
            callback(1);
    
        return true;
    };