<?php
include '../sys/inc/yadro.php';
header('Content-type: application/json');

echo json_encode(languages::getList());