<?
include '../sys/inc/yadro.php';
session_start();
$_SESSION ['bolimlarga'] = 'prekt';
