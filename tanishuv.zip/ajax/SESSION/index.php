<?
include_once '../../sys/inc/yadro.php';
$doc = new document_json();
echo'<div style="margin: 0;     padding: 10px;
    background: #fbfcfd;
    border: 1px solid #f1f1f1;" >
            	<div class="col-xs-13">
								<div>
									<ul class="ace-thumbnails clearfix">';	
$listing = new listing();
$pages = new pages(mysql_result(mysql_query("SELECT COUNT(*) FROM `magazin_file`"), 0));
$q = mysql_query("SELECT * FROM `magazin_file` WHERE `id` ORDER BY `time_add` DESC LIMIT ".$pages->limit);
while ($magaz = @mysql_fetch_assoc($q)) {
$ank = new user($magaz['id_user']);
$magazin = $listing->magazin();
$dd = $magaz['blok'];
if ($dd == 1){
$magazin->image = '/img/bloq.png';
$magazin->time = misc::when($magaz['time_add']);
$magazin->title = __('Tavar blo`qlangan');
$magazin->admine = '&nbsp;&nbsp;<b><span style="color:red">'.text::toOutput($magaz['sum']).'</span> '.__('sum').'</b>';	
$magazin->mehmon = text::toOutput($magaz['saq']);
}else{
$magazin->image = $magaz['url_img'];
$magazin->url = '/magazin/file.php?id=' . $ank->id . '&amp;yuklemi=' . $magaz['path_file_rell'].'&amp;yolga=' . $magaz['path_file_rel'].'';
$magazin->admine = misc::when($magaz['time_add']);
$magazin->title = text::toOutput($magaz['runame']);	
$magazin->time = '&nbsp;&nbsp;<b><span style="color:red">'.text::toOutput($magaz['sum']).'</span> '.__('sum').'</b>';	
$magazin->mehmon = text::toOutput($magaz['saq']);
 
}
	}

$listing->display(__('Maydon bo`sh'));	


echo'</ul>
								</div>
							</div>
						</div>	';