<?
include_once '../../sys/inc/yadro.php';
$doc = new document_json();
echo $_POST['matn'];
?>