 <style>
			@media (max-width:578px) and (min-width:100px) {
	       .cdubfkbd {
	    width: 350px;
		height: 210px;
      } 
			}
					@media (max-width:878px) and (min-width:578px) {
	       .cdubfkbd {
	    width: 500px;
		height: 300px;
      } 	  
					}
							@media (max-width:3278px) and (min-width:878px) {

	       .cdubfkbd {
	    width: 720px;
		height: 360px;
      } 
							}
    </style><center style="margin: 5px;">
   <? $dd = '/files/yuklanmalar/.sts/_PHP_Pishem_svoj_dvizhok_2_0__Podt.mp4';?>
<video id="myVideo"  class="cdubfkbd" controls loop">
 <source src="<?=$dd?>" type="video/mp4">
 <?=__('Sizni bravzeringiz html 5 ni padderjit qila olmayapti')?>
</video>	</center>	
<script>
var vid = document.getElementById("myVideo");
function enableAutoplay() { 
    vid.autoplay = true;
    vid.load();
}

function disableAutoplay() { 
    vid.autoplay = false;
    vid.load();
} 

function checkAutoplay() { 
    alert(vid.autoplay);
} 
</script> 
<script>
document.addEventListener("visibilitychange", onchange);
function onchange (evt) {
   document.getElementById("myVideo").pause();
}
</script> 
<script>
window.addEventListener("visibilitychange", onchange);
function onchange (evt) {
    document.getElementByID("myVideo").onfocus = play();
}
</script><?