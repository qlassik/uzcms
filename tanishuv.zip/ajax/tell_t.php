<?
include '../sys/inc/yadro.php';
$ank = (empty($_SESSION ['qongiroq'])) ? $user : new user((int)$_SESSION ['qongiroq']);
?>
<style>
.arr img {
	vertical-align: top;
}
.arr a {
	color:#fff;
}
</style>


<?
if ($_SESSION['id_'.$ank->id.'_id'] == 'id_'.$ank->id.'_idy'){
?><div class="alert alert-fkk hidden-sm hidden-xs">
									<button type="button" class="close" data-dismiss="alert">
										<i class="ace-icon fa fa-times"></i>
									</button>
								<?=__('Chaqiryapti')?>.
								</div>

								<div class="alert alert-fkk hidden-md hidden-lg">
									<button type="button" class="close" data-dismiss="alert">
										<i class="ace-icon fa fa-times"></i>
									</button>
								<?=__('Chaqiryapti')?>.
								
</div><div class="chiziq_t"></div>	
<?
if ($ank->golos_chaqiruv()){
	if (mysql_result(mysql_query("SELECT COUNT(*) FROM `tell` WHERE `id_user` = '".$ank->id."' AND `ank` = '".$user->id."' AND `ko` = '2'"), 0)){
mysql_query("UPDATE `tell` SET `qildi` = `qildi` + '1' WHERE `id_user` = '".$ank->id."' AND `ank` = '".$user->id."' AND `ko` = '2' LIMIT 1");
}else{               	
mysql_query("INSERT INTO `tell` (`id_user`, `ank`, `qildi`, `ko`, `time`) VALUES ('".$ank->id."', '".$user->id."', '1', '2', '". TIME ."')");

}
?><script type="text/javascript">
    window.onload = function() {
        new Audio('<?=$ank->golos_chaqiruv()?>').play();
    };
  </script><audio autoplay="autoplay">
  <source src="<?=$ank->golos_chaqiruv()?>" type="audio/mpeg">
  <source src="<?=$ank->golos_chaqiruv()?>" type="audio/ogg; codecs=vorbis">
  <source src="<?=$ank->golos_chaqiruv()?>" type="audio/wav; codecs=vorbis">
	</audio><?

}else{
	if (mysql_result(mysql_query("SELECT COUNT(*) FROM `tell` WHERE `id_user` = '".$ank->id."' AND `ank` = '".$user->id."' AND `ko` = '2'"), 0)){
mysql_query("UPDATE `tell` SET `qildi` = `qildi` + '1' WHERE `id_user` = '".$ank->id."' AND `ank` = '".$user->id."' AND `ko` = '2' LIMIT 1");
}else{               	
mysql_query("INSERT INTO `tell` (`id_user`, `ank`, `qildi`, `ko`, `time`) VALUES ('".$ank->id."', '".$user->id."', '1', '2', '". TIME ."')");

}
?>


<script type="text/javascript">
    window.onload = function() {
        new Audio('/files/yuklanmalar/.tell/tut.ogg').play();
    };
  </script><audio autoplay="autoplay">
  <source src="/files/yuklanmalar/.tell/tut.mp3" type="audio/mpeg">
  <source src="/files/yuklanmalar/.tell/tut.ogg" type="audio/ogg; codecs=vorbis">
  <source src="/files/yuklanmalar/.tell/tut.wav" type="audio/wav; codecs=vorbis">
	</audio>
	<?
}
	}else{	
?><div class="alert alert-fkk hidden-sm hidden-xs">
									<button type="button" class="close" data-dismiss="alert">
										<i class="ace-icon fa fa-times"></i>
									</button>
								<?=__('O`chiq ekan')?>.
								</div>

								<div class="alert alert-fkk hidden-md hidden-lg">
									<button type="button" class="close" data-dismiss="alert">
										<i class="ace-icon fa fa-times"></i>
									</button>
								<?=__('O`chiq ekan')?>.
								
</div><div class="chiziq_t"></div>	
<?
if ($ank->ochigu){
	if (mysql_result(mysql_query("SELECT COUNT(*) FROM `tell` WHERE `id_user` = '".$ank->id."' AND `ank` = '".$user->id."' AND `ko` = '3'"), 0)){
mysql_query("UPDATE `tell` SET `qildi` = `qildi` + '1' WHERE `id_user` = '".$ank->id."' AND `ank` = '".$user->id."' AND `ko` = '3' LIMIT 1");
}else{               	
mysql_query("INSERT INTO `tell` (`id_user`, `ank`, `qildi`, `ko`, `time`) VALUES ('".$ank->id."', '".$user->id."', '1', '3', '". TIME ."')");

}
?>
<script type="text/javascript">
    window.onload = function() {
        new Audio('/files/yuklanmalar/.tell/<?=$user->login;?>_tut.ogg').play();
    };
  </script><audio autoplay="autoplay">
  <source src="<?=$ank->golos_o()?>" type="audio/mpeg">
  <source src="<?=$ank->golos_o()?>" type="audio/ogg; codecs=vorbis">
  <source src="<?=$ank->golos_o()?>" type="audio/wav; codecs=vorbis">
	</audio><?}else{?>
<script type="text/javascript">
    window.onload = function() {
        new Audio('/files/yuklanmalar/.tell/och.ogg').play();
    };
  </script><audio autoplay="autoplay">
  <source src="/files/yuklanmalar/.tell/och.mp3" type="audio/mpeg">
  <source src="/files/yuklanmalar/.tell/och.ogg" type="audio/ogg; codecs=vorbis">
  <source src="/files/yuklanmalar/.tell/och.wav" type="audio/wav; codecs=vorbis">
	</audio><?
	}
}
exit;
?>