<?
if(!(isset($_SERVER['HTTP_X_REQUESTED_WITH']) && !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest')) die;
include '../sys/inc/yadro.php';

?>
<style>
.arr img {
	vertical-align: top;
}
.arr a {
	color:#fff;
}
</style>
<?
$listing = new listing();
$q = mysql_query("SELECT * FROM `mail` WHERE `is_read` = '0'  AND `id_user` = '".$user->id."'  ORDER BY `time` DESC LIMIT 5");
 while ($maisl = mysql_fetch_assoc($q)) {
  $mg = array('1' => "et.png", '0' => "etm.png");
  $ank2 = new user((int)$maisl ['id_sender']);
	$pa = $listing->pa();
     if ($user->id == $maisl ['id_sender']){
			$pa->bottom = 'men';
			}else{
			$pa->bottom = 'menga';
			}
        $pa->url = '/xabar?id='.$ank2->id.'';
		//$pa->image = $ank2->getAva();
        $pa->title = $ank2->nick();
        $pa->time = misc::when($maisl ['time']);
        $pa->admine = smiles(text::toOutput($maisl['mess']));
        if ($maisl['file']){
		$ds	= $fileee  = stripcslashes(htmlspecialchars(@iconv_substr($maisl['file'], 0, 15, 'utf-8')));
		if($ds == '/files/.strike/'){	
		$pa->mehmon = $maisl['file'];
		}else{
		$pa->mehmon = '/files/.mail/'.$maisl['file'];
		
		}
		  }
	

		?>
		<script>   
		$(function() {
			$.fx.speeds._default = 100;   

		    $( "#mail_vk_modal" ).dialog({
		    autoOpen: false,
		    show: "blind",
		    hide: "blind",
		    modal: false
			});
			
			$( "#mail_vk<?=$mail['id']?>" ).click(function() 
			{
			    $( "#mail_vk_modal" ).dialog( "open" );
				loading_mail('<?=$mail['id']?>');
			    return false;
			});
		});
		</script>
		<?
		$audio = true;
if (isset($_SESSION['sms_keldi']) && $_SESSION['sms_keldi'] == 'sms_keldi' && isset($audio) || isset($_COOKIE['sms_keldi'])  && $_COOKIE['sms_keldi'] == 'sms_keldi' && isset($audio)){

	?>
	<script type="text/javascript">
    window.onload = function() {
        new Audio('/files/yuklanmalar/.tell/<?=$user->login;?>_tut.ogg').play();
    };
  </script><audio autoplay="autoplay">
	  <source src="/ajax/audio.ogg" type="audio/ogg; codecs=vorbis">
	  <source src="/ajax/audio.mp3" type="audio/mpeg">
	</audio>
	<?	
}
 }
	
	
	}
    $listing->display();
    




exit;
?>