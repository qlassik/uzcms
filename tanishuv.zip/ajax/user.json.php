<?php

include '../sys/inc/yadro.php';
$default = array('id');
$skip = array('_', 'password', 'a_code', 'recovery_password', 'wmid_tmp_code');
$data = array();
$options = array_merge($default, array_keys(@$_GET));

foreach ($options as $key) {
    if (in_array($key, $skip)) {
        continue;
    }
    $data[$key] = $user->$key;
}

header('Content-type: application/json');
echo json_encode($data);