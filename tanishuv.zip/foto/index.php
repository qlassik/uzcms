<?php 
include_once '../sys/inc/yadro.php';
$doc = new document ();
$doc->title = __('Fo`to`albom');
$photos = new files ( FILES . '/.foto' );



?>