<?php

include_once '../sys/inc/yadro.php';
$doc = new document ();
$doc->title = __('Fo`to`albom');

if (!empty($_GET ['id'])) {
    $ank = new user((int) $_GET ['id']);
} else {
    $ank = $user;
}

if (!$ank->group) {
    $doc->access_denied(__('Fodalanuvchiniki xato'));
}

$photos = new files(FILES . '/.foto');
$albums_path = FILES . '/.foto/' . $ank->id;

if (!@is_dir($albums_path)) {
    if (!$albums_dir = $photos->mkdir($ank->login, $ank->id))
        $doc->access_denied(__('Sizda daraja yo`q yoki ro`yhatdan otib korin'));

    $albums_dir->id_user = $ank->id;
    $albums_dir->group_show = 0;
    $albums_dir->group_write = min($ank->group, 2);
    $albums_dir->group_edit = max($ank->group, 4);
    unset($albums_dir);
}

$albums_dir = new files($albums_path);

if (empty($_GET ['album']) || !$albums_dir->is_dir($_GET ['album'])) {
    $doc->err(__('Bunday albom yo`q'));
    $doc->kor(__('Albomga'), 'albums.php?id=' . $ank->id);
    header('Refresh: 1; url=albums.php?id=' . $ank->id);
    exit();
}

$album_name = (string) $_GET ['album'];
$album = new files($albums_path . '/' . $album_name);
$doc->title = $album->runame;

if (empty($_GET ['photo']) || !$album->is_file($_GET ['photo'])) {
    $doc->err(__('Fo`to`albomga topilmadi'));
    $doc->kor(__('Fo`to`albomga %s', $name), 'photos.php?id=' . $ank->id . '&amp;album=' . urlencode($album->name));
    $doc->kor(__('Albomga'), 'albums.php?id=' . $ank->id);
    header('Refresh: 1; url=photos.php?id=' . $ank->id . '&alnum=' . urlencode($album->name));
    exit();
}

$photo_name = $_GET ['photo'];

$photo = new files_file($albums_path . '/' . $album_name, $photo_name);
$doc->title = $photo->runame;

$doc->description = __('Surat %s:%s', $ank->title, $photo->runame);
$doc->keywords [] = $photo->runame;
$doc->keywords [] = $album->runame;
$doc->keywords [] = $ank->title;
if (isset($_GET ['baxx'])){

if (mysql_result(mysql_query("SELECT COUNT(`id`) FROM `baxo` WHERE `id_user` = '".$ank->id."' AND `id_who` = '".$user->id."' AND `id_url` = '?id=" . $ank->id . "&amp;album=" . urlencode($album->name) . "&amp;photo=" . urlencode($photo->name)."' LIMIT 1"),0)!=0){
		 $doc->err(__('Siz baholab bo`lgansiz.'));
	}elseif ($_GET ['id'] == $ank->id && $_GET ['album'] == $album_name && $_GET ['photo'] == $photo_name) {



if ($_GET ['baxx'] == '55' || $_GET ['baxx'] == '5' || $_GET ['baxx'] == '4' || $_GET ['baxx'] == '3' || $_GET ['baxx'] == '2' || $_GET ['baxx'] == '1'){
if ($_GET ['baxx'] == '55' || $_GET ['baxx'] == '5' || $_GET ['baxx'] == '4'){
$okd = '1'; 
$photo->s_2++;
}
if ($_GET ['baxx'] == '3' || $_GET ['baxx'] == '2' || $_GET ['baxx'] == '1'){
$okd = '2';
$photo->s_3++;
}

mysql_query("INSERT INTO `baxo` (`id_user`, `id_who`, `tur`, `time`, `kor`, `korga`, `id_url`) VALUES ('$ank->id', '$user->id', '$okd','" . TIME . "', '".$_GET ['baxx']."', 'baxo', '?id=" . $ank->id . "&amp;album=" . urlencode($album->name) . "&amp;photo=" . urlencode($photo->name)."')");
$ank->baxo++;

}
}
}
?>
<style>
.ayy{
    display: inline-block;
    min-width: 8px;
    padding: 1px 4px;
    font-size: 10px;
    font-weight: 700;
    line-height: 1;
    color: #fff;
    text-align: center;
    white-space: nowrap;
    vertical-align: middle;
    background-color: #777;
    border-radius: 7px;
	}
</style>
<?


if (isset($_GET ['bax'])){
if ($_GET ['id'] == $ank->id && $_GET ['album'] == $album_name && $_GET ['photo'] == $photo_name) {
$doc -> title = __('Baxolar');

$pages = new pages(mysql_result(mysql_query("SELECT COUNT(*) FROM `baxo` WHERE `id_user` = '".$ank->id."' AND `korga` = 'baxo' AND `tur` = '".$_GET ['bax']."'"), 0));
$listing = new listing();
$q = mysql_query("SELECT * FROM `baxo` WHERE `id_user` = '".$ank->id."' AND `korga` = 'baxo' AND `tur` = '".$_GET ['bax']."' ORDER BY `time` DESC LIMIT ".$pages->limit);
while ($p_user = mysql_fetch_assoc($q)) {

$ank = new user($p_user['id_who']);
$kv = $listing->kv();
$kv->url = '/ID'.$ank->id.'';
$kv->image = $ank->getAva($doc->img_max_width());
$kv->title = $ank->nick();
$kv->mehmon = ''.('Berilgan baxo').' <img class="ayy" src="/img/baxo/'.$p_user['kor'].'.png" title="voo.uz" alt="voo.uz" /></b>';
$kv->time = misc::when($ank->last_visit);
$kv->admine = ''.stsID($ank->id).'';
if ($user->id == $ank->id);else{
$kv->action('shx', '/xabar?id='.$ank->id.'');	
} 
 }

$listing->display(__('Ro`yhat bo`sh'));
if ($user->id == $ank->id){
$user->baxo = '';
}

$pages->this_page();
$pages->display('?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name) . '&amp;bax=' . urlencode($_GET ['bax']).'&');
$doc->kor(__('Tozalash'), '/baxo_royhatini_tozalash.html');
$doc->kor(__('Fo`to`ga'), '?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name));
$doc->kor(__('Albo`m %s', $album->name), 'photos.php?id=' . $ank->id . '&amp;album=' . urlencode($album->name));
$doc->kor(__('%s albo`mi', $ank->title), 'albums.php?id=' . $ank->id);
                	
exit;
}
} 
if ($photo->id_user && $photo->id_user == $user->id) {




    if (!empty($_GET ['act']) && $_GET ['act'] === 'ava') {
$avatar_file_name = $user->login . '.png';
$avatars_path = FILES . '/.avatars'; 
$avatars_dir = new files($avatars_path);
$file = $albums_path . '/' . $album_name . '/' . $photo_name;
$newfile = $avatars_path . '/' . $user->id . '.png';
	if (empty($_POST ['ava'])) {
            if (copy($file, $newfile)) {
                $user->ava = $photo->name;
				$doc->msg(__('So`rovingiz mufoqatli amalga oshirildi'));
                $doc->ret(__('Fo`to`ga'), '?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name));
                $doc->ret(__('Albo`m %s', $album->name), 'photos.php?id=' . $ank->id . '&amp;album=' . urlencode($album->name));
                $doc->ret(__('%s albo`mi', $ank->title), 'albums.php?id=' . $ank->id);
                header('Refresh: 1; url=?id=' . $ank->id . '&album=' . urlencode($album->name) . '&photo=' . urlencode($photo->name) . '&' . passgen());
                exit();
            } else {

                $doc->err(__('O`rnatilmadi'));
                $doc->ret(__('Fo`to`ga'), '?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name));
                $doc->ret(__('Albo`m %s', $album->name), 'photos.php?id=' . $ank->id . '&amp;album=' . urlencode($album->name));
                $doc->ret(__('%s albo`mi', $ank->nick()), 'albums.php?id=' . $ank->id);
                header('Refresh: 1; url=?id=' . $ank->id . '&album=' . urlencode($album->name) . '&photo=' . urlencode($photo->name) . '&' . passgen());
            }
            exit();
        }	
	
	}
	
    if (!empty($_GET ['act']) && $_GET ['act'] === 'delete') {

        if (!empty($_POST ['delete'])) {
            if (empty($_POST ['captcha']) || empty($_POST ['captcha_session']) || !captcha::check($_POST ['captcha'], $_POST ['captcha_session']))
                $doc->err(__('Raqam to`gri holatda kiritilmadi'));
            elseif ($photo->delete()) {
                $doc->msg(__('foto o`chirildi'));
                $doc->ret(__('Albom %s', $album->name), 'photos.php?id=' . $ank->id . '&amp;album=' . urlencode($album->name));
                $doc->ret(__('Albomga %s', $ank->nick()), 'albums.php?id=' . $ank->id);
                header('Refresh: 1; url=photos.php?id=' . $ank->id . '&album=' . urlencode($album->name) . '&' . passgen());
                exit();
            } else {

                $doc->err(__('iloji bo`lmadi o`chirishga'));
                $doc->ret(__('Fo`to`nga'), '?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name));
                $doc->ret(__('Albom %s', $album->name), 'photos.php?id=' . $ank->id . '&amp;album=' . urlencode($album->name));
                $doc->ret(__('Albomga %s', $ank->nick()), 'albums.php?id=' . $ank->id);
                header('Refresh: 1; url=?id=' . $ank->id . '&album=' . urlencode($album->name) . '&photo=' . urlencode($photo->name) . '&' . passgen());
            }
            exit();
        }

        $smarty = new design ();
        $smarty->assign('method', 'post');
        $smarty->assign('action', '?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name) . '&amp;act=delete&amp;' . passgen());
        $elements = array();
        $elements [] = array('type' => 'captcha', 'session' => captcha::gen(), 'br' => 1);
        $elements [] = array('type' => 'submit', 'br' => 0, 'info' => array('name' => 'delete', 'value' => __('Fo`to`ni o`chirish'))); // кнопка
        $smarty->assign('el', $elements);
        $smarty->display('input.form.tpl');

        $doc->ret(__('Fo`to`nga'), '?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name));
        $doc->ret(__('Albomga %s', $album->name), 'photos.php?id=' . $ank->id . '&amp;album=' . urlencode($album->name));
        $doc->ret(__('Albomga %s', $ank->nick()), 'albums.php?id=' . $ank->id);
        exit();
    }

    $doc->act(__('Fo`to`ni o`chirish'), '?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name) . '&amp;act=delete');
}
?>
<style>
	.voouzga{
	width: 50%;
	margin: 2px auto;
    background: #EBEBEB;
    padding: 5px;
    border: 1px solid #DFDFDF;
    border-radius: 5px;
	margin-top:  10px;  
    }
.bax{
    display: inline-block;
    min-width: 8px;
	width: 18px;
    padding: 4px;
    font-size: 10px;
    font-weight: 700;
    line-height: 1;
    color: #fff;
    text-align: center;
    white-space: nowrap;
    vertical-align: middle;
    background-color: #777;
    border-radius: 25px;
	margin: 3px;
	}
.bax2{
    display: inline-block;
    min-width: 8px;
	width: 22px;
    padding: 4px;
    font-size: 10px;
    font-weight: 700;
    line-height: 1;
    color: #fff;
    text-align: center;
    white-space: nowrap;
    vertical-align: middle;
    background-color: #fff;
    border-radius: 25px;
	margin: 3px;
	}
.baxq{
    display: inline-block;
    min-width: 8px;
	padding: 4px;
    font-size: 10px;
    font-weight: 700;
    line-height: 1;
    color: #fff;
    text-align: center;
    white-space: nowrap;
    vertical-align: middle;
    background-color: #777;
    border-radius: 25px;
	margin: 3px;
	}		
</style>
<?
if ($screen = $photo->getScreen($doc->img_max_width(), 0)) {

 if (mysql_result(mysql_query("SELECT COUNT(`id`) FROM `fo` WHERE `id` = '".$ank->id."' AND `path_file_rel` = '/files/.foto/".$ank->id."/".$album->name."/".$photo->name."' LIMIT 1"),0)!=0){
	mysql_query("UPDATE `fo` SET  `time` = '" . TIME . "' WHERE `id` = '$ank->id' AND `path_file_rel` = '/files/.foto/".$ank->id."/".$album->name."/".$photo->name."' LIMIT 1");
  }else{
      mysql_query("INSERT INTO `fo` (`id`, `path_file_rel`, `fo_k`, `url`, `time`) VALUES ('$user->id', '/files/.foto/".$ank->id."/".$album->name."/".$photo->name."', '".$user->fo_k."', '".$_SERVER['REQUEST_URI']."', '" . TIME . "')");
	}

   echo "<center><img class='voouzga' src='" . $screen . "' alt='" . __('VOO UZ') . " " . text::toValue($photo->runame) . "' />\n";
		
	
	
	if ($ank->id == $user->id){
	echo '<span style="display: block !important; margin-top: -50px;"><a href="?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name) . '&amp;bax=1"><span  class="baxq">'.__('Zo`r').' ('.$photo->s_2.') </span><img class="bax"  src="/img/baxo/bb.png" title="voo.uz" alt="voo.uz"/></a><a href="?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name) . '&amp;bax=2"><img class="bax"  src="/img/baxo/dd.png" title="voo.uz" alt="voo.uz"/><span  class="baxq"> ('.$photo->s_3.') '.__('Yomon').'</span></a><br />';
	
	
	
	
	if ($user->ava == $photo->name){
	echo '<span  class="baxq">  '.__('O`rnatilgan').'</span></span></center><br /><br />';
	}else{
	echo '<a href="?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name) . '&amp;act=ava"><span  class="baxq">  '.__('Bosh sahifaga qo`yish').'</span></a></span></center><br /><br />';
	}
	
	
	}else{
	if (mysql_result(mysql_query("SELECT COUNT(`id`) FROM `baxo` WHERE `id_user` = '".$ank->id."' AND `id_who` = '".$user->id."' AND `id_url` = '?id=" . $ank->id . "&amp;album=" . urlencode($album->name) . "&amp;photo=" . urlencode($photo->name)."' LIMIT 1"),0)!=0){
		 $doc->err(__('Siz baholab bo`lgansiz.'));
	}else{
	echo '<span style="display: block !important; margin-top: -50px;"><a href="?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name) . '&amp;baxx=55"><img  class="bax2" src="/img/baxo/55.png" title="voo.uz" alt="voo.uz"/></a><a href="?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name) . '&amp;baxx=5"><img class="bax"  src="/img/baxo/5.png" title="voo.uz" alt="voo.uz"/></a><a href="?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name) . '&amp;baxx=4"><img class="bax"  src="/img/baxo/4.png" title="voo.uz" alt="voo.uz"/></a><a href="?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name) . '&amp;baxx=3"><img class="bax"  src="/img/baxo/3.png" title="voo.uz" alt="voo.uz"/></a><a href="?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name) . '&amp;baxx=2"><img class="bax"  src="/img/baxo/2.png" title="voo.uz" alt="voo.uz"/></a><a href="?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name) . '&amp;baxx=1"><img class="bax"  src="/img/baxo/1.png" title="voo.uz" alt="voo.uz"/></a><br />';
	}
	
	echo '<span style="display: block !important; margin-top: -50px;"><a href="?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name) . '&amp;bax=1"><span  class="baxq">'.__('Zo`r').' ('.$photo->s_2.') </span><img class="bax"  src="/img/baxo/bb.png" title="voo.uz" alt="voo.uz"/></a><a href="?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name) . '&amp;bax=2"><img class="bax"  src="/img/baxo/dd.png" title="voo.uz" alt="voo.uz"/><span  class="baxq"> ('.$photo->s_3.') '.__('Yomon').'</span></a></span><br /></center><br />';
	}
}else{
	
	
	
	
	
	
	
	
	
	 if (mysql_result(mysql_query("SELECT COUNT(`id`) FROM `fo` WHERE `id` = '".$ank->id."' AND `path_file_rel` = '/files/.foto/".$ank->id."/".$album->name."/".$photo->name."' LIMIT 1"),0)!=0){
	mysql_query("UPDATE `fo` SET  `time` = '" . TIME . "' WHERE `id` = '$ank->id' AND `path_file_rel` = '/files/.foto/".$ank->id."/".$album->name."/".$photo->name."' LIMIT 1");
  }else{
      mysql_query("INSERT INTO `fo` (`id`, `path_file_rel`, `fo_k`, `url`, `time`) VALUES ('$user->id', '/files/.foto/".$ank->id."/".$album->name."/".$photo->name."', '".$user->fo_k."', '".$_SERVER['REQUEST_URI']."', '" . TIME . "')");
	}

  echo '<center><img class="voouzga" src="/files/.foto/'.$ank->id.'/'. urlencode($album->name) . '/'.$photo->name . '" alt="' . __('VOO UZ') . '' . text::toValue($photo->runame) . '" />';
	
	
	
	if ($ank->id == $user->id){
	echo '<span style="display: block !important; margin-top: -50px;"><a href="?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name) . '&amp;bax=1"><span  class="baxq">'.__('Zo`r').' ('.$photo->s_2.') </span><img class="bax"  src="/img/baxo/bb.png" title="voo.uz" alt="voo.uz"/></a><a href="?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name) . '&amp;bax=2"><img class="bax"  src="/img/baxo/dd.png" title="voo.uz" alt="voo.uz"/><span  class="baxq"> ('.$photo->s_3.') '.__('Yomon').'</span></a><br />';
	
	
	
	
	if ($user->ava == $photo->name){
	echo '<span  class="baxq">  '.__('O`rnatilgan').'</span></span></center><br /><br />';
	}else{
	echo '<a href="?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name) . '&amp;act=ava"><span  class="baxq">  '.__('Bosh sahifaga qo`yish').'</span></a></span></center><br /><br />';
	}
	
	
	}else{
	if (mysql_result(mysql_query("SELECT COUNT(`id`) FROM `baxo` WHERE `id_user` = '".$ank->id."' AND `id_who` = '".$user->id."' AND `id_url` = '?id=" . $ank->id . "&amp;album=" . urlencode($album->name) . "&amp;photo=" . urlencode($photo->name)."' LIMIT 1"),0)!=0){
		 $doc->err(__('Siz baholab bo`lgansiz.'));
	}else{
	echo '<span style="display: block !important; margin-top: -50px;"><a href="?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name) . '&amp;baxx=55"><img  class="bax2" src="/img/baxo/55.png" title="voo.uz" alt="voo.uz"/></a><a href="?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name) . '&amp;baxx=5"><img class="bax"  src="/img/baxo/5.png" title="voo.uz" alt="voo.uz"/></a><a href="?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name) . '&amp;baxx=4"><img class="bax"  src="/img/baxo/4.png" title="voo.uz" alt="voo.uz"/></a><a href="?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name) . '&amp;baxx=3"><img class="bax"  src="/img/baxo/3.png" title="voo.uz" alt="voo.uz"/></a><a href="?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name) . '&amp;baxx=2"><img class="bax"  src="/img/baxo/2.png" title="voo.uz" alt="voo.uz"/></a><a href="?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name) . '&amp;baxx=1"><img class="bax"  src="/img/baxo/1.png" title="voo.uz" alt="voo.uz"/></a><br />';
	}
	
	echo '<span style="display: block !important; margin-top: -50px;"><a href="?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name) . '&amp;bax=1"><span  class="baxq">'.__('Zo`r').' ('.$photo->s_2.') </span><img class="bax"  src="/img/baxo/bb.png" title="voo.uz" alt="voo.uz"/></a><a href="?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name) . '&amp;bax=2"><img class="bax"  src="/img/baxo/dd.png" title="voo.uz" alt="voo.uz"/><span  class="baxq"> ('.$photo->s_3.') '.__('Yomon').'</span></a></span><br /></center><br />';
	}
	
	
	
	
	
	
	
	
	
	
	
	
}

$can_write = true;
if (!$user->is_writeable) {
    $doc->err(__('Siz %s Soatdan kegin sharh yoza olas', $uzcms->user_write_limit_hour));
    $can_write = false;
}




     if (isset($_POST['message']))if($user->ak == '3'){
		 $doc->err(__('Siz bloqlangansiz'));		  
	  }elseif($user->ak == '2'){
		 $doc->err(__('Sizning profilingiz aktivmas'));		  
	  }elseif (mysql_result(mysql_query("SELECT COUNT(`id`) FROM `surat_sharxi` WHERE `id_user` = '".$user->id."' AND `text` = '".mysql_escape_string($_POST ['message'])."' AND `time` > '".(time()-180)."' LIMIT 1"),0)!=0){
		 $doc->err(__('Birhil jullalik manodagi habar yozmang'));		  
	  }elseif (mysql_result(mysql_query("SELECT COUNT(`id`) FROM `surat_sharxi` WHERE `id_user` = '".$user->id."' AND `time` > '".(time()-8)."' LIMIT 1"),0)!=0){
		 $doc->err(__('Haskerlik qilmang men elyorbek nickm qlassik_ru hammayoqni oldini olganman'));
	}elseif (isset($_POST ['send']) && isset($_POST ['message']) && $user->group && $user->ak == '1') {
        $message = text::input_text($_POST ['message']);

        if ($photo->id_user && $photo->id_user != $user->id && (empty($_POST ['captcha']) || empty($_POST ['captcha_session']) || !captcha::check($_POST ['captcha'], $_POST ['captcha_session'])))
            $doc->err(__('Raqam to`gri holatda kiritilmadi'));
        elseif ($uzcms->censure && $mat = is_valid::mat($message))
            $doc->err(__('ZIT: %s', $mat));
        elseif ($message) {
            $user->balls++;
            mysql_query("INSERT INTO `surat_sharxi` (`id_file`, `id_user`, `time`, `text`) VALUES ('$photo->id','$user->id', '" . TIME . "', '" . my_esc($message) . "')");
            $doc->msg(__('Sharh qoldirildi'));
            $photo->unvon++;

            if ($photo->id_user && $photo->id_user != $user->id) { 
            ///sharh qoldirildi
			}
        } else {
            $doc->err(__('Sharh bo`sh'));
        }
    }

if ($user->group && $user->ak == '1') {
        $smarty = new design ();
        $smarty->assign('method', 'post');
        $smarty->assign('action', '?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name) . '&amp;' . passgen());
        $elements = array();
        $elements [] = array('type' => 'textarea', 'title' => __('Sharh <span style="color: red;">(%s)</span>', $photo->unvon), 'br' => 1, 'info' => array('name' => 'message'));

        if ($photo->id_user && $photo->id_user != $user->id)
            $elements [] = array('type' => 'captcha', 'session' => captcha::gen(), 'br' => 1);

        $elements [] = array('type' => 'submit', 'br' => 0, 'info' => array('name' => 'send', 'value' => __('Yuborish'))); 
        $smarty->assign('el', $elements);
        $smarty->display('input.form.tpl');
    }

if (!empty($_GET ['delete_comm']) && $user->group >= $photo->group_edit) {
    $delete_comm = (int) $_GET ['delete_comm'];
    if (mysql_result(mysql_query("SELECT COUNT(*) FROM `surat_sharxi` WHERE `id` = '$delete_comm' AND `id_file` = '$photo->id' LIMIT 1"), 0)) {
        mysql_query("DELETE FROM `surat_sharxi` WHERE `id` = '$delete_comm' LIMIT 1");
        $photo->unvon--;
        $doc->msg(__('Sharh o`chirildi'));
    } else
        $doc->err(__('Sharh o`chirilgan'));
}

$pages = new pages ();
$pages->posts = mysql_result(mysql_query("SELECT COUNT(*) FROM `surat_sharxi` WHERE `id_file` = '$photo->id'"), 0); // количество сообщений
$q = mysql_query("SELECT * FROM `surat_sharxi` WHERE `id_file` = '$photo->id' ORDER BY `id` DESC LIMIT ".$pages->limit);

$listing = new listing();
while ($comment = mysql_fetch_assoc($q)) {
    $ank = new user($comment ['id_user']);
    $kv = $listing->kv();
    $kv->url = '/ID'.$ank->id.'';
    $kv->title = $ank->nick();
    $kv->time = misc::when($comment ['time']);
    $kv->image = $ank->getAva($doc->img_max_width());
    $kv->icon($ank->icon());
    $kv->admine = text::toOutput($comment ['text']);

    if ($user->group >= $photo->group_edit) {
        $kv->action('delete', '?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name) . '&amp;delete_comm=' . $comment ['id']);
    }
}
$listing->display(__('Sharhlar yo`q'));
$pages->display('?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name) . '&amp;'); 
$doc->act(__('Mening foto`yim'), '?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name) . '&amp;act=ava');
$doc->kor(__('Albomga %s', $album->runame), 'photos.php?id=' . $ank->id . '&amp;album=' . urlencode($album->name));
$doc->kor(__('Albomga %s', $ank->nick()), 'albums.php?id=' . $ank->id);