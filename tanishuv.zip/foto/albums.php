<?php

include_once '../sys/inc/yadro.php';
$doc = new document ();
$doc->title = __('Fo`to`albom');

if (!empty($_GET ['id'])) {
    $ank = new user((int) $_GET ['id']);
} else {
    $ank = $user;
}

if (!$ank->group) {
    $doc->access_denied(__('Xatolik bor'));
}

if ($ank->id == $user->id) {
    $doc->title = __('Mening fo`to`albom');
} else {
    $doc->title = __('Fo`to`albom %s', $ank->title);
}


$doc->description = __('Fo`to`albom %s', $ank->title);
$doc->keywords[] = $ank->title;


$photos = new files(FILES . '/.foto');
$albums_path = FILES . '/.foto/' . $ank->id;

if (!@is_dir($albums_path)) {
    if (!$albums_dir = $photos->mkdir($ank->login, $ank->id))
    $doc->access_denied(__('Iloji yoq fo`to`albomda papka yaratishda'));
    $albums_dir->group_show = 0;
    $albums_dir->group_write = max($ank->group, 2);
    $albums_dir->group_edit = max($ank->group, 4);
    $albums_dir->id_user = $ank->id;
    unset($albums_dir);
}

$albums_dir = new files($albums_path);
if ($ank->id == $user->id && !empty($_GET ['act']) && $_GET ['act'] == 'create') {
    $doc->title .= ' - ' . __('Albom yaratish');

    if (!empty($_POST ['name'])) {
        $name = text::for_name($_POST ['name']);

        if (!$name)
            $doc->err(__('Papka nomi simmollardan iborat bo`lmasin'));
        elseif (!$album = $albums_dir->mkdir($name))
            $dir->err(__('iloji bo`lmadi Albom yaratish'));
        else {
            $doc->ret(__('Albomga %s', $name), 'photos.php?id=' . $ank->id . '&mp;album=' . urlencode($album->name));
            $doc->ret(__('Albomga'), '?id=' . $ank->id);
            header('Refresh: 1; url=photos.php?id=' . $ank->id . '&album=' . urlencode($album->name));
            $doc->msg(__('Albom "%s" yaratildi', $name));
            exit();
        }
    }

    $smarty = new design ();
    $smarty->assign('method', 'post');

    $smarty->assign('action', '?id=' . $ank->id . '&amp;act=create&amp;' . passgen());
    $elements = array();

    $elements [] = array('type' => 'input_text', 'title' => __('Albom nomi'), 'br' => 1, 'info' => array('name' => 'name'));
    $elements [] = array('type' => 'submit', 'br' => 0, 'info' => array('value' => __('Yaratish')));
    $smarty->assign('el', $elements);
    $smarty->display('input.form.tpl');

    //$doc->ret(__('Albomga'), '?id=' . $ank->id . '&amp;' . passgen());
    $doc->ret(' <img src="/img/answer.png">  '.__('Albomga'), '?id=' . $ank->id . '&amp;' . passgen());
	exit();
}

$content = $albums_dir->getList('time_add:desc');
$dirs = &$content ['dirs'];
echo '<div style="margin-top: 10px; margin-left: 10px;">';
$listing = new listing();
for ($i = 0; $i < count($dirs); $i++) {
    $albom = $listing->albom();
    $albom->icon($dirs [$i]->icon());
    $albom->url = "photos.php?id={$ank->id}&amp;album=" . urlencode($dirs [$i]->name);
    $bor = text::toValue($dirs [$i]->runame);
	$albom->title = text::toValue($dirs [$i]->runame);
	$albom->hightlight = text::toValue($dirs [$i]->kirdi);    
	}
$listing->display(__('Fo`to`albom yo`q'));

echo '</div>';
if (!isset($bor)){
$album = $albums_dir->mkdir('Lichni');
}

if ($user->id == $ank->id) {
   // $doc->act(__('Albom yaratish'), '?id=' . $ank->id . '&amp;act=create');
    $doc->kor(__('Albom yaratish'), '?id=' . $ank->id . '&amp;act=create');
	$doc->kor(__('Fo`to` yuklash'), 'photos.php??id=' . $ank->id . '&amp;album=' . urlencode('Lichni') . '&amp;act=photo_add');
    
	
	}
?>