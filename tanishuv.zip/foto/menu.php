<?php

include_once '../sys/inc/yadro.php';
$doc = new document ();
$doc->title = __('Fo`to`albom');

if (!empty($_GET ['id'])) {
    $ank = new user((int) $_GET ['id']);
} else {
    $ank = $user;
}

if (!$ank->group) {
    $doc->access_denied(__('Fodalanuvchiniki xato'));
}

$photos = new files(FILES . '/.foto');
$albums_path = FILES . '/.foto/' . $ank->id;

if (!@is_dir($albums_path)) {
    if (!$albums_dir = $photos->mkdir($ank->login, $ank->id))
        $doc->access_denied(__('Sizda daraja yo`q yoki ro`yhatdan otib korin'));

    $albums_dir->id_user = $ank->id;
    $albums_dir->group_show = 0;
    $albums_dir->group_write = min($ank->group, 2);
    $albums_dir->group_edit = max($ank->group, 4);
    unset($albums_dir);
}

$albums_dir = new files($albums_path);

if (empty($_GET ['album']) || !$albums_dir->is_dir($_GET ['album'])) {
    $doc->err(__('Bunday albom yo`q'));
    $doc->ret(__('Albomga'), 'albums.php?id=' . $ank->id);
    header('Refresh: 1; url=albums.php?id=' . $ank->id);
    exit();
}

$album_name = (string) $_GET ['album'];
$album = new files($albums_path . '/' . $album_name);
$doc->title = $album->runame;

if (empty($_GET ['photo']) || !$album->is_file($_GET ['photo'])) {
    $doc->err(__('Fo`to`albomga topilmadi'));
    $doc->ret(__('Fo`to`albomga %s', $name), 'photos.php?id=' . $ank->id . '&amp;album=' . urlencode($album->name));
    $doc->ret(__('Albomga'), 'albums.php?id=' . $ank->id);
    header('Refresh: 1; url=photos.php?id=' . $ank->id . '&alnum=' . urlencode($album->name));
    exit();
}

$photo_name = $_GET ['photo'];

$photo = new files_file($albums_path . '/' . $album_name, $photo_name);
$doc->title = $photo->runame;

$doc->description = __('Фото fodalanuvchiniki %s:%s', $ank->login, $photo->runame);
$doc->keywords [] = $photo->runame;
$doc->keywords [] = $album->runame;
$doc->keywords [] = $ank->login;

if ($photo->id_user && $photo->id_user == $user->id) {
    
	
// modul 1


    if (!empty($_GET ['act']) && $_GET ['act'] === 'slayt1') {
$slayt1tar_file_name = '1.png';
$slayt1tars_path = FILES . '/.modul'; 
$slayt1tars_dir = new files($slayt1tars_path);
$file = $albums_path . '/' . $album_name . '/' . $photo_name;
$newfile = $slayt1tars_path . '/1.png';
	if (empty($_POST ['slayt1'])) {
            if (copy($file, $newfile)) {
                $doc->msg(__('So`rovingiz mufoqatli amalga oshirildi'));
                $doc->ret(__('Fo`to`ga'), '?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name));
                $doc->ret(__('Albo`m %s', $album->name), 'photos.php?id=' . $ank->id . '&amp;album=' . urlencode($album->name));
                $doc->ret(__('%s albo`mi', $ank->login), 'albums.php?id=' . $ank->id);
                header('Refresh: 1; url=?id=' . $ank->id . '&album=' . urlencode($album->name) . '&photo=' . urlencode($photo->name) . '&' . passgen());
                exit();
            } else {

                $doc->err(__('O`rnatilmadi'));
                $doc->ret(__('Fo`to`ga'), '?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name));
                $doc->ret(__('Albo`m %s', $album->name), 'photos.php?id=' . $ank->id . '&amp;album=' . urlencode($album->name));
                $doc->ret(__('%s albo`mi', $ank->login), 'albums.php?id=' . $ank->id);
                header('Refresh: 1; url=?id=' . $ank->id . '&album=' . urlencode($album->name) . '&photo=' . urlencode($photo->name) . '&' . passgen());
            }
            exit();
        }	
	
	}
// modul 2


    if (!empty($_GET ['act']) && $_GET ['act'] === 'slayt2') {
$slayt2tar_file_name = '2.png';
$slayt2tars_path = FILES . '/.modul'; 
$slayt2tars_dir = new files($slayt2tars_path);
$file = $albums_path . '/' . $album_name . '/' . $photo_name;
$newfile = $slayt2tars_path . '/2.png';
	if (empty($_POST ['slayt2'])) {
            if (copy($file, $newfile)) {
                $doc->msg(__('So`rovingiz mufoqatli amalga oshirildi'));
                $doc->ret(__('Fo`to`ga'), '?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name));
                $doc->ret(__('Albo`m %s', $album->name), 'photos.php?id=' . $ank->id . '&amp;album=' . urlencode($album->name));
                $doc->ret(__('%s albo`mi', $ank->login), 'albums.php?id=' . $ank->id);
                header('Refresh: 1; url=?id=' . $ank->id . '&album=' . urlencode($album->name) . '&photo=' . urlencode($photo->name) . '&' . passgen());
                exit();
            } else {

                $doc->err(__('O`rnatilmadi'));
                $doc->ret(__('Fo`to`ga'), '?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name));
                $doc->ret(__('Albo`m %s', $album->name), 'photos.php?id=' . $ank->id . '&amp;album=' . urlencode($album->name));
                $doc->ret(__('%s albo`mi', $ank->login), 'albums.php?id=' . $ank->id);
                header('Refresh: 1; url=?id=' . $ank->id . '&album=' . urlencode($album->name) . '&photo=' . urlencode($photo->name) . '&' . passgen());
            }
            exit();
        }	
	
	}
// modul 3


    if (!empty($_GET ['act']) && $_GET ['act'] === 'slayt3') {
$slayt3tar_file_name = '3.png';
$slayt3tars_path = FILES . '/.modul'; 
$slayt3tars_dir = new files($slayt3tars_path);
$file = $albums_path . '/' . $album_name . '/' . $photo_name;
$newfile = $slayt3tars_path . '/3.png';
	if (empty($_POST ['slayt3'])) {
            if (copy($file, $newfile)) {
                $doc->msg(__('So`rovingiz mufoqatli amalga oshirildi'));
                $doc->ret(__('Fo`to`ga'), '?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name));
                $doc->ret(__('Albo`m %s', $album->name), 'photos.php?id=' . $ank->id . '&amp;album=' . urlencode($album->name));
                $doc->ret(__('%s albo`mi', $ank->login), 'albums.php?id=' . $ank->id);
                header('Refresh: 1; url=?id=' . $ank->id . '&album=' . urlencode($album->name) . '&photo=' . urlencode($photo->name) . '&' . passgen());
                exit();
            } else {

                $doc->err(__('O`rnatilmadi'));
                $doc->ret(__('Fo`to`ga'), '?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name));
                $doc->ret(__('Albo`m %s', $album->name), 'photos.php?id=' . $ank->id . '&amp;album=' . urlencode($album->name));
                $doc->ret(__('%s albo`mi', $ank->login), 'albums.php?id=' . $ank->id);
                header('Refresh: 1; url=?id=' . $ank->id . '&album=' . urlencode($album->name) . '&photo=' . urlencode($photo->name) . '&' . passgen());
            }
            exit();
        }	
	
	}	
// modul 4


    if (!empty($_GET ['act']) && $_GET ['act'] === 'slayt4') {
$slayt4tar_file_name = '4.png';
$slayt4tars_path = FILES . '/.modul'; 
$slayt4tars_dir = new files($slayt4tars_path);
$file = $albums_path . '/' . $album_name . '/' . $photo_name;
$newfile = $slayt4tars_path . '/4.png';
	if (empty($_POST ['slayt4'])) {
            if (copy($file, $newfile)) {
                $doc->msg(__('So`rovingiz mufoqatli amalga oshirildi'));
                $doc->ret(__('Fo`to`ga'), '?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name));
                $doc->ret(__('Albo`m %s', $album->name), 'photos.php?id=' . $ank->id . '&amp;album=' . urlencode($album->name));
                $doc->ret(__('%s albo`mi', $ank->login), 'albums.php?id=' . $ank->id);
                header('Refresh: 1; url=?id=' . $ank->id . '&album=' . urlencode($album->name) . '&photo=' . urlencode($photo->name) . '&' . passgen());
                exit();
            } else {

                $doc->err(__('O`rnatilmadi'));
                $doc->ret(__('Fo`to`ga'), '?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name));
                $doc->ret(__('Albo`m %s', $album->name), 'photos.php?id=' . $ank->id . '&amp;album=' . urlencode($album->name));
                $doc->ret(__('%s albo`mi', $ank->login), 'albums.php?id=' . $ank->id);
                header('Refresh: 1; url=?id=' . $ank->id . '&album=' . urlencode($album->name) . '&photo=' . urlencode($photo->name) . '&' . passgen());
            }
            exit();
        }	
	
	}

// modul 5


    if (!empty($_GET ['act']) && $_GET ['act'] === 'slayt5') {
$slayt5tar_file_name = '5.png';
$slayt5tars_path = FILES . '/.modul'; 
$slayt5tars_dir = new files($slayt5tars_path);
$file = $albums_path . '/' . $album_name . '/' . $photo_name;
$newfile = $slayt5tars_path . '/5.png';
	if (empty($_POST ['slayt5'])) {
            if (copy($file, $newfile)) {
                $doc->msg(__('So`rovingiz mufoqatli amalga oshirildi'));
                $doc->ret(__('Fo`to`ga'), '?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name));
                $doc->ret(__('Albo`m %s', $album->name), 'photos.php?id=' . $ank->id . '&amp;album=' . urlencode($album->name));
                $doc->ret(__('%s albo`mi', $ank->login), 'albums.php?id=' . $ank->id);
                header('Refresh: 1; url=?id=' . $ank->id . '&album=' . urlencode($album->name) . '&photo=' . urlencode($photo->name) . '&' . passgen());
                exit();
            } else {

                $doc->err(__('O`rnatilmadi'));
                $doc->ret(__('Fo`to`ga'), '?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name));
                $doc->ret(__('Albo`m %s', $album->name), 'photos.php?id=' . $ank->id . '&amp;album=' . urlencode($album->name));
                $doc->ret(__('%s albo`mi', $ank->login), 'albums.php?id=' . $ank->id);
                header('Refresh: 1; url=?id=' . $ank->id . '&album=' . urlencode($album->name) . '&photo=' . urlencode($photo->name) . '&' . passgen());
            }
            exit();
        }	
	
	} 
	// modul 6


    if (!empty($_GET ['act']) && $_GET ['act'] === 'slayt6') {
$slayt6tar_file_name = '6.png';
$slayt6tars_path = FILES . '/.modul'; 
$slayt6tars_dir = new files($slayt6tars_path);
$file = $albums_path . '/' . $album_name . '/' . $photo_name;
$newfile = $slayt6tars_path . '/6.png';
	if (empty($_POST ['slayt6'])) {
            if (copy($file, $newfile)) {
                $doc->msg(__('So`rovingiz mufoqatli amalga oshirildi'));
                $doc->ret(__('Fo`to`ga'), '?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name));
                $doc->ret(__('Albo`m %s', $album->name), 'photos.php?id=' . $ank->id . '&amp;album=' . urlencode($album->name));
                $doc->ret(__('%s albo`mi', $ank->login), 'albums.php?id=' . $ank->id);
                header('Refresh: 1; url=?id=' . $ank->id . '&album=' . urlencode($album->name) . '&photo=' . urlencode($photo->name) . '&' . passgen());
                exit();
            } else {

                $doc->err(__('O`rnatilmadi'));
                $doc->ret(__('Fo`to`ga'), '?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name));
                $doc->ret(__('Albo`m %s', $album->name), 'photos.php?id=' . $ank->id . '&amp;album=' . urlencode($album->name));
                $doc->ret(__('%s albo`mi', $ank->login), 'albums.php?id=' . $ank->id);
                header('Refresh: 1; url=?id=' . $ank->id . '&album=' . urlencode($album->name) . '&photo=' . urlencode($photo->name) . '&' . passgen());
            }
            exit();
        }	
	
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
    if (!empty($_GET ['act']) && $_GET ['act'] === 'delete') {

        if (!empty($_POST ['delete'])) {
            if (empty($_POST ['captcha']) || empty($_POST ['captcha_session']) || !captcha::check($_POST ['captcha'], $_POST ['captcha_session']))
                $doc->err(__('Raqam to`gri holatda kiritilmadi'));
            elseif ($photo->delete()) {
                $doc->msg(__('foto o`chirildi'));
                $doc->ret(__('Albom %s', $album->name), 'photos.php?id=' . $ank->id . '&amp;album=' . urlencode($album->name));
                $doc->ret(__('Albomga %s', $ank->nick), 'albums.php?id=' . $ank->id);
                header('Refresh: 1; url=photos.php?id=' . $ank->id . '&album=' . urlencode($album->name) . '&' . passgen());
                exit();
            } else {

                $doc->err(__('iloji bo`lmadi o`chirishga'));
                $doc->ret(__('Fo`to`nga'), '?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name));
                $doc->ret(__('Albom %s', $album->name), 'photos.php?id=' . $ank->id . '&amp;album=' . urlencode($album->name));
                $doc->ret(__('Albomga %s', $ank->login), 'albums.php?id=' . $ank->id);
                header('Refresh: 1; url=?id=' . $ank->id . '&album=' . urlencode($album->name) . '&photo=' . urlencode($photo->name) . '&' . passgen());
            }
            exit();
        }

        $smarty = new design ();
        $smarty->assign('method', 'post');
        $smarty->assign('action', '?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name) . '&amp;act=delete&amp;' . passgen());
        $elements = array();
        $elements [] = array('type' => 'captcha', 'session' => captcha::gen(), 'br' => 1);
        $elements [] = array('type' => 'submit', 'br' => 0, 'info' => array('name' => 'delete', 'value' => __('Fo`to`ni o`chirish'))); // кнопка
        $smarty->assign('el', $elements);
        $smarty->display('input.form.tpl');

        $doc->ret(__('Fo`to`nga'), '?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name));
        $doc->ret(__('Albomga %s', $album->name), 'photos.php?id=' . $ank->id . '&amp;album=' . urlencode($album->name));
        $doc->ret(__('Albomga %s', $ank->login), 'albums.php?id=' . $ank->id);
        exit();
    }
    $doc->act(__('Modul "1"'), '?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name) . '&amp;act=slayt1');
    $doc->act(__('Modul "2"'), '?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name) . '&amp;act=slayt2');
    $doc->act(__('Modul "3"'), '?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name) . '&amp;act=slayt3');
    $doc->act(__('Modul "4"'), '?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name) . '&amp;act=slayt4');
    $doc->act(__('Modul "5"'), '?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name) . '&amp;act=slayt5');
    $doc->act(__('Modul "6"'), '?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name) . '&amp;act=slayt6');
    
	$doc->act(__('Slaytka o`tish'), 'photo.php?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name) . '');
    $doc->act(__('Fo`to`ni o`chirish'), '?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name) . '&amp;act=delete');
}

if ($screen = $photo->getScreen($doc->img_max_width(), 0)) {
    echo "<img class='UZCMS_photo' src='" . $screen . "' alt='" . __('Фото') . " " . text::toValue($photo->runame) . "' /><br />\n";
}

$can_write = true;
if (!$user->is_writeable) {
    $doc->err(__('Siz %s Soatdan kegin sharh yoza olas', $uzcms->user_write_limit_hour));
    $can_write = false;
}

if ($can_write) {




    if (isset($_POST ['send']) && isset($_POST ['message']) && $user->group) {
        $message = text::input_text($_POST ['message']);

        if ($photo->id_user && $photo->id_user != $user->id && (empty($_POST ['captcha']) || empty($_POST ['captcha_session']) || !captcha::check($_POST ['captcha'], $_POST ['captcha_session'])))
            $doc->err(__('Raqam to`gri holatda kiritilmadi'));
        elseif ($uzcms->censure && $mat = is_valid::mat($message))
            $doc->err(__('ZIT: %s', $mat));
        elseif ($message) {
            $user->balls++;
            mysql_query("INSERT INTO `files_comments` (`id_file`, `id_user`, `time`, `text`) VALUES ('$photo->id','$user->id', '" . TIME . "', '" . my_esc($message) . "')");
            $doc->msg(__('Sharh qoldirildi'));
            $photo->comments++;

            if ($photo->id_user && $photo->id_user != $user->id) { 
                $ank->mess("$user->login оставил" . ($user->sex ? '' : 'а') . " sizning fotoyingizga sharh qoldirildi [url=/foto/menu.php?id=$ank->id&album=$album->name&photo=$photo->name]{$photo->runame}[/url]");
            }
        } else {
            $doc->err(__('Sharh bo`sh'));
        }
    }

if ($user->group) {
        $smarty = new design ();
        $smarty->assign('method', 'post');
        $smarty->assign('action', '?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name) . '&amp;' . passgen());
        $elements = array();
        $elements [] = array('type' => 'textarea', 'title' => __('Sharh'), 'br' => 1, 'info' => array('name' => 'message'));

        if ($photo->id_user && $photo->id_user != $user->id)
            $elements [] = array('type' => 'captcha', 'session' => captcha::gen(), 'br' => 1);

        $elements [] = array('type' => 'submit', 'br' => 0, 'info' => array('name' => 'send', 'value' => __('Yuborish'))); 
        $smarty->assign('el', $elements);
        $smarty->display('input.form.tpl');
    }
}
if (!empty($_GET ['delete_comm']) && $user->group >= $photo->group_edit) {
    $delete_comm = (int) $_GET ['delete_comm'];
    if (mysql_result(mysql_query("SELECT COUNT(*) FROM `files_comments` WHERE `id` = '$delete_comm' AND `id_file` = '$photo->id' LIMIT 1"), 0)) {
        mysql_query("DELETE FROM `files_comments` WHERE `id` = '$delete_comm' LIMIT 1");
        $photo->comments--;
        $doc->msg(__('Sharh o`chirildi'));
    } else
        $doc->err(__('Sharh o`chirilgan'));
}

$pages = new pages ();
$pages->posts = mysql_result(mysql_query("SELECT COUNT(*) FROM `files_comments` WHERE `id_file` = '$photo->id'"), 0); // количество сообщений
$q = mysql_query("SELECT * FROM `files_comments` WHERE `id_file` = '$photo->id' ORDER BY `id` DESC LIMIT ".$pages->limit);

$listing = new listing();
while ($comment = mysql_fetch_assoc($q)) {
    $ank2 = new user($comment ['id_user']);
    $post = $listing->post();

    $post->title = $ank2->nick();
    $post->time = misc::when($comment ['time']);
    $post->icon($ank2->icon());
    $post->content = text::toOutput($comment ['text']);

    if ($user->group >= $photo->group_edit) {
        $post->action('delete', '?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name) . '&amp;delete_comm=' . $comment ['id']);
    }
}
$listing->display(__('Sharhlar yo`q'));

$pages->display('?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;photo=' . urlencode($photo->name) . '&amp;'); 


$doc->ret(__('Albomga %s', $album->runame), 'photos.php?id=' . $ank->id . '&amp;album=' . urlencode($album->name));
$doc->ret(__('Albomgaы %s', $ank->login), 'albums.php?id=' . $ank->id);