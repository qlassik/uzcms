<?php

include_once '../sys/inc/yadro.php';
$doc = new document ();
$doc->title = __('Fo`to`albom');


if (!empty($_GET ['id'])) {
    $ank = new user((int)$_GET ['id']);
} else {
    $ank = $user;
}

if (!$ank->group) {
    $doc->access_denied(__('Qandaydir xato bor'));
}

$photos = new files(FILES . '/.foto');
$albums_path = FILES . '/.foto/' . $ank->id;

if (!@is_dir($albums_path)) {
    if (!$albums_dir = $photos->mkdir($ank->login, $ank->id)) {
        $doc->access_denied(__('Sizda daraja yo`q yoki ro`yhatdan otib korin'));
    }
    $albums_dir->group_show = 0;
    $albums_dir->group_write = max($ank->group, 2);
    $albums_dir->group_edit = max($ank->group, 4);
    $albums_dir->id_user = $ank->id;
    unset($albums_dir);
}

$albums_dir = new files($albums_path);

if (empty($_GET ['album']) || !$albums_dir->is_dir($_GET ['album'])) {
    $doc->err(__('Bunday albom yoq'));
    $doc->ret(__('Albomga %s', $name), 'albums.php?id=' . $ank->id);
    header('Refresh: 1; url=albums.php?id=' . $ank->id);
    exit();
}

$album_name = (string)$_GET ['album'];
$album = new files($albums_path . '/' . $album_name);
$doc->title = $album->runame;

$doc->description = __('Fo`to`albom %s:%s foydalanuvchiniki', $ank->title, $album->runame);
$doc->keywords [] = $album->runame;
$doc->keywords [] = $ank->title;

if (!empty($_GET ['act']) && $ank->id == $user->id) {
    switch ($_GET ['act']) {
        case 'prop' :
            $doc->title .= ' - ' . __('Sozlama');

            $doc->ret(__('Albomga'), '?id=' . $ank->id . '&amp;album=' . urlencode($album->name));
            exit();
        case 'photo_add' :
            $doc->title .= ' - ' . __('Foto yuklash');

            if (!empty($_FILES ['file'])) {
                if (preg_match('/\\.(jpg|png|gif|jepg)$/i', text::for_filename($_FILES ['file'] ['name']))) {
    if (!$img = @imagecreatefromjpeg($_FILES ['file'] ['tmp_name']) || !$img = @imagecreatefromgif($_FILES ['file'] ['tmp_name']) || !$img = @imagecreatefrompng($_FILES ['file'] ['tmp_name'])) {
        $doc->err(__('Rasim farmatda emas'));
    }elseif ($_FILES ['file'] ['error']) {
                    $doc->err(__('Yuklashda hatolik bor'));
                } elseif (!$_FILES ['file'] ['size']) {
                    $doc->err(__('Fayl yo`q'));
                } else {
                    if ($files_ok = $album->filesAdd(array($_FILES ['file'] ['tmp_name'] => $_FILES ['file'] ['name']))) {
                        $files_ok [$_FILES ['file'] ['tmp_name']]->username = $user->username;
                        $files_ok [$_FILES ['file'] ['tmp_name']]->userfam = $user->userfam;
                        $files_ok [$_FILES ['file'] ['tmp_name']]->runame = $_POST['runame'];						
                        $files_ok [$_FILES ['file'] ['tmp_name']]->unvon = '0';
						$files_ok [$_FILES ['file'] ['tmp_name']]->id_user = $user->id;
                        $files_ok [$_FILES ['file'] ['tmp_name']]->group_edit = max($ank->group, $album->group_write, 4);
                        $album->kirdi = $album->kirdi + 1;
                        unset($files_ok);
                        $doc->msg(__('Foto albomga "%s" qo`shildi', $_FILES ['file'] ['name']));
						//header('Refresh: 1; url=/foto/photo.php?id=' . $user->id . '&album=' . $album->name.'&photo= '.urlencode($_FILES ['file'] ['name']));
						header('Refresh: 1; url=/foto/photos.php?id=' . $user->id . '&album=' . $album->name);
						
            } else {
                        $doc->err(__('Iloji yo`q fayl saqlashga'));
                    }
                }
            }
			}
			$smarty = new design ();
            $smarty->assign('method', 'post');
            $smarty->assign('files', 1);
            $smarty->assign('action', '?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;act=photo_add&amp;' . passgen());
            $elements = array();
            $elements [] = array('type' => 'input_text', 'title' => __('Fo`to nomi') . ' (*.jpg, png, gif)', 'br' => 1, 'info' => array('name' => 'runame'));
            $elements [] = array('type' => 'file', 'info' => array('name' => 'file'));
            $elements [] = array('type' => 'submit', 'br' => 0, 'info' => array('value' => __('Yuklash')));
            $smarty->assign('el', $elements);
            $smarty->display('input.form.tpl');

            $doc->kor(__('Albomga'), '?id=' . $ank->id . '&amp;album=' . urlencode($album->name));
            exit();
        case 'delete' :
            $doc->title .= ' - '.__('O`chirish').'';

            if (!empty($_POST ['delete'])) {

                if (empty($_POST ['captcha']) || empty($_POST ['captcha_session']) || !captcha::check($_POST ['captcha'], $_POST ['captcha_session']))
                    $doc->err(__('Raqam to`gri holatda kiritilmadi'));
                elseif ($album->delete()) {
                    $doc->msg(__('Fo`to`albomni o`chirildi'));
                    $doc->ret(__('Fo`to`albomi %s', $ank->title), 'albums.php?id=' . $ank->id);
                    header('Refresh: 1; url=albums.php?id=' . $ank->id . '&' . passgen());
                } else {

                    $doc->err(__('iloji bo`lmadi Fo`to`albomni o`chirish'));
                    $doc->ret(__('Albomga'), '?id=' . $ank->id . '&amp;album=' . urlencode($album->name));
                    $doc->ret(__('Fo`to`albomi %s', $ank->title), 'albums.php?id=' . $ank->id);
                    header('Refresh: 1; url=?id=' . $ank->id . '&album=' . urlencode($album->name) . '&' . passgen());
                }

                exit();
            }

            $smarty = new design ();
            $smarty->assign('method', 'post');
            $smarty->assign('action', '?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;act=delete&amp;' . passgen());
            $elements = array();
            $elements [] = array('type' => 'captcha', 'session' => captcha::gen(), 'br' => 1);
            $elements [] = array('type' => 'submit', 'br' => 0, 'info' => array('name' => 'delete', 'value' => __('Fo`to`albomni o`chirish'))); 
            $smarty->assign('el', $elements);
            $smarty->display('input.form.tpl');

            $doc->kor(__('Albomga'), '?id=' . $ank->id . '&amp;album=' . urlencode($album->name));
            exit();
    } 
}

$list = $album->getList('time_add:desc'); 
$files = $list ['files']; 

$pages = new pages ();
$pages->posts = count($files);
$pages->this_page();
$start = $pages->my_start();
$end = $pages->end();

echo '<div style="margin-top: 10px; margin-left: 10px;">';

$listing = new listing();
for ($i = $start; $i < $end && $i < $pages->posts; $i++) {
    $fotos = $listing->fotos();
    if($files [$i]->image()){
	$fotos->image = $files [$i]->image();
    }else{
	$fotos->image = '/files/.foto/'.$ank->id.'/'. urlencode($album->name) . '/'.$files [$i]->name;
	}	
	$fotos->url = "photo.php?id=$ank->id&amp;album=" . urlencode($album->name) . "&amp;photo=" . urlencode($files [$i]->name);
    $fotos->title = text::toValue($files [$i]->runame);
    $fotos->admine = $files [$i]->unvon;	



  //  $fotos->content = text::toOutput($fotos->content);
}
$listing->display(__('Fo`to`albom yo`q'));
echo '</div>';
$pages->display('?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;');


if ($ank->id == $user->id) {
    $doc->kor(__('Fo`to` yuklash'), '?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;act=photo_add');
    $doc->kor(__('Sozlama'), '?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;act=prop');
    $doc->kor(__('Fo`to`albomni o`chirish'), '?id=' . $ank->id . '&amp;album=' . urlencode($album->name) . '&amp;act=delete');
}

$doc->ret(__('Fo`to`albomi %s', $ank->nick), 'albums.php?id=' . $ank->id);