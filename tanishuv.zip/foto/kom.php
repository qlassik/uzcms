<?php
include_once '../../sys/inc/yadro.php';
$doc = new document(1);


$doc -> title = __('Statuslar');
if (isset($_GET['ochir'])){
$us=mysql_fetch_assoc(mysql_query("SELECT * FROM `status` WHERE `id` = '".intval($_GET['ochir'])."' LIMIT 1"));
if ($user->id == $us['id_user']){
$aaaa = (int) $_GET['ochir'] ;
$us=mysql_fetch_assoc(mysql_query("SELECT * FROM `status` WHERE `id` = '".intval($_GET['ochir'])."' LIMIT 1"));
$us = mysql_fetch_assoc($q);
mysql_query("DELETE FROM `status` WHERE `id` = '$aaaa' LIMIT 1");
$doc->msg(__('O`chirildi'));
header("Location: /user/status/");
exit;
}else{
	$doc->msg('Hakkerlik qilmang kuchiz etmaydi');
}
}

if (isset($_GET['reset'])){
$us=mysql_fetch_assoc(mysql_query("SELECT * FROM `status` WHERE `id` = '".intval($_GET['reset'])."' LIMIT 1"));

mysql_query("UPDATE `status` SET `pokaz` = '0' WHERE `id_user` = '$user->id'");
if ($user->id == $us['id_user']){
mysql_query("UPDATE `status` SET `pokaz` = '1' WHERE `id` = '".$us['id']."'");
header("Location: /user/status/");
exit;
}else{
	msg('Hakkerlik qilmang kuchiz etmaydi');
}
}
$pages = new pages(mysql_result(mysql_query("SELECT COUNT(*) FROM `status`"), 0));
$listing = new listing();
$q = mysql_query("SELECT * FROM `status` WHERE `id_user` = '$user->id' ORDER BY `time` DESC LIMIT ".$pages->limit);

while ($us = mysql_fetch_assoc($q)) {

$ank = new user($us['id_user']);
$post = $listing->post();
$post->url = 'komp.php?=id'.$us['id'].'';
$post->time = misc::when($us['time']);
$post->title = text::toOutput($us['msg']);
if ($us['pokaz'] == 1){
$post->action('approve', '?reset=' . urlencode(''.$us['id'].'') . '&amp;' . passgen());
}else{
$post->action('guest', '?reset=' . urlencode(''.$us['id'].'') . '&amp;' . passgen());
}
$post->action('delete', '?ochir=' . urlencode(''.$us['id'].'') . '&amp;' . passgen());
}

$listing->display(__('Ro`yhat bo`sh'));
$user->status = '';
         
$pages->this_page();

$pages->display('?');
    $doc->act(__('Tozalash'), 'delete_all.php');
?>
