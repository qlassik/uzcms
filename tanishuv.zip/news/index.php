<?php

include_once '../sys/inc/yadro.php';
$doc = new document();

$doc->title = __('Bizning yangilik');

$pages = new pages;
$pages->posts = mysql_result(mysql_query("SELECT COUNT(*) FROM `news`"), 0);
$pages->this_page(); 

$q = mysql_query("SELECT * FROM `news` ORDER BY `id` DESC LIMIT $pages->limit");


$listing = new listing();
while ($news = mysql_fetch_assoc($q)) {
    $post = $listing->post();
    $ank = new user((int) $news['id_user']);


    $post->icon('news');
    $post->content = text::toOutput($news['text']);
    $post->title = text::toValue($news['title']);
    $post->url = 'comments.php?id=' . $news['id'];
    $post->time = misc::when($news['time']);
    $post->bottom = '<a href="/ID' . $news['id_user'] . '">' . $ank->nick() . '</a>';

    if ($user->group >= max($ank->group, 4)) {
        if (!$news['sended']) {
            $post->action('send', "news.send.php?id=$news[id]");
        }
        $post->action('edit', "news.edit.php?id=$news[id]");
        $post->action('delete', "news.delete.php?id=$news[id]"); 
    }
}

$listing->display(__('Yangilik yo`q'));

$pages->display('?'); 

if ($user->group >= 4) {
    $doc->act(__('Yangilik qo`shish'), 'news.add.php');
}
?>
