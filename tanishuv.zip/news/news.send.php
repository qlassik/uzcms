<?php

include_once '../sys/inc/yadro.php';
$doc = new document(4);
$doc->title = __('Рассылка Yangilik');
$doc->ret(__('Yangilikka qaytish'), './');

$id = (int)@$_GET['id'];

$q = mysql_query("SELECT * FROM `news` WHERE `id` = '$id' LIMIT 1");

if (!mysql_num_rows($q))
    $doc->access_denied(__('Yangilik topilmadi yoki o`chirilgan'));

$news = mysql_fetch_assoc($q);

$ank = new user($news['id_user']);

if ($ank->group > $user->group)
    $doc->access_denied(__('Holad mavjud emas'));
if ($news['sended'])
    $doc->access_denied(__('Yangilik faol'));

if (isset($_POST['send'])) {
    if (empty($_POST['captcha']) || empty($_POST['captcha_session']) || !captcha::check($_POST['captcha'], $_POST['captcha_session'])) {
        $doc->err(__('Raqam to`gri holatda kiritilmadi'));
    } else {
        $mail_unsubscribe = array();
        $q = mysql_query("SELECT * FROM `mail_unsubscribe`");
        while ($mu = mysql_fetch_assoc($q)) {
            $mail_unsubscribe[$mu['email']] = (bool)$mu['code'];
        }

        $mailes = array();

        $q = mysql_query("SELECT `reg_mail`, `email` FROM `users` ORDER BY `id`");

        while ($um = mysql_fetch_assoc($q)) {
            if ($um['reg_mail']) {
                $mailes[] = $um['reg_mail'];
            } elseif ($um['email'] && !empty($_POST['sendToAnkMail'])) {
                $mailes[] = $um['email'];
            }
        }

        $mailes_to_send = array();
        for ($i = 0; $i < count($mailes); $i++) {
            if (array_key_exists($mailes[$i], $mail_unsubscribe)) {
                if (!$mail_unsubscribe[$mailes[$i]]) {
                    continue;
                }
            }
            $mailes_to_send[] = $mailes[$i];
        }

        $mailes_to_send = array_unique($mailes_to_send);

        if ($mailes_to_send) {
            $to_unsubscribe_table = array();
            $contents = array();
            for ($i = 0; $i < count($mailes_to_send); $i++) {
                if (array_key_exists($mailes_to_send[$i], $mail_unsubscribe)) {
                    $unsubscribe_code = $mail_unsubscribe[$mailes_to_send[$i]];
                } else {
                    $unsubscribe_code = passgen(32);
                    $to_unsubscribe_table[$mailes_to_send[$i]] = $unsubscribe_code;
                }

                $t = new design();
                $t->assign('title', 'Yangilik');
                $t->assign('site', $uzcms->sitename);
                $t->assign('content', text::toOutput($news['text']));
                $t->assign('email', $mailes_to_send[$i]);
                $t->assign('unsubscribe', 'http://' . $_SERVER['HTTP_HOST'] . '/email.html?code=' . $unsubscribe_code);
                $contents[] = $t->fetch('file:' . H . '/style/otp/mail.news.tpl');
            }
            mail::send($mailes_to_send, $news['title'], $contents);
            mysql_query("UPDATE `news` SET `sended` = '1' WHERE `id` = '$id' LIMIT 1");

            foreach ($to_unsubscribe_table AS $email => $code) {
                mysql_query("INSERT INTO `mail_unsubscribe` (`email`, `code`) VALUES ('" . my_esc($email) . "', '" . my_esc($code) . "')");
            }

                $doc->msg(__('Yangilik yuborildi'));
        } else {
            $doc->err(__('Holat bo`ycha'));
        }
        
        exit;
    }
}

$smarty = new design();
$smarty->assign('method', 'post');
$smarty->assign('action', '?id=' . $id . '&amp;' . passgen());
$elements = array();
$elements [] = array('type' => 'checkbox', 'br' => 1, 'info' => array('value' => 1, 'name' => 'sendToAnkMail', 'text' => __('Email adres bo`ycha') . '*'));
$elements [] = array('type' => 'text', 'br' => 1, 'value' => '* ' . __('Email bor foydalanuvchilarga yuborilsin'));
$elements[] = array('type' => 'captcha', 'session' => captcha::gen(), 'br' => 1);
$elements[] = array('type' => 'submit', 'br' => 0, 'info' => array('name' => 'send', 'value' => __('Yangilik  Emaillar uchun'))); 
$smarty->assign('el', $elements);
$smarty->display('input.form.tpl');
