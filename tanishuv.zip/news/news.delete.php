<?php

include_once '../sys/inc/yadro.php';
$doc = new document(4);
$doc->title = __('Yangilikni o`chirish');
$doc->ret(__('Yangilikka qaytish'), './');

$id = (int) @$_GET['id'];

$q = mysql_query("SELECT * FROM `news` WHERE `id` = '$id' LIMIT 1");

if (!mysql_num_rows($q))
    $doc->access_denied(__('Yangilik topilmadi yoki o`chirilgan'));

$news = mysql_fetch_assoc($q);

$ank = new user($news['id_user']);

if ($ank->group > $user->group)
    $doc->access_denied(__('holat mavjud emas'));

if (isset($_POST['delete'])) {
    if (empty($_POST['captcha']) || empty($_POST['captcha_session']) || !captcha::check($_POST['captcha'], $_POST['captcha_session'])) {
        $doc->err(__('Raqam to`gri holatda kiritilmadi'));
    } else {
        mysql_query("DELETE FROM `news` WHERE `id` = '$id' LIMIT 1");
        mysql_query("DELETE FROM `news_comments` WHERE `id_news` = '$id'");
        $doc->msg(__('Yangilik o`chirildiа'));
        header('Refresh: 1; url=./');
        exit;
    }
}

$smarty = new design();
$smarty->assign('method', 'post');
$smarty->assign('action', '?id=' . $id . '&amp;' . passgen());
$elements = array();
$elements[] = array('type' => 'captcha', 'session' => captcha::gen(), 'br' => 1);
$elements[] = array('type' => 'text', 'value' => '* ' . text::toOutput(__('Yangilik "%s" ochirilyapti', $news['title'])), 'br' => 1);
$elements[] = array('type' => 'submit', 'br' => 0, 'info' => array('name' => 'delete', 'value' => __('O`chirish'))); 
$smarty->assign('el', $elements);
$smarty->display('input.form.tpl');
?>
