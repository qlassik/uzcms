<?php

include_once '../sys/inc/yadro.php';
$doc = new document();
$doc->title = __('Forum');
$doc->dost(__('Katigoryaga'), './');
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Refresh: 1; url=./');
    $doc->err(__('Bu ID bo`ycha Katigorya'));
    exit;
}
$id_cat = (int) $_GET['id'];

$q = mysql_query("SELECT * FROM `forum_categories` WHERE `id` = '$id_cat' AND `group_show` <= '$user->group'");

if (!mysql_num_rows($q)) {
    header('Refresh: 1; url=./');
    $doc->err(__('Katigorya joylashmagan'));
    exit;
}

$category = mysql_fetch_assoc($q);

$doc->title .= ' - ' . $category['name'];

$pages = new pages;
$pages->posts = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum_topics` WHERE `id_category` = '$category[id]' AND `group_show` <= '$user->group'"), 0); // количество категорий форума

$q = mysql_query("SELECT * FROM `forum_topics` WHERE `id_category` = '$category[id]' AND `group_show` <= '$user->group' ORDER BY `time_last` DESC LIMIT ".$pages->limit);

$listing = new listing();
while ($topics = mysql_fetch_assoc($q)) {
    $post = $listing->post();
    $post->icon('forum.topic.png');
    $post->title = text::toValue($topics['name']);
    $post->content = text::for_opis($topics['description']);
    $post->url = "topic.php?id={$topics['id']}";
}
$listing->display(__('Sizda daraja  yo`q'));


$pages->display('?id=' . $id_cat . '&amp;'); // вывод страниц

if ($category['group_write'] <= $user->group) {
    $doc->grp(__('Bo`lim yaratish'), 'topic.new.php?id_category=' . $category['id'] . "&amp;return=" . URL);
}
if ($category['group_edit'] <= $user->group) {
    $doc->grp(__('Sozlama Katigorya'), 'category.edit.php?id=' . $category['id'] . "&amp;return=" . URL);
}