<?php

include_once '../sys/inc/yadro.php';
$doc = new document();

$doc->title = __('O`chiriladigan Katigorya');

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Refresh: 1; url=./');
    $doc->err(__('Bu ID bo`ycha Katigorya'));
    $doc->dost(__('Forum'), './');
    exit;
}
$id_category = (int) $_GET['id'];

$q = mysql_query("SELECT * FROM `forum_categories` WHERE `id` = '$id_category' AND `group_edit` <= '$user->group'");

if (!mysql_num_rows($q)) {
    header('Refresh: 1; url=./');
    $doc->err(__('Katigorya joylashmagan'));
    $doc->dost(__('Forum'), './');
    exit;
}

$category = mysql_fetch_assoc($q);
$doc->title = __('O`chiriladigan Katigorya "%s"', $category['name']);

if (isset($_POST['delete'])) {
    if (empty($_POST['captcha']) || empty($_POST['captcha_session']) || !captcha::check($_POST['captcha'], $_POST['captcha_session'])) {
        $doc->err(__('Raqam to`gri holatda kiritilmadi'));
    } else {
     
        $q = mysql_query("SELECT `id` FROM `forum_themes` WHERE `id_category` = '$category[id]'");
        while ($theme = mysql_fetch_assoc($q)) {
            $dir = new files(FILES . '/.forum/' . $theme['id']);
            $dir->delete();
            unset($dir);
        }

        mysql_query("DELETE
FROM `forum_topics`, `forum_themes` , `forum_messages`, `forum_history`, `forum_files`, `forum_vote`, `forum_vote_votes`
USING `forum_topics`
LEFT JOIN `forum_themes` ON `forum_themes`.`id_topic` = `forum_topics`.`id`
LEFT JOIN `forum_messages` ON `forum_messages`.`id_topic` = `forum_topics`.`id`
LEFT JOIN `forum_history` ON `forum_history`.`id_message` = `forum_messages`.`id`
LEFT JOIN `forum_files` ON `forum_files`.`id_topic` = `forum_topics`.`id`
LEFT JOIN `forum_vote` ON `forum_vote`.`id_theme` = `forum_themes`.`id`
LEFT JOIN `forum_vote_votes` ON `forum_vote_votes`.`id_theme` = `forum_themes`.`id`
LEFT JOIN `forum_views` ON `forum_vote_votes`.`id_theme` = `forum_themes`.`id`
WHERE `forum_topics`.`id_category` = '$category[id]'");

        mysql_query("DELETE FROM `forum_categories` WHERE `id` = '$category[id]' LIMIT 1");
     
        header('Refresh: 1; url=./');
        $uzcms->log('Forum', 'O`chiriladigan Katigorya "' . $category['name'] . '"');
        $doc->msg(__('Katigorya o`chirildiа'));
        $doc->dost(__('Forum'), './');
        exit;
    }
}

$form = new form("?id=$category[id]&amp;" . passgen() . (isset($_GET['return']) ? '&amp;return=' . urlencode($_GET['return']) : null));
$form->captcha();
$form->button(__('O`chirish'), 'delete');
$form->display();

$doc->grp(__('Sozlama Katigorya'), 'category.edit.php?id=' . $category['id']);
$doc->dost(__('Katigoryaga'), 'category.php?id=' . $category['id']);
$doc->dost(__('Forum'), './');
?>