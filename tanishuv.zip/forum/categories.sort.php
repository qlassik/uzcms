<?php

include_once '../sys/inc/yadro.php';
$doc = new document();
$doc->title = __('Toifasi boycha o`zgartirish');


if (isset($_GET['sortable'])) {

    $sort = explode(',', $_POST['sortable']);
    $q = mysql_query("SELECT * FROM `forum_categories` WHERE `group_show` <= '$user->group' ORDER BY `position` ASC");
    while ($category = mysql_fetch_assoc($q)) {
        if (($position = array_search('cid' . $category['id'], $sort)) !== false) {
            mysql_query("UPDATE `forum_categories` SET `position` = '$position' WHERE `id` = '{$category['id']}'");
        }
    }

    $doc->clean();
    header('Content-type: application/json');
    echo json_encode(array('result' => 1, 'description' => __('Ketma ketligi bilan joylash успешно сохранен')));
    exit;
}

if (!empty($_GET['id']) && !empty($_GET['act'])) {
    $sort = array();
    $q = mysql_query("SELECT * FROM `forum_categories` WHERE `group_show` <= '$user->group' ORDER BY `position` ASC");
    while ($category = mysql_fetch_assoc($q)) {
        $sort[$category['id']] = $category['id'];
    }

    switch ($_GET['act']) {
        case 'up':
            if (misc::array_key_move($sort, $_GET['id'], -1)) {
                $doc->msg(__('Kategoriya muvaffaqiyatli tepaga ko`tarildi'));
            } else
                $doc->err(__('Kategoriya muvaffaqiyatli tepaga ko`tarilgan'));
            break;

        case 'down':
            if (misc::array_key_move($sort, $_GET['id'], 1)) {

                $doc->msg(__('Kategoriya muvaffaqiyatli pastga ko`tushdi'));
            } else
                $doc->err(__('Kategoriya muvaffaqiyatli pastga ko`tushgan'));

            break;
    }

    $q = mysql_query("SELECT * FROM `forum_categories` WHERE `group_show` <= '$user->group' ORDER BY `position` ASC");
    while ($category = mysql_fetch_assoc($q)) {
        if (($position = array_search('cid' . $category['id'], $sort)) !== false) {
            mysql_query("UPDATE `forum_categories` SET `position` = '$position' WHERE `id` = '{$category['id']}'");
        }
    }

    $doc->dost('Orqaga qaytish', '?' . passgen());
    header('Refresh: 1; url=?' . passgen());
    exit;
}

$listing = new listing();
$q = mysql_query("SELECT * FROM `forum_categories` WHERE `group_show` <= '$user->group' ORDER BY `position` ASC");
while ($category = mysql_fetch_assoc($q)) {
    $post = $listing->post();
    $post->id = 'cid' . $category['id'];
    $post->title = text::toValue($category['name']);
    $post->icon('forum.category');
    $post->post = text::for_opis($category['description']);

    $post->action('up', '?id=' . $category['id'] . '&amp;act=up');
    $post->action('down', '?id=' . $category['id'] . '&amp;act=down');
}
$listing->sortable = '?sortable';
$listing->display(__('Bu katigoryaga darajangiz etmaydi'));

$doc->dost(__('Forum'), 'index.php');