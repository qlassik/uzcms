<?php

include_once '../sys/inc/yadro.php';
$groups = groups::load_ini(); 
$doc = new document();
$doc->title = __('Katigoryani sozlash');

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Refresh: 1; url=./');
    $doc->err(__('Bu ID bo`ycha'));
    exit;
}
$id_category = (int) $_GET['id'];

$q = mysql_query("SELECT * FROM `forum_categories` WHERE `id` = '$id_category' AND `group_edit` <= '$user->group'");

if (!mysql_num_rows($q)) {
    header('Refresh: 1; url=./');
    $doc->err(__('Katigorya joylashmagan'));
    exit;
}

$category = mysql_fetch_assoc($q);

if (isset($_POST['save'])) {
    if (isset($_POST['name']) && isset($_POST['description'])) {
        $name = text::for_name($_POST['name']);
        $description = text::input_text($_POST['description']);

        if ($name && $name != $category['name']) {
            $uzcms->log('Forum', 'Изменение названия Katigorya "' . $category['name'] . '" на [url=/forum/category.php?id=' . $category['id'] . ']"' . $name . '"[/url]');
            $category['name'] = $name;
            mysql_query("UPDATE `forum_categories` SET `name` = '" . my_esc($category['name']) . "' WHERE `id` = '$category[id]' LIMIT 1");
            $doc->msg(__('Katigorya nomi yuklatildi'));
        }

        if ($description != $category['description']) {
            $category['description'] = $description;
            mysql_query("UPDATE `forum_categories` SET `description` = '" . my_esc($category['description']) . "' WHERE `id` = '$category[id]' LIMIT 1");
            $doc->msg(__('Tafsif Katigorya yuklatildi'));
            $uzcms->log('Forum', 'Katigorya [url=/forum/category.php?id=' . $category['id'] . ']"' . $category['name'] . '"[/url]');
        }
    }

    if (isset($_POST['position'])) { 
        $position = (int) $_POST['position'];
        if ($position != $category['position']) {
            $uzcms->log('Forum', 'Изменение позиции Katigorya [url=/forum/category.php?id=' . $category['id'] . ']"' . $category['name'] . '"[/url] с ' . $category['position'] . ' на ' . $position);

            $category['position'] = $position;
            mysql_query("UPDATE `forum_categories` SET `position` = '$category[position]' WHERE `id` = '$category[id]' LIMIT 1");
            $doc->msg(__('Katigorya tafsifi yuklatildi'));
            $uzcms->log('Forum', 'Katigorya [url=/forum/category.php?id=' . $category['id'] . ']"' . $category['name'] . '"[/url] на ' . $position);
        }
    }

    if (isset($_POST['group_show'])) { 
        $group_show = (int) $_POST['group_show'];
        if (isset($groups[$group_show]) && $group_show != $category['group_show']) {
            $category['group_show'] = $group_show;
            mysql_query("UPDATE `forum_categories` SET `group_show` = '$category[group_show]' WHERE `id` = '$category[id]' LIMIT 1");
            $doc->msg(__('Endi "%s" mansabdorlar uchun faol', groups::name($group_show)));
            $uzcms->log('Forum', 'mansabha [url=/forum/category.php?id=' . $category['id'] . ']"' . $category['name'] . '"[/url] для группы ' . groups::name($group_show));
        }
    }

    if (isset($_POST['group_write'])) { 
        $group_write = (int) $_POST['group_write'];
        if (isset($groups[$group_write]) && $group_write != $category['group_write']) {
            if ($category['group_show'] > $group_write)
                $doc->err(__('xatolik "%s" mansab ko`rsatkichiga emas', groups::name($group_write)));
            else {
                $category['group_write'] = $group_write;
                mysql_query("UPDATE `forum_categories` SET `group_write` = '$category[group_write]' WHERE `id` = '$category[id]' LIMIT 1");
                $doc->msg(__('endi "%s" shu mansablar uchun', groups::name($group_write)));
                $uzcms->log('Forum', 'mansab qabul qilindi [url=/forum/category.php?id=' . $category['id'] . ']"' . $category['name'] . '"[/url] для группы ' . groups::name($group_write));
            }
        }
    }

    if (isset($_POST['group_edit'])) { 
        $group_edit = (int) $_POST['group_edit'];
        if (isset($groups[$group_edit]) && $group_edit != $category['group_edit']) {
            if ($category['group_write'] > $group_edit)
                $doc->err(__('shu "%s" masabdorlar o`zgartirish mumkin', groups::name($group_edit)));
            else {
                $category['group_edit'] = $group_edit;
                mysql_query("UPDATE `forum_categories` SET `group_edit` = '$category[group_edit]' WHERE `id` = '$category[id]' LIMIT 1");
                $doc->msg(__('Shu "%s" masabdorlar o`zgartirish mumkin', groups::name($group_edit)));
                $uzcms->log('Forum', 'masabdorlar o`zgartirish mumkin [url=/forum/category.php?id=' . $category['id'] . ']"' . $category['name'] . '"[/url] для группы ' . groups::name($group_write));
            }
        }
    }
}

$doc->title = __('Katigorya "%s" o`zgartirish', $category['name']); 

$form = new form("?id=$category[id]&amp;" . passgen() . (isset($_GET['return']) ? '&amp;return=' . urlencode($_GET['return']) : null));
$form->text('name', __('Nomi'), $category['name']);
$form->textarea('description', __('Tafsif'), $category['description']);
$form->text('position', __('Tafsif'), $category['position']);

$options = array();
foreach ($groups as $type => $value)
    $options[] = array($type, $value['name'], $type == $category['group_show']);
$form->select('group_show', __('Bo`limni ko`rish'), $options);

$options = array();
foreach ($groups as $type => $value)
    $options[] = array($type, $value['name'], $type == $category['group_write']);
$form->select('group_write', __('Bo`limni yaratish'), $options);

$options = array();
foreach ($groups as $type => $value)
    $options[] = array($type, $value['name'], $type == $category['group_edit']);
$form->select('group_edit', __('Sozlamalarni o`zgartirish'), $options);


$form->button(__('Saqlash'), 'save');
$form->display();

$doc->grp(__('Katigoryani tozalash'), 'category.clear.php?id=' . $category['id']);
$doc->grp(__('Katigoryani o`chirish'), 'category.delete.php?id=' . $category['id']);

if (isset($_GET['return']))
    $doc->dost(__('Katigoryaga'), text::toValue($_GET['return']));
else
    $doc->dost(__('Katigoryaga'), 'category.php?id=' . $category['id']);

$doc->dost(__('Forum'), './');