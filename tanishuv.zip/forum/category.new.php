<?php

include_once '../sys/inc/yadro.php';
$doc = new document(5);
$doc->title = __('Yangi katigorya');

if (isset($_POST['name']) && isset($_POST['description']) && isset($_POST['position'])) {
    $name = text::for_name($_POST['name']);
    $description = text::input_text($_POST['description']);
    $position = (int) $_POST['position'];
    if (!$name) {
        $doc->err(__('Katigorya nomida xatolik'));
    } else {
        mysql_query("INSERT INTO `forum_categories` (`name`, `description`, `position`, `group_edit`)
 VALUES ('" . my_esc($name) . "', '" . my_esc($description) . "', '$position', '" . max($user->group, 5) . "')");

        $id_category = mysql_insert_id();
        $uzcms->log('Forum', 'Katigorya qo`shish "' . $name . '"');
        $doc->msg(__('Katigorya qo`shildi'));
        $doc->grp(__('Yana qo`shish'), '?' . passgen());
        $doc->dost(__('Katigoryaga'), 'category.php?id=' . $id_category);
        $doc->dost(__('Forum'), './');
        exit;
    }
}

$form = new form('?' . passgen() . (isset($_GET['return']) ? '&amp;return=' . urlencode($_GET['return']) : null));
$form->text('name', __('Katigorya nomi'));
$form->textarea('description', __('Tafsif'));
$form->text('position', __('Raqami'), mysql_result(mysql_query("SELECT MAX(`position`) FROM `forum_categories`"), 0) + 1);
$form->button(__('Yaratish'));
$form->display();

$doc->dost(__('Forumga qaytish'), './');
?>