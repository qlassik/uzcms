<?php

include_once '../sys/inc/yadro.php';
$doc = new document();
$doc->title = __('Yangi bo`lim');

if (!isset($_GET['id_category']) || !is_numeric($_GET['id_category'])) {
    if (isset($_GET['return']))
        header('Refresh: 1; url=' . $_GET['return']);
    else
        header('Refresh: 1; url=./?' . SID);
    $doc->err(__('Bu ID bo`ycha Katigorya'));
    exit;
}
$id_category = (int) $_GET['id_category'];

$q = mysql_query("SELECT * FROM `forum_categories` WHERE `id` = '$id_category' AND `group_write` <= '$user->group'");

if (!mysql_num_rows($q)) {
    if (isset($_GET['return']))
        header('Refresh: 1; url=' . $_GET['return']);
    else
        header('Refresh: 1; url=./?' . SID);
    $doc->err(__('Bu erda bo`lim yaratib bo`lmaydi'));
    exit;
}

$category = mysql_fetch_assoc($q);

if (isset($_POST['name'])) {
    $name = text::for_name($_POST['name']);
    $description = text::input_text($_POST['description']);
    if (!$name) {
        $doc->err(__('o`lim nomini kiritin'));
    } else {
        mysql_query("INSERT INTO `forum_topics` (`id_category`, `time_create`,`time_last`, `name`, `description`, `group_show`, `group_write`, `group_edit`)
 VALUES ('$category[id]', '" . TIME . "','" . TIME . "','" . my_esc($name) . "', '" . my_esc($description) . "', '$category[group_show]','" . max($category['group_show'], 1) . "','" . max($user->group, 4) . "')");

        $id_topic = mysql_insert_id();
        $doc->msg(__('bo`lim yaratildi'));

        $uzcms->log('Forum', 'yaratildi bo`limа [url=/forum/topic.php?id=' . $id_topic . ']' . $name . '[/url] в Katigorya [url=/forum/category.php?id=' . $category['id'] . ']' . $category['name'] . '[/url]');

        if (isset($_GET['return'])) {
            header('Refresh: 1; url=' . $_GET['return']);
            $doc->dost(__('Orqaga qaytish'), text::toValue($_GET['return']));
        } else {
            header('Refresh: 1; url=topic.php?id=' . $id_topic . '&' . SID);
            $doc->dost(__('Bo`limga'), 'topic.php?id=' . $id_topic);
        }

        exit;
    }
}

$doc->title = $category['name'] . ' - ' . __('Yangi bo`lim');

$form = new form("?id_category=$category[id]&amp;" . passgen() . (isset($_GET['return']) ? '&amp;return=' . urlencode($_GET['return']) : null));
$form->text('name', __('Bo`lim nomi'));
$form->textarea('description', __('Tafsif'));
$form->button(__('Bo`lim yaratish'));
$form->display();

if (isset($_GET['return']))
    $doc->dost(__('Katigoryaga'), text::toValue($_GET['return']));
else
    $doc->dost(__('Katigoryaga'), 'category.php?id=' . $category['id']);