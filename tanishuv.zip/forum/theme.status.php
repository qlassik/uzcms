<?php

include_once '../sys/inc/yadro.php';
$doc = new document(2);
$doc->title = __('Forum');

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Refresh: 1; url=./');
    $doc->err(__('Bu ID bo`ycha mavzu yo`q'));
    exit;
}
$id_theme = (int) $_GET['id'];
$q = mysql_query("SELECT `forum_themes`.* ,
        `forum_categories`.`name` AS `category_name` ,
        `forum_topics`.`name` AS `topic_name`,
        `forum_topics`.`group_write` AS `topic_group_write`
FROM `forum_themes`
LEFT JOIN `forum_categories` ON `forum_categories`.`id` = `forum_themes`.`id_category`
LEFT JOIN `forum_topics` ON `forum_topics`.`id` = `forum_themes`.`id_topic`
WHERE `forum_themes`.`id` = '$id_theme' AND `forum_themes`.`group_show` <= '$user->group' AND `forum_topics`.`group_show` <= '$user->group' AND `forum_categories`.`group_show` <= '$user->group'");
if (!mysql_num_rows($q)) {
    header('Refresh: 1; url=./');
    $doc->err(__('Mavzu joylashmagan'));
    exit;
}
$theme = mysql_fetch_assoc($q);


$doc->dost(__('Malumotiga'), 'theme.actions.php?id=' . $theme['id']);
$doc->dost(__('Orqaga qaytish Mavzuga'), 'theme.php?id=' . $theme['id']);
$doc->dost(empty($theme['topic_name']) ? __('Bo`limga') : $theme['topic_name'], 'topic.php?id=' . $theme['id_topic']);
$doc->dost(empty($theme['category_name']) ? __('Katigoryaga') : $theme['category_name'], 'category.php?id=' . $theme['id_category']);
$doc->dost(__('Forum'), './');

$group_write_open = $theme['topic_group_write'];
$group_write_close = $theme['topic_group_write'] + 1;

$is_open = $theme['group_write'] <= $group_write_open;

$doc->title = $is_open ? __('Bekitish %s', $theme['name']) : __('Ochish %s', $theme['name']);

if (!empty($_POST['open'])) {
    if ($is_open) {
        $doc->msg(__('Mavzu oldin ochilgan'));
    } else {
        $theme['group_write'] = $group_write_open;
        mysql_query("UPDATE `forum_themes` SET `group_write` = '$theme[group_write]' WHERE `id` = '$theme[id]' LIMIT 1");

        $message = __('%s открыл' . ($user->sex ? '' : 'а') . ' тему для обсуждения', '[user]' . $user->id . '[/user]');
        if ($reason = text::input_text($_POST['reason'])) {
            $message .= "\n" . __('Sabab: %s', $reason);
        }
        $uzcms->log('Forum', 'berkitildi [url=/theme.php?id=' . $theme['id'] . ']' . $theme['name'] . '[/url]' . ($reason ? "\nSababi: $reason" : ''));

        mysql_query("INSERT INTO `forum_messages` (`id_category`, `id_topic`, `id_theme`, `id_user`, `time`, `message`, `group_show`, `group_edit`)
 VALUES ('$theme[id_category]','$theme[id_topic]','$theme[id]','0','" . TIME . "','" . my_esc($message) . "','$theme[group_show]','$theme[group_edit]')");

        $doc->msg(__('Mavzu berkitildi'));
        exit;
    }
}


if (!empty($_POST['close'])) {
    if (!$is_open) {
        $doc->msg(__('Mavzu berkitilgan'));
    } else {
        $theme['group_write'] = $group_write_close;
        mysql_query("UPDATE `forum_themes` SET `group_write` = '$theme[group_write]' WHERE `id` = '$theme[id]' LIMIT 1");
        $message = __('%s закрыл' . ($user->sex ? '' : 'а') . ' тему для обсуждения', '[user]' . $user->id . '[/user]');
        if ($reason = text::input_text($_POST['reason'])) {
            $message .= "\n" . __('Sabab: %s', $reason);
        }
        $uzcms->log('Forum', 'ochish [url=/theme.php?id=' . $theme['id'] . ']' . $theme['name'] . '[/url]' . ($reason ? "\nПричина: $reason" : ''));
        mysql_query("INSERT INTO `forum_messages` (`id_category`, `id_topic`, `id_theme`, `id_user`, `time`, `message`, `group_show`, `group_edit`)
 VALUES ('$theme[id_category]','$theme[id_topic]','$theme[id]','0','" . TIME . "','" . my_esc($message) . "','$theme[group_show]','$theme[group_edit]')");
        $doc->msg(__('Mavzu berkitilgan'));
        exit;
    }
}

$form = new form("?id=$theme[id]&amp;" . passgen());
$form->textarea('reason', $is_open ? __('Sababsiz bekitish') : __('Sababsiz ochish'));
if ($is_open)
    $form->button(__('Berkitish'), 'close');
else
    $form->button(__('Ochish'), 'open');
$form->display();


?>
