<?php

include_once '../sys/inc/yadro.php';
$doc = new document(2);
$doc->title = __('O`chiriladigan mavzu');

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Refresh: 1; url=./');
    $doc->err(__('Bu ID bo`ycha mavzu yo`q'));
    exit;
}
$id_theme = (int)$_GET['id'];

$q = mysql_query("SELECT * FROM `forum_themes` WHERE `id` = '$id_theme' AND `group_edit` <= '$user->group'");

if (!mysql_num_rows($q)) {
    header('Refresh: 1; url=./');
    $doc->err(__('Mavzu joylashmagan'));
    exit;
}

$theme = mysql_fetch_assoc($q);

$q = mysql_query("SELECT * FROM `forum_topics` WHERE `id` = '$theme[id_topic]' LIMIT 1");

$topic = mysql_fetch_assoc($q);

$doc->title .= ' "' . $theme['name'] . '"';

if (isset($_POST['delete'])) {
    if (empty($_POST['captcha']) || empty($_POST['captcha_session']) || !captcha::check($_POST['captcha'], $_POST['captcha_session'])) {
        $doc->err(__('Raqam to`gri holatda kiritilmadi'));
    } else {
        mysql_query("DELETE FROM `forum_themes` WHERE `id` = '$theme[id]' LIMIT 1");

        mysql_query("DELETE
FROM `forum_messages`, `forum_history`
USING `forum_messages`
LEFT JOIN `forum_history` ON `forum_history`.`id_message` = `forum_messages`.`id`
WHERE `forum_messages`.`id_theme` = '$theme[id]'");
        mysql_query("DELETE FROM `forum_vote` WHERE `id_theme` = '$theme[id]'");
        mysql_query("DELETE FROM `forum_vote_votes` WHERE `id_theme` = '$theme[id]'");
        mysql_query("DELETE FROM `forum_views` WHERE `id_theme` = '$theme[id]'");
        $dir = new files(FILES . '/.forum/' . $theme['id']);
        $dir->delete();
        unset($dir);

        header('Refresh: 1; url=topic.php?id=' . $theme['id_topic']);
        $doc->msg(__('Mavzu o`chirildiа'));
        $uzcms->log('Forum', 'O`chiriladigan темы "' . $theme['name'] . '" из раздела [url=/forum/topic.php?id=' . $topic['id'] . ']' . $topic['name'] . '[/url]');
        exit;
    }
}

$form = new form("?id=$theme[id]&amp;" . passgen());
$form->captcha();
$form->bbcode('* ' . __('xammasi o`chirildi.'));
$form->button(__('O`chirish'), 'delete');
$form->display();

if (isset($_GET['return']))
    $doc->dost(__('Mavzuga'), text::toValue($_GET['return']));
else
    $doc->dost(__('Mavzuga'), 'theme.php?id=' . $theme['id']);

$doc->dost(__('Bo`limga'), 'topic.php?id=' . $theme['id_topic']);
$doc->dost(__('Katigoryaga'), 'category.php?id=' . $theme['id_category']);
$doc->dost(__('Forum'), './');