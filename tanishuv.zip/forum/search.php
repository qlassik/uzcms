<?php

include_once '../sys/inc/yadro.php';
$doc = new document();

$searched = & $_SESSION['search']['result'];
$searched_mark = & $_SESSION['search']['mark'];
$search_query = & $_SESSION['search']['query'];
$search_query_sql = & $_SESSION['search']['query_sql'];
$doc->title = __('Izlash');

if ($uzcms->forum_search_reg && !$user->group) {
    $doc->err(__('Faqat ro`yhatdan o`tkanlar izlay oladi'));
    $doc->dost(__('Katigoryaga'), './');
    exit;
}

if (!isset($_GET['cache']) || empty($searched)) {
    $searched = array();
    $search_query = null;
    $search_query_sql = array();
    $searched_mark = array();
}
if (!empty($_POST['query'])) {
    if ($uzcms->forum_search_captcha && (empty($_POST['captcha']) || empty($_POST['captcha_session']) || !captcha::check($_POST['captcha'], $_POST['captcha_session'])))
        $doc->err(__('qod с картинки введен неверно'));
    else {
        $stemmer = new stemmer();
        $searched = array();
        $search_query = text::input_text($_POST['query']);
        $search_query_sql = array();
        $searched_mark = array();
        $search_array = preg_split('#\s+#u', text::input_text($_POST['query']));
       $search_query = implode(' ', $search_array);
        for ($i = 0; $i < count($search_array); $i++) {
            $st = $stemmer->stem_word($search_array[$i]);
            if (text::strlen($st) < 3)
                continue;
            $searched_mark[$i] = '#([^\[].*)(' . preg_quote($st, '#') . '[a-zа-я0-9]*)([^\]].*)#ui';
            $search_query_sql[$i] = '+' . my_esc($st) . '*';
        }
        $q = mysql_query("SELECT `forum_themes`.`id`,`forum_themes`.`name`, `forum_messages`.`message`, `forum_messages`.`id` AS `id_message` FROM `forum_themes`
LEFT JOIN `forum_messages` ON `forum_themes`.`id` = `forum_messages`.`id_theme`
WHERE `forum_themes`.`group_show` <= '$user->group' AND  (`forum_messages`.`group_show` IS NULL OR `forum_messages`.`group_show` <= '$user->group')
AND MATCH (`forum_themes`.`name`,`forum_messages`.`message`) AGAINST ('" . implode(' ', $search_query_sql) . "' IN BOOLEAN MODE)
GROUP BY `forum_themes`.`id`");
        while ($result = mysql_fetch_assoc($q)) {
            $searched[] = $result;
        }
    }
}

$listing = new listing();
$pages = new pages;
$pages->posts = count($searched);
$end = min($pages->items_per_page * $pages->this_page, $pages->posts);
$start = $pages->my_start();
for ($i = $start; $i < $end; $i++) {
    $post = $listing->post();


    $theme = $searched[$i];
    $title = preg_replace($searched_mark, '\1<span class="UZCMS_mark">\2</span>\3', text::toValue($theme['name']));
    $post->content = text::toOutput(preg_replace($searched_mark, '\1[mark]\2[/mark]\3', $theme['message']));

    $post->title = $title;
    $post->url = 'theme.php?id=' . $theme['id'];


    if ($post->content) {
        $post->content .= "<br /><a href='message.php?id_message=$theme[id_message]&amp;return=" . urlencode('search.php?cache&page=' . $pages->this_page) . "'>К сообщению</a>";
    }
}

$listing->display($search_query ? __('siz izlagan "%s" malumot yo`q', $search_query) : false);

$pages->display('?cache&amp;'); 

$form = new form('?' . passgen());
$form->text('query', __('Nimani izlaymiz'), $search_query, $uzcms->forum_search_captcha);
if ($uzcms->forum_search_captcha)
    $form->captcha();
$form->button(__('Izlash'));
$form->display();

$doc->dost(__('Forum'), './');