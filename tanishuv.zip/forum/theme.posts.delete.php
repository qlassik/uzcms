<?php

include_once '../sys/inc/yadro.php';
$doc = new document();
$doc->title = __('Xabarni o`chirish');

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Refresh: 1; url=./');
    $doc->err(__('Bu ID bo`ycha mavzu yo`q'));
    exit;
}
$id_theme = (int)$_GET['id'];

$q = mysql_query("SELECT * FROM `forum_themes` WHERE `id` = '$id_theme' AND `group_edit` <= '$user->group'");

if (!mysql_num_rows($q)) {
    header('Refresh: 1; url=./');
    $doc->err(__('Mavzu joylashmagan'));
    exit;
}

$theme = mysql_fetch_assoc($q);

$doc->title .= ' - ' . $theme['name'];

switch (@$_GET['show']) {
    case 'all':
        $show = 'all';
        break;
    default:
        $show = 'part';
        break;
}

$delete_posts = array();

foreach ($_POST as $key => $value) {
    if ($value && preg_match('#^post([0-9]+)$#ui', $key, $n))
        $delete_posts[] = "`forum_messages`.`id` = '$n[1]'";
}

if ($delete_posts) {
    if (isset($_POST['delete'])) {
        foreach ($_POST as $key => $value) {
            if ($value && preg_match('#^post([0-9]+)$#ui', $key, $n)) {
                $dir = new files(FILES . '/.forum/' . $theme['id'] . '/' . $n[1]);
                $dir->delete();
                unset($dir);
            }
        }

        mysql_query("DELETE FROM `forum_messages`, `forum_history`
USING `forum_messages`
LEFT JOIN `forum_history`
ON `forum_messages`.`id` = `forum_history`.`id_message`
WHERE `forum_messages`.`id_theme` = '$theme[id]' AND (" . implode(' OR ', $delete_posts) . ")");

        $uzcms->log('Forum', 'Xabarni o`chirish из темы [url=/forum/theme.php?id=' . $theme['id'] . ']' . $theme['name'] . '[/url]');

        $doc->msg(__('%d xabar o`chirildi ', count($delete_posts)));
    }

    if (isset($_POST['hide'])) {
        mysql_query("UPDATE `forum_messages` SET `forum_messages`.`group_show` = '2' WHERE `forum_messages`.`id_theme` = '$theme[id]' AND (" . implode(' OR ', $delete_posts) . ") LIMIT " . count($delete_posts));

        $uzcms->log('Forum', 'Bekitilgan tema [url=/forum/theme.php?id=' . $theme['id'] . ']' . $theme['name'] . '[/url]');
        $doc->msg(__('%d xabar bekitildi', count($delete_posts)));
    }
}

$ord = array();
$ord[] = array("?id=$theme[id]&amp;show=all", __('Hammasi'), $show == 'all');
$ord[] = array("?id=$theme[id]&amp;show=part", __('Ko`rsatkichdan'), $show == 'part');
$or = new design();
$or->assign('order', $ord);
$or->display('design.order.tpl');

$listing = new listing();

if ($show == 'part') {
    $pages = new pages;
    $pages->posts = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum_messages` WHERE `id_theme` = '$theme[id]' AND `group_show` <= '$user->group'"), 0); // количество сообщений  теме
    $q = mysql_query("SELECT `id`, `id_user`, `message`, `time` FROM `forum_messages`  WHERE `id_theme` = '$theme[id]' AND `group_show` <= '$user->group' ORDER BY `id` ASC LIMIT " . $pages->limit);
} else
    $q = mysql_query("SELECT `id`, `id_user`, `message`, `time` FROM `forum_messages`  WHERE `id_theme` = '$theme[id]' AND `group_show` <= '$user->group' ORDER BY `id` ASC");

while ($messages = mysql_fetch_assoc($q)) {
    $ch = $listing->checkbox();

    $ank = new user((int)$messages['id_user']);

    $ch->title = $ank->nick;
    $ch->time = misc::when($messages['time']);
    $ch->name = 'post' . $messages['id'];
    $ch->content = text::for_opis($messages['message']);
}

$form = new form('?id=' . $theme['id']);
$form->html($listing->fetch(__('Xabarlar yo`q')));
$form->button(__('O`chirish'), 'delete', false);
$form->button(__('Bekitish'), 'hide', false);
$form->display();

if ($show == 'part')
    $pages->display('?id=' . $theme['id'] . '&amp;show=part&amp;');

$doc->dost(__('Mavzuga qaytish '), 'theme.php?id=' . $theme['id'] . ($show == 'part' ? '&amp;page=' . $pages->this_page : ''));

$doc->dost(__('Bo`limga'), 'topic.php?id=' . $theme['id_topic']);
$doc->dost(__('Katigoryaga'), 'category.php?id=' . $theme['id_category']);
$doc->dost(__('Forum'), './');
