<?php

include_once '../sys/inc/yadro.php';
$doc = new document();
$doc->title = __('Forum: ovoz qoyish');

if (!isset($_GET['id_theme']) || !is_numeric($_GET['id_theme'])) {
    if (isset($_GET['return']))
        header('Refresh: 1; url=' . $_GET['return']);
    else
        header('Refresh: 1; url=./');
    $doc->err(__('Bu ID bo`ycha mavzu yo`q'));
    exit;
}
$id_theme = (int)$_GET['id_theme'];

$q = mysql_query("SELECT * FROM `forum_themes` WHERE `id` = '$id_theme' AND `group_edit` <= '$user->group'");

if (!mysql_num_rows($q)) {
    if (isset($_GET['return']))
        header('Refresh: 1; url=' . $_GET['return']);
    else
        header('Refresh: 1; url=theme.php?id=' . $theme['id']);
    $doc->err(__('Mavzu joylashmagan'));
    exit;
}

$theme = mysql_fetch_assoc($q);

if (empty($theme['id_vote'])) {
    if (isset($_GET['return']))
        header('Refresh: 1; url=' . $_GET['return']);
    else
        header('Refresh: 1; url=theme.php?id=' . $theme['id']);
    $doc->err(__('Ovozlar yo`q'));
    exit;
}

$q = mysql_query("SELECT * FROM `forum_vote` WHERE `id` = '$theme[id_vote]'");

if (!mysql_num_rows($q)) {
    if (isset($_GET['return']))
        header('Refresh: 1; url=' . $_GET['return']);
    else
        header('Refresh: 1; url=theme.php?id=' . $theme['id']);
    $doc->err(__('Ovozlar yo`q'));
    exit;
}

$vote_a = mysql_fetch_assoc($q);

if (!empty($_POST['vote'])) {
    $vote = text::input_text($_POST['vote']);
    if (!$vote)
        $doc->err(__('javoblar yo`q'));
    else {
        $set = array();
        foreach ($_POST as $key => $value) {
            $vv = text::input_text($value);
            if ($vv && preg_match('#^v([0-9]+)$#', $key, $m)) {
                if ($m[1] > 0 || $m[1] <= 10)
                    $set[] = "`v$m[1]` = '" . my_esc($vv) . "'";
            }
        }
        $num = count($set);
        for ($i = 0; $i < (10 - $num); $i++)
            $set[] = "`v" . (10 - $i) . "` = null";

        if (count($set) < 2)
            $doc->err(__('Eng kami 2 ta javob qo`yilsin'));
        else {
            
            if (isset($_GET['return']))
                header('Refresh: 1; url=' . $_GET['return']);
            else
                header('Refresh: 1; url=theme.php?id=' . $theme['id']);

            if (!empty($_POST['finish'])) {
                mysql_query("UPDATE `forum_vote` SET `active` = '0' WHERE `id` = '$vote_a[id]' LIMIT 1");
                $uzcms->log('Forum', 'ovozlarni berkitish [url=/forum/theme.php?id=' . $theme['id'] . ']' . $theme['name'] . '[/url]');
                $doc->msg(__('Ovozlar tugatildi'));
            } elseif (!empty($_POST['clear'])) {
                mysql_query("UPDATE `forum_vote` SET `active` = '1' WHERE `id` = '$vote_a[id]' LIMIT 1");
                mysql_query("DELETE FROM `forum_vote_votes` WHERE `id_vote` = '$vote_a[id]'");
                $uzcms->log('Forum', 'Ovoz qoyish shakillandi [url=/forum/theme.php?id=' . $theme['id'] . ']' . $theme['name'] . '[/url]');
                $doc->msg(__('Ovoz to`liq'));
            } elseif (!empty($_POST['delete'])) {
                mysql_query("DELETE FROM `forum_vote`  WHERE `id` = '$vote_a[id]' LIMIT 1");
                mysql_query("DELETE FROM `forum_vote_votes` WHERE `id_vote` = '$vote_a[id]'");
                mysql_query("UPDATE `forum_themes` SET `id_vote` = null WHERE `id` = '$theme[id]' LIMIT 1");
                $uzcms->log('Forum', 'O`chiriladigan ovoz [url=/forum/theme.php?id=' . $theme['id'] . ']' . $theme['name'] . '[/url]');
                $doc->msg(__('Ovozlarni o`chirildi'));
            } else {
                $uzcms->log('Forum', 'Sozlamalarni o`zgartirish [url=/forum/theme.php?id=' . $theme['id'] . ']' . $theme['name'] . '[/url]');
                mysql_query("UPDATE `forum_vote` SET " . implode(', ', $set) . ", `name` = '" . my_esc($vote) . "' WHERE `id` = '$vote_a[id]' LIMIT 1");
                $doc->msg(__('Sozlama qabul qilindi'));
            }

            if (isset($_GET['return']))
                $doc->dost('Mavzuga', text::toValue($_GET['return']));
            else
                $doc->dost(__('Mavzuga'), 'theme.php?id=' . $theme['id']);
            exit;
        }
    }
}

$form = new form("?id_theme=$theme[id]&amp;" . passgen() . (isset($_GET['return']) ? '&amp;return=' . urlencode($_GET['return']) : null));
$form->textarea('vote', __('Savol'), $vote_a['name']);
for ($i = 1; $i <= 10; $i++)
    $form->text("v$i", __('Javob №') . $i, $vote_a['v' . $i]);
$form->checkbox('finish', __('Tugatush'));
$form->checkbox('clear', __('Boshlash'));
$form->checkbox('delete', __('Ochirish'));
$form->button(__('Saqlash'));
$form->display();

if (isset($_GET['return']))
    $doc->dost(__('Mavzuga'), text::toValue($_GET['return']));
else
    $doc->dost(__('Mavzuga'), 'theme.php?id=' . $theme['id']);