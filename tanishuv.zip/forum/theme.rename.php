<?php

include_once '../sys/inc/yadro.php';
$doc = new document(2);
$doc->title = __('Forum');

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Refresh: 1; url=./');
    $doc->err(__('Bu ID bo`ycha mavzu yo`q'));
    exit;
}
$id_theme = (int) $_GET['id'];
$q = mysql_query("SELECT `forum_themes`.* , `forum_categories`.`name` AS `category_name` , `forum_topics`.`name` AS `topic_name`
FROM `forum_themes`
LEFT JOIN `forum_categories` ON `forum_categories`.`id` = `forum_themes`.`id_category`
LEFT JOIN `forum_topics` ON `forum_topics`.`id` = `forum_themes`.`id_topic`
WHERE `forum_themes`.`id` = '$id_theme' AND `forum_themes`.`group_show` <= '$user->group' AND `forum_topics`.`group_show` <= '$user->group' AND `forum_categories`.`group_show` <= '$user->group'");
if (!mysql_num_rows($q)) {
    header('Refresh: 1; url=./');
    $doc->err(__('Mavzu joylashmagan'));
    exit;
}
$theme = mysql_fetch_assoc($q);

if (isset($_POST['save'])) {
    if (isset($_POST['name'])) {
        $name = text::for_name($_POST['name']);
        if ($name && $name != $theme['name']) {
            $uzcms->log('Forum', 'Изменение названия темы ' . $theme['name'] . ' на [url=/forum/theme.php?id=' . $theme['id'] . ']' . $name . '[/url]');

            $theme['name'] = $name;
            mysql_query("UPDATE `forum_themes` SET `name` = '" . my_esc($theme['name']) . "' WHERE `id` = '$theme[id]' LIMIT 1");
            $doc->msg(__('Название темы yuklatildi'));
        }
    }
}
$doc->title = __('Joyni o`zgartirish %s', $theme['name']);

$form = new form("?id=$theme[id]&amp;" . passgen());
$form->text('name', __('Nomi'), $theme['name']);
$form->button(__('Saqlash'), 'save');
$form->display();

$doc->dost(__('Malumotiga'), 'theme.actions.php?id=' . $theme['id']);
$doc->dost(__('Orqaga qaytish Mavzuga'), 'theme.php?id=' . $theme['id']);
$doc->dost(empty($theme['topic_name']) ? __('Bo`limga') : $theme['topic_name'], 'topic.php?id=' . $theme['id_topic']);
$doc->dost(empty($theme['category_name']) ? __('Katigoryaga') : $theme['category_name'], 'category.php?id=' . $theme['id_category']);
$doc->dost(__('Forum'), './');
?>
