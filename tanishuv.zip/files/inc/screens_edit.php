<?php

$doc->title = __('fayl %s - Skrishotы', $file->runame);

if (!empty($_FILES['file'])) {
    if ($_FILES['file']['error'])
        $doc->err(__('xatoboldi'));
    elseif (!$_FILES['file']['size'])
        $doc->err(__('fayldа ushlanish yo`q')); else {
        $info = pathinfo($_FILES['file']['name']);

        switch (strtolower($info['extension'])) {
            case 'jpg':
                $img_screen = @imagecreatefromjpeg($_FILES['file']['tmp_name']);
                break;
            case 'jpeg':
                $img_screen = @imagecreatefromjpeg($_FILES['file']['tmp_name']);
                break;
            case 'gif':
                $img_screen = @imagecreatefromgif($_FILES['file']['tmp_name']);
                break;
            case 'png':
                $img_screen = @imagecreatefrompng($_FILES['file']['tmp_name']);
                break;
            default:
                $doc->err(__('Holat yakullanmagan'));
                break;
        }

        if (!empty($img_screen)) {
            if ($file->screenAdd($img_screen)) {
                header('Refresh: 1; url=?order=' . $order . '&act=edit_screens&' . SID);
                $doc->ret('Orqaga qaytish', '?order=' . $order . '&amp;act=edit_screens');

                $doc->msg(__('Skrishot qo`shildi'));
                exit;
            } else
                $doc->err(__('Skrishot qo`shilmadi'));
        }
    }
}

if (isset($_GET['delete'])) {
    if ($file->screenDelete($_GET['delete'])) {
        header('Refresh: 1; url=?order=' . $order . '&act=edit_screens&' . SID);
        $doc->ret(__('Orqaga qaytish'), '?order=' . $order . '&amp;act=edit_screens');

        $doc->msg(__('Skrishot o`chirildi'));
        exit;
    } else
        $doc->err(__('Skrishot o`chirilgan yoki xatolik bor'));
}

$screens_count = $file->getScreensCount();

$listing = new listing();
for ($i = 0; $i < $screens_count; $i++) {
    $post = $listing->post();
    $post->image = $file->getScreen(48, $i);
    $post->title = __('Skrishot №%s', ($i + 1));
    $post->action('delete', '?order=' . $order . '&amp;act=edit_screens&amp;delete=' . $i);
}
$listing->display(__('Skrishotы yo`q'));

$form = new form('?order=' . $order . '&amp;act=edit_screens&amp;' . passgen());
$form->file('file', __('Skrishot qo`shish videoga rasim biriktrish rasim tanlaydi'));
$form->button(__('Qo`shish'));
$form->display();
$doc->ret(__('Faylga'), '?order=' . $order);
exit;
