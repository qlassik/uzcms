<?php

defined('UZCMS') or die();
$qoshe = $dir->dars_soat;
if ($access_write) {
if ($dir->toplam == 'img'){	
if (!empty($_FILES ['file'])) {
        if ($_FILES ['file'] ['error'])
            $doc->err(__('Yuklanishdsa xato mavjud'));
        elseif (!$_FILES ['file'] ['size'])
            $doc->err(__('Fayl ushalmadi'));
        elseif ($dir->is_file(text::for_filename($_FILES ['file'] ['name']))) {
            $doc->err(__('Bunday fayl bazada bor'));
        }else {
            if(!preg_match("/\.(gif|png|jpg|GIF|PNG|JPG)$/", $_FILES ['file'] ['name'])){
        $doc->err(__('Rasim farmatda emas'));
        }elseif ($files_ok = $dir->filesAdd(array($_FILES ['file'] ['tmp_name'] => $_FILES ['file'] ['name']))) {
                $files_ok [$_FILES ['file'] ['tmp_name']]->username = $user->ismi;
                $files_ok [$_FILES ['file'] ['tmp_name']]->userfam = $user->fam;
				$files_ok [$_FILES ['file'] ['tmp_name']]->id_user = $user->id;
				$files_ok [$_FILES ['file'] ['tmp_name']]->sayti = $dir->toplam;	
                $files_ok [$_FILES ['file'] ['tmp_name']]->group_edit = max($user->group, $dir->group_write, 2);
                $qoshe ++;
                $doc->msg(__('"%s" fayl qo`shildi', $_FILES ['file'] ['name']));
                if ($dir->group_write > 1)
                    $uzcms->log('fayl', 'Yuklandi [url="/files' . $files_ok [$_FILES ['file'] ['tmp_name']]->getPath() . '"]' . $_FILES ['file'] ['name'] . '[/url]');
				unset($files_ok);
            	header('Location: '.$_SESSION['qaytamiz']);
				exit;
            } else {
                $doc->err(__('fayil yuklanmadi'));
            }
			
        }
    }
}
if ($dir->toplam == 'mp3'){	
if (!empty($_FILES ['file'])) {
        if ($_FILES ['file'] ['error'])
            $doc->err(__('Yuklanishdsa xato mavjud'));
        elseif (!$_FILES ['file'] ['size'])
            $doc->err(__('Fayl ushalmadi'));
        elseif ($dir->is_file(text::for_filename($_FILES ['file'] ['name']))) {
            $doc->err(__('Bunday fayl bazada bor'));
        } else {
            if(!preg_match("/\.(mp3|waw)$/", $_FILES ['file'] ['name'])){
        $doc->err(__('Mp3 farmatda emas'));
        }elseif ($files_ok = $dir->filesAdd(array($_FILES ['file'] ['tmp_name'] => $_FILES ['file'] ['name']))) {
                $files_ok [$_FILES ['file'] ['tmp_name']]->username = $user->ismi;
                $files_ok [$_FILES ['file'] ['tmp_name']]->userfam = $user->fam;
				$files_ok [$_FILES ['file'] ['tmp_name']]->id_user = $user->id;
				$files_ok [$_FILES ['file'] ['tmp_name']]->sayti = $dir->toplam;	
				$files_ok [$_FILES ['file'] ['tmp_name']]->group_edit = max($user->group, $dir->group_write, 2);
                 $qoshe ++;
                $doc->msg(__('"%s" fayl qo`shildi', $_FILES ['file'] ['name']));
                if ($dir->group_write > 1)
                    $uzcms->log('fayl', 'Yuklandi [url="/files' . $files_ok [$_FILES ['file'] ['tmp_name']]->getPath() . '"]' . $_FILES ['file'] ['name'] . '[/url]');
					header('Location: '.$_SESSION['qaytamiz']);
				exit;
           
                unset($files_ok);
            } else {
                $doc->err(__('fayil yuklanmadi'));
            }
        }
    }
}


if ($dir->toplam == 'Fayillar'){	
if (!empty($_FILES ['file'])) {
        if ($_FILES ['file'] ['error'])
            $doc->err(__('Yuklanishdsa xato mavjud'));
        elseif (!$_FILES ['file'] ['size'])
            $doc->err(__('Fayl ushalmadi'));
        elseif ($dir->is_file(text::for_filename($_FILES ['file'] ['name']))) {
            $doc->err(__('Bunday fayl bazada bor'));
        } else {
            if(!preg_match("/\.(zip|apk|exe|rar|pdf|docx|doc|sql|ini|txt|css|js)$/", $_FILES ['file'] ['name'])){
        $doc->err(__('Mp3 farmatda emas'));
        }elseif ($files_ok = $dir->filesAdd(array($_FILES ['file'] ['tmp_name'] => $_FILES ['file'] ['name']))) {
                $files_ok [$_FILES ['file'] ['tmp_name']]->username = $user->ismi;
                $files_ok [$_FILES ['file'] ['tmp_name']]->userfam = $user->fam;
				$files_ok [$_FILES ['file'] ['tmp_name']]->id_user = $user->id;
				$files_ok [$_FILES ['file'] ['tmp_name']]->sayti = $dir->toplam;	
				$files_ok [$_FILES ['file'] ['tmp_name']]->group_edit = max($user->group, $dir->group_write, 2);
                 $qoshe ++;
                $doc->msg(__('"%s" fayl qo`shildi', $_FILES ['file'] ['name']));
                if ($dir->group_write > 1)
                    $uzcms->log('fayl', 'Yuklandi [url="/files' . $files_ok [$_FILES ['file'] ['tmp_name']]->getPath() . '"]' . $_FILES ['file'] ['name'] . '[/url]');
                unset($files_ok);
					header('Location: '.$_SESSION['qaytamiz']);
				exit;
           
            } else {
                $doc->err(__('fayil yuklanmadi'));
            }
        }
    }
}

if ($dir->toplam == 'video'){	
if (!empty($_FILES ['file'])) {
        if ($_FILES ['file'] ['error'])
            $doc->err(__('Yuklanishdsa xato mavjud'));
        elseif (!$_FILES ['file'] ['size'])
            $doc->err(__('Fayl ushalmadi'));
        elseif ($dir->is_file(text::for_filename($_FILES ['file'] ['name']))) {
              $doc->err(__('Bunday fayl bazada bor'));
        } else {
            if(!preg_match("/\.(mp4|ogv|webm)$/", $_FILES ['file'] ['name'])){
        $doc->err(__('Video farmatda emas'));
        }elseif ($files_ok = $dir->filesAdd(array($_FILES ['file'] ['tmp_name'] => $_FILES ['file'] ['name']))) {
                $files_ok [$_FILES ['file'] ['tmp_name']]->username = $user->ismi;
                $files_ok [$_FILES ['file'] ['tmp_name']]->userfam = $user->fam;
				$files_ok [$_FILES ['file'] ['tmp_name']]->id_user = $user->id;
				$files_ok [$_FILES ['file'] ['tmp_name']]->sayti = $dir->toplam;	
				$files_ok [$_FILES ['file'] ['tmp_name']]->group_edit = max($user->group, $dir->group_write, 2);
                 $qoshe ++;
                $doc->msg(__('"%s" fayl qo`shildi', $_FILES ['file'] ['name']));
                if ($dir->group_write > 1)
                    $uzcms->log('fayl', 'Yuklandi [url="/files' . $files_ok [$_FILES ['file'] ['tmp_name']]->getPath() . '"]' . $_FILES ['file'] ['name'] . '[/url]');
                unset($files_ok);
					header('Location: '.$_SESSION['qaytamiz']);
				exit;
            } else {
                $doc->err(__('fayil yuklanmadi'));
            }
	}
	}
        
    
}


}
if ($access_edit) {

    if ($dir->toplam == 'img'){	
if (!empty($_POST ['file_import'])) {
        if ($dir->is_file(text::for_filename($_POST ['file_import']))) {
            $doc->err(__('Bunday fayl bazada bor'));
        }else {
            if(!preg_match("/\.(gif|png|jpg|GIF|PNG|JPG)$/", $_FILES ['file'] ['name'])){
        $doc->err(__('Rasim farmatda emas'));
        }elseif (!empty($_POST ['file_import']) && !empty($_POST ['url'])) {
        if ($file = $dir->fileImport($_POST ['url'])) {
            $doc->msg(__('"%s" yuklanmadi', $file->runame));
            $file->id_user = $user->id;
            if ($dir->group_write > 1) {
                $uzcms->log('fayl', 'import qilindi [url="/files' . $file->getPath() . '"]' . $file->runame . '[/url]');
            }

            header('Refresh: 1; url=?act=file_import&' . passgen());

            $doc->ret(__('Faylga qaytish'), '/files' . $file->getPath() . '.htm');
            $doc->ret(__('Orqaga qaytish'), '?act=file_import&amp;' . passgen());
            exit();
        } elseif ($error = $dir->error) {
            $doc->err($error);
        } else {
            $doc->err(__('iloji bo`lmadi Inport qilishda'));
        }
            }
			
        }
    }
}
if ($dir->toplam == 'mp3'){	
	
	if (!empty($_POST ['file_import'])) {
        if ($dir->is_file(text::for_filename($_POST ['file_import']))) {
            $doc->err(__('Bunday fayl bazada bor'));
        }else {
            if(!preg_match("/\.(mp3|waw)$/", $_POST ['file_import'])){
        $doc->err(__('Rasim farmatda emas'));
        }elseif (!empty($_POST ['file_import']) && !empty($_POST ['url'])) {
        if ($file = $dir->fileImport($_POST ['url'])) {
            $doc->msg(__('"%s" yuklanmadi', $file->runame));
            $file->id_user = $user->id;
            if ($dir->group_write > 1) {
                $uzcms->log('fayl', 'import qilindi [url="/files' . $file->getPath() . '"]' . $file->runame . '[/url]');
            }

            header('Refresh: 1; url=?act=file_import&' . passgen());

            $doc->ret(__('Faylga qaytish'), '/files' . $file->getPath() . '.htm');
            $doc->ret(__('Orqaga qaytish'), '?act=file_import&amp;' . passgen());
            exit();
        } elseif ($error = $dir->error) {
            $doc->err($error);
        } else {
            $doc->err(__('iloji bo`lmadi Inport qilishda'));
        }
            }
			
        }
    }
}
if ($dir->toplam == 'Fayillar'){	
if (!empty($_POST ['file_import'])) {
        if ($dir->is_file(text::for_filename($_POST ['file_import']))) {
            $doc->err(__('Bunday fayl bazada bor'));
        }else {
            if(!preg_match("/\.(zip|apk|exe|rar|pdf|docx|doc|sql|ini|txt|css|js)$/", $_POST ['file_import'])){
        $doc->err(__('Rasim farmatda emas'));
        }elseif (!empty($_POST ['file_import']) && !empty($_POST ['url'])) {
        if ($file = $dir->fileImport($_POST ['url'])) {
            $doc->msg(__('"%s" yuklanmadi', $file->runame));
            $file->id_user = $user->id;
            if ($dir->group_write > 1) {
                $uzcms->log('fayl', 'import qilindi [url="/files' . $file->getPath() . '"]' . $file->runame . '[/url]');
            }

            header('Refresh: 1; url=?act=file_import&' . passgen());

            $doc->ret(__('Faylga qaytish'), '/files' . $file->getPath() . '.htm');
            $doc->ret(__('Orqaga qaytish'), '?act=file_import&amp;' . passgen());
            exit();
        } elseif ($error = $dir->error) {
            $doc->err($error);
        } else {
            $doc->err(__('iloji bo`lmadi Inport qilishda'));
        }
            }
			
        }
    }
}
if ($dir->toplam == 'video'){	
if (!empty($_POST ['file_import'])) {
        if ($dir->is_file(text::for_filename($_POST ['file_import']))) {
            $doc->err(__('Bunday fayl bazada bor'));
        }else {
            if(!preg_match("/\.(mp4|webm|ogv)$/", $_POST ['file_import'])){
        $doc->err(__('Rasim farmatda emas'));
        }elseif (!empty($_POST ['file_import']) && !empty($_POST ['url'])) {
        if ($file = $dir->fileImport($_POST ['url'])) {
            $doc->msg(__('"%s" yuklanmadi', $file->runame));
            $file->id_user = $user->id;
            if ($dir->group_write > 1) {
                $uzcms->log('fayl', 'import qilindi [url="/files' . $file->getPath() . '"]' . $file->runame . '[/url]');
            }

            header('Refresh: 1; url=?act=file_import&' . passgen());

            $doc->ret(__('Faylga qaytish'), '/files' . $file->getPath() . '.htm');
            $doc->ret(__('Orqaga qaytish'), '?act=file_import&amp;' . passgen());
            exit();
        } elseif ($error = $dir->error) {
            $doc->err($error);
        } else {
            $doc->err(__('iloji bo`lmadi Inport qilishda'));
        }
            }
			
        }
    }
}
 
  
    if (isset($_POST ['edit_path']) && !empty($_POST ['path_rel_new'])) {
        
        $root_dir = new files(FILES);
        $dirs = $root_dir->getPathesRecurse($dir);

        $path_rel_new = $_POST ['path_rel_new'];

        foreach ($dirs as $dir2) {
            if ($dir2->group_show > $user->group || $dir2->group_write > $user->group) {
                continue;
            }
           if ($dir2->path_rel == $dir->path_rel)
                continue;
            if ($dir2->getPath() == $path_rel_new) {
                $path_abs_new = $dir2->path_abs . '/' . $dir->name;
            }
        }

        if (!empty($path_abs_new)) {
            if ($dir->move($path_abs_new)) {
               $uzcms->log('fayl', 'Ko`chirish papka [url="/files' . $dir->getPath() . '"]' . $dir->runame . '[/url]');
                $qoshe --;
				$dir2->dars_soat = $dir2->dars_soat + 1;
                $doc->msg(__('Papka mufaqiyatli ko`chdi'));
                $doc->ret(__('Orqaga qaytish'), '/files' . $dir->getPath() . '?' . passgen());
                header('Refresh: 1; url=/files' . $dir->getPath() . '?' . passgen());
                exit();
            } else {
                $doc->err(__('Ko`chirish yakullanmadi'));
            }
        } else
            $doc->err(__('Bunday bo`lim yo`q'));
    }

    if (isset($_POST ['write_dir']) && isset($_POST ['name'])) {
        $runame = text::for_name($_POST ['name']);

        if (!$runame)
            $doc->err(__('Ismida simmollar bor'));
        elseif (!$new_dir = $dir->mkdir($runame))
            $doc->err(__('iloji bo`lmadi papka yaratish sewerda'));
        else {
            $new_dir->id_user = $user->id;
            $new_dir->ochmas = 1; 
			$uzcms->log('fayl', 'yaratilgan papka [url="/files' . $new_dir->getPath() . '"]' . $new_dir->runame . '[/url]');
            $doc->msg(__('"%s" papkasi yaratildi', $runame));
            $doc->ret(__('Orqaga qaytish'), '?act=write_dir');
            header('Refresh: 1; url=?act=write_dir');
            exit();
        }
    }

    if (isset($_POST ['edit_unlink']) && $rel_path && $dir->name{0} !== '.') {
        if (empty($_POST ['captcha']) || empty($_POST ['captcha_session']) || !captcha::check($_POST ['captcha'], $_POST ['captcha_session'])) {
            $design->err(__('Raqam to`gri holatda kiritilmadi'));
        } else {
            if ($dir->delete()) {
                $uzcms->log('fayl', 'O`chirib tashlash ' . $dir->runame . ' (' . $dir->getPath() . ')');
                 $qoshe --;
                $doc->msg(__('Papka o`chirildi'));
                $doc->ret(__('Orqaga qaytish'), '../?' . passgen());
                header('Refresh: 1; url=../?' . passgen());
                exit();
            } else {
                $doc->err(__('Papkani o`chirishda hatolik mavjud'));
            }
        }
    }

    if (isset($_POST ['edit_prop'])) {
        $groups = groups::load_ini(); 


        if ($rel_path && isset($_POST ['position'])) {
            $dir->position = (int)$_POST ['position'];
        }
        if (isset($_POST ['description'])) {
            $dir->description = text::input_text($_POST ['description']);
        }
        if (isset($_POST ['meta_description'])) {
            $dir->meta_description = text::input_text($_POST ['meta_description']);
        }
        if (isset($_POST ['meta_keywords'])) {
            $dir->meta_keywords = text::input_text($_POST ['meta_keywords']);
        }


        $order_keys = $dir->getKeys();
        if (!empty($_POST ['sort_default']) && isset($order_keys [$_POST ['sort_default']])) {
            $dir->sort_default = $_POST ['sort_default'];
        }


        if (!empty($_POST ['name'])) {
            $runame = text::for_name($_POST ['name']);
            $name = text::for_filename($runame);

            if ($runame != $dir->runame) {
                $oldname = $dir->runame;
                if (!$runame || !$name)
                    $doc->err(__('To`ri yozilmadi'));
                elseif (!$dir->rename($runame, $name))
                    $doc->err(__('iloji bo`lmadi papka ko`chirishda'));
                else {
                    $uzcms->log('fayl', 'papka ko`chdi ' . $oldname . ' в [url="/files' . $dir->getPath() . '"]' . $dir->runame . '[/url]');
                    $doc->msg(__('yangi papka nomi "%s"', $runame));
                }
            }
        }

        if (isset($_POST ['group_show'])) { 
            $group_show = (int)$_POST ['group_show'];
            if (isset($groups [$group_show]) && $group_show != $dir->group_show) {
                $dir->setGroupShowRecurse($group_show); 


                $uzcms->log('fayl', 'papka korish [url="/files' . $dir->getPath() . '"]' . $dir->runame . '[/url] mansabga ' . groups::name($group_show));

                $doc->msg(__('Papkani ko`rish mansabdor "%s" uchun', groups::name($group_show)));
            }
        }

        if (isset($_POST ['group_write'])) { 
            $group_write = (int)$_POST ['group_write'];
            if (isset($groups [$group_write]) && $group_write != $dir->group_write) {
                if ($dir->group_show > $group_write)
                    $doc->err(__('Yuklangan fayl "%s" qabul qilindi', groups::name($group_write)));
                else {
                    $dir->group_write = $group_write;

                    $uzcms->log('fayl', 'Fayl yuklanishi [url="/files' . $dir->getPath() . '"]' . $dir->runame . '[/url] mansabga ' . groups::name($group_write));

                    $doc->msg(__('Fayl yukladi "%s" mansabdor', groups::name($group_write)));
                }
            }
        }

        if (isset($_POST ['group_edit'])) { 
            $group_edit = (int)$_POST ['group_edit'];
            if (isset($groups [$group_edit]) && $group_edit != $dir->group_edit) {
                if ($dir->group_write > $group_edit)
                    $doc->err(__('Yuklangan fayl "%s" qabul qilindi', groups::name($group_write)));
                else {
                    $dir->group_edit = $group_edit;

                   $uzcms->log('fayl', 'Fayl yuklanishi [url="/files' . $dir->getPath() . '"]' . $dir->runame . '[/url] mansabga ' . groups::name($group_write));

                    $doc->msg(__('Sozlama bu "%s" mansabga', groups::name($group_edit)));
                }
            }
        }


        $doc->msg(__('Sozlama qabul qilindi'));
        $doc->ret(__('Orqaga qaytish'), '/files' . $dir->getPath() . '?' . passgen());
        header('Refresh: 2; url=/files' . $dir->getPath() . '?' . passgen());
        exit;
    }
}