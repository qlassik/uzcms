<?php

if (isset($_POST['edit_unlink']) && $file->name{0} !== '.') {
    $id_user = $file->id_user;
    $runame = $file->runame;
    if ($file->delete()) {
        if ($id_user && $id_user != $user->id && !empty($_POST['reason'])) {
            $reason = text::input_text(@$_POST['reason']);
            $ank = new user($id_user);
            $ank->mess("Sizning $runame fayliz o`chirildi.\nSabab: $reason.\nO`chirildi [user]$user->id[/user].");

            $uzcms->log('fayl', 'O`chiriladigan faylа ' . $runame . ' fodalanuvchiniki [user]' . $id_user . '[/user]. sabab: ' . $reason);
        } else
            $uzcms->log('fayl', 'O`chiriladigan faylа ' . $runame . ' fodalanuvchiniki [user]' . $id_user . '[/user]');

        $doc->msg(__('fayl o`chirildi'));
        $doc->ret(__('Orqaga qaytish'), './?' . passgen() . '&amp;order=' . $order);
        header('Refresh: 1; url=./?' . passgen() . '&order=' . $order);
        exit;
    } else {
        $doc->err(__('O`chirishda xato bo`ldi'));
    }
}

if (isset($_POST['edit_prop'])) {
    $groups = groups::load_ini(); 

    if (isset($_POST['description']))
        $file->description = text::input_text($_POST['description']);
    if (isset($_POST['description_small']))
        $file->description_small = text::input_text($_POST['description_small']);
    if (isset($_POST ['meta_description']))
        $file->meta_description = text::input_text($_POST ['meta_description']);
    if (isset($_POST ['meta_keywords']))
        $file->meta_keywords = text::input_text($_POST ['meta_keywords']);

    if (!empty($_POST['name'])) {
        $runame = text::for_name($_POST['name']);
        $name = basename(text::for_filename($runame), '.' . $file->ext);

        if ($file->ext) {
            $new_filename = $name . '.' . $file->ext;
        } else {
            $new_filename = $name;
        }

        if (!$access_write_dir)
            $new_filename = false;

        if ($runame != $file->runame) {
            if (!$runame || !$name)
                $doc->err(__('Holat shakillanmagan'));
            elseif (!$file->rename($runame, $new_filename))
                $doc->err(__('iloji bo`lmadi nomini o`zgartirishga'));
            else {

                $uzcms->log('fayl', 'nomi o`chirildi ' . $file->runame . ' dan ' . $runame);
                $doc->msg(__('yangi nomi faylа: "%s"', $runame));
                $doc->ret(__('Orqaga qaytish'), './' . $file->name . '.htm?order=' . $order);
                header('Refresh: 1; url=./' . $file->name . '.htm?order=' . $order);
                exit;
            }
        }
    }
    if ($file->group_edit <= $user->group) {
        if (isset($_POST['group_show'])) {
            $group_show = (int)$_POST['group_show'];
            if (isset($groups[$group_show]) && $group_show != $file->group_show) {
                $file->group_show = $group_show;
                $doc->msg(__('Fayl "%s" bu gurpalarga', groups::name($group_show)));
                $uzcms->log('fayl', 'ko`rish [url="/files' . $file->getPath() . '"]' . $file->runame . '[/url] ga ' . groups::name($group_show));
            }
        }

        if (isset($_POST['group_edit'])) { 
            $group_edit = (int)$_POST['group_edit'];
            if (isset($groups[$group_edit]) && $group_edit != $file->group_edit) {
                if ($file->group_show > $group_show)
                    $doc->err(__('O`zgartirish uchun "%s" chimod togri yo`nalmagan', groups::name($group_edit)));
                else {
                    $file->group_edit = $group_edit;
                    $doc->msg(__('Shu "%s" mb uchunansa', groups::name($group_edit)));
                    $uzcms->log('fayl', 'ИO`zgarish saqlandi faylа [url="/files' . $file->getPath() . '"]' . $file->runame . '[/url] dan ' . groups::name($group_edit));
                }
            }
        }
    }
}


if (isset($_POST ['edit_path']) && !empty($_POST ['path_rel_new'])) {

    $dir_new = new files(FILES . $_POST ['path_rel_new']);

    if (strpos($dir_new->path_abs, FILES) !== 0 || !file_exists($dir_new->path_abs)) {
        $doc->err(__('Xatolik'));
        exit;
    }


    $path_abs_new = $dir_new->path_abs;

    if (!empty($path_abs_new)) {
        if ($file->moveTo($path_abs_new)) {
            $uzcms->log('fayl', 'Ko`chirish faylа [url="/files' . $file->getPath() . '.htm"]' . $file->runame . '[/url]');

            $doc->msg(__('fayl ko`chdi'));
            $doc->ret(__('Orqaga qaytish'), '/files' . $file->getPath() . '.htm?' . passgen());
            header('Refresh: 1; url=/files' . $file->getPath() . '.htm?' . passgen());
            exit();
        } else {
            $doc->err(__('ko`chisda xatolik'));
        }
    } else {
        $doc->err(__('Xato'));
    }
}