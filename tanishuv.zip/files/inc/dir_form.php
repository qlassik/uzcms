<?php
defined('UZCMS') or die();
if ($access_write) {
    switch (@$_GET ['act']) {
        case 'file_upload' :
        {
            $smarty = new design ();
            $smarty->assign('method', 'post');
            $smarty->assign('files', 1);
            $smarty->assign('action', '?' . passgen());
            $elements = array();
            $elements [] = array('type' => 'file', 'title' => __('fayl'), 'br' => 1, 'info' => array('name' => 'file'));
            $elements [] = array('type' => 'submit', 'br' => 0, 'info' => array('value' => __('Yuklash')));
            $smarty->assign('el', $elements);
            $smarty->display('input.form.tpl');
        }
            break;
    }
if (!$dir->ochmas == '1'){
    $doc->kor(__('Fayl yuklash'), '?act=file_upload');
}
}
if ($access_edit) {
    switch (@$_GET ['act']) {
        case 'file_import' :
        {
            $smarty = new design ();
            $smarty->assign('method', 'post');
            $smarty->assign('action', '?' . passgen());
            $elements = array();
            $elements [] = array('type' => 'input_text', 'title' => __('URL'), 'br' => 1, 'info' => array('name' => 'url', 'value' => 'http://'));
            $elements [] = array('type' => 'submit', 'br' => 0, 'info' => array('name' => 'file_import', 'value' => __('Inport'))); // кнопка
            $smarty->assign('el', $elements);
            $smarty->display('input.form.tpl');
        }
            break;
        case 'write_dir' :
        {
            $smarty = new design ();
            $smarty->assign('method', 'post');
            $smarty->assign('action', '?' . passgen());
            $elements = array();
            $elements [] = array('type' => 'input_text', 'title' => __('Papka nomi') . ' *', 'br' => 1, 'info' => array('name' => 'name'));
            $elements [] = array('type' => 'text', 'value' => '* ' . __('Server aftomatiski translatsa qiladi'), 'br' => 1);
            $elements [] = array('type' => 'submit', 'br' => 0, 'info' => array('name' => 'write_dir', 'value' => __('Yaratish'))); // кнопка
            $smarty->assign('el', $elements);
            $smarty->display('input.form.tpl');
        }
            break;

        case 'edit_unlink' :
        {
            $smarty = new design ();
            $smarty->assign('method', 'post');
            $smarty->assign('action', '?' . passgen());
            $elements = array();
            $elements [] = array('type' => 'captcha', 'session' => captcha::gen(), 'br' => 1);
            $elements [] = array('type' => 'text', 'value' => '* ' . __('Siz ushbu papkani o`chiryapsiz qaytib tikkala olmaysiz'), 'br' => 1);
            $elements [] = array('type' => 'submit', 'br' => 0, 'info' => array('name' => 'edit_unlink', 'value' => __('O`chirish'))); 
            $smarty->assign('el', $elements);
            if ($rel_path)
                $smarty->display('input.form.tpl');
        }
            break;
        case 'edit_path' :
        {
            $smarty = new design ();
            $smarty->assign('method', 'post');
            $smarty->assign('action', '?' . passgen());
            $elements = array();

            $options = array();

             $root_dir = new files(FILES . '/.downloads');
            $dirs = $root_dir->getPathesRecurse($dir);
            foreach ($dirs as $dir2) {

                if ($dir2->group_show > $user->group || $dir2->group_write > $user->group) {
                    continue;
                }

                if ($dir2->path_rel == $dir->path_rel) {
                    $options [] = array($dir2->path_rel, $dir2->getPathRu(), true);
                } else {
                    $options [] = array($dir2->getPath(), text::toValue($dir2->getPathRu() . ' <- ' . $dir->runame));
                }
            }
$root_dir = new files(FILES . '/.obmen');
            $dirs = $root_dir->getPathesRecurse($dir);
            foreach ($dirs as $dir2) {

                if ($dir2->group_show > $user->group || $dir2->group_write > $user->group) {
                    continue;
                }

                if ($dir2->path_rel == $dir->path_rel) {
                    $options [] = array($dir2->path_rel, $dir2->getPathRu(), true);
                } else {
                    $options [] = array($dir2->getPath(), text::toValue($dir2->getPathRu() . ' <- ' . $dir->runame));
                }
            }


            $elements [] = array('type' => 'select', 'br' => 1, 'title' => __('Yangi joy'), 'info' => array('name' => 'path_rel_new', 'options' => $options));

            $elements [] = array('type' => 'submit', 'br' => 0, 'info' => array('name' => 'edit_path', 'value' => __('Saqlash'))); // кнопка
            $smarty->assign('el', $elements);
            $smarty->display('input.form.tpl');
        }
            break;
        case 'edit_prop' :
        {
            $groups = groups::load_ini(); 

            $form = new form('?' . passgen());
            $form->text('name', __('Papka nomi') . ' *', $dir->runame);
            $form->textarea('description', __('Tafsif'), $dir->description);

            if ($rel_path)
                $form->text('position', __('Tafsif') . ' **', $dir->position);

            $order_keys = $dir->getKeys();
            $options = array();
            foreach ($order_keys as $key => $key_name) {
                $options [] = array($key, $key_name, $key == $dir->sort_default);
            }
            $form->select('sort_default', __('Jamlash'), $options);

            $options = array();
            foreach ($groups as $type => $value) {
                $options [] = array($type, $value ['name'], $type == $dir->group_show);
            }
            $form->select('group_show', __('Papkani ko`rish') . ' ***', $options);

            $options = array();
            foreach ($groups as $type => $value) {
                $options [] = array($type, $value ['name'], $type == $dir->group_write);
            }
            $form->select('group_write', __('Fayl yuklash'), $options);

            $options = array();
            foreach ($groups as $type => $value) {
                $options [] = array($type, $value ['name'], $type == $dir->group_edit);
            }
            $form->select('group_edit', __('Sozlamalarni sozlash papkani'), $options);

            if ($rel_path && $dir->name{0} !== '.');
            else
            if ($rel_path)
            
            $form->textarea('meta_description', __('Tafsif') . ' [META]', $dir->meta_description);
            $form->textarea('meta_keywords', __('Kulich soz') . ' [META]', $dir->meta_keywords);

            $form->button(__('Saqlash'), 'edit_prop');
            $form->display();
        }
            break;
    }
if (!$dir->ochmas == '1'){
    $doc->kor(__('Inport fayl'), '?act=file_import');
} 
   $doc->kor(__('Papka yaratish'), '?order=' . $order . '&amp;act=write_dir');
  $doc->kor(__('Sozlama'), '?order=' . $order . '&amp;act=edit_prop');

    if ($rel_path && $dir->name{0} !== '.') {
        $doc->kor(__('Ko`chirish'), '?order=' . $order . '&amp;act=edit_path');
        $doc->kor(__('O`chirib tashlash'), '?order=' . $order . '&amp;act=edit_unlink');
    }
}