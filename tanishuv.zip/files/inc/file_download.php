<?php
defined('UZCMS') or die;

$pathinfo = pathinfo($abs_path);
$dir = new files($pathinfo['dirname']);

if ($dir->group_show > $user->group)$doc->access_denied(__('Sizda daraja yo`q yoki ro`yhatdan otib korin'));

$file = new files_file($pathinfo['dirname'], $pathinfo['basename']);
if ($file->group_show > $user->group)$doc->access_denied(__('Ro`yhatdan oting bu faylni ko`chirib olish uchun.'));
if ($file->kochir == 1){
$mag = $file->runame;
$q = mysql_query("SELECT * FROM `magazin_ol` WHERE `path_file_rell` = '$mag' ORDER BY `time` ");
while ($olgan = @mysql_fetch_assoc($q)) {	
if ($user->id == $olgan['id_user']){
$userga = $olgan['id_user'];
}else{
$userga = 'xkx';	
}

}

if ($user->id == $userga);else$doc->access_denied(__('Hakkerlik qilmang men Qodirov Elyorbek siz o`ylagan narsalarga javob topib bekitib bo`lganman'));
}
$doc->clean();
$f = new download($abs_path, $abs_path);
$downloaded = $f->output();

$file->downloads += round($file->size / $downloaded, 7);
exit;
?>
