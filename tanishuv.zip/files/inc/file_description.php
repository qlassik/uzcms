<?php

defined('UZCMS') or die;
$pathinfo = pathinfo($abs_path);
$dir = new files($pathinfo['dirname']);

if ($dir->group_show > $user->group) {
    $doc->access_denied(__('Sizda darajangiz etmaydi ko`rishka'));
}
$access_write_dir = $dir->group_write <= $user->group || ($dir->id_user && $user->id == $dir->id_user);

$order_keys = $dir->getKeys();
if (!empty($_GET['order']) && isset($order_keys[$_GET['order']]))
    $order = $_GET['order'];
else
    $order = 'runame:asc';

$file = new files_file($pathinfo['dirname'], $pathinfo['basename']);

if ($file->group_show > $user->group)
    $doc->access_denied(__('Sizda darajangiz etmaydi ko`rishka'));

$access_edit = $file->group_edit <= $user->group || ($file->id_user && $file->id_user == $user->id);

if ($access_edit && isset($_GET['act']) && $_GET['act'] == 'edit_screens')
    include 'inc/screens_edit.php';


$doc->title = __('%s - ni ko`chirib olish', $file->title);
$doc->description = $file->meta_description ? $file->meta_description : $dir->meta_description;
$doc->keywords = $file->meta_keywords ? explode(',', $file->meta_keywords) : ($dir->meta_keywords ? explode(',', $dir->meta_keywords) : '');
	?>
	<style>
	.voouz{
	width: 100%;
	height: 50px;
    margin: 2px auto;
    background: #EBEBEB;
    padding: 5px;
    border: 1px solid #DFDFDF;
    border-radius: 5px;
    }
	.voouzga{
	width: 50%;
	margin: 2px auto;
    background: #EBEBEB;
    padding: 5px;
    border: 1px solid #DFDFDF;
    border-radius: 5px;
    }	
	
	@media (max-width:500px) and (min-width:100px) {
	.wwwvoouz{
	width: 220px;
	height: 115px;
	margin: 2px auto;
	margin-top: -120px;
    padding: 5px;
    border: 1px solid #DFDFDF;
    border-radius: 5px;
    }	
    }
	@media (min-width:500px) and (max-width:2700px) {
	.wwwvoouz{
	width: 400px;
	height: 305px;
	margin: 2px auto;
    margin-top: -280px;
	padding: 5px;
    border: 1px solid #DFDFDF;
    border-radius: 5px;
    }	
    }
	</style>
	<?

if ($access_edit)
    include 'inc/file_act.php';

if ($user->group && $file->id_user != $user->id && isset($_kv['rating'])) {
    $my_rating = (int)$_kv['rating'];
    if (isset($file->ratings[$my_rating])) {
        $file->rating_my($my_rating);
        $doc->msg(__('Berilgan baxoyingiz qabul qilindi'));

        header('Refresh: 1; url=?order=' . $order . '&' . passgen() . SID);
        $doc->ret(__('Orqaga qaytish'), '?order=' . $order . '&amp;' . passgen());
        exit;
    } else {
        $doc->err(__('Bunday fayl yo`q'));
    }
}

if (empty($_GET['act'])) {
	
	
	
	   	  $gg= end(explode(".", ''.$file->getPath().''));

      if($gg == 'mp4' || $gg == '3gp' || $gg == 'flv'){
		  $SSSSH = '2';
	  }else{
		  $SSSSH = '1';
	  }
    $screens_count = $file->getScreensCount();
    $query_screen = (int)@$_GET['screen_num'];
    if ($screens_count) {
        if ($query_screen < 0 || $query_screen >= $screens_count)
            $query_screen = 0;
     if ($screen = $file->getScreen($doc->img_max_width(), $query_screen)) {

if($gg == 'mp3' || $gg == 'ogg' || $gg == 'wav' || $gg == 'mp4' || $gg == '3gp' || $gg == 'flv' || $gg == 'avi');else{
         echo'<div class="gmenu"><div class="tepabg"><img src="' . $screen . '" alt="' . __('Skrishot') . ' $query_screen"></div></div>';
}
	   }
	  
        if ($screens_count > 1) {
            $select = array();

            for ($i = 0; $i < $screens_count; $i++) {
                $select[] = array('?order=' . $order . '&amp;screen_num=' . $i, $i + 1, $query_screen == $i);
            }

            $show = new design();
            $show->assign('select', $select);
            $show->display('design.select_bar.tpl');
        }
    }else{
	if($gg == 'mp3' || $gg == 'ogg' || $gg == 'wav' || $gg == 'mp4' || $gg == '3gp' || $gg == 'flv' || $gg == 'avi');else{	
		 echo'<div class="gmenu"><div class="tepabg"><img src="/img/1.jpg" alt="' . __('Skrishot') . ' $query_screen"></div></div>';
     }
	 if($gg == 'mp4' || $gg == '3gp' || $gg == 'flv'){
	$screen = '/files/.fon/videoga.png';	 
	 }else{
	$screen = '/files/.fon/mp3ga.png';
	 }
	}


	

if($gg == 'mp4' || $gg == '3gp' || $gg == 'flv'){










?>
   
    <script src="/style/js/jquery.video.js"></script>
    <link rel="stylesheet" href="/style/css/jquery.video.css" />
    <style>
			@media (max-width:578px) and (min-width:100px) {
	       .cdubfkbd {
	    width: 350px;
		height: 210px;
      } 
			}
					@media (max-width:878px) and (min-width:578px) {
	       .cdubfkbd {
	    width: 500px;
		height: 300px;
      } 	  
					}
							@media (max-width:3278px) and (min-width:878px) {

	       .cdubfkbd {
	    width: 720px;
		height: 360px;
      } 
							}
    </style><center style="margin: 5px;">
    <script>
      $(function(){
        $('video').video();
      });
    </script>
    <video controls poster="<?=$screen?>" class="cdubfkbd">
	<source type="video/h264" src="/files/yuklanmalar/<?=$file->path_file_rel?>" data-flavorid="iPad" ></source>
	<source type="video/h264" src="/files/yuklanmalar/<?=$file->path_file_rel?>" data-flavorid="iPhone" ></source>
	<source type="video/webm" src="/files/yuklanmalar/<?=$file->path_file_rel?>" data-flavorid="webm" ></source>
	<source type="video/ogg" src="/files/yuklanmalar/<?=$file->path_file_rel?>" data-flavorid="ogg" ></source>
      <track kind="subtitles" srclang="de" src="/lang/sintel_de.srt"> 
      <track kind="subtitles" srclang="en" src="/lang/sintel_en.srt"> 
      <track kind="subtitles" srclang="es" src="/lang/sintel_es.srt"> 
      <track kind="subtitles" srclang="fr" src="/lang/sintel_fr.srt"> 
      <track kind="subtitles" srclang="it" src="/lang/sintel_it.srt"> 
      <track kind="subtitles" srclang="nl" src="/lang/sintel_nl.srt"> 
      <track kind="subtitles" srclang="pl" src="/lang/sintel_pl.srt"> 
      <track kind="subtitles" srclang="pt" src="/lang/sintel_pt.srt"> 
      <track kind="subtitles" srclang="ru" src="/lang/sintel_ru.srt"> 
    </video>  
	</center>
<div class="news"><?=$file->runame?></div>
			<? 
			echo '<div class="joy2">'.__('Davomiyligi').': '.$file->playtime_string.'</div>
			<div class="joy2">'.__('Hajmi').': '.misc::getDataCapacity($file->size).'</div>
			<div class="joy2">'.__('Ko`rildi').': '.$file->ozi_xaqida.' '.__('marta').'</div>';
			
 }
if($gg == 'mp3' || $gg == 'ogg' || $gg == 'wav'){
    ?> 
<script src="/style/js/jquery.min.js" type="text/javascript"></script>
<link rel='stylesheet' type="text/css" href="/style/css/audioplayer.css"/>
<script src="/style/js/audioplayer.js" type="text/javascript"></script>
			<script>
    jQuery(document).ready(function ($) {
        

        var lab = '';

        var val = 0;
        var use_spectrum = 'off';

        var design_color_bg = '444444';

         lab = 'spectrum';
        if(get_query_arg(window.location.href, lab)=='on'){
            use_spectrum = 'on';
             $('a[title="waveform"]').removeClass('active');
            $('a[title="with dynamic spectrum"]').addClass('active');
        }

        lab = 'skinwave_layout_demo';
        val = 'demo1';
        if(get_query_arg(window.location.href, lab)){

            val = (get_query_arg(window.location.href, lab));




            $('*[data-label*="'+lab+'"]').each(function(){
                var _t = $(this);
 
                if(_t.attr('data-value')==val){
                    _t.parent().parent().find('.active').removeClass('active');
                    _t.addClass('active');
                }
            })
        }
         var val_demo = val;

        var _c = $('#ap1');
        if(val=='demo1'){

                 $('.preview-css').append('body .extra-html { color: #444444; opacity:0.5; } .audioplayer.skin-wave{ margin-bottom: 55px!important; } .mcon-maindemo { background-color: #fff!important; }')
            $('.overlay-comments').css('top', '30px')
        }



        if(val=='demo2'){

          _c.attr('data-thumb','/img/1.jpg');


            _c.removeClass('alternate-layout');
            _c.removeClass('button-aspect-noir');
            $('.preview-css').append('body .extra-html { color: #444444; opacity:0.5; } .audioplayer.skin-wave{ margin-bottom: 55px!important; } .mcon-maindemo { background-color: #e0c0c0!important; } .extra-html { margin-top: 20px; }  .extra-html .float-left{ padding-left: 150px; }')
            $('.overlay-comments').css('top', '30px')
        }

        var val_skinwave_mode = 'default';
        if(val=='demo3'){

            design_color_bg = 'dddddd';
            val_skinwave_mode = 'small';
 

            _c.attr('data-thumb','/img/bg.jpg');
            _c.addClass('button-aspect-noir theme-light');
            _c.removeClass('button-aspect-noir--filled');
            $('.preview-css').append('body .extra-html { color: #444444; opacity:0.5; } .audioplayer.skin-wave{ margin-bottom: 55px!important; } .mcon-maindemo { background-color: #444!important; } .extra-html { margin-top: 20px; }  .extra-html .float-left{ }')
            $('.overlay-comments').css('top', '30px')
        }


        var str_rate = '<div class="float-left "> <span class=" btn-zoomsounds btn-like"><a href="/files/Mp3/"><span class="the-label hide-on-active"><?=__('Musiqalarimga');?></span></span></a> </div>';
        var str_rate2 = '<div class="counter-likes"><i class="fa fa-heart"></i><span class="the-number"><?=$file->kom?></span></div>';
        var str_views = '<div class="counter-hits"><i class="fa fa-play"></i><span class="the-number"><?=$file->ozi_xaqida?></span></div>';
        if(get_query_arg(window.location.href, 'rating')=='off'){
            str_rate = '';
            str_rate2 = '';

            $('.option-selecter-object[data-label*="rating-"]').each(function(){
                var _t = $(this);
				if(_t.attr('data-value')=='off'){
                    _t.parent().children().removeClass('active');
                    _t.addClass('active');
                }
            })
        }

        if(get_query_arg(window.location.href, 'disable_views')=='on'){
            str_views = '';
            $('input[name="disable_views"]').prop('checked', true);
        }

        var disable_scrub = 'default';

        if(get_query_arg(window.location.href, 'disable_scrub')=='on'){
            disable_scrub = 'on';
            $('input[name="disable_scrub"]').prop('checked', true);
        }


        var disable_volume = 'off';

 
        if(get_query_arg(window.location.href, 'disable_volume')=='on'){
            disable_volume = 'on';
            $('input[name="disable_volume"]').prop('checked', true);
        }

        var skinwave_mode = 'normal';
        var skinwave_wave_mode = 'canvas';

        lab = 'skinwave-mode'

        if(val_skinwave_mode!='default'){
            skinwave_mode = val_skinwave_mode;
        }
        if(get_query_arg(window.location.href,lab )){
            val = get_query_arg(window.location.href,lab );

//            console.info('val_skinwave_mode - ',val_skinwave_mode);
            if(val_skinwave_mode!='default'){
                val = val_skinwave_mode;
            }

            skinwave_mode = val;



            $('.option-selecter-object[data-label="'+lab+'"]').each(function(){
                var _t = $(this);
            if(_t.attr('data-value')==val){
                    _t.parent().children().removeClass('active');
                    _t.addClass('active');
                }
            })
        }
        if(skinwave_mode=='small'){
            _c.removeClass('alternate-layout');
        }

        var bar_len = 3;
        var bar_space = 1;

        lab= 'skinwave-number';
        if(get_query_arg(window.location.href, lab )){

            bar_len = parseInt(get_query_arg(window.location.href, lab), 10);

            if(bar_len == 900){
                bar_space = 0;
                bar_len = 1;
            }

            val = parseInt(get_query_arg(window.location.href, lab), 10);

            console.info(lab, ' - ',val, 'bar_len - ',bar_len);


            $('*[data-label="'+lab+'"]').each(function() {
                var _t = $(this);


                console.info(_t, val);
                _t.removeClass('active');
                if (_t.attr('data-value') == val){

                    _t.addClass('active');
                }
            })
        }

        lab= 'skinwave_wave_mode';
        if(get_query_arg(window.location.href,lab )){

            skinwave_wave_mode = (get_query_arg(window.location.href, lab));

            $('*[data-label="'+lab+'"]').each(function() {
                var _t = $(this);
                _t.removeClass('active');
                if (_t.attr('data-value') == skinwave_wave_mode){

                    _t.addClass('active');
                }
            })
        }



        var reflection_size = 0.25;
        if(get_query_arg(window.location.href, 'reflection_size')){

            reflection_size = parseFloat(get_query_arg(window.location.href, 'reflection_size'));



        }





        $('#preview-buttons-colors-field').bind('change', function(){
            var _t = $(this);

            var aux = '.audioplayer.skin-wave .btn-embed-code, body .audioplayer.skin-wave .volume_active, body .audioplayer.skin-wave .volume_active{ background-color: '+_t.val()+'; }';

            aux += 'body .audioplayer.skin-wave .meta-artist .the-artist{ color: '+_t.val()+'; } ';


            if(val_demo=='demo2'){

                aux += '.audioplayer.skin-wave .ap-controls .con-playpause .playbtn,.audioplayer.skin-wave .ap-controls .con-playpause .pausebtn{ background-color: '+_t.val()+'; } ';
            }

            $("#preview-buttons-colors").html(aux);


            if(document.getElementById("ap1") && document.getElementById("ap1").api_change_design_color_highlight){
                var val = String(_t.val()).replace('#','');
                document.getElementById("ap1").api_change_design_color_highlight(val);
            }


        })


        var settings_ap = {
            disable_volume: disable_volume
            ,disable_scrub: disable_scrub
            ,design_skin: 'skin-wave'
            ,skinwave_dynamicwaves:'on'
            ,skinwave_enableSpectrum:use_spectrum
            ,settings_backup_type:'full'
            ,settings_useflashplayer:'auto'
            ,skinwave_spectrummultiplier: '4'
            ,design_color_bg: design_color_bg
            ,skinwave_comments_enable:'on'
            ,skinwave_mode: skinwave_mode
            ,autoplay: 'on'
            ,embed_code:""
            ,settings_extrahtml:str_rate+str_views+str_rate2
            ,skinwave_wave_mode: skinwave_wave_mode
            ,skinwave_wave_mode_canvas_waves_number: bar_len
            ,skinwave_wave_mode_canvas_waves_padding: bar_space
            ,skinwave_wave_mode_canvas_reflection_size: reflection_size
            ,design_animateplaypause: "on"
        };
        dzsap_init('#ap1',settings_ap);
    });



    function get_query_arg(purl, key){
 

        if(purl.indexOf(key+'=')>-1){ 
            var regexS = "[?&]"+key + "=.+";
            var regex = new RegExp(regexS);
            var regtest = regex.exec(purl);

            if(regtest != null){
                var splitterS = regtest[0];
                if(splitterS.indexOf('&')>-1){
                    var aux = splitterS.split('&');
 
                    if(aux[0].indexOf('?')>-1){
                        splitterS = aux[0];
                    }else{
                        splitterS = aux[1];
                    }

 

                }
 
                var splitter = splitterS.split('=');
 
                return splitter[1];

            }
            
        }
    }



    function add_query_arg(purl, key,value){
        key = encodeURIComponent(key); value = encodeURIComponent(value);

        var s = purl;
        var pair = key+"="+value;

        var r = new RegExp("(&|\\?)"+key+"=[^\&]*");

        s = s.replace(r,"$1"+pair);
        if(s.indexOf(key + '=')>-1){


        }else{
            if(s.indexOf('?')>-1){
                s+='&'+pair;
            }else{
                s+='?'+pair;
            }
        }
        
        return s;
    }


</script>
	
        <div class="joy2">
               <div id="ap1" class="audioplayer-tobe alternate-layout is-preview button-aspect-noir button-aspect-noir--filled" style="width:100%; margin-top:40px; margin-bottom: 40px;" data-thumb="<?=$screen?>" data-thumb_link="/img/thumb.jpg" data-bgimage="/img/bg.jpg" data-scrubbg="/img/scrubbg.png" data-scrubprog="/img/scrubprog.png" data-type="normal" data-source="/files/yuklanmalar/<?=$file->path_file_rel?>" data-sourceogg="/files/yuklanmalar/<?=$file->path_file_rel?>">
                   
                        <div class="meta-artist"><span class="the-artist"><strong><a href="?act=artist&alt=jasurbek-jabborov-ft-dilnoza-akbarova" target="_blank"><?=$file->runame?></a></strong></span><span class="the-name"><?=$file->title?></span>
                        </div>
                    </div>
        </div>

	
			<div style="margin-top: -50px;" class="news"><?=$file->title?></div>
			<? 
			echo '<div class="joy2">'.__('Davomiyligi').': '.$file->playtime_string.'</div>
			<div class="joy2">'.__('Hajmi').': '.misc::getDataCapacity($file->size).'</div>
			<div class="joy2">'.__('Ko`rildi').': '.$file->ozi_xaqida.' '.__('marta').'</div>';
			?><script src="/style/js/bootstrap3_player.js"></script>

<style>.lives {
visibility: hidden;
display: none;
opacity: 0;
}</style>
<? }
	
	
    $listing = new listing();

    if ($description = $file->description) {
        $kv = $listing->kv();
        $kv->title = __('Tafsif');
        $kv->icon('info');
        $kv->content[] = $description;
    }
    $listing->display();
    echo '<table width="100%" border="0"  class="voouz">';
	echo '<tr><center>';
	echo '<th width="30%"><center>';	
	echo intval($file->downloads) . ' ' . __(misc::number($file->downloads, 'marta', 'marta', 'marta'));	
	echo '</center></th>';	
    echo '<th width="30%"><center>';	
    echo misc::getDataCapacity($file->size);	
	echo '</center></th>';	
	echo '<th width="30%"><center>';	
	echo $file->rating_name . ' (' . round($file->rating, 1) . '/' . $file->rating_count . ")";	
	echo '</center></th>';	
	echo '</tr>';	
	echo '</table>';
	$file->ozi_xaqida ++; 
/*
    if ($user->group && $file->id_user != $user->id) {
        $my_rating = $file->rating_my(); 
        $form = new design();
        $form->assign('method', 'kv');
        $form->assign('action', '?order=' . $order . '&amp;screen_num=' . $query_screen . '&amp;' . passgen());
        $elements = array();
        $options = array();
        foreach ($file->ratings AS $rating => $rating_name) {
            $options[] = array($rating, $rating_name, $rating == $my_rating);
        }
        $elements[] = array('type' => 'select', 'title' => __('Faylga baxo berish'), 'br' => 1, 'info' => array('name' => 'rating', 'options' => $options));
        $elements[] = array('type' => 'submit', 'br' => 0, 'info' => array('name' => 'save', 'value' => __('Baxo berish'))); 
        $form->assign('el', $elements);
        $form->display('input.form.tpl');
    }
*/
    $smarty = new design();
    $elements = array();

    $elements[] = array('type' => 'input_text', 'br' => 0, 'title' => __('Adresni ko`chirib olish'), 'info' => array('value' => 'http://' . $_SERVER['HTTP_HOST'] . '/files' . $file->getPath()));
    $smarty->assign('el', $elements);
    $smarty->display('input.form.tpl');

    $form = new form('/files' . $file->getPath());
    $form->hidden('rnd', passgen());
    $form->button(__('Yuklash %s', $file->title));
    $form->display();
}

$can_write = true;
if (!$user->is_writeable) {
    $doc->msg(__('Hozircha yoza olmaysiz'), 'write_denied');
    $can_write = false;
}

// комменты Faylga qaytish
if ($can_write && isset($_kv['send']) && isset($_kv['message']) && $user->group) {
    $message = (string)$_kv['message'];
    $users_in_message = text::nickSearch($message);
    $message = text::input_text($message);

    if ($file->id_user && $file->id_user != $user->id && (empty($_kv['captcha']) || empty($_kv['captcha_session']) || !captcha::check($_kv['captcha'], $_kv['captcha_session']))) {
        $doc->err(__('Raqam to`gri holatda kiritilmadi'));
    } elseif ($uzcms->censure && $user->ak == '2' && $mat = is_valid::mat($message)) {
        $doc->err(__('ZIT: %s', $mat));
    } elseif ($message) {
        $user->balls++;
        mysql_query("INSERT INTO `files_comments` (`id_file`, `id_user`, `time`, `text`) VALUES ('$file->id','$user->id', '" . TIME . "', '" . my_esc($message) . "')");
        $doc->msg(__('Sharh qoldirildi'));

        $id_message = mysql_insert_id();
        if ($users_in_message) {
            for ($i = 0; $i < count($users_in_message) && $i < 20; $i++) {
                $user_id_in_message = $users_in_message[$i];
                if ($user_id_in_message == $user->id || ($file->id_user && $file->id_user == $user_id_in_message)) {
                    continue;
                }
                $ank_in_message = new user($user_id_in_message);
                if ($ank_in_message->notice_mention) {
                    $ank_in_message->mess("[user]{$user->id}[/user] korildi" . ($user->sex ? '' : 'а') . " о Вас в Sharhlar Faylga qaytish [url=/files{$file->getPath()}.htm#comment{$id_message}]$file->runame[/url]");
                }
            }
        }

        $file->comments++;

        if ($file->id_user && $file->id_user != $user->id) { 
            $ank = new user($file->id_user);
            $ank->mess("[user]{$user->id}[/user] qoldirildi" . ($user->sex ? '' : 'а') . " Sizning fayilizga sharh qoldirdi [url=/files{$file->getPath()}.htm]$file->runame[/url]");
        }
    } else {
        $doc->err(__('Sharh bo`sh'));
    }
}

if (empty($_GET['act'])) {
    if ($can_write && $user->group) {
        $smarty = new design();
        $smarty->assign('method', 'kv');
        $smarty->assign('action', '?order=' . $order . '&amp;screen_num=' . $query_screen . '&amp;' . passgen());
        $elements = array();
        $elements[] = array('type' => 'textarea', 'title' => __('Sharh'), 'br' => 1, 'info' => array('name' => 'message'));

        if ($file->id_user && $file->id_user != $user->id)
            $elements[] = array('type' => 'captcha', 'session' => captcha::gen(), 'br' => 1);

        $elements[] = array('type' => 'submit', 'br' => 0, 'info' => array('name' => 'send', 'value' => __('Yuborish'))); 
        $smarty->assign('el', $elements);
        $smarty->display('input.form.tpl');
    }

    if (!empty($_GET['delete_comm']) && $user->group >= $file->group_edit) {
        $delete_comm = (int)$_GET['delete_comm'];
        if (mysql_result(mysql_query("SELECT COUNT(*) FROM `files_comments` WHERE `id` = '$delete_comm' AND `id_file` = '$file->id' LIMIT 1"), 0)) {
            mysql_query("DELETE FROM `files_comments` WHERE `id` = '$delete_comm' LIMIT 1");
            $file->comments--;
            $doc->msg(__('Sharh o`chirildi'));
        } else
            $doc->err(__('Sharh o`chirilgan'));
    }

    
    $listing = new listing();
    $pages = new pages(mysql_result(mysql_query("SELECT COUNT(*) FROM `files_comments` WHERE `id_file` = '$file->id'"), 0));
   
    $q = mysql_query("SELECT * FROM `files_comments` WHERE `id_file` = '$file->id' ORDER BY `id` DESC LIMIT ".$pages->limit);
    while ($comment = mysql_fetch_assoc($q)) {
        $ank = new user($comment['id_user']);

        $kv = $listing->kv();
        $kv->url = '/ID' . $ank->id;
        $kv->title = $ank->nick();
        $kv->time = misc::when($comment['time']);
        $kv->admine = text::toOutput($comment['text']);
        $kv->image = $ank->getAva($doc->img_max_width());

        if ($user->group >= $file->group_edit) {
            $kv->action('delete', '?order=' . $order . '&amp;screen_num=' . $query_screen . '&amp;delete_comm=' . $comment['id']);
        }
    }
    $listing->display(__('Sharhlar yo`q'));

    $pages->display('?order=' . $order . '&amp;screen_num=' . $query_screen . '&amp;'); 
}


$content = $dir->getList($order);
$files = & $content['files'];
$count = count($files);

if ($count > 1) {
    for ($i = 0; $i < $count; $i++) {
        if ($file->name == $files[$i]->name)
            $fileindex = $i;
    }

    if (isset($fileindex)) {
        $select = array();

        if ($fileindex >= 1) {
            $last_index = $fileindex - 1;
            $select[] = array('./' . urlencode($files[$last_index]->name) . '.htm?order=' . $order, text::toValue($files[$last_index]->runame));
        }

        $select[] = array('?order=' . $order, text::toValue($file->runame), true);

        if ($fileindex < $count - 1) {
            $next_index = $fileindex + 1;
            $select[] = array('./' . urlencode($files[$next_index]->name) . '.htm?order=' . $order, text::toValue($files[$next_index]->runame));
        }

        $show = new design();
        $show->assign('select', $select);
        $show->display('design.select_bar.tpl');
    }
}

$doc->ret($dir->runame, './?order=' . $order); 
$return = $dir->ret(5); 
for ($i = 0; $i < count($return); $i++) {
    $doc->ret($return[$i]['runame'], '/files' . $return[$i]['path']);
}

if ($access_edit)
    include 'inc/file_form.php';
exit;