<?php

include_once '../sys/inc/yadro.php';

$doc = new document();
$doc->title = __('Fayl');

$path = @$_GET['path'];
if (preg_match('#(.+)\.htm$#', $path, $m)) {
    $path = $m[1];
    $file_description = true;
}
$abs_path = realpath(FILES . '/' . $path);
if (strpos($abs_path, FILES) !== 0 || !file_exists($abs_path)) {
    header('Location: ../?' . SID);
    exit;
} 
$rel_path = str_replace(FILES, '', $abs_path);


if (!empty($file_description) && is_file($abs_path)) {
    include 'inc/file_description.php';
}

elseif (is_file($abs_path)) {
    include 'inc/file_download.php';
}


elseif (is_dir($abs_path)) {
    include 'inc/dir_listing.php';
}



?>
