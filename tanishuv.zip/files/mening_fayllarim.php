<?php
include_once '../sys/inc/yadro.php';
$doc = new document();
$ank = (empty($_GET ['id'])) ? $user : new user((int)$_GET ['id']);
$doc->title = ($user->id && $ank->id == $user->id)? __('Mening fayllarim') : __('(%s)chini fayllri', $ank->group_name);
$doc->description = __('Anketa "%s"', $ank->title);
$doc->keywords [] = $ank->title;








	if(isset($_GET['img'])){
	$pages = new pages(mysql_result(mysql_query("SELECT COUNT(*) FROM `files_cache` WHERE `id_user` = '$ank->id' AND `berk` = 'img'"), 0));
$listing = new listing();
$q = mysql_query("SELECT * FROM `files_cache` WHERE `id_user` = '$ank->id' AND `berk` = 'img' ORDER BY `time_add` DESC LIMIT ".$pages->limit);
while ($files = mysql_fetch_assoc($q)) {
    $img = $listing->img();
	$img->title = text::toValue($files['runam']).'<br /><span style="color: red;">'.text::toOutput($files['runame']).'</span>';
    $img->time = misc::when($files['time_add']);
    $img->url = "/files" . $files['path_file_rel'] . ".htm";
	if(!preg_match("/\.(gif|png|jpg|GIF|PNG|JPG)$/", $files['path_file_rel'])){
    $img->image = "/files" . $files['path_file_rel'];
	}else{
	$img->image = '/files/.fon/videoga.png';
	}
 }

$listing->display(__('Ro`yhat bo`sh'));
$pages->this_page();
$pages->display('?img&');	
$doc->grp(__('Qaytish'), '/files/mening_fayllarim.php?id='.$ank->id.'');		
$doc->grp(__('Yuklamalar'), '/files');
$doc->dost(__('Sozlash'), '?sozlash');
exit;
    }
    		if(isset($_GET['mp3'])){
	$pages = new pages(mysql_result(mysql_query("SELECT COUNT(*) FROM `files_cache` WHERE `id_user` = '$ank->id' AND `berk` = 'mp3'"), 0));
$listing = new listing();
$q = mysql_query("SELECT * FROM `files_cache` WHERE `id_user` = '$ank->id' AND `berk` = 'mp3' ORDER BY `time_add` DESC LIMIT ".$pages->limit);
while ($files = mysql_fetch_assoc($q)) {
    $mp3 = $listing->mp3();
	$mp3->title = text::toValue($files['runam']).'<br /><span style="color: red;">'.text::toOutput($files['runame']).'</span>';
    $mp3->time = misc::when($files['time_add']);
    $mp3->url = "/files" . $files['path_file_rel'] . ".htm";
	
 }

$listing->display(__('Ro`yhat bo`sh'));
$pages->this_page();
$pages->display('?mp3&');	
		
$doc->grp(__('Qaytish'), '/files/mening_fayllarim.php?id='.$ank->id.'');		
$doc->grp(__('Yuklamalar'), '/files');
$doc->dost(__('Sozlash'), '?sozlash');
exit;
    }
	if(isset($_GET['video'])){
	$pages = new pages(mysql_result(mysql_query("SELECT COUNT(*) FROM `files_cache` WHERE `id_user` = '$ank->id' AND `berk` = 'video'"), 0));
$listing = new listing();
$q = mysql_query("SELECT * FROM `files_cache` WHERE `id_user` = '$ank->id' AND `berk` = 'video' ORDER BY `time_add` DESC LIMIT ".$pages->limit);
while ($files = mysql_fetch_assoc($q)) {
    $video = $listing->video();
	$video->title = text::toValue($files['runam']).'<br /><span style="color: red;">'.text::toOutput($files['runame']).'</span>';
    $video->time = misc::when($files['time_add']);
    $video->url = "/files" . $files['path_file_rel'] . ".htm";
	$video->image = '/files/.fon/videoga.png';
	
 }

$listing->display(__('Ro`yhat bo`sh'));
$pages->this_page();
$pages->display('?video&');	
		
		
$doc->grp(__('Qaytish'), '/files/mening_fayllarim.php?id='.$ank->id.'');		
 $doc->grp(__('Yuklamalar'), '/files');
$doc->dost(__('Sozlash'), '?sozlash');
exit;
    }
    	if(isset($_GET['Fayillar'])){
	$pages = new pages(mysql_result(mysql_query("SELECT COUNT(*) FROM `files_cache` WHERE `id_user` = '$ank->id' AND `berk` = 'Fayillar'"), 0));
$listing = new listing();
$q = mysql_query("SELECT * FROM `files_cache` WHERE `id_user` = '$ank->id' AND `berk` = 'Fayillar' ORDER BY `time_add` DESC LIMIT ".$pages->limit);
while ($files = mysql_fetch_assoc($q)) {
    $filega = $listing->filega();
	$filega->title = text::toValue($files['runam']).'<br /><span style="color: red;">'.text::toOutput($files['runame']).'</span>';
    $filega->time = misc::when($files['time_add']);
    $filega->url = "/files" . $files['path_file_rel'] . ".htm";
	$filega->image = '/files/.fon/filega.png';
	
 }

$listing->display(__('Ro`yhat bo`sh'));
$pages->this_page();
$pages->display('?Fayillar&');	
		
$doc->grp(__('Qaytish'), '/files/mening_fayllarim.php?id='.$ank->id.'');		
$doc->grp(__('Yuklamalar'), '/files');
$doc->dost(__('Sozlash'), '?sozlash');
exit;
    }
	

$listing = new listing();
$post = $listing->post();
$post->title = __('Rasimlar');
$post->url = '?id='.$ank->id.'&img';
$post->hightlight = mysql_result(mysql_query("SELECT COUNT(*) FROM `files_rating` WHERE `id_user` = '".$ank->id."' AND `berk` = 'img'"), 0);
$post = $listing->post();
$post->title = __('Mp3lar');
$post->url = '?id='.$ank->id.'&mp3';
$post->hightlight = mysql_result(mysql_query("SELECT COUNT(*) FROM `files_rating` WHERE `id_user` = '".$ank->id."' AND `berk` = 'mp3'"), 0);
$post = $listing->post();
$post->title = __('Videolar');
$post->url = '?id='.$ank->id.'&video';
$post->hightlight = mysql_result(mysql_query("SELECT COUNT(*) FROM `files_rating` WHERE `id_user` = '".$ank->id."' AND `berk` = 'video'"), 0);
$post = $listing->post();
$post->title = __('Pragramma va o`yinlar');
$post->url = '?id='.$ank->id.'&Fayillar';
$post->hightlight = mysql_result(mysql_query("SELECT COUNT(*) FROM `files_rating` WHERE `id_user` = '".$ank->id."' AND `berk` = 'Fayillar'"), 0);
$listing->display();
$doc->grp(__('Yuklamalar'), '/files');
$doc->dost(__('Sozlash'), '?sozlash');
?>