<?php

include_once '../sys/inc/yadro.php';

$doc = new document();
$doc->title = __('Yangi fayillar');

$abs_path = realpath(FILES . '/' . @$_GET['dir']);

if (strpos($abs_path, FILES) !== 0 || !file_exists($abs_path)) {
    header('Location: ../?' . SID);
    exit;
}

$dir = new files($abs_path);

if ($dir->group_show > $user->group) {
    $doc->access_denied(__('У Вас нет прав для просмотра новых faylов в данной папке'));
}

$doc->title = __('%s - Новые fayl', $dir->runame);

$content = $dir->getNewFiles();

$files = &$content['files'];

$listing = new listing();
$pages = new pages;
$pages->posts = count($files);
$pages->this_page();

$start = $pages->my_start();
$end = $pages->end();
for ($i = $start; $i < $end && $i < $pages->posts; $i++) {
    $ank = new user($files[$i]->id_user);

    $post = $listing->post();
    $post->title = text::toValue($files[$i]->runame);
    $post->url = "/files" . $files[$i]->getPath() . ".htm";
    $post->image = $files[$i]->image();
    $post->icon($files[$i]->icon());
    $post1 = __('Qo`shilgan vaqti') . ': ' . misc::when($files[$i]->time_add) . ($ank->id ? ' (' . $ank->nick . ')' : '') . "<br />\n";


    $post2 = '';
    if ($properties = $files[$i]->properties)
        ; 
    $post2 .= $properties . "\n";

    if ($description = $files[$i]->description_small)
        $post2 .= $description . "\n";

    $post->post = $post1 . text::toOutput($post2);
}

$listing->display(__('Oxirgi kun qo`shilgan fayl'));
$pages->display('?dir=' . $dir->path_rel . '&amp;'); 
?>